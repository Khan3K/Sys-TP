<?php

define('PROJECT_ROOT', dirname(__DIR__));
// Prevent index.php from booting the full framework
$_SERVER['REQUEST_METHOD'] = 'CLI';
$_SERVER['REQUEST_URI'] = '/phpunit';
$_SERVER['HTTP_HOST'] = 'localhost';

spl_autoload_register(function ($class) {
    $prefixes = [
        'Core\\' => '/src/Core/',
        'Controllers\\' => '/src/Controllers/',
        'Quality\\Checks\\' => '/src/Quality/Checks/',
        'Quality\\' => '/src/Quality/',
        'Helpers\\' => '/src/Helpers/',
        'Services\\' => '/src/Services/',
    ];
    foreach ($prefixes as $prefix => $dir) {
        if (strncmp($class, $prefix, strlen($prefix)) === 0) {
            $file = PROJECT_ROOT . $dir . substr($class, strlen($prefix)) . '.php';
            if (file_exists($file)) { require $file; return; }
        }
    }
});
