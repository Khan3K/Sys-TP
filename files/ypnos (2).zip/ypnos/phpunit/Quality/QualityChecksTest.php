<?php

namespace Quality\Checks;

use PHPUnit\Framework\TestCase;

class QualityChecksTest extends TestCase
{
    public function testAttentionCheckNoQuestions(): void
    {
        $check = new AttentionCheck();
        $result = $check->run(['questions' => [], 'answers' => []]);
        $this->assertTrue($result['passed']);
        $this->assertEquals(100, $result['score']);
    }

    public function testAttentionCheckCorrect(): void
    {
        $check = new AttentionCheck();
        $questions = [
            ['id' => 1, 'is_attention_check' => true, 'expected_answer' => '5'],
        ];
        $answers = [
            ['question_id' => 1, 'answer_value' => '5'],
        ];
        $result = $check->run(['questions' => $questions, 'answers' => $answers]);
        $this->assertTrue($result['passed']);
    }

    public function testAttentionCheckIncorrect(): void
    {
        $check = new AttentionCheck();
        $questions = [
            ['id' => 1, 'is_attention_check' => true, 'expected_answer' => '5'],
        ];
        $answers = [
            ['question_id' => 1, 'answer_value' => '3'],
        ];
        $result = $check->run(['questions' => $questions, 'answers' => $answers]);
        $this->assertFalse($result['passed']);
        $this->assertLessThan(100, $result['score']);
    }

    public function testTimeCheckNoData(): void
    {
        $check = new TimeCheck();
        $result = $check->run([
            'response' => ['time_spent_seconds' => 0],
            'questions' => [],
        ]);
        $this->assertTrue($result['passed']);
        $this->assertEquals(100, $result['score']);
    }

    public function testTimeCheckTooFast(): void
    {
        $check = new TimeCheck();
        $questions = array_fill(0, 10, ['id' => 1]);
        $result = $check->run([
            'response' => ['time_spent_seconds' => 15],
            'questions' => $questions,
        ]);
        $this->assertFalse($result['passed']);
        $this->assertLessThan(100, $result['score']);
    }

    public function testTimeCheckReasonable(): void
    {
        $check = new TimeCheck();
        $questions = array_fill(0, 10, ['id' => 1]);
        $result = $check->run([
            'response' => ['time_spent_seconds' => 300],
            'questions' => $questions,
        ]);
        $this->assertTrue($result['passed']);
        $this->assertEquals(100, $result['score']);
    }

    public function testPatternCheckStraightLine(): void
    {
        $check = new PatternCheck();
        $questions = array_fill(0, 5, ['id' => 1, 'type' => 'likert5']);
        $answers = [];
        foreach ($questions as $i => $q) {
            $q['id'] = $i + 1;
            $questions[$i] = $q;
            $answers[] = ['question_id' => $i + 1, 'answer_value' => '3'];
        }
        $result = $check->run(['answers' => $answers, 'questions' => $questions]);
        $this->assertFalse($result['passed']);
    }

    public function testPatternCheckNoPattern(): void
    {
        $check = new PatternCheck();
        $questions = array_fill(0, 5, ['id' => 1, 'type' => 'likert5']);
        $answers = [];
        foreach ($questions as $i => $q) {
            $q['id'] = $i + 1;
            $questions[$i] = $q;
            $answers[] = ['question_id' => $i + 1, 'answer_value' => (string)($i + 1)];
        }
        $result = $check->run(['answers' => $answers, 'questions' => $questions]);
        $this->assertTrue($result['passed']);
    }

    public function testEmojiCheckExcessive(): void
    {
        $check = new EmojiCheck();
        $emoji = str_repeat('😀😁😂🤣😃', 5);
        $questions = [['id' => 1, 'type' => 'text']];
        $answers = [['question_id' => 1, 'answer_value' => $emoji]];
        $result = $check->run(['answers' => $answers, 'questions' => $questions]);
        $this->assertFalse($result['passed']);
    }

    public function testEmojiCheckClean(): void
    {
        $check = new EmojiCheck();
        $questions = [['id' => 1, 'type' => 'text']];
        $answers = [['question_id' => 1, 'answer_value' => 'This is a normal response.']];
        $result = $check->run(['answers' => $answers, 'questions' => $questions]);
        $this->assertTrue($result['passed']);
    }

    public function testGibberishCheckDetectsLowVowels(): void
    {
        $check = new GibberishCheck();
        $questions = [['id' => 1, 'type' => 'text']];
        $answers = [['question_id' => 1, 'answer_value' => 'bcdfghjklmnpqrstvwxyz']];
        $result = $check->run(['answers' => $answers, 'questions' => $questions]);
        $this->assertFalse($result['passed']);
    }

    public function testGibberishCheckNormal(): void
    {
        $check = new GibberishCheck();
        $questions = [['id' => 1, 'type' => 'text']];
        $answers = [['question_id' => 1, 'answer_value' => 'This is a completely normal response.']];
        $result = $check->run(['answers' => $answers, 'questions' => $questions]);
        $this->assertTrue($result['passed']);
    }

    public function testLongstringRepeatedPattern(): void
    {
        $check = new LongstringCheck();
        $questions = [['id' => 1, 'type' => 'text']];
        $answers = [['question_id' => 1, 'answer_value' => str_repeat('abc', 20)]];
        $result = $check->run(['answers' => $answers, 'questions' => $questions]);
        $this->assertFalse($result['passed']);
    }

    public function testSpeedBumpNoQuestions(): void
    {
        $check = new SpeedBumpCheck();
        $result = $check->run(['questions' => [], 'answers' => []]);
        $this->assertTrue($result['passed']);
        $this->assertEquals(100, $result['score']);
    }

    public function testSpeedBumpCorrect(): void
    {
        $check = new SpeedBumpCheck();
        $questions = [['id' => 1, 'is_speed_bump' => true, 'expected_answer' => '42']];
        $answers = [['question_id' => 1, 'answer_value' => '42']];
        $result = $check->run(['questions' => $questions, 'answers' => $answers]);
        $this->assertTrue($result['passed']);
    }

    public function testTrapNoQuestions(): void
    {
        $check = new TrapCheck();
        $result = $check->run(['questions' => [], 'answers' => []]);
        $this->assertTrue($result['passed']);
    }

    public function testBotCheckNoIndicators(): void
    {
        $check = new BotCheck();
        $result = $check->run([
            'response' => [
                'ip_address' => '8.8.8.8',
                'user_agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120',
                'device_fingerprint' => 'abc123',
            ],
        ]);
        $this->assertTrue($result['passed']);
        $this->assertEquals(100, $result['score']);
    }

    public function testOutlierWithinRange(): void
    {
        $check = new OutlierCheck();
        $questions = [['id' => 1, 'type' => 'number', 'min_value' => 1, 'max_value' => 10]];
        $answers = [['question_id' => 1, 'answer_value' => '5']];
        $result = $check->run([
            'answers' => $answers,
            'questions' => $questions,
            'response' => ['time_spent_seconds' => 120],
        ]);
        $this->assertTrue($result['passed']);
    }

    public function testProfanityClean(): void
    {
        $check = new ProfanityCheck();
        $questions = [['id' => 1, 'type' => 'text']];
        $answers = [['question_id' => 1, 'answer_value' => 'This is a polite response.']];
        $result = $check->run(['answers' => $answers, 'questions' => $questions]);
        $this->assertTrue($result['passed']);
    }

    public function testConsistencyNoContradiction(): void
    {
        $check = new ConsistencyCheck();
        $questions = [
            ['id' => 1, 'question_text' => 'What is your age?'],
            ['id' => 2, 'question_text' => 'What is your year of birth?'],
        ];
        $answers = [
            ['question_id' => 1, 'answer_value' => '30'],
            ['question_id' => 2, 'answer_value' => '1996'],
        ];
        $result = $check->run([
            'answers' => $answers,
            'questions' => $questions,
            'response' => ['completed_at' => '2026-07-13'],
        ]);
        $this->assertTrue($result['passed']);
    }
}
