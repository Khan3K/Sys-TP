<?php

namespace Core;

use PHPUnit\Framework\TestCase;

class ValidatorTest extends TestCase
{
    private Validator $v;

    protected function setUp(): void
    {
        $_POST = [];
        $this->v = new Validator($_POST);
    }

    public function testRequiredPasses(): void
    {
        $_POST['name'] = 'John';
        $v = new Validator($_POST);
        $this->assertTrue($v->required('name', 'Name')->passes());
    }

    public function testRequiredFails(): void
    {
        $this->assertFalse($this->v->required('name', 'Name')->passes());
    }

    public function testEmailValid(): void
    {
        $_POST['email'] = 'test@example.com';
        $v = new Validator($_POST);
        $this->assertTrue($v->email('email')->passes());
    }

    public function testEmailInvalid(): void
    {
        $_POST['email'] = 'not-an-email';
        $v = new Validator($_POST);
        $this->assertFalse($v->email('email')->passes());
    }

    public function testMinPasses(): void
    {
        $_POST['field'] = 'hello';
        $v = new Validator($_POST);
        $this->assertTrue($v->min('field', 3)->passes());
    }

    public function testMinFails(): void
    {
        $_POST['field'] = 'ab';
        $v = new Validator($_POST);
        $this->assertFalse($v->min('field', 3)->passes());
    }

    public function testNumericPasses(): void
    {
        $_POST['num'] = '42';
        $v = new Validator($_POST);
        $this->assertTrue($v->numeric('num')->passes());
    }

    public function testNumericFails(): void
    {
        $_POST['num'] = 'not-a-number';
        $v = new Validator($_POST);
        $this->assertFalse($v->numeric('num')->passes());
    }

    public function testInListPasses(): void
    {
        $_POST['role'] = 'admin';
        $v = new Validator($_POST);
        $this->assertTrue($v->inList('role', ['admin', 'user'])->passes());
    }

    public function testInListFails(): void
    {
        $_POST['role'] = 'superadmin';
        $v = new Validator($_POST);
        $this->assertFalse($v->inList('role', ['admin', 'user'])->passes());
    }

    public function testMultipleRules(): void
    {
        $_POST['email'] = 'test@example.com';
        $v = new Validator($_POST);
        $this->assertTrue($v->required('email', 'Email')->email('email')->passes());
    }

    public function testMultipleRulesFailure(): void
    {
        $_POST['email'] = '';
        $v = new Validator($_POST);
        $this->assertFalse($v->required('email', 'Email')->email('email')->passes());
    }

    public function testFirstError(): void
    {
        $_POST['email'] = '';
        $v = new Validator($_POST);
        $v->required('email', 'Email');
        $this->assertNotEmpty($v->firstError());
    }
}
