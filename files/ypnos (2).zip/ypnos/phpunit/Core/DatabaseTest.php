<?php

namespace Core;

use PHPUnit\Framework\TestCase;

class DatabaseTest extends TestCase
{
    public function testAllowedTablesIncludeAllExpected(): void
    {
        $tables = [
            'users', 'sessions', 'password_resets', 'rate_limits', 'admin_logs',
            'surveys', 'questions', 'question_rules', 'responses', 'answers',
            'quality_logs', 'quality_scores', 'api_tokens', 'export_history',
            'behavioral_logs', 'reputation_history', 'research_projects',
            'research_project_surveys', 'research_visualizations', 'survey_urls',
            'animation_presets',
        ];

        $ref = new \ReflectionClass(Database::class);
        $prop = $ref->getProperty('allowedTables');
        $prop->setAccessible(true);
        $allowed = $prop->getValue(null);

        foreach ($tables as $t) {
            $this->assertContains($t, $allowed, "Table '{$t}' should be in allowed list");
        }
    }

    public function testAllowedColumnsIncludeCriticalColumns(): void
    {
        $ref = new \ReflectionClass(Database::class);
        $prop = $ref->getProperty('allowedColumns');
        $prop->setAccessible(true);
        $allowed = $prop->getValue(null);

        $critical = ['id', 'email', 'password_hash', 'role', 'status', 'title',
            'question_text', 'answer_value', 'overall_score', 'quality_score'];

        foreach ($critical as $c) {
            $this->assertContains($c, $allowed, "Column '{$c}' should be in allowed list");
        }
    }

    public function testValidateIdentifier(): void
    {
        $ref = new \ReflectionClass(Database::class);
        $method = $ref->getMethod('validateIdentifier');
        $method->setAccessible(true);

        $this->assertEquals('users', $method->invoke(null, 'users'));
        $this->assertEquals('quality_scores', $method->invoke(null, 'quality_scores'));
    }

    public function testValidateIdentifierRejectsInvalid(): void
    {
        $ref = new \ReflectionClass(Database::class);
        $method = $ref->getMethod('validateIdentifier');
        $method->setAccessible(true);

        $this->expectException(\InvalidArgumentException::class);
        $method->invoke(null, 'users; DROP TABLE');
    }
}
