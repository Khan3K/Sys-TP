<?php

namespace Core;

use PHPUnit\Framework\TestCase;

class CsrfTest extends TestCase
{
    public static function setUpBeforeClass(): void
    {
        if (session_status() === PHP_SESSION_NONE) {
            @session_start();
        }
    }

    public function testTokenGeneration(): void
    {
        unset($_SESSION['_csrf_token']);
        $token = Csrf::token();
        $this->assertNotEmpty($token);
        $this->assertEquals(64, strlen($token));
    }

    public function testFieldReturnsHiddenInput(): void
    {
        unset($_SESSION['_csrf_token']);
        Csrf::token();
        $field = Csrf::field();
        $this->assertStringContainsString('_csrf_token', $field);
        $this->assertStringContainsString('hidden', $field);
    }

    public function testValidTokenPasses(): void
    {
        unset($_SESSION['_csrf_token']);
        $token = Csrf::token();
        $_POST['_csrf_token'] = $token;
        $this->assertTrue(Csrf::valid());
    }

    public function testInvalidTokenFails(): void
    {
        unset($_SESSION['_csrf_token']);
        Csrf::token();
        $_POST['_csrf_token'] = str_repeat('x', 64);
        $this->assertFalse(Csrf::valid());
    }

    public function testMissingTokenFails(): void
    {
        unset($_SESSION['_csrf_token']);
        Csrf::token();
        unset($_POST['_csrf_token']);
        $this->assertFalse(Csrf::valid());
    }

    public static function tearDownAfterClass(): void
    {
        unset($_SESSION['_csrf_token'], $_POST['_csrf_token']);
    }
}
