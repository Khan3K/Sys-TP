<?php

$envBool = static function (string $key, bool $default = false): bool {
    $value = getenv($key);
    if ($value === false || $value === null || $value === "") {
        return $default;
    }

    $normalized = strtolower(trim((string) $value));
    if (in_array($normalized, ["1", "true", "yes", "on"], true)) {
        return true;
    }
    if (in_array($normalized, ["0", "false", "no", "off"], true)) {
        return false;
    }

    return $default;
};

return [
    "name" => "Resrch",
    "url" => "http://localhost/dashboard/ypnos",
    "base_url" => "/dashboard/ypnos",
    "debug" => $envBool("APP_DEBUG", false),
    "force_https" => $envBool("FORCE_HTTPS", false),
    "timezone" => "UTC",
    "session_lifetime" => 86400,
    "password_reset_expiry" => 3600,
    "rate_limit" => [
        "max_requests" => 100,
        "window_minutes" => 60,
    ],
    "quality" => [
        "default_threshold" => 70,
        "max_retries" => 3,
        "log_all_checks" => true,
    ],
    "export" => [
        "formats" => ["csv", "json"],
        "max_rows" => 50000,
    ],
    "reputation" => [
        "initial" => 50,
        "max" => 100,
        "good_response_bonus" => 2,
        "poor_response_penalty" => -5,
        "flagged_penalty" => -10,
        "decay_per_month" => -5,
        "decay_days" => 30,
    ],
    "google_oauth" => [
        "client_id" => getenv("GOOGLE_CLIENT_ID") ?: "",
        "client_secret" => getenv("GOOGLE_CLIENT_SECRET") ?: "",
        "redirect_uri" => "", // set dynamically in AuthController
    ],
];
