<?php
// Resrch Seed Script — Creates admin user and sample data
// Run: php database/seed.php

require_once __DIR__ . '/../config/database.php';

$config = require __DIR__ . '/../config/database.php';

$dsn = "mysql:host={$config['host']};port={$config['port']};charset={$config['charset']}";
$pdo = new PDO($dsn, $config['username'], $config['password'], [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
]);

// Drop and recreate
$pdo->exec("DROP DATABASE IF EXISTS `{$config['dbname']}`");
$pdo->exec("CREATE DATABASE IF NOT EXISTS `{$config['dbname']}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
$pdo->exec("USE `{$config['dbname']}`");

// Run schema
$schema = file_get_contents(__DIR__ . '/schema.sql');
$pdo->exec($schema);

echo "Database schema created.\n";

// Create admin user
$stmt = $pdo->prepare("INSERT IGNORE INTO users (email, password_hash, full_name, role, is_active) VALUES (?, ?, ?, 'admin', 1)");
$stmt->execute(['admin@resrch.dev', password_hash('admin123', PASSWORD_BCRYPT), 'Admin User']);
echo "Admin user created: admin@resrch.dev / admin123\n";

// Create sample researcher
$stmt = $pdo->prepare("INSERT IGNORE INTO users (email, password_hash, full_name, role, is_active) VALUES (?, ?, ?, 'researcher', 1)");
$stmt->execute(['researcher@resrch.dev', password_hash('research123', PASSWORD_BCRYPT), 'Dr. Smith']);
echo "Researcher user created: researcher@resrch.dev / research123\n";

// Create sample respondent
$stmt = $pdo->prepare("INSERT IGNORE INTO users (email, password_hash, full_name, role, is_active) VALUES (?, ?, ?, 'respondent', 1)");
$stmt->execute(['respondent@resrch.dev', password_hash('respondent123', PASSWORD_BCRYPT), 'Respondent User']);
echo "Respondent user created: respondent@resrch.dev / respondent123\n";

// Set reputation scores
$pdo->exec("UPDATE users SET reputation_score = 50 WHERE role = 'respondent'");
$pdo->exec("UPDATE users SET reputation_score = 80 WHERE role = 'researcher'");
$pdo->exec("UPDATE users SET reputation_score = 100 WHERE role = 'admin'");

// Get researcher ID
$researcher = $pdo->query("SELECT id FROM users WHERE email = 'researcher@resrch.dev'")->fetch(PDO::FETCH_ASSOC);
$researcherId = $researcher['id'];

// Create sample survey
$qualityConfig = json_encode([
    'honeypot' => true,
    'min_time_seconds' => 30,
    'captcha' => true,
    'min_text_length' => 10,
    'prevent_duplicates' => true,
    'detect_straightline' => true,
    'confirm_answers' => false,
    'validate_input' => true,
]);
$stmt = $pdo->prepare("INSERT INTO surveys (researcher_id, title, description, status, quality_threshold, min_reputation, quality_config) VALUES (?, ?, ?, ?, ?, ?, ?)");
$stmt->execute([$researcherId, 'Customer Satisfaction Survey', 'Help us improve our services by sharing your feedback.', 'active', 70, 0, $qualityConfig]);
$surveyId = $pdo->lastInsertId();
echo "Sample survey created (ID: {$surveyId}).\n";

// Add questions
$questions = [
    ['type' => 'text', 'text' => 'What is your full name?', 'order' => 1, 'required' => 1],
    ['type' => 'email', 'text' => 'What is your email address?', 'order' => 2, 'required' => 1],
    ['type' => 'number', 'text' => 'How old are you?', 'order' => 3, 'required' => 1],
    ['type' => 'likert5', 'text' => 'How satisfied are you with our service?', 'order' => 4, 'required' => 1, 'options' => json_encode(['Very Dissatisfied', 'Dissatisfied', 'Neutral', 'Satisfied', 'Very Satisfied'])],
    ['type' => 'mcq_single', 'text' => 'How did you hear about us?', 'order' => 5, 'required' => 1, 'options' => json_encode(['Social Media', 'Friend Referral', 'Search Engine', 'Advertisement', 'Other'])],
    ['type' => 'yes_no', 'text' => 'Would you recommend us to others?', 'order' => 6, 'required' => 1],
    ['type' => 'text', 'text' => 'Any additional comments?', 'order' => 7, 'required' => 0],
    ['type' => 'likert5', 'text' => 'Please select "Agree" for this verification check.', 'order' => 8, 'required' => 1, 'is_attention_check' => 1, 'expected_answer' => '4', 'options' => json_encode(['Strongly Disagree', 'Disagree', 'Neutral', 'Agree', 'Strongly Agree'])],
];

foreach ($questions as $q) {
    $stmt = $pdo->prepare("INSERT INTO questions (survey_id, type, question_text, options_json, order_index, is_required, is_attention_check, expected_answer) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        $surveyId,
        $q['type'],
        $q['text'],
        $q['options'] ?? null,
        $q['order'],
        $q['required'],
        $q['is_attention_check'] ?? 0,
        $q['expected_answer'] ?? null,
    ]);
}
echo "Sample questions added.\n";

echo "\n=== Setup Complete ===\n";
echo "Admin:      admin@resrch.dev / admin123\n";
echo "Researcher: researcher@resrch.dev / research123\n";
echo "Respondent: respondent@resrch.dev / respondent123\n";
echo "Sample survey created with ID {$surveyId}.\n";
