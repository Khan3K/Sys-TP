-- Resrch Survey Platform Schema
CREATE DATABASE IF NOT EXISTS resrch CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE resrch;

CREATE TABLE users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    avatar_url VARCHAR(500) NULL,
    role ENUM('admin','researcher','respondent') NOT NULL DEFAULT 'respondent',
    reputation_score DECIMAL(5,2) NOT NULL DEFAULT 50,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    approval_status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'approved',
    last_login_at DATETIME NULL,
    last_activity_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_role (role),
    INDEX idx_email (email)
) ENGINE=InnoDB;

CREATE TABLE sessions (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    token VARCHAR(128) NOT NULL UNIQUE,
    expires_at DATETIME NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_token (token)
) ENGINE=InnoDB;

CREATE TABLE password_resets (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    token VARCHAR(128) NOT NULL UNIQUE,
    expires_at DATETIME NOT NULL,
    used_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_token (token)
) ENGINE=InnoDB;

CREATE TABLE rate_limits (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ip_address VARCHAR(45) NOT NULL,
    endpoint VARCHAR(500) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_ip (ip_address, created_at)
) ENGINE=InnoDB;

CREATE TABLE admin_logs (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    admin_id INT UNSIGNED NOT NULL,
    action VARCHAR(255) NOT NULL,
    details_json JSON NULL,
    ip_address VARCHAR(45) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (admin_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_admin (admin_id),
    INDEX idx_action (action),
    INDEX idx_created (created_at)
) ENGINE=InnoDB;

CREATE TABLE surveys (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    researcher_id INT UNSIGNED NOT NULL,
    title VARCHAR(500) NOT NULL,
    description TEXT NULL,
    status ENUM('draft','active','closed','archived') NOT NULL DEFAULT 'draft',
    quality_threshold DECIMAL(5,2) NOT NULL DEFAULT 70.00,
    min_reputation DECIMAL(5,2) NOT NULL DEFAULT 0,
    max_responses INT UNSIGNED NULL,
    current_responses INT UNSIGNED NOT NULL DEFAULT 0,
    allow_anonymous TINYINT(1) NOT NULL DEFAULT 0,
    require_quality_check TINYINT(1) NOT NULL DEFAULT 1,
    quality_config JSON NULL,
    type ENUM('form','chat') NOT NULL DEFAULT 'form',
    chat_config JSON NULL,
    ai_config JSON NULL,
    theme_config JSON NULL,
    access_password VARCHAR(255) NULL,
    starts_at DATETIME NULL,
    ends_at DATETIME NULL,
    shuffle_questions TINYINT(1) NOT NULL DEFAULT 0,
    shuffle_options TINYINT(1) NOT NULL DEFAULT 0,
    fullscreen_mode TINYINT(1) NOT NULL DEFAULT 0,
    inactivity_timeout INT UNSIGNED NOT NULL DEFAULT 300,
    allow_resume TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (researcher_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_status (status),
    INDEX idx_researcher (researcher_id),
    INDEX idx_type (type),
    INDEX idx_researcher_status (researcher_id, status)
) ENGINE=InnoDB;

CREATE TABLE questions (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    survey_id INT UNSIGNED NOT NULL,
    type ENUM('text','number','email','phone','date','likert5','likert7','mcq_single','mcq_multiple','dropdown','rating','slider','yes_no','matrix','file_upload','textarea','url','nps','ranking','multi_text','address','time','datetime','color','percentage','signature',
        'image_choice','drag_drop_rank','slider_labels','star_rating','emoji_rating','constant_sum','heatmap','click_map','audio_response','video_response','drawing','card_sort','max_diff','conjoint','image_hotspot','location_picker','date_range','duration','phone_intl','currency','rich_text','code_editor','formula') NOT NULL,
    question_text TEXT NOT NULL,
    options_json JSON NULL,
    order_index INT UNSIGNED NOT NULL DEFAULT 0,
    is_required TINYINT(1) NOT NULL DEFAULT 1,
    is_attention_check TINYINT(1) NOT NULL DEFAULT 0,
    expected_answer VARCHAR(500) NULL,
    is_trap TINYINT(1) NOT NULL DEFAULT 0,
    is_timed TINYINT(1) NOT NULL DEFAULT 0,
    time_limit_seconds INT UNSIGNED NULL,
    min_value DECIMAL(15,2) NULL,
    max_value DECIMAL(15,2) NULL,
    char_limit INT UNSIGNED NULL,
    min_length INT UNSIGNED NULL,
    max_length INT UNSIGNED NULL,
    allow_paste TINYINT(1) NOT NULL DEFAULT 1,
    is_speed_bump TINYINT(1) NOT NULL DEFAULT 0,
    rows_json JSON NULL,
    placeholder VARCHAR(500) NULL,
    hint VARCHAR(500) NULL,
    image_url VARCHAR(1000) NULL,
    shuffle_options TINYINT(1) NOT NULL DEFAULT 0,
    include_other TINYINT(1) NOT NULL DEFAULT 1,
    animation VARCHAR(50) NULL,
    accent_color VARCHAR(20) NULL,
    explanation TEXT NULL,
    -- New theme & behavior columns
    font_family VARCHAR(100) NULL,
    font_size VARCHAR(20) NULL,
    border_radius VARCHAR(20) NULL,
    shadow_style VARCHAR(20) NULL,
    bg_type ENUM('solid','gradient','image','video','particles') NULL DEFAULT 'solid',
    bg_value VARCHAR(500) NULL,
    frozen_animation VARCHAR(50) NULL,
    interaction_animation VARCHAR(50) NULL,
    validation_rules JSON NULL,
    scoring_weight DECIMAL(5,2) NULL DEFAULT 1.00,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (survey_id) REFERENCES surveys(id) ON DELETE CASCADE,
    INDEX idx_survey (survey_id),
    INDEX idx_survey_type (survey_id, type),
    INDEX idx_order (survey_id, order_index)
) ENGINE=InnoDB;

CREATE TABLE question_rules (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    question_id INT UNSIGNED NOT NULL,
    rule_type ENUM('consistency_group','skip_logic','min_time','max_time','depend_on') NOT NULL,
    rule_value TEXT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (question_id) REFERENCES questions(id) ON DELETE CASCADE,
    INDEX idx_question (question_id)
) ENGINE=InnoDB;

CREATE TABLE responses (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    survey_id INT UNSIGNED NOT NULL,
    respondent_id INT UNSIGNED NULL,
    session_id VARCHAR(128) NULL,
    ip_address VARCHAR(45) NULL,
    device_fingerprint VARCHAR(255) NULL,
    question_random_seed INT UNSIGNED NULL,
    resume_code VARCHAR(64) NULL,
    tab_switch_count INT UNSIGNED NOT NULL DEFAULT 0,
    user_agent TEXT NULL,
    started_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at DATETIME NULL,
    time_spent_seconds INT UNSIGNED NULL,
    status ENUM('in_progress','completed','flagged','rejected','accepted') NOT NULL DEFAULT 'in_progress',
    chat_data TEXT NULL,
    quality_score DECIMAL(5,2) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (survey_id) REFERENCES surveys(id) ON DELETE CASCADE,
    FOREIGN KEY (respondent_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_survey (survey_id),
    INDEX idx_status (status),
    INDEX idx_quality (quality_score),
    INDEX idx_respondent (respondent_id),
    INDEX idx_survey_status (survey_id, status),
    INDEX idx_survey_respondent (survey_id, respondent_id)
) ENGINE=InnoDB;

CREATE TABLE answers (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    response_id INT UNSIGNED NOT NULL,
    question_id INT UNSIGNED NOT NULL,
    answer_value TEXT NULL,
    time_spent_seconds DECIMAL(10,3) NULL,
    is_flagged TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (response_id) REFERENCES responses(id) ON DELETE CASCADE,
    FOREIGN KEY (question_id) REFERENCES questions(id) ON DELETE CASCADE,
    INDEX idx_response (response_id),
    INDEX idx_flagged (is_flagged),
    INDEX idx_question_response (question_id, response_id)
) ENGINE=InnoDB;

CREATE TABLE quality_logs (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    response_id INT UNSIGNED NOT NULL,
    check_type ENUM('attention','response_time','pattern','consistency','trap','bot','gibberish','outlier','longstring','reputation','emoji','profanity','speed_bump') NOT NULL,
    passed TINYINT(1) NOT NULL DEFAULT 0,
    score DECIMAL(5,2) NOT NULL DEFAULT 0,
    details_json JSON NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (response_id) REFERENCES responses(id) ON DELETE CASCADE,
    INDEX idx_response (response_id),
    INDEX idx_check (check_type),
    INDEX idx_response_check (response_id, check_type)
) ENGINE=InnoDB;

CREATE TABLE quality_scores (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    response_id INT UNSIGNED NOT NULL UNIQUE,
    overall_score DECIMAL(5,2) NOT NULL DEFAULT 0,
    attention_score DECIMAL(5,2) NOT NULL DEFAULT 0,
    time_score DECIMAL(5,2) NOT NULL DEFAULT 0,
    pattern_score DECIMAL(5,2) NOT NULL DEFAULT 0,
    consistency_score DECIMAL(5,2) NOT NULL DEFAULT 0,
    trap_score DECIMAL(5,2) NOT NULL DEFAULT 0,
    bot_score DECIMAL(5,2) NOT NULL DEFAULT 0,
    gibberish_score DECIMAL(5,2) NOT NULL DEFAULT 0,
    longstring_score DECIMAL(5,2) NOT NULL DEFAULT 0,
    outlier_score DECIMAL(5,2) NOT NULL DEFAULT 0,
    emoji_score DECIMAL(5,2) NOT NULL DEFAULT 0,
    profanity_score DECIMAL(5,2) NOT NULL DEFAULT 0,
    speed_bump_score DECIMAL(5,2) NOT NULL DEFAULT 0,
    is_auto_rejected TINYINT(1) NOT NULL DEFAULT 0,
    researcher_verdict ENUM('pending','accepted','rejected') NOT NULL DEFAULT 'pending',
    notes TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (response_id) REFERENCES responses(id) ON DELETE CASCADE,
    INDEX idx_overall (overall_score),
    INDEX idx_verdict (researcher_verdict)
) ENGINE=InnoDB;

CREATE TABLE api_tokens (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    token VARCHAR(128) NOT NULL UNIQUE,
    permissions JSON NOT NULL,
    expires_at DATETIME NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_token (token)
) ENGINE=InnoDB;

CREATE TABLE export_history (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    survey_id INT UNSIGNED NOT NULL,
    format ENUM('csv','json') NOT NULL,
    filter_criteria JSON NULL,
    file_path VARCHAR(500) NULL,
    row_count INT UNSIGNED NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (survey_id) REFERENCES surveys(id) ON DELETE CASCADE,
    INDEX idx_user (user_id)
) ENGINE=InnoDB;

CREATE TABLE behavioral_logs (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    response_id INT UNSIGNED NOT NULL,
    event_type VARCHAR(50) NOT NULL,
    event_data JSON NULL,
    timestamp_ms BIGINT UNSIGNED NOT NULL DEFAULT 0,
    question_index INT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (response_id) REFERENCES responses(id) ON DELETE CASCADE,
    INDEX idx_response (response_id),
    INDEX idx_event_type (event_type),
    INDEX idx_response_event (response_id, event_type)
) ENGINE=InnoDB;

CREATE TABLE reputation_history (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    response_id INT UNSIGNED NULL,
    survey_id INT UNSIGNED NULL,
    old_score DECIMAL(5,2) NOT NULL,
    new_score DECIMAL(5,2) NOT NULL,
    change_reason VARCHAR(255) NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (response_id) REFERENCES responses(id) ON DELETE SET NULL,
    FOREIGN KEY (survey_id) REFERENCES surveys(id) ON DELETE SET NULL,
    INDEX idx_user (user_id),
    INDEX idx_response (response_id),
    INDEX idx_user_created (user_id, created_at)
) ENGINE=InnoDB;

CREATE TABLE research_projects (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    researcher_id INT UNSIGNED NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (researcher_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_researcher (researcher_id)
) ENGINE=InnoDB;

CREATE TABLE research_project_surveys (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    project_id INT UNSIGNED NOT NULL,
    survey_id INT UNSIGNED NOT NULL,
    import_config JSON NULL,
    imported_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES research_projects(id) ON DELETE CASCADE,
    FOREIGN KEY (survey_id) REFERENCES surveys(id) ON DELETE CASCADE,
    INDEX idx_project (project_id),
    INDEX idx_survey (survey_id)
) ENGINE=InnoDB;

CREATE TABLE research_visualizations (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    project_id INT UNSIGNED NOT NULL,
    name VARCHAR(255) NOT NULL,
    chart_type VARCHAR(50) NOT NULL,
    chart_config JSON NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES research_projects(id) ON DELETE CASCADE,
    INDEX idx_project (project_id)
) ENGINE=InnoDB;

CREATE TABLE survey_urls (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    survey_id INT UNSIGNED NOT NULL,
    short_code VARCHAR(100) NULL,
    custom_slug VARCHAR(100) NULL,
    slug VARCHAR(100) NULL UNIQUE,
    full_url VARCHAR(500) NULL,
    qr_code_path VARCHAR(500) NULL,
    use_count INT UNSIGNED NOT NULL DEFAULT 0,
    click_count INT UNSIGNED NOT NULL DEFAULT 0,
    utm_source VARCHAR(100) NULL,
    utm_medium VARCHAR(100) NULL,
    utm_campaign VARCHAR(100) NULL,
    utm_content VARCHAR(100) NULL,
    utm_term VARCHAR(100) NULL,
    password VARCHAR(255) NULL,
    max_uses INT UNSIGNED NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    expires_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (survey_id) REFERENCES surveys(id) ON DELETE CASCADE,
    INDEX idx_survey (survey_id),
    INDEX idx_slug (slug)
) ENGINE=InnoDB;

CREATE TABLE animation_presets (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    key_name VARCHAR(50) NOT NULL UNIQUE,
    label VARCHAR(100) NOT NULL,
    category ENUM('entrance','exit','emphasis','special') NOT NULL,
    css_class VARCHAR(100) NOT NULL,
    duration_ms INT UNSIGNED NOT NULL DEFAULT 500,
    description TEXT NULL,
    is_premium TINYINT(1) NOT NULL DEFAULT 0,
    sort_order INT UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB;

INSERT INTO animation_presets (key_name, label, category, css_class, duration_ms, description, is_premium, sort_order) VALUES
('fade-in', 'Fade In', 'entrance', 'anim-fade-in', 400, 'Smooth opacity fade', 0, 1),
('fade-out', 'Fade Out', 'exit', 'anim-fade-out', 300, 'Smooth opacity fade out', 0, 2),
('slide-up', 'Slide Up', 'entrance', 'anim-slide-up', 500, 'Slide up from bottom', 0, 3),
('slide-down', 'Slide Down', 'entrance', 'anim-slide-down', 500, 'Slide down from top', 0, 4),
('slide-left', 'Slide Left', 'entrance', 'anim-slide-left', 500, 'Slide in from right', 0, 5),
('slide-right', 'Slide Right', 'entrance', 'anim-slide-right', 500, 'Slide in from left', 0, 6),
('zoom-in', 'Zoom In', 'entrance', 'anim-zoom-in', 400, 'Scale up from center', 0, 7),
('zoom-out', 'Zoom Out', 'exit', 'anim-zoom-out', 300, 'Scale down to center', 0, 8),
('flip-x', 'Flip X', 'entrance', 'anim-flip-x', 600, '3D flip horizontally', 0, 9),
('flip-y', 'Flip Y', 'entrance', 'anim-flip-y', 600, '3D flip vertically', 0, 10),
('rotate-in', 'Rotate In', 'entrance', 'anim-rotate-in', 500, 'Rotate into view', 0, 11),
('bounce-in', 'Bounce In', 'entrance', 'anim-bounce-in', 700, 'Bouncy entrance', 0, 12),
('elastic-in', 'Elastic In', 'entrance', 'anim-elastic-in', 800, 'Elastic spring effect', 0, 13),
('swing-in', 'Swing In', 'entrance', 'anim-swing-in', 700, 'Swing like a pendulum', 0, 14),
('jack-in-box', 'Jack-in-the-Box', 'entrance', 'anim-jack-in-box', 800, 'Pop out with rotation', 0, 15),
('roll-in', 'Roll In', 'entrance', 'anim-roll-in', 600, 'Rolling entrance', 0, 16),
('flip-in', 'Flip In', 'entrance', 'anim-flip-in', 600, '3D flip into view', 0, 17),
('twist-in', 'Twist In', 'entrance', 'anim-twist-in', 700, 'Twist into position', 0, 18),
('puff-in', 'Puff In', 'entrance', 'anim-puff-in', 500, 'Scale and fade', 0, 19),
('vanish-in', 'Vanish In', 'entrance', 'anim-vanish-in', 400, 'Scale from 0', 0, 20),
('slide-up-fade', 'Slide Up & Fade', 'entrance', 'anim-slide-up-fade', 500, 'Combined slide and fade', 0, 21),
('slide-down-fade', 'Slide Down & Fade', 'entrance', 'anim-slide-down-fade', 500, 'Combined slide and fade', 0, 22),
('stagger-fade', 'Stagger Fade', 'entrance', 'anim-stagger-fade', 600, 'Sequential fade for children', 0, 23),
('stagger-slide', 'Stagger Slide', 'entrance', 'anim-stagger-slide', 700, 'Sequential slide for children', 0, 24),
('heart-beat', 'Heart Beat', 'emphasis', 'anim-heart-beat', 1000, 'Pulsing scale animation', 0, 25),
('pulse', 'Pulse', 'emphasis', 'anim-pulse', 2000, 'Gentle breathing pulse', 0, 26),
('shake-x', 'Shake X', 'emphasis', 'anim-shake-x', 500, 'Horizontal shake', 0, 27),
('shake-y', 'Shake Y', 'emphasis', 'anim-shake-y', 500, 'Vertical shake', 0, 28),
('wobble', 'Wobble', 'emphasis', 'anim-wobble', 1000, 'Wobble effect', 0, 29),
('jello', 'Jello', 'emphasis', 'anim-jello', 1000, 'Jiggle like jelly', 0, 30),
('rubber-band', 'Rubber Band', 'emphasis', 'anim-rubber-band', 1000, 'Stretch and snap', 0, 31),
('tada', 'Tada', 'emphasis', 'anim-tada', 1000, 'Celebration animation', 0, 32),
('swing', 'Swing', 'emphasis', 'anim-swing', 1000, 'Swing back and forth', 0, 33),
('bounce', 'Bounce', 'emphasis', 'anim-bounce', 1000, 'Bounce up and down', 0, 34),
('flash', 'Flash', 'emphasis', 'anim-flash', 1000, 'Quick background flash', 0, 35),
('spin', 'Spin', 'emphasis', 'anim-spin', 1000, 'Full rotation spin', 0, 36),
('hinge', 'Hinge', 'exit', 'anim-hinge', 1000, 'Swing down like a hinge', 0, 37),
('roll-out', 'Roll Out', 'exit', 'anim-roll-out', 600, 'Roll away', 0, 38),
('flip-out', 'Flip Out', 'exit', 'anim-flip-out', 600, '3D flip away', 0, 39),
('zoom-out-down', 'Zoom Out Down', 'exit', 'anim-zoom-out-down', 500, 'Zoom and fall', 0, 40),
('fade-out-up', 'Fade Out Up', 'exit', 'anim-fade-out-up', 400, 'Fade and slide up', 0, 41),
('fade-out-down', 'Fade Out Down', 'exit', 'anim-fade-out-down', 400, 'Fade and slide down', 0, 42),
('bounce-out', 'Bounce Out', 'exit', 'anim-bounce-out', 700, 'Bounce and exit', 0, 43),
('slide-out-left', 'Slide Out Left', 'exit', 'anim-slide-out-left', 500, 'Exit stage left', 0, 44),
('slide-out-right', 'Slide Out Right', 'exit', 'anim-slide-out-right', 500, 'Exit stage right', 0, 45),
('magic-entrance', 'Magic Entrance', 'special', 'anim-magic-entrance', 1000, 'Sparkle and appear', 1, 46),
('morph-in', 'Morph In', 'special', 'anim-morph-in', 800, 'Shape morph entrance', 1, 47),
('portal-in', 'Portal In', 'special', 'anim-portal-in', 1000, 'Portal ring entrance', 1, 48),
('glitch-in', 'Glitch In', 'special', 'anim-glitch-in', 600, 'Digital glitch effect', 1, 49),
('neon-pulse', 'Neon Pulse', 'special', 'anim-neon-pulse', 2000, 'Cyberpunk neon glow', 1, 50);
