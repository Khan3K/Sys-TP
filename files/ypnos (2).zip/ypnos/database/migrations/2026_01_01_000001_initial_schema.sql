-- Resrch Initial Schema
-- Created: 2026-01-01

CREATE TABLE IF NOT EXISTS users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    avatar_url VARCHAR(500) NULL,
    role ENUM('admin','researcher','respondent') NOT NULL DEFAULT 'respondent',
    reputation_score DECIMAL(5,2) NOT NULL DEFAULT 50,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    approval_status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'approved',
    last_login_at DATETIME NULL,
    last_activity_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_role (role),
    INDEX idx_email (email)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS sessions (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    token VARCHAR(128) NOT NULL UNIQUE,
    expires_at DATETIME NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_token (token)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS password_resets (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    token VARCHAR(128) NOT NULL UNIQUE,
    expires_at DATETIME NOT NULL,
    used_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_token (token)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS rate_limits (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ip_address VARCHAR(45) NOT NULL,
    endpoint VARCHAR(500) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_ip (ip_address, created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS admin_logs (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    admin_id INT UNSIGNED NOT NULL,
    action VARCHAR(255) NOT NULL,
    details_json JSON NULL,
    ip_address VARCHAR(45) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (admin_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_admin (admin_id),
    INDEX idx_action (action),
    INDEX idx_created (created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS surveys (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    researcher_id INT UNSIGNED NOT NULL,
    title VARCHAR(500) NOT NULL,
    description TEXT NULL,
    status ENUM('draft','active','closed','archived') NOT NULL DEFAULT 'draft',
    quality_threshold DECIMAL(5,2) NOT NULL DEFAULT 70.00,
    min_reputation DECIMAL(5,2) NOT NULL DEFAULT 0,
    max_responses INT UNSIGNED NULL,
    current_responses INT UNSIGNED NOT NULL DEFAULT 0,
    allow_anonymous TINYINT(1) NOT NULL DEFAULT 0,
    require_quality_check TINYINT(1) NOT NULL DEFAULT 1,
    quality_config JSON NULL,
    type ENUM('form','chat') NOT NULL DEFAULT 'form',
    chat_config JSON NULL,
    ai_config JSON NULL,
    theme_config JSON NULL,
    access_password VARCHAR(255) NULL,
    starts_at DATETIME NULL,
    ends_at DATETIME NULL,
    shuffle_questions TINYINT(1) NOT NULL DEFAULT 0,
    shuffle_options TINYINT(1) NOT NULL DEFAULT 0,
    fullscreen_mode TINYINT(1) NOT NULL DEFAULT 0,
    inactivity_timeout INT UNSIGNED NOT NULL DEFAULT 300,
    allow_resume TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (researcher_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_status (status),
    INDEX idx_researcher (researcher_id),
    INDEX idx_type (type),
    INDEX idx_researcher_status (researcher_id, status)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS questions (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    survey_id INT UNSIGNED NOT NULL,
    type VARCHAR(50) NOT NULL,
    question_text TEXT NOT NULL,
    options_json JSON NULL,
    order_index INT UNSIGNED NOT NULL DEFAULT 0,
    is_required TINYINT(1) NOT NULL DEFAULT 1,
    is_attention_check TINYINT(1) NOT NULL DEFAULT 0,
    expected_answer VARCHAR(500) NULL,
    is_trap TINYINT(1) NOT NULL DEFAULT 0,
    is_timed TINYINT(1) NOT NULL DEFAULT 0,
    time_limit_seconds INT UNSIGNED NULL,
    min_value DECIMAL(15,2) NULL,
    max_value DECIMAL(15,2) NULL,
    char_limit INT UNSIGNED NULL,
    min_length INT UNSIGNED NULL,
    max_length INT UNSIGNED NULL,
    allow_paste TINYINT(1) NOT NULL DEFAULT 1,
    is_speed_bump TINYINT(1) NOT NULL DEFAULT 0,
    rows_json JSON NULL,
    placeholder VARCHAR(500) NULL,
    hint VARCHAR(500) NULL,
    image_url VARCHAR(1000) NULL,
    shuffle_options TINYINT(1) NOT NULL DEFAULT 0,
    include_other TINYINT(1) NOT NULL DEFAULT 1,
    animation VARCHAR(50) NULL,
    accent_color VARCHAR(20) NULL,
    explanation TEXT NULL,
    font_family VARCHAR(100) NULL,
    font_size VARCHAR(20) NULL,
    border_radius VARCHAR(20) NULL,
    shadow_style VARCHAR(20) NULL,
    bg_type ENUM('solid','gradient','image','video','particles') NULL DEFAULT 'solid',
    bg_value VARCHAR(500) NULL,
    frozen_animation VARCHAR(50) NULL,
    interaction_animation VARCHAR(50) NULL,
    validation_rules JSON NULL,
    scoring_weight DECIMAL(5,2) NULL DEFAULT 1.00,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (survey_id) REFERENCES surveys(id) ON DELETE CASCADE,
    INDEX idx_survey (survey_id),
    INDEX idx_survey_type (survey_id, type),
    INDEX idx_order (survey_id, order_index)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS question_rules (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    question_id INT UNSIGNED NOT NULL,
    rule_type ENUM('consistency_group','skip_logic','min_time','max_time','depend_on') NOT NULL,
    rule_value TEXT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (question_id) REFERENCES questions(id) ON DELETE CASCADE,
    INDEX idx_question (question_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS responses (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    survey_id INT UNSIGNED NOT NULL,
    respondent_id INT UNSIGNED NULL,
    session_id VARCHAR(128) NULL,
    ip_address VARCHAR(45) NULL,
    device_fingerprint VARCHAR(255) NULL,
    question_random_seed INT UNSIGNED NULL,
    resume_code VARCHAR(64) NULL,
    tab_switch_count INT UNSIGNED NOT NULL DEFAULT 0,
    user_agent TEXT NULL,
    started_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at DATETIME NULL,
    time_spent_seconds INT UNSIGNED NULL,
    status ENUM('in_progress','completed','flagged','rejected','accepted') NOT NULL DEFAULT 'in_progress',
    chat_data TEXT NULL,
    quality_score DECIMAL(5,2) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (survey_id) REFERENCES surveys(id) ON DELETE CASCADE,
    FOREIGN KEY (respondent_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_survey (survey_id),
    INDEX idx_status (status),
    INDEX idx_quality (quality_score),
    INDEX idx_respondent (respondent_id),
    INDEX idx_survey_status (survey_id, status),
    INDEX idx_survey_respondent (survey_id, respondent_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS answers (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    response_id INT UNSIGNED NOT NULL,
    question_id INT UNSIGNED NOT NULL,
    answer_value TEXT NULL,
    time_spent_seconds DECIMAL(10,3) NULL,
    is_flagged TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (response_id) REFERENCES responses(id) ON DELETE CASCADE,
    FOREIGN KEY (question_id) REFERENCES questions(id) ON DELETE CASCADE,
    INDEX idx_response (response_id),
    INDEX idx_flagged (is_flagged),
    INDEX idx_question_response (question_id, response_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS quality_logs (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    response_id INT UNSIGNED NOT NULL,
    check_type VARCHAR(50) NOT NULL,
    passed TINYINT(1) NOT NULL DEFAULT 0,
    score DECIMAL(5,2) NOT NULL DEFAULT 0,
    details_json JSON NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (response_id) REFERENCES responses(id) ON DELETE CASCADE,
    INDEX idx_response (response_id),
    INDEX idx_check (check_type),
    INDEX idx_response_check (response_id, check_type)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS quality_scores (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    response_id INT UNSIGNED NOT NULL UNIQUE,
    overall_score DECIMAL(5,2) NOT NULL DEFAULT 0,
    attention_score DECIMAL(5,2) NOT NULL DEFAULT 0,
    time_score DECIMAL(5,2) NOT NULL DEFAULT 0,
    pattern_score DECIMAL(5,2) NOT NULL DEFAULT 0,
    consistency_score DECIMAL(5,2) NOT NULL DEFAULT 0,
    trap_score DECIMAL(5,2) NOT NULL DEFAULT 0,
    bot_score DECIMAL(5,2) NOT NULL DEFAULT 0,
    gibberish_score DECIMAL(5,2) NOT NULL DEFAULT 0,
    longstring_score DECIMAL(5,2) NOT NULL DEFAULT 0,
    outlier_score DECIMAL(5,2) NOT NULL DEFAULT 0,
    emoji_score DECIMAL(5,2) NOT NULL DEFAULT 0,
    profanity_score DECIMAL(5,2) NOT NULL DEFAULT 0,
    speed_bump_score DECIMAL(5,2) NOT NULL DEFAULT 0,
    is_auto_rejected TINYINT(1) NOT NULL DEFAULT 0,
    researcher_verdict ENUM('pending','accepted','rejected') NOT NULL DEFAULT 'pending',
    notes TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (response_id) REFERENCES responses(id) ON DELETE CASCADE,
    INDEX idx_overall (overall_score),
    INDEX idx_verdict (researcher_verdict)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS api_tokens (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    token VARCHAR(128) NOT NULL UNIQUE,
    permissions JSON NOT NULL,
    expires_at DATETIME NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_token (token)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS export_history (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    survey_id INT UNSIGNED NOT NULL,
    format ENUM('csv','json') NOT NULL,
    filter_criteria JSON NULL,
    file_path VARCHAR(500) NULL,
    row_count INT UNSIGNED NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (survey_id) REFERENCES surveys(id) ON DELETE CASCADE,
    INDEX idx_user (user_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS behavioral_logs (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    response_id INT UNSIGNED NOT NULL,
    event_type VARCHAR(50) NOT NULL,
    event_data JSON NULL,
    timestamp_ms BIGINT UNSIGNED NOT NULL DEFAULT 0,
    question_index INT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (response_id) REFERENCES responses(id) ON DELETE CASCADE,
    INDEX idx_response (response_id),
    INDEX idx_event_type (event_type),
    INDEX idx_response_event (response_id, event_type)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS reputation_history (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    response_id INT UNSIGNED NULL,
    survey_id INT UNSIGNED NULL,
    old_score DECIMAL(5,2) NOT NULL,
    new_score DECIMAL(5,2) NOT NULL,
    change_reason VARCHAR(255) NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (response_id) REFERENCES responses(id) ON DELETE SET NULL,
    FOREIGN KEY (survey_id) REFERENCES surveys(id) ON DELETE SET NULL,
    INDEX idx_user (user_id),
    INDEX idx_response (response_id),
    INDEX idx_user_created (user_id, created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS research_projects (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    researcher_id INT UNSIGNED NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (researcher_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_researcher (researcher_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS research_project_surveys (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    project_id INT UNSIGNED NOT NULL,
    survey_id INT UNSIGNED NOT NULL,
    import_config JSON NULL,
    imported_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES research_projects(id) ON DELETE CASCADE,
    FOREIGN KEY (survey_id) REFERENCES surveys(id) ON DELETE CASCADE,
    INDEX idx_project (project_id),
    INDEX idx_survey (survey_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS research_visualizations (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    project_id INT UNSIGNED NOT NULL,
    name VARCHAR(255) NOT NULL,
    chart_type VARCHAR(50) NOT NULL,
    chart_config JSON NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES research_projects(id) ON DELETE CASCADE,
    INDEX idx_project (project_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS survey_urls (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    survey_id INT UNSIGNED NOT NULL,
    short_code VARCHAR(100) NULL,
    custom_slug VARCHAR(100) NULL,
    slug VARCHAR(100) NULL UNIQUE,
    full_url VARCHAR(500) NULL,
    qr_code_path VARCHAR(500) NULL,
    use_count INT UNSIGNED NOT NULL DEFAULT 0,
    click_count INT UNSIGNED NOT NULL DEFAULT 0,
    utm_source VARCHAR(100) NULL,
    utm_medium VARCHAR(100) NULL,
    utm_campaign VARCHAR(100) NULL,
    utm_content VARCHAR(100) NULL,
    utm_term VARCHAR(100) NULL,
    password VARCHAR(255) NULL,
    max_uses INT UNSIGNED NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    expires_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (survey_id) REFERENCES surveys(id) ON DELETE CASCADE,
    INDEX idx_survey (survey_id),
    INDEX idx_slug (slug)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS animation_presets (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    key_name VARCHAR(50) NOT NULL UNIQUE,
    label VARCHAR(100) NOT NULL,
    category ENUM('entrance','exit','emphasis','special') NOT NULL,
    css_class VARCHAR(100) NOT NULL,
    duration_ms INT UNSIGNED NOT NULL DEFAULT 500,
    description TEXT NULL,
    is_premium TINYINT(1) NOT NULL DEFAULT 0,
    sort_order INT UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB;
