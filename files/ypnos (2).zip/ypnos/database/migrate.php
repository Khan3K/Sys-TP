<?php
// Resrch Schema Migration
// Run: php database/migrate.php
//
// Applies the unified schema.sql to create/update all tables.
// Safe to run multiple times — uses IF NOT EXISTS / IF EXISTS.

$config = require __DIR__ . '/../config/database.php';

try {
    $pdo = new PDO(
        "mysql:host={$config['host']};port={$config['port']};charset={$config['charset']}",
        $config['username'], $config['password'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$config['dbname']}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $pdo->exec("USE `{$config['dbname']}`");
} catch (PDOException $e) {
    echo "Error connecting: " . $e->getMessage() . "\n";
    exit(1);
}

$schema = file_get_contents(__DIR__ . '/schema.sql');
$statements = explode(';', $schema);

$count = 0;
foreach ($statements as $stmt) {
    $stmt = trim($stmt);
    if (empty($stmt)) continue;
    try {
        $pdo->exec($stmt);
        $count++;
    } catch (PDOException $e) {
        if (str_contains($e->getMessage(), 'Base table or view already exists') ||
            str_contains($e->getMessage(), 'Duplicate column name') ||
            str_contains($e->getMessage(), 'Duplicate entry')) {
            echo "SKIP: " . substr($stmt, 0, 70) . "...\n";
        } else {
            echo "ERROR: " . $e->getMessage() . "\n";
        }
    }
}

// Fix existing columns that may have stricter constraints than the final schema
$fixes = [
    "ALTER TABLE survey_urls MODIFY slug VARCHAR(100) NULL",
    "ALTER TABLE survey_urls MODIFY full_url VARCHAR(500) NULL",
];
foreach ($fixes as $sql) {
    try {
        $pdo->exec($sql);
        echo "OK: " . $sql . "\n";
        $count++;
    } catch (PDOException $e) {
        echo "SKIP: " . $e->getMessage() . "\n";
    }
}

echo "\nMigration complete. {$count} statements executed.\n";
