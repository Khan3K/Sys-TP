<?php
$config = require __DIR__ . '/../config/database.php';
$pdo = new PDO("mysql:host={$config['host']};port={$config['port']};charset={$config['charset']}", $config['username'], $config['password'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
$pdo->exec("USE `{$config['dbname']}`");

$changes = [
    "ALTER TABLE surveys ADD COLUMN min_reputation DECIMAL(5,2) NOT NULL DEFAULT 0 AFTER quality_threshold",
    "CREATE TABLE IF NOT EXISTS reputation_history (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id INT UNSIGNED NOT NULL,
        response_id INT UNSIGNED NULL,
        survey_id INT UNSIGNED NULL,
        old_score DECIMAL(5,2) NOT NULL,
        new_score DECIMAL(5,2) NOT NULL,
        change_reason VARCHAR(255) NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (response_id) REFERENCES responses(id) ON DELETE SET NULL,
        FOREIGN KEY (survey_id) REFERENCES surveys(id) ON DELETE SET NULL,
        INDEX idx_user (user_id),
        INDEX idx_response (response_id)
    ) ENGINE=InnoDB",
];

foreach ($changes as $sql) {
    try {
        $pdo->exec($sql);
        echo "OK: " . substr($sql, 0, 60) . "...\n";
    } catch (Exception $e) {
        echo "Note: " . $e->getMessage() . "\n";
    }
}

// Set initial reputation for seed users
$pdo->exec("UPDATE users SET reputation_score = 50 WHERE role = 'respondent'");
$pdo->exec("UPDATE users SET reputation_score = 80 WHERE role = 'researcher'");
$pdo->exec("UPDATE users SET reputation_score = 100 WHERE role = 'admin'");

echo "Reputations initialized.\n";
echo "Done.\n";