<?php

spl_autoload_register(function ($class) {
    $map = [
        'Core\\' => 'src/Core/',
        'Controllers\\' => 'src/Controllers/',
        'Quality\\' => 'src/Quality/',
        'Quality\\Checks\\' => 'src/Quality/Checks/',
        'Helpers\\' => 'src/Helpers/',
        'Services\\' => 'src/Services/',
    ];
    foreach ($map as $prefix => $dir) {
        if (strncmp($class, $prefix, strlen($prefix)) === 0) {
            $file = __DIR__ . '/' . $dir . substr($class, strlen($prefix)) . '.php';
            if (file_exists($file)) { require $file; return; }
        }
    }
});

$config = require __DIR__ . '/config/app.php';
$dbConfig = require __DIR__ . '/config/database.php';

// Enforce HTTPS in production
if (!empty($config['force_https']) && empty($_SERVER['HTTPS']) && (!isset($_SERVER['HTTP_X_FORWARDED_PROTO']) || $_SERVER['HTTP_X_FORWARDED_PROTO'] !== 'https')) {
    $redirect = 'https://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . ($_SERVER['REQUEST_URI'] ?? '');
    header('HTTP/1.1 301 Moved Permanently');
    header("Location: {$redirect}");
    exit;
}

// Secure session configuration
ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');
ini_set('session.cookie_httponly', '1');
ini_set('session.cookie_samesite', 'Lax');
ini_set('session.gc_maxlifetime', strval($config['session_lifetime'] ?? 86400));
if (!empty($_SERVER['HTTPS']) || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https')) {
    ini_set('session.cookie_secure', '1');
}
session_start();
date_default_timezone_set($config['timezone']);

// Regenerate session ID periodically to prevent fixation
if (!isset($_SESSION['_created'])) {
    $_SESSION['_created'] = time();
} elseif (time() - $_SESSION['_created'] > 3600) {
    session_regenerate_id(true);
    $_SESSION['_created'] = time();
}

\Core\Database::init($dbConfig);

function url(string $path = ''): string
{
    static $base = null;
    if ($base === null) {
        $cfg = require __DIR__ . '/config/app.php';
        $base = $cfg['base_url'] ?? '';
    }
    return $base . '/' . ltrim($path, '/');
}

function old(string $key, string $default = ''): string
{
    return htmlspecialchars($_POST[$key] ?? $default);
}

function csrf(): string
{
    return \Core\Csrf::field();
}

function help(string $text): string
{
    return '<span class="help-icon" data-tip="' . htmlspecialchars($text) . '"><i class="fas fa-question"></i></span>';
}

$router = new Core\Router();
$router->load();
