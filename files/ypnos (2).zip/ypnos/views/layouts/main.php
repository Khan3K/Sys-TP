<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle ?? 'Resrch') ?> — Resrch</title>
    <link rel="icon" href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>📋</text></svg>">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <?php
    $_navUri = $_SERVER['REQUEST_URI'] ?? '';
    $_navBase = rtrim(url(''), '/');
    $_navPath = parse_url($_navUri, PHP_URL_PATH);
    if ($_navBase && strpos($_navPath, $_navBase) === 0) $_navPath = substr($_navPath, strlen($_navBase));
    $_navActiveFn = function($route) use (&$_navPath) { return $_navPath === $route || strpos($_navPath, $route . '/') === 0; };
    $_navExactFn = function($route) use (&$_navPath) { return $_navPath === $route; };
    ?>
    <script>
    tailwind.config = {
        theme: {
            extend: {
                colors: {
                    primary: {50:'#eef2ff',100:'#e0e7ff',200:'#c7d2fe',300:'#a5b4fc',400:'#818cf8',500:'#6366f1',600:'#4f46e5',700:'#4338ca',800:'#3730a3',900:'#312e81'},
                }
            }
        }
    }
    </script>
    <style>
    body { font-family: 'Inter', system-ui, -apple-system, sans-serif; }
    .active-nav { background: rgba(99,102,241,0.1); color: #4f46e5; }

    /* Animations */
    .fade-in { animation: fadeIn 0.3s ease-in-out; }
    @keyframes fadeIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }
    .slide-in { animation: slideIn 0.3s ease-out; }
    @keyframes slideIn { from { opacity: 0; transform: translateX(-10px); } to { opacity: 1; transform: translateX(0); } }
    .slide-up { animation: slideUp 0.4s cubic-bezier(0.4, 0, 0.2, 1); }
    @keyframes slideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
    .scale-in { animation: scaleIn 0.3s cubic-bezier(0.4, 0, 0.2, 1); }
    @keyframes scaleIn { from { opacity: 0; transform: scale(0.95); } to { opacity: 1; transform: scale(1); } }

    /* Enhanced animations */
    .animate-fade-in { animation: animateFadeIn 0.5s ease-out forwards; opacity: 0; }
    @keyframes animateFadeIn { from { opacity: 0; transform: translateY(12px); } to { opacity: 1; transform: translateY(0); } }
    .animate-fade-in-up { animation: animateFadeInUp 0.5s ease-out forwards; opacity: 0; }
    @keyframes animateFadeInUp { from { opacity: 0; transform: translateY(24px); } to { opacity: 1; transform: translateY(0); } }
    .animate-scale-in { animation: animateScaleIn 0.35s cubic-bezier(0.4, 0, 0.2, 1) forwards; }
    @keyframes animateScaleIn { from { opacity: 0; transform: scale(0.92) translateY(10px); } to { opacity: 1; transform: scale(1) translateY(0); } }
    .animate-spin { animation: spin 0.8s linear infinite; }
    @keyframes spin { to { transform: rotate(360deg); } }
    .animate-pulse-soft { animation: pulseSoft 2s ease-in-out infinite; }
    @keyframes pulseSoft { 0%, 100% { opacity: 1; } 50% { opacity: 0.6; } }

    /* Glassmorphism */
    .glass {
        background: rgba(255, 255, 255, 0.65);
        backdrop-filter: blur(16px);
        -webkit-backdrop-filter: blur(16px);
        border: 1px solid rgba(255, 255, 255, 0.4);
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.04);
    }
    .glass-card {
        background: rgba(255, 255, 255, 0.7);
        backdrop-filter: blur(20px);
        -webkit-backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.5);
        box-shadow: 0 8px 32px rgba(99, 102, 241, 0.06);
        transition: all 0.3s ease;
    }
    .glass-card:hover {
        background: rgba(255, 255, 255, 0.85);
        box-shadow: 0 12px 40px rgba(99, 102, 241, 0.12);
        transform: translateY(-1px);
    }
    .glass-dark {
        background: rgba(17, 24, 39, 0.6);
        backdrop-filter: blur(16px);
        -webkit-backdrop-filter: blur(16px);
        border: 1px solid rgba(255, 255, 255, 0.08);
    }
    .glass-input {
        background: rgba(255, 255, 255, 0.5);
        backdrop-filter: blur(8px);
        -webkit-backdrop-filter: blur(8px);
        border: 1px solid rgba(255, 255, 255, 0.6);
    }
    .glass-input:focus {
        background: rgba(255, 255, 255, 0.8);
        box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.15);
    }

    /* Tooltip / Help Icon */
    .help-icon {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 18px;
        height: 18px;
        border-radius: 50%;
        background: rgba(99, 102, 241, 0.08);
        color: #818cf8;
        font-size: 10px;
        cursor: help;
        transition: all 0.2s ease;
        position: relative;
        flex-shrink: 0;
    }
    .help-icon:hover {
        background: rgba(99, 102, 241, 0.2);
        color: #4f46e5;
        transform: scale(1.1);
    }
    .help-icon::after {
        content: attr(data-tip);
        position: absolute;
        bottom: calc(100% + 8px);
        left: 50%;
        transform: translateX(-50%) translateY(4px);
        background: rgba(15, 23, 42, 0.95);
        backdrop-filter: blur(12px);
        color: #f1f5f9;
        padding: 10px 14px;
        border-radius: 10px;
        font-size: 12px;
        line-height: 1.5;
        font-weight: 400;
        white-space: normal;
        width: max-content;
        max-width: 280px;
        pointer-events: none;
        opacity: 0;
        transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
        z-index: 100;
        border: 1px solid rgba(255, 255, 255, 0.1);
        box-shadow: 0 12px 40px rgba(0, 0, 0, 0.25);
        text-align: left;
    }
    .help-icon:hover::after {
        opacity: 1;
        transform: translateX(-50%) translateY(0);
    }
    .help-icon::before {
        content: '';
        position: absolute;
        bottom: calc(100% + 4px);
        left: 50%;
        transform: translateX(-50%) translateY(4px);
        border: 6px solid transparent;
        border-top-color: rgba(15, 23, 42, 0.95);
        pointer-events: none;
        opacity: 0;
        transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
        z-index: 100;
    }
    .help-icon:hover::before {
        opacity: 1;
        transform: translateX(-50%) translateY(0);
    }

    /* Segments / Tabs */
    .segment-tabs {
        display: flex;
        gap: 2px;
        background: rgba(0, 0, 0, 0.03);
        border-radius: 12px;
        padding: 3px;
        overflow-x: auto;
    }
    .segment-tab {
        padding: 8px 16px;
        border-radius: 10px;
        font-size: 13px;
        font-weight: 500;
        color: #64748b;
        transition: all 0.2s ease;
        white-space: nowrap;
        display: flex;
        align-items: center;
        gap: 6px;
    }
    .segment-tab:hover {
        color: #1e293b;
        background: rgba(255, 255, 255, 0.5);
    }
    .segment-tab.active {
        color: #4f46e5;
        background: rgba(255, 255, 255, 0.9);
        box-shadow: 0 1px 4px rgba(0, 0, 0, 0.06);
    }

    /* Feature search */
    .feature-search {
        transition: all 0.3s ease;
    }
    .feature-search:focus {
        box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.15);
    }
    .feature-card {
        transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .feature-card.hidden-feature {
        display: none;
    }
    .feature-card.highlight {
        box-shadow: 0 0 0 2px rgba(99, 102, 241, 0.3);
        border-color: #818cf8;
    }

    /* Template cards */
    .template-card {
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        cursor: pointer;
    }
    .template-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 16px 48px rgba(0, 0, 0, 0.08);
    }
    .template-card.selected {
        border-color: #6366f1;
        box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.2);
    }

    /* Question slide animation */
    .question-slide {
        transition: all 0.5s cubic-bezier(0.4, 0, 0.2, 1);
    }
    .question-slide-enter {
        opacity: 0;
        transform: translateX(40px) scale(0.97);
    }
    .question-slide-active {
        opacity: 1;
        transform: translateX(0) scale(1);
    }
    .question-slide-exit {
        opacity: 0;
        transform: translateX(-40px) scale(0.97);
    }

    /* Star rating */
    .star-rating input:checked ~ label i { color: #facc15; }
    .star-rating label:hover i { color: #facc15; }
    .tooltip { position: relative; }
    .tooltip:hover::after { content: attr(data-tip); position: absolute; bottom: 100%; left: 50%; transform: translateX(-50%); background: #1f2937; color: white; padding: 4px 8px; border-radius: 6px; font-size: 12px; white-space: nowrap; z-index: 10; }
    @media (max-width: 640px) { .mobile-hide { display: none !important; } }
    @keyframes flashTimer { from { width: 100%; } to { width: 0%; } }
    @keyframes float { 0%, 100% { transform: translateY(0px); } 50% { transform: translateY(-6px); } }
    .animate-float { animation: float 3s ease-in-out infinite; }
    .safe-area-bottom { padding-bottom: env(safe-area-inset-bottom, 0px); }
    .scroll-top-btn { transition: all 0.3s cubic-bezier(0.4,0,0.2,1); }
    .scroll-top-btn:hover { transform: translateY(-2px); box-shadow: 0 8px 24px rgba(99,102,241,0.3); }
    @keyframes loaderBar { 0% { width: 0%; margin-left: 0; } 50% { width: 70%; margin-left: 15%; } 100% { width: 0%; margin-left: 100%; } }
    </style>
</head>
<body class="bg-gradient-to-br from-gray-50 via-indigo-50/30 to-purple-50/30 min-h-screen antialiased">
    <nav class="glass sticky top-0 z-50 border-b border-gray-200/50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <a href="<?= url('/dashboard') ?>" class="flex items-center gap-2">
                        <span class="w-8 h-8 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-lg flex items-center justify-center text-white text-sm font-bold shadow-md">R</span>
                        <span class="text-xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">Resrch</span>
                    </a>
                    <?php if (\Core\Auth::check()): ?>
                        <div class="ml-8 hidden md:flex space-x-1">
                            <a href="<?= url('/dashboard') ?>" class="px-3 py-2 text-sm font-medium rounded-lg transition-colors <?= $_navActiveFn('/dashboard') && !$_navActiveFn('/admin') ? 'bg-indigo-50 text-indigo-700' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100' ?>">
                                <i class="fas fa-th-large mr-1.5"></i>Dashboard
                            </a>
                            <?php if (\Core\Auth::isResearcher()): ?>
                                <a href="<?= url('/survey/create') ?>" class="px-3 py-2 text-sm font-medium rounded-lg transition-colors <?= $_navActiveFn('/survey/create') ? 'bg-indigo-50 text-indigo-700' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100' ?>">
                                    <i class="fas fa-plus-circle mr-1.5"></i>Create
                                </a>
                                <a href="<?= url('/templates') ?>" class="px-3 py-2 text-sm font-medium rounded-lg transition-colors <?= $_navActiveFn('/template') ? 'bg-indigo-50 text-indigo-700' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100' ?>">
                                    <i class="fas fa-layer-group mr-1.5"></i>Templates
                                </a>
                                <a href="<?= url('/research') ?>" class="px-3 py-2 text-sm font-medium rounded-lg transition-colors <?= $_navActiveFn('/research') ? 'bg-indigo-50 text-indigo-700' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100' ?>">
                                    <i class="fas fa-flask mr-1.5"></i>Research
                                </a>
                            <?php endif; ?>
                            <?php if (\Core\Auth::isAdmin()): ?>
                                <a href="<?= url('/admin/users') ?>" class="px-3 py-2 text-sm font-medium rounded-lg transition-colors <?= $_navActiveFn('/admin') ? 'bg-indigo-50 text-indigo-700' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100' ?>">
                                    <i class="fas fa-users-cog mr-1.5"></i>Admin
                                </a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="flex items-center gap-2 sm:gap-3">
                    <?php if (\Core\Auth::check()): ?>
                        <?php if (\Core\Auth::isRespondent()): ?>
                            <div class="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-amber-50 to-yellow-50 border border-amber-200/50 rounded-full glass">
                                <i class="fas fa-star text-amber-500 text-xs"></i>
                                <span class="text-sm font-semibold text-amber-700"><?= number_format((float)(\Core\Auth::user()['reputation_score'] ?? 0), 1) ?></span>
                            </div>
                        <?php endif; ?>
                        <div class="flex items-center gap-2">
                            <span class="hidden sm:block text-sm text-gray-600 font-medium truncate max-w-[120px]"><?= htmlspecialchars(\Core\Auth::user()['full_name'] ?? '') ?></span>
                            <span class="px-2 py-0.5 text-xs rounded-full font-medium
                                <?= \Core\Auth::isAdmin() ? 'bg-red-50 text-red-700 border border-red-200' : (\Core\Auth::isResearcher() ? 'bg-blue-50 text-blue-700 border border-blue-200' : 'bg-green-50 text-green-700 border border-green-200') ?>">
                                <?= \Core\Auth::role() === 'researcher' ? 'Researcher' : (\Core\Auth::role() === 'admin' ? 'Admin' : 'Respondent') ?>
                            </span>
                        </div>
                        <div class="flex items-center gap-1">
                            <a href="<?= url('/profile') ?>" class="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors tooltip" data-tip="Profile">
                                <i class="fas fa-user-cog text-sm"></i>
                            </a>
                            <a href="<?= url('/logout') ?>" class="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors tooltip" data-tip="Logout">
                                <i class="fas fa-sign-out-alt text-sm"></i>
                            </a>
                        </div>
                    <?php else: ?>
                        <a href="<?= url('/login') ?>" class="text-sm font-medium text-gray-600 hover:text-gray-900 px-3 py-2">Login</a>
                        <a href="<?= url('/register') ?>" class="text-sm font-medium bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition-colors shadow-sm">Register</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <!-- Admin Segment Nav -->
    <?php if (\Core\Auth::isAdmin() && $_navActiveFn('/admin')): ?>
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4">
        <div class="segment-tabs">
            <a href="<?= url('/admin/dashboard') ?>" class="segment-tab <?= $_navExactFn('/admin/dashboard') || $_navExactFn('/admin') ? 'active' : '' ?>">
                <i class="fas fa-chart-pie"></i> Dashboard
            </a>
            <a href="<?= url('/admin/users') ?>" class="segment-tab <?= $_navActiveFn('/admin/users') ? 'active' : '' ?>">
                <i class="fas fa-users"></i> Users
            </a>
            <a href="<?= url('/admin/surveys') ?>" class="segment-tab <?= $_navActiveFn('/admin/surveys') ? 'active' : '' ?>">
                <i class="fas fa-clipboard-list"></i> Surveys
            </a>
            <a href="<?= url('/admin/templates') ?>" class="segment-tab <?= $_navActiveFn('/admin/templates') ? 'active' : '' ?>">
                <i class="fas fa-layer-group"></i> Templates
            </a>
            <a href="<?= url('/admin/settings') ?>" class="segment-tab <?= $_navActiveFn('/admin/settings') ? 'active' : '' ?>">
                <i class="fas fa-cog"></i> Settings
            </a>
            <a href="<?= url('/admin/logs') ?>" class="segment-tab <?= $_navActiveFn('/admin/logs') ? 'active' : '' ?>">
                <i class="fas fa-history"></i> Logs
            </a>
        </div>
    </div>
    <?php endif; ?>

    <!-- Researcher Segment Nav -->
    <?php if (\Core\Auth::isResearcher() && !$_navActiveFn('/admin')): ?>
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4">
        <div class="segment-tabs">
            <a href="<?= url('/dashboard') ?>" class="segment-tab <?= $_navActiveFn('/dashboard') && !$_navActiveFn('/survey') ? 'active' : '' ?>">
                <i class="fas fa-th-large"></i> Dashboard
            </a>
            <a href="<?= url('/survey/create') ?>" class="segment-tab <?= $_navActiveFn('/survey/create') ? 'active' : '' ?>">
                <i class="fas fa-plus-circle"></i> Create
            </a>
            <a href="<?= url('/templates') ?>" class="segment-tab <?= $_navActiveFn('/template') ? 'active' : '' ?>">
                <i class="fas fa-layer-group"></i> Templates
            </a>
            <a href="<?= url('/research') ?>" class="segment-tab <?= $_navActiveFn('/research') ? 'active' : '' ?>">
                <i class="fas fa-flask"></i> Research Ground
            </a>
            <?php if (!empty($survey) && !empty($survey['id'])): ?>
                <span class="segment-tab text-gray-300 cursor-default"><i class="fas fa-chevron-right text-xs"></i></span>
                <span class="segment-tab text-gray-500">
                    <i class="fas fa-pen"></i> <?= htmlspecialchars(mb_substr($survey['title'] ?? 'Edit', 0, 20)) ?>
                </span>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- Mobile bottom nav -->
    <?php if (\Core\Auth::check()): ?>
    <div class="fixed bottom-0 left-0 right-0 bg-white/90 backdrop-blur-xl border-t border-gray-200 md:hidden z-50 safe-area-bottom">
        <div class="flex justify-around py-1.5">
            <a href="<?= url('/dashboard') ?>" class="flex flex-col items-center px-2 py-1 text-xs <?= $_navActiveFn('/dashboard') && !$_navActiveFn('/survey') && !$_navActiveFn('/admin') ? 'text-indigo-600' : 'text-gray-500' ?>">
                <i class="fas fa-th-large text-lg"></i>
                <span class="mt-0.5">Home</span>
            </a>
            <?php if (\Core\Auth::isResearcher()): ?>
                <a href="<?= url('/survey/create') ?>" class="flex flex-col items-center px-2 py-1 text-xs <?= $_navActiveFn('/survey/create') ? 'text-indigo-600' : 'text-gray-500' ?>">
                    <i class="fas fa-plus-circle text-lg"></i>
                    <span class="mt-0.5">New</span>
                </a>
                <a href="<?= url('/templates') ?>" class="flex flex-col items-center px-2 py-1 text-xs <?= $_navActiveFn('/template') ? 'text-indigo-600' : 'text-gray-500' ?>">
                    <i class="fas fa-layer-group text-lg"></i>
                    <span class="mt-0.5">Templates</span>
                </a>
                <a href="<?= url('/research') ?>" class="flex flex-col items-center px-2 py-1 text-xs <?= $_navActiveFn('/research') ? 'text-indigo-600' : 'text-gray-500' ?>">
                    <i class="fas fa-flask text-lg"></i>
                    <span class="mt-0.5">Research</span>
                </a>
            <?php endif; ?>
            <?php if (\Core\Auth::isAdmin()): ?>
                <a href="<?= url('/admin/dashboard') ?>" class="flex flex-col items-center px-2 py-1 text-xs <?= $_navActiveFn('/admin') ? 'text-indigo-600' : 'text-gray-500' ?>">
                    <i class="fas fa-shield-alt text-lg"></i>
                    <span class="mt-0.5">Admin</span>
                </a>
            <?php endif; ?>
            <a href="<?= url('/profile') ?>" class="flex flex-col items-center px-2 py-1 text-xs <?= $_navActiveFn('/profile') ? 'text-indigo-600' : 'text-gray-500' ?>">
                <i class="fas fa-user text-lg"></i>
                <span class="mt-0.5">Profile</span>
            </a>
        </div>
    </div>
    <?php endif; ?>

    <!-- Flash Messages -->
    <?php if (\Core\Session::hasFlash()): ?>
        <?php foreach (\Core\Session::getFlash() as $flash): ?>
            <div class="flash-msg max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-4 fade-in">
                <div class="glass-card p-4 rounded-xl shadow-sm border relative overflow-hidden <?= ($flash['type'] ?? '') === 'success' ? 'border-emerald-200/50' : (($flash['type'] ?? '') === 'danger' ? 'border-red-200/50' : (($flash['type'] ?? '') === 'warning' ? 'border-amber-200/50' : 'border-blue-200/50')) ?>">
                    <div class="flex items-center gap-2">
                        <i class="fas <?= ($flash['type'] ?? '') === 'success' ? 'fa-check-circle text-emerald-500' : (($flash['type'] ?? '') === 'danger' ? 'fa-exclamation-circle text-red-500' : (($flash['type'] ?? '') === 'warning' ? 'fa-exclamation-triangle text-amber-500' : 'fa-info-circle text-blue-500')) ?>"></i>
                        <span class="text-sm font-medium text-gray-800 flex-1"><?= htmlspecialchars($flash['message'] ?? '') ?></span>
                        <button onclick="this.closest('.flash-msg').remove()" class="text-gray-400 hover:text-gray-600 p-1">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <div class="flash-timer absolute bottom-0 left-0 h-0.5 bg-current opacity-20" style="animation: flashTimer 5s linear forwards;"></div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 <?php if (\Core\Auth::check()) echo 'pb-20 md:pb-6'; ?>" id="main-content">
        <?php if (isset($_content)): ?>
            <div class="fade-in">
                <?php $_content(); ?>
            </div>
        <?php endif; ?>
    </main>

    <!-- Back to top -->
    <!-- Page loading bar -->
    <div id="page-loader" class="fixed top-0 left-0 right-0 h-0.5 z-50 pointer-events-none opacity-0 transition-opacity duration-200">
        <div class="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500" style="animation: loaderBar 1.5s ease-in-out infinite;"></div>
    </div>

    <button id="scroll-top-btn" onclick="window.scrollTo({top:0,behavior:'smooth'})" class="scroll-top-btn fixed bottom-24 md:bottom-8 right-6 w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-600 to-purple-600 text-white shadow-lg flex items-center justify-center opacity-0 translate-y-4 pointer-events-none transition-all z-40">
        <i class="fas fa-arrow-up text-sm"></i>
    </button>

    <script>
    // Page loader — show on link clicks, hide when ready
    (function() {
        var loader = document.getElementById('page-loader');
        if (!loader) return;
        var timeout;
        function showLoader() { loader.style.opacity = '1'; }
        function hideLoader() { loader.style.opacity = '0'; }
        // Show briefly on page load, then hide
        showLoader();
        clearTimeout(timeout);
        timeout = setTimeout(hideLoader, 400);
        // Show on navigation clicks
        document.addEventListener('click', function(e) {
            var a = e.target.closest('a');
            if (a && a.href && a.href.indexOf(window.location.origin) === 0 && !a.getAttribute('target') && !a.getAttribute('download') && !e.ctrlKey && !e.metaKey) {
                // Allow browser to navigate
                setTimeout(showLoader, 100);
            }
        });
    })();

    // Auto-dismiss flash messages after 5s
    document.querySelectorAll('.flash-msg').forEach(function(el) {
        setTimeout(function() {
            if (el.parentNode) {
                el.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
                el.style.opacity = '0';
                el.style.transform = 'translateY(-8px)';
                setTimeout(function() { if (el.parentNode) el.remove(); }, 300);
            }
        }, 5000);
    });

    // Back to top button visibility
    var scrollBtn = document.getElementById('scroll-top-btn');
    if (scrollBtn) {
        window.addEventListener('scroll', function() {
            if (window.scrollY > 400) {
                scrollBtn.style.opacity = '1';
                scrollBtn.style.transform = 'translateY(0)';
                scrollBtn.style.pointerEvents = 'auto';
            } else {
                scrollBtn.style.opacity = '0';
                scrollBtn.style.transform = 'translateY(4px)';
                scrollBtn.style.pointerEvents = 'none';
            }
        });
    }

    // Smooth scroll for all internal anchor links
    document.querySelectorAll('a[href^="#"]').forEach(function(a) {
        a.addEventListener('click', function(e) {
            var target = document.querySelector(this.getAttribute('href'));
            if (target) { e.preventDefault(); target.scrollIntoView({ behavior: 'smooth' }); }
        });
    });

    // Close flash on outside click
    document.addEventListener('click', function(e) {
        if (e.target.closest('.flash-msg .flash-timer')) {
            e.target.closest('.flash-msg').remove();
        }
    });
    </script>

    <?php if (\Core\Auth::check()): ?>
    <footer class="hidden md:block border-t border-gray-200/50 mt-12 py-6 glass">
        <div class="max-w-7xl mx-auto px-4 text-center text-gray-400 text-xs">
            &copy; <?= date('Y') ?> Resrch — Research Survey Platform. All rights reserved.
            <span class="mx-2">·</span>
            <a href="#" class="hover:text-gray-600">Privacy</a>
            <span class="mx-2">·</span>
            <a href="#" class="hover:text-gray-600">Terms</a>
        </div>
    </footer>
    <?php endif; ?>
</body>
</html>
