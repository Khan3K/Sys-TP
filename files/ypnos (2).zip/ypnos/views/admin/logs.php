<div class="max-w-5xl mx-auto space-y-6">
    <div class="slide-up">
        <h1 class="text-2xl font-bold text-gray-900">Admin Logs</h1>
        <p class="text-gray-500 text-sm mt-1">Audit trail of administrative actions (<?= $total ?> entries)</p>
    </div>

    <div class="glass-card rounded-2xl overflow-hidden">
        <?php if (empty($logs)): ?>
        <div class="p-10 text-center">
            <div class="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <i class="fas fa-clipboard-list text-2xl text-gray-400"></i>
            </div>
            <p class="text-gray-600 font-medium">No log entries yet</p>
            <p class="text-gray-400 text-sm mt-1">Administrative actions will appear here.</p>
        </div>
        <?php else: ?>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="border-b border-gray-100 bg-gray-50/50">
                        <th class="text-left p-3 font-semibold text-gray-600">Time</th>
                        <th class="text-left p-3 font-semibold text-gray-600">Admin</th>
                        <th class="text-left p-3 font-semibold text-gray-600">Action</th>
                        <th class="text-left p-3 font-semibold text-gray-600">Details</th>
                        <th class="text-left p-3 font-semibold text-gray-600">IP</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-50">
                    <?php foreach ($logs as $log): ?>
                    <tr class="hover:bg-gray-50/50 transition-colors">
                        <td class="p-3 text-gray-500 whitespace-nowrap text-xs">
                            <?= date('M j, g:ia', strtotime(($log['created_at'] ?? ''))) ?>
                        </td>
                        <td class="p-3">
                            <div class="text-gray-800 font-medium"><?= htmlspecialchars($log['admin_name'] ?? 'Unknown') ?></div>
                            <div class="text-xs text-gray-400"><?= htmlspecialchars($log['admin_email'] ?? '') ?></div>
                        </td>
                        <td class="p-3">
                            <span class="px-2 py-0.5 text-xs rounded-full
                                <?= strpos(($log['action'] ?? ''), 'deleted') !== false ? 'bg-red-50 text-red-700 border border-red-200' : '' ?>
                                <?= strpos(($log['action'] ?? ''), 'created') !== false || strpos(($log['action'] ?? ''), 'approved') !== false ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : '' ?>
                                <?= strpos(($log['action'] ?? ''), 'rejected') !== false || strpos(($log['action'] ?? ''), 'deactivated') !== false ? 'bg-amber-50 text-amber-700 border border-amber-200' : '' ?>
                                <?= strpos(($log['action'] ?? ''), 'activated') !== false ? 'bg-blue-50 text-blue-700 border border-blue-200' : '' ?>
                                <?= strpos(($log['action'] ?? ''), 'deleted') === false && strpos(($log['action'] ?? ''), 'created') === false && strpos(($log['action'] ?? ''), 'approved') === false && strpos(($log['action'] ?? ''), 'rejected') === false && strpos(($log['action'] ?? ''), 'deactivated') === false && strpos(($log['action'] ?? ''), 'activated') === false ? 'bg-gray-100 text-gray-700' : '' ?>">
                                <?= htmlspecialchars(str_replace('_', ' ', ($log['action'] ?? ''))) ?>
                            </span>
                        </td>
                        <td class="p-3 text-gray-600 text-xs max-w-xs truncate">
                            <?php
                                $details = json_decode(($log['details_json'] ?? '{}'), true);
                                if ($details) {
                                    echo htmlspecialchars(implode(', ', array_map(function($k, $v) {
                                        return $k . ': ' . $v;
                                    }, array_keys($details), $details)));
                                } else {
                                    echo '-';
                                }
                            ?>
                        </td>
                        <td class="p-3 text-gray-400 text-xs font-mono">
                            <?= htmlspecialchars($log['ip_address'] ?? '-') ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>

    <?php if ($totalPages > 1): ?>
    <div class="flex items-center justify-center gap-2">
        <?php for ($p = 1; $p <= $totalPages; $p++): ?>
            <a href="<?= url('/admin/logs?page=' . $p) ?>"
               class="px-3 py-1.5 rounded-lg text-sm transition-colors <?= $p === $page ? 'bg-indigo-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200' ?>">
                <?= $p ?>
            </a>
        <?php endfor; ?>
    </div>
    <?php endif; ?>
</div>
