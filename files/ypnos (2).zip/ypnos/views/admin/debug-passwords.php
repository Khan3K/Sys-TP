<div class="max-w-lg mx-auto">
    <div class="mb-6">
        <h1 class="text-2xl font-bold text-gray-900">
            <i class="fas fa-key text-red-500 mr-2"></i>Debug: Password Reset
        </h1>
        <p class="text-sm text-gray-500 mt-1">Immediately change any user's password. Use with caution.</p>
    </div>

    <form method="POST" action="<?= url('/admin/debug/passwords') ?>" class="glass-card rounded-2xl p-6">
        <?= csrf() ?>

        <div class="mb-5">
            <label class="block text-sm font-medium text-gray-700 mb-1.5">Select User</label>
            <select name="user_id" required
                class="glass-input w-full px-4 py-2.5 rounded-xl focus:ring-2 focus:ring-indigo-500 text-sm"
                onchange="document.getElementById('userInfo').classList.toggle('hidden', !this.value)">
                <option value="">-- Choose a user --</option>
                <?php foreach ($users as $u): ?>
                    <option value="<?= $u['id'] ?>"
                        data-role="<?= htmlspecialchars($u['role']) ?>"
                        data-email="<?= htmlspecialchars($u['email']) ?>"
                        data-name="<?= htmlspecialchars($u['full_name']) ?>"
                        data-active="<?= $u['is_active'] ?>">
                        <?= htmlspecialchars($u['full_name'] ?: $u['email']) ?> (<?= htmlspecialchars($u['role']) ?>)
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div id="userInfo" class="hidden mb-5 p-3 bg-gray-50 rounded-xl text-sm">
            <div class="grid grid-cols-2 gap-2">
                <span class="text-gray-500">Name:</span>
                <span id="infoName" class="font-medium"></span>
                <span class="text-gray-500">Email:</span>
                <span id="infoEmail" class="font-medium"></span>
                <span class="text-gray-500">Role:</span>
                <span id="infoRole" class="font-medium"></span>
                <span class="text-gray-500">Active:</span>
                <span id="infoActive" class="font-medium"></span>
            </div>
        </div>

        <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700 mb-1">New Password</label>
            <input type="password" name="password" required minlength="6"
                class="glass-input w-full px-4 py-2.5 rounded-xl focus:ring-2 focus:ring-red-500 text-sm"
                placeholder="Min. 6 characters" autocomplete="new-password">
        </div>

        <div class="mb-6">
            <label class="block text-sm font-medium text-gray-700 mb-1">Confirm Password</label>
            <input type="password" name="password_confirm" required minlength="6"
                class="glass-input w-full px-4 py-2.5 rounded-xl focus:ring-2 focus:ring-red-500 text-sm"
                placeholder="Repeat password" autocomplete="new-password">
        </div>

        <div class="flex items-center gap-3 p-3 bg-red-50 border border-red-200 rounded-xl mb-5">
            <i class="fas fa-exclamation-triangle text-red-500"></i>
            <p class="text-xs text-red-700">This immediately changes the user's password. No confirmation will be sent to them. This action is logged.</p>
        </div>

        <button type="submit"
            class="w-full bg-gradient-to-r from-red-600 to-rose-600 text-white py-2.5 rounded-xl hover:from-red-700 hover:to-rose-700 transition-all font-medium shadow-sm">
            <i class="fas fa-key mr-2"></i>Reset Password
        </button>
    </form>
</div>

<script>
document.querySelector('select[name="user_id"]').addEventListener('change', function() {
    var opt = this.options[this.selectedIndex];
    if (!this.value) { return; }
    document.getElementById('infoName').textContent = opt.dataset.name || '(no name)';
    document.getElementById('infoEmail').textContent = opt.dataset.email;
    document.getElementById('infoRole').textContent = opt.dataset.role;
    document.getElementById('infoActive').textContent = opt.dataset.active === '1' ? 'Yes' : 'No';
});
</script>
