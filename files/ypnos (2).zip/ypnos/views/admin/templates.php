<div class="max-w-6xl mx-auto space-y-6">
    <!-- Header -->
    <div class="flex items-center justify-between flex-wrap gap-4 slide-up">
        <div>
            <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-gray-100/80 border border-gray-200 text-gray-600 text-xs font-medium mb-2">
                <i class="fas fa-shield-alt text-gray-500"></i>
                Administration &middot; Template Management
            </div>
            <h1 class="text-2xl font-bold text-gray-900">Survey Templates</h1>
            <p class="text-gray-500 text-sm mt-0.5">Manage platform survey templates — view structure, quality presets, and usage</p>
        </div>
        <div class="flex gap-2">
            <button onclick="window.location='<?= url('/survey/create') ?>'" class="px-4 py-2 bg-indigo-600 text-white text-sm font-medium rounded-xl hover:bg-indigo-700 transition-all shadow-sm inline-flex items-center gap-1.5">
                <i class="fas fa-plus"></i> New Survey
            </button>
        </div>
    </div>

    <!-- Overview Stats -->
    <?php
    $cats = \Helpers\SurveyTemplates::categories();
    $totalQuestions = array_sum(array_map(function($t) { return count($t['questions'] ?? []); }, $templates));
    $totalQcFeatures = array_sum(array_map(function($t) { return count(array_filter($t['quality'] ?? [], fn($v) => is_bool($v) && $v)); }, $templates));
    $avgAccuracy = round(array_sum(array_map(fn($t) => $t['accuracy_score'] ?? 0, $templates)) / max(count($templates), 1));
    ?>
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 animate-fade-in-up" style="animation-delay:0.1s">
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center text-blue-600"><i class="fas fa-layer-group"></i></div>
                <div>
                    <div class="text-2xl font-bold text-gray-900"><?= count($templates) ?></div>
                    <div class="text-xs text-gray-500">Total Templates</div>
                </div>
            </div>
        </div>
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-emerald-50 flex items-center justify-center text-emerald-600"><i class="fas fa-question-circle"></i></div>
                <div>
                    <div class="text-2xl font-bold text-gray-900"><?= $totalQuestions ?></div>
                    <div class="text-xs text-gray-500">Total Questions</div>
                </div>
            </div>
        </div>
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-purple-50 flex items-center justify-center text-purple-600"><i class="fas fa-shield-alt"></i></div>
                <div>
                    <div class="text-2xl font-bold text-gray-900"><?= $totalQcFeatures ?></div>
                    <div class="text-xs text-gray-500">Active QC Features</div>
                </div>
            </div>
        </div>
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-amber-50 flex items-center justify-center text-amber-600"><i class="fas fa-chart-line"></i></div>
                <div>
                    <div class="text-2xl font-bold text-gray-900"><?= $avgAccuracy ?>%</div>
                    <div class="text-xs text-gray-500">Avg Accuracy Score</div>
                </div>
            </div>
        </div>
    </div>

    <!-- Templates Table -->
    <div class="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden animate-fade-in-up" style="animation-delay:0.15s">
        <div class="p-4 border-b border-gray-100 flex items-center justify-between">
            <h2 class="font-semibold text-gray-900"><i class="fas fa-list mr-2 text-gray-400"></i>Template Registry</h2>
            <span class="text-xs text-gray-400"><?= count($templates) ?> entries</span>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="bg-gray-50/80 border-b border-gray-100">
                        <th class="text-left p-3 font-semibold text-gray-600">Template</th>
                        <th class="text-left p-3 font-semibold text-gray-600">Category</th>
                        <th class="text-center p-3 font-semibold text-gray-600">Questions</th>
                        <th class="text-center p-3 font-semibold text-gray-600">Difficulty</th>
                        <th class="text-center p-3 font-semibold text-gray-600">Accuracy</th>
                        <th class="text-center p-3 font-semibold text-gray-600">Time</th>
                        <th class="text-center p-3 font-semibold text-gray-600">Active QC</th>
                        <th class="text-center p-3 font-semibold text-gray-600">Popularity</th>
                        <th class="text-center p-3 font-semibold text-gray-600">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-50">
                    <?php foreach ($templates as $key => $tpl): ?>
                    <?php
                        $color = $tpl['color'] ?? 'gray';
                        $catInfo = $cats[$tpl['category'] ?? 'feedback'] ?? ['label' => 'General', 'icon' => 'fa-folder'];
                        $diffInfo = \Helpers\SurveyTemplates::difficultyLevels()[$tpl['difficulty'] ?? 'easy'];
                        $qCount = count($tpl['questions'] ?? []);
                        $accScore = $tpl['accuracy_score'] ?? 85;
                        $qcCount = count(array_filter($tpl['quality'] ?? [], fn($v) => is_bool($v) && $v));
                        $tags = $tpl['tags'] ?? [];
                    ?>
                    <tr class="hover:bg-gray-50/50 transition-colors">
                        <td class="p-3">
                            <div class="flex items-center gap-3">
                                <div class="w-9 h-9 rounded-lg bg-gradient-to-br from-<?= $color ?>-50 to-<?= $color ?>-100 flex items-center justify-center flex-shrink-0">
                                    <i class="fas <?= $tpl['icon'] ?? 'fa-file' ?> text-<?= $color ?>-600 text-sm"></i>
                                </div>
                                <div>
                                    <span class="font-medium text-gray-900"><?= htmlspecialchars($tpl['name'] ?? '') ?></span>
                                    <div class="flex items-center gap-1 mt-0.5">
                                        <?php foreach (array_slice($tags, 0, 2) as $tag): ?>
                                        <span class="text-[10px] px-1.5 py-0.5 rounded bg-gray-100 text-gray-500">#<?= $tag ?></span>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td class="p-3">
                            <span class="px-2 py-0.5 text-xs rounded-full bg-gray-100 text-gray-600 border border-gray-200">
                                <i class="fas <?= $catInfo['icon'] ?> mr-1"></i><?= $catInfo['label'] ?>
                            </span>
                        </td>
                        <td class="p-3 text-center font-mono text-gray-700"><?= $qCount ?></td>
                        <td class="p-3 text-center">
                            <span class="inline-flex items-center gap-1 text-xs font-medium <?= $diffInfo['color'] ?>">
                                <i class="fas <?= $diffInfo['icon'] ?>"></i><?= $diffInfo['label'] ?>
                            </span>
                        </td>
                        <td class="p-3 text-center">
                            <div class="flex items-center justify-center gap-2">
                                <div class="w-16 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                                    <div class="h-full rounded-full <?= \Helpers\SurveyTemplates::accuracyBar($accScore) ?>" style="width:<?= $accScore ?>%"></div>
                                </div>
                                <span class="text-xs font-bold <?= \Helpers\SurveyTemplates::accuracyColor($accScore) ?>"><?= $accScore ?>%</span>
                            </div>
                        </td>
                        <td class="p-3 text-center font-mono text-gray-600"><?= $tpl['estimated_minutes'] ?? 3 ?>m</td>
                        <td class="p-3 text-center">
                            <span class="px-2 py-0.5 text-xs rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200 font-medium"><?= $qcCount ?></span>
                        </td>
                        <td class="p-3 text-center">
                            <?php if (($tpl['popularity'] ?? '') === 'high'): ?>
                            <span class="inline-flex items-center gap-1 text-xs font-medium text-amber-600"><i class="fas fa-fire"></i>Popular</span>
                            <?php else: ?>
                            <span class="text-xs text-gray-400">Standard</span>
                            <?php endif; ?>
                        </td>
                        <td class="p-3 text-center">
                            <a href="<?= url('/survey/create') ?>?template=<?= $key ?>" class="px-3 py-1.5 text-xs bg-<?= $color ?>-600 text-white rounded-lg hover:bg-<?= $color ?>-700 transition-colors inline-flex items-center gap-1 shadow-sm">
                                <i class="fas fa-external-link-alt text-[10px]"></i> Use
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Category Breakdown -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 animate-fade-in-up" style="animation-delay:0.2s">
        <?php foreach ($cats as $ck => $cv): ?>
        <?php
            $catTemplates = array_filter($templates, fn($t) => ($t['category'] ?? 'feedback') === $ck);
            $catQ = array_sum(array_map(fn($t) => count($t['questions'] ?? []), $catTemplates));
            $catAcc = count($catTemplates) > 0 ? round(array_sum(array_map(fn($t) => $t['accuracy_score'] ?? 0, $catTemplates)) / count($catTemplates)) : 0;
        ?>
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-5 hover:shadow-md transition-shadow">
            <div class="flex items-center gap-3 mb-3">
                <div class="w-10 h-10 rounded-xl bg-<?= $cv['color'] ?>-50 flex items-center justify-center text-<?= $cv['color'] ?>-600">
                    <i class="fas <?= $cv['icon'] ?>"></i>
                </div>
                <div>
                    <h3 class="font-semibold text-gray-900"><?= $cv['label'] ?></h3>
                    <p class="text-xs text-gray-500"><?= count($catTemplates) ?> templates</p>
                </div>
            </div>
            <div class="space-y-2">
                <div class="flex justify-between text-xs"><span class="text-gray-500">Questions</span><span class="font-medium text-gray-700"><?= $catQ ?></span></div>
                <div class="flex justify-between text-xs"><span class="text-gray-500">Avg Accuracy</span><span class="font-medium <?= \Helpers\SurveyTemplates::accuracyColor($catAcc) ?>"><?= $catAcc ?>%</span></div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
