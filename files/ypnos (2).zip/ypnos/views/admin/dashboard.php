<div class="space-y-6">
    <h1 class="text-2xl font-bold text-gray-900">Admin Dashboard</h1>

    <!-- Stats Grid -->
    <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <div class="glass-card rounded-xl p-4">
            <p class="text-sm text-gray-500">Total Users</p>
            <p class="text-2xl font-bold text-gray-900"><?= $stats['total_users'] ?? 0 ?></p>
        </div>
        <div class="glass-card rounded-xl p-4">
            <p class="text-sm text-gray-500">Researchers</p>
            <p class="text-2xl font-bold text-blue-600"><?= $stats['researchers'] ?? 0 ?></p>
        </div>
        <div class="glass-card rounded-xl p-4">
            <p class="text-sm text-gray-500">Respondents</p>
            <p class="text-2xl font-bold text-green-600"><?= $stats['respondents'] ?? 0 ?></p>
        </div>
        <div class="glass-card rounded-xl p-4">
            <p class="text-sm text-gray-500">Total Surveys</p>
            <p class="text-2xl font-bold text-gray-900"><?= $stats['total_surveys'] ?? 0 ?></p>
        </div>
        <div class="glass-card rounded-xl p-4">
            <p class="text-sm text-gray-500">Active Surveys</p>
            <p class="text-2xl font-bold text-green-600"><?= $stats['active_surveys'] ?? 0 ?></p>
        </div>
        <div class="glass-card rounded-xl p-4">
            <p class="text-sm text-gray-500">Total Responses</p>
            <p class="text-2xl font-bold text-indigo-600"><?= $stats['total_responses'] ?? 0 ?></p>
        </div>
    </div>

    <!-- Recent Users & Surveys -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Recent Users -->
        <div class="glass-card overflow-hidden">
            <div class="p-4 border-b border-gray-100/50 flex items-center justify-between">
                <h2 class="font-semibold text-gray-900">Recent Users</h2>
                <a href="<?= url('/admin/users') ?>" class="text-sm text-indigo-600 hover:underline">View All</a>
            </div>
            <div class="divide-y divide-gray-50">
                <?php foreach ($recentUsers as $u): ?>
                    <div class="p-3 flex items-center justify-between hover:bg-gray-50/30 transition-colors">
                        <div>
                            <p class="font-medium text-sm"><?= htmlspecialchars($u['full_name'] ?? ($u['email'] ?? '')) ?></p>
                            <p class="text-xs text-gray-500"><?= htmlspecialchars($u['email'] ?? '') ?></p>
                        </div>
                        <span class="text-xs px-2 py-0.5 rounded-full 
                            <?= ($u['role'] ?? '') === 'admin' ? 'bg-red-100 text-red-800' : (($u['role'] ?? '') === 'researcher' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800') ?>">
                            <?= $u['role'] ?? '' ?>
                        </span>
                    </div>
                <?php endforeach; ?>
                <?php if (empty($recentUsers)): ?>
                    <p class="p-4 text-sm text-gray-400 text-center">No users yet.</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Recent Surveys -->
        <div class="glass-card overflow-hidden">
            <div class="p-4 border-b border-gray-100/50 flex items-center justify-between">
                <h2 class="font-semibold text-gray-900">Recent Surveys</h2>
                <a href="<?= url('/admin/surveys') ?>" class="text-sm text-indigo-600 hover:underline">View All</a>
            </div>
            <div class="divide-y divide-gray-50">
                <?php foreach ($recentSurveys as $s): ?>
                    <div class="p-3 hover:bg-gray-50/30 transition-colors">
                        <p class="font-medium text-sm"><?= htmlspecialchars($s['title'] ?? '') ?></p>
                        <div class="flex items-center gap-2 mt-1">
                            <span class="text-xs text-gray-500">by <?= htmlspecialchars($s['researcher_name'] ?? '') ?></span>
                            <span class="text-xs px-2 py-0.5 rounded-full
                                <?= ($s['status'] ?? '') === 'active' ? 'bg-green-100 text-green-800' : (($s['status'] ?? '') === 'draft' ? 'bg-gray-100 text-gray-800' : 'bg-yellow-100 text-yellow-800') ?>">
                                <?= $s['status'] ?? '' ?>
                            </span>
                        </div>
                    </div>
                <?php endforeach; ?>
                <?php if (empty($recentSurveys)): ?>
                    <p class="p-4 text-sm text-gray-400 text-center">No surveys yet.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
