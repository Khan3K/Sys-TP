<div class="space-y-6">
    <h1 class="text-2xl font-bold text-gray-900">All Surveys</h1>

    <div class="glass-card rounded-2xl overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="border-b border-gray-100 bg-gray-50/30">
                        <th class="text-left p-3 font-semibold text-gray-600">Title</th>
                        <th class="text-left p-3 font-semibold text-gray-600">Researcher</th>
                        <th class="text-left p-3 font-semibold text-gray-600">Status</th>
                        <th class="text-left p-3 font-semibold text-gray-600">Responses</th>
                        <th class="text-left p-3 font-semibold text-gray-600">Threshold</th>
                        <th class="text-left p-3 font-semibold text-gray-600">Created</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-50">
                    <?php foreach ($surveys as $s): ?>
                        <tr class="hover:bg-gray-50/30 transition-colors">
                            <td class="p-3 font-medium"><?= htmlspecialchars($s['title'] ?? '') ?></td>
                            <td class="p-3 text-gray-500"><?= htmlspecialchars($s['researcher_name'] ?? '') ?></td>
                            <td class="p-3">
                                <span class="px-2 py-0.5 text-xs rounded-full 
                                    <?= ($s['status'] ?? '') === 'active' ? 'bg-green-100 text-green-800' : (($s['status'] ?? '') === 'draft' ? 'bg-gray-100 text-gray-800' : (($s['status'] ?? '') === 'closed' ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800')) ?>">
                                    <?= $s['status'] ?? '' ?>
                                </span>
                            </td>
                            <td class="p-3"><?= $s['response_count'] ?? 0 ?></td>
                            <td class="p-3"><?= $s['quality_threshold'] ?? '70' ?></td>
                            <td class="p-3 text-gray-500 text-xs"><?= date('M j, Y', strtotime(($s['created_at'] ?? ''))) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
