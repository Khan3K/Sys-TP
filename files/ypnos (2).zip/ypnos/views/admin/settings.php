<div class="max-w-3xl mx-auto space-y-6">
    <div class="slide-up">
        <h1 class="text-2xl font-bold text-gray-900">System Settings</h1>
        <p class="text-gray-500 text-sm mt-1">Manage application configuration</p>
    </div>

    <?php $config = require __DIR__ . '/../../config/app.php'; ?>

    <div class="glass-card rounded-2xl p-6">
        <h2 class="text-lg font-bold text-gray-900 mb-4"><i class="fas fa-cog text-indigo-500 mr-2"></i>General</h2>
        <form method="POST" action="<?= url('/admin/settings') ?>">
            <?= csrf() ?>

            <div class="space-y-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Application Name</label>
                    <input type="text" name="app_name" value="<?= htmlspecialchars($config['app_name'] ?? 'Resrch') ?>" required maxlength="100"
                        class="glass-input w-full px-4 py-2.5 rounded-xl focus:ring-2 focus:ring-indigo-500 text-sm">
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">Base URL</label>
                        <input type="text" value="<?= htmlspecialchars($config['base_url'] ?? '/dashboard/ypnos') ?>" readonly disabled
                            class="glass-input w-full px-4 py-2.5 rounded-xl text-sm bg-gray-50 text-gray-500 cursor-not-allowed">
                        <p class="text-xs text-gray-400 mt-1">Change via config/app.php</p>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">Environment</label>
                        <input type="text" value="<?= htmlspecialchars($config['env'] ?? 'production') ?>" readonly disabled
                            class="glass-input w-full px-4 py-2.5 rounded-xl text-sm bg-gray-50 text-gray-500 cursor-not-allowed">
                    </div>
                </div>
            </div>

            <div class="mt-6 pt-5 border-t border-gray-100">
                <h3 class="text-sm font-bold text-gray-800 mb-3">Quality Defaults</h3>
                <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Quality Threshold</label>
                        <input type="number" value="<?= $config['quality']['default_threshold'] ?? 70 ?>" readonly disabled
                            class="glass-input w-full px-4 py-2 rounded-xl text-sm bg-gray-50 text-gray-500 cursor-not-allowed">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Min Time (sec)</label>
                        <input type="number" value="<?= $config['quality']['min_time_seconds'] ?? 30 ?>" readonly disabled
                            class="glass-input w-full px-4 py-2 rounded-xl text-sm bg-gray-50 text-gray-500 cursor-not-allowed">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Min Text Length</label>
                        <input type="number" value="<?= $config['quality']['min_text_length'] ?? 10 ?>" readonly disabled
                            class="glass-input w-full px-4 py-2 rounded-xl text-sm bg-gray-50 text-gray-500 cursor-not-allowed">
                    </div>
                </div>
            </div>

            <div class="mt-6 pt-5 border-t border-gray-100">
                <h3 class="text-sm font-bold text-gray-800 mb-3">Reputation</h3>
                <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Initial Score</label>
                        <input type="number" value="<?= $config['reputation']['initial'] ?? 50 ?>" readonly disabled
                            class="glass-input w-full px-4 py-2 rounded-xl text-sm bg-gray-50 text-gray-500 cursor-not-allowed">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Bonus per Good Response</label>
                        <input type="number" value="<?= $config['reputation']['bonus_per_response'] ?? 2 ?>" readonly disabled
                            class="glass-input w-full px-4 py-2 rounded-xl text-sm bg-gray-50 text-gray-500 cursor-not-allowed">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Penalty per Flagged</label>
                        <input type="number" value="<?= $config['reputation']['penalty_per_flag'] ?? 10 ?>" readonly disabled
                            class="glass-input w-full px-4 py-2 rounded-xl text-sm bg-gray-50 text-gray-500 cursor-not-allowed">
                    </div>
                </div>
                <p class="text-xs text-gray-400 mt-2">Reputation settings are configurable via config/app.php</p>
            </div>

            <button type="submit" class="mt-6 bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-8 py-2.5 rounded-xl hover:from-indigo-700 hover:to-purple-700 transition-all font-medium text-sm shadow-sm">
                <i class="fas fa-save mr-2"></i>Save Settings
            </button>
        </form>
    </div>

    <div class="glass-card rounded-2xl p-6">
        <h2 class="text-lg font-bold text-gray-900 mb-4"><i class="fas fa-info-circle text-indigo-500 mr-2"></i>System Info</h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
            <div class="flex justify-between p-3 bg-gray-50 rounded-xl">
                <span class="text-gray-500">PHP Version</span>
                <span class="font-mono text-gray-800"><?= phpversion() ?></span>
            </div>
            <div class="flex justify-between p-3 bg-gray-50 rounded-xl">
                <span class="text-gray-500">Database</span>
                <span class="font-mono text-gray-800">MySQL (PDO)</span>
            </div>
            <div class="flex justify-between p-3 bg-gray-50 rounded-xl">
                <span class="text-gray-500">Server</span>
                <span class="font-mono text-gray-800"><?= $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown' ?></span>
            </div>
            <div class="flex justify-between p-3 bg-gray-50 rounded-xl">
                <span class="text-gray-500">Document Root</span>
                <span class="font-mono text-gray-800 text-xs truncate"><?= $_SERVER['DOCUMENT_ROOT'] ?? 'Unknown' ?></span>
            </div>
        </div>
    </div>
</div>
