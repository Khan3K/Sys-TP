<div class="max-w-lg mx-auto">
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-2xl font-bold text-gray-900">Create User Account</h1>
        <a href="<?= url('/admin/users') ?>" class="text-sm text-indigo-600 hover:underline">&larr; Back to Users</a>
    </div>

    <div class="glass-card rounded-2xl p-6">
        <form method="POST" action="<?= url('/admin/users/create') ?>">
          <?= csrf() ?>
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                <input type="text" name="full_name" required
                    class="glass-input w-full px-4 py-2.5 rounded-xl focus:ring-2 focus:ring-indigo-500 text-sm"
                    placeholder="John Doe">
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <input type="email" name="email" required
                    class="glass-input w-full px-4 py-2.5 rounded-xl focus:ring-2 focus:ring-indigo-500 text-sm"
                    placeholder="user@example.com">
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-1">Password</label>
                <input type="password" name="password" required minlength="6"
                    class="glass-input w-full px-4 py-2.5 rounded-xl focus:ring-2 focus:ring-indigo-500 text-sm"
                    placeholder="Min. 6 characters">
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Account Type</label>
                <div class="grid grid-cols-2 gap-3">
                    <label class="flex items-center justify-center p-4 border-2 rounded-xl cursor-pointer transition-all has-[:checked]:border-indigo-500 has-[:checked]:bg-indigo-50 border-gray-200 hover:border-gray-300">
                        <input type="radio" name="role" value="respondent" checked class="sr-only">
                        <div class="text-center">
                            <i class="fas fa-pen-fancy text-xl text-indigo-600 mb-1"></i>
                            <div class="text-sm font-medium">Respondent</div>
                            <div class="text-xs text-gray-500">Take surveys</div>
                        </div>
                    </label>
                    <label class="flex items-center justify-center p-4 border-2 rounded-xl cursor-pointer transition-all has-[:checked]:border-purple-500 has-[:checked]:bg-purple-50 border-gray-200 hover:border-gray-300">
                        <input type="radio" name="role" value="researcher" class="sr-only">
                        <div class="text-center">
                            <i class="fas fa-flask text-xl text-purple-600 mb-1"></i>
                            <div class="text-sm font-medium">Researcher</div>
                            <div class="text-xs text-gray-500">Create surveys</div>
                        </div>
                    </label>
                </div>
            </div>
            <div class="mb-6">
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Approval Status</label>
                <div class="grid grid-cols-3 gap-2">
                    <label class="flex items-center justify-center p-2.5 border-2 rounded-xl cursor-pointer transition-all has-[:checked]:border-green-500 has-[:checked]:bg-green-50 border-gray-200 hover:border-gray-300">
                        <input type="radio" name="approval_status" value="approved" checked class="sr-only">
                        <span class="text-sm font-medium text-green-700">Approved</span>
                    </label>
                    <label class="flex items-center justify-center p-2.5 border-2 rounded-xl cursor-pointer transition-all has-[:checked]:border-amber-500 has-[:checked]:bg-amber-50 border-gray-200 hover:border-gray-300">
                        <input type="radio" name="approval_status" value="pending" class="sr-only">
                        <span class="text-sm font-medium text-amber-700">Pending</span>
                    </label>
                    <label class="flex items-center justify-center p-2.5 border-2 rounded-xl cursor-pointer transition-all has-[:checked]:border-red-500 has-[:checked]:bg-red-50 border-gray-200 hover:border-gray-300">
                        <input type="radio" name="approval_status" value="rejected" class="sr-only">
                        <span class="text-sm font-medium text-red-700">Rejected</span>
                    </label>
                </div>
            </div>
            <button type="submit" class="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-2.5 rounded-xl hover:from-indigo-700 hover:to-purple-700 transition-all font-medium shadow-sm">
                <i class="fas fa-user-plus mr-2"></i>Create Account
            </button>
        </form>
    </div>
</div>
