<div class="space-y-6">
    <div class="flex items-center justify-between flex-wrap gap-3">
        <h1 class="text-2xl font-bold text-gray-900">Manage Users</h1>
        <div class="flex items-center gap-3">
            <a href="<?= url('/admin/users/create') ?>" class="px-3 py-1.5 bg-indigo-600 text-white text-sm rounded-lg hover:bg-indigo-700 transition-colors">
                <i class="fas fa-plus mr-1"></i>Create User
            </a>
            <div class="flex gap-2 text-sm">
            <span class="px-3 py-1 bg-blue-100 text-blue-800 rounded-full"><?= ($stats['researchers'] ?? 0) ?> Researchers</span>
            <span class="px-3 py-1 bg-green-100 text-green-800 rounded-full"><?= ($stats['respondents'] ?? 0) ?> Respondents</span>
            <span class="px-3 py-1 bg-red-100 text-red-800 rounded-full"><?= ($stats['admins'] ?? 0) ?> Admins</span>
            <?php if (($stats['pending'] ?? 0) > 0): ?>
                <span class="px-3 py-1 bg-amber-100 text-amber-800 rounded-full animate-pulse"><?= ($stats['pending'] ?? 0) ?> Pending</span>
            <?php endif; ?>
        </div>
    </div>

    <!-- Filters -->
    <div class="flex gap-3 flex-wrap">
        <a href="<?= url('/admin/users') ?>" class="text-sm px-3 py-1.5 rounded-lg border <?= empty($roleFilter) && empty($approvalFilter) ? 'bg-indigo-50 border-indigo-300 text-indigo-700' : 'border-gray-300 text-gray-600 hover:bg-gray-50' ?>">All</a>
        <a href="<?= url('/admin/users?approval=pending') ?>" class="text-sm px-3 py-1.5 rounded-lg border <?= $approvalFilter === 'pending' ? 'bg-amber-50 border-amber-300 text-amber-700' : 'border-gray-300 text-gray-600 hover:bg-gray-50' ?>">Pending</a>
        <a href="<?= url('/admin/users?role=researcher') ?>" class="text-sm px-3 py-1.5 rounded-lg border <?= $roleFilter === 'researcher' ? 'bg-blue-50 border-blue-300 text-blue-700' : 'border-gray-300 text-gray-600 hover:bg-gray-50' ?>">Researchers</a>
        <a href="<?= url('/admin/users?role=respondent') ?>" class="text-sm px-3 py-1.5 rounded-lg border <?= $roleFilter === 'respondent' ? 'bg-green-50 border-green-300 text-green-700' : 'border-gray-300 text-gray-600 hover:bg-gray-50' ?>">Respondents</a>
    </div>

    <div class="glass-card rounded-2xl overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="border-b border-gray-100 bg-gray-50/30">
                        <th class="text-left p-3 font-semibold text-gray-600">Name</th>
                        <th class="text-left p-3 font-semibold text-gray-600">Email</th>
                        <th class="text-left p-3 font-semibold text-gray-600">Role</th>
                        <th class="text-left p-3 font-semibold text-gray-600">Status</th>
                        <th class="text-left p-3 font-semibold text-gray-600">Reputation</th>
                        <th class="text-left p-3 font-semibold text-gray-600">Active</th>
                        <th class="text-left p-3 font-semibold text-gray-600">Joined</th>
                        <th class="text-left p-3 font-semibold text-gray-600">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-50">
                    <?php foreach ($users as $u): ?>
                        <tr class="hover:bg-gray-50/30 transition-colors <?= ($u['approval_status'] ?? '') === 'pending' ? 'bg-amber-50/30' : (($u['approval_status'] ?? '') === 'rejected' ? 'bg-red-50/20' : '') ?>">
                            <td class="p-3 font-medium"><?= htmlspecialchars($u['full_name'] ?? '') ?></td>
                            <td class="p-3 text-gray-500"><?= htmlspecialchars($u['email'] ?? '') ?></td>
                            <td class="p-3">
                                <span class="px-2 py-0.5 text-xs rounded-full 
                                    <?= ($u['role'] ?? '') === 'admin' ? 'bg-red-100 text-red-800' : (($u['role'] ?? '') === 'researcher' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800') ?>">
                                    <?= $u['role'] ?? '' ?>
                                </span>
                            </td>
                            <td class="p-3">
                                <?php if (($u['approval_status'] ?? '') === 'pending'): ?>
                                    <span class="px-2 py-0.5 text-xs rounded-full bg-amber-100 text-amber-800">Pending</span>
                                <?php elseif (($u['approval_status'] ?? '') === 'rejected'): ?>
                                    <span class="px-2 py-0.5 text-xs rounded-full bg-red-100 text-red-800">Rejected</span>
                                <?php else: ?>
                                    <span class="px-2 py-0.5 text-xs rounded-full bg-green-100 text-green-800">Approved</span>
                                <?php endif; ?>
                            </td>
                            <td class="p-3"><?= $u['reputation_score'] ?? 0 ?></td>
                            <td class="p-3">
                                <span class="<?= !empty($u['is_active']) ? 'text-green-600' : 'text-red-600' ?>">
                                    <?= !empty($u['is_active']) ? 'Yes' : 'No' ?>
                                </span>
                            </td>
                            <td class="p-3 text-gray-500 text-xs"><?= date('M j, Y', strtotime(($u['created_at'] ?? ''))) ?></td>
                            <td class="p-3">
                                <div class="flex items-center gap-2 flex-wrap">
                                    <?php if (($u['role'] ?? '') !== 'admin'): ?>
                                        <?php if (($u['approval_status'] ?? '') === 'pending'): ?>
                                            <form method="POST" action="<?= url('/admin/users/approve/' . ($u['id'] ?? '')) ?>">
                                              <?= csrf() ?>
                                                <button type="submit" class="text-xs px-2 py-1 bg-green-100 text-green-700 rounded hover:bg-green-200 transition-colors">Approve</button>
                                            </form>
                                            <form method="POST" action="<?= url('/admin/users/reject/' . ($u['id'] ?? '')) ?>">
                                              <?= csrf() ?>
                                                <button type="submit" class="text-xs px-2 py-1 bg-red-100 text-red-700 rounded hover:bg-red-200 transition-colors">Reject</button>
                                            </form>
                                        <?php endif; ?>
                                        <form method="POST" action="<?= url('/admin/users/toggle/' . ($u['id'] ?? '')) ?>">
                                          <?= csrf() ?>
                                            <button type="submit" class="text-xs px-2 py-1 rounded border <?= !empty($u['is_active']) ? 'text-amber-700 border-amber-300 hover:bg-amber-50' : 'text-green-700 border-green-300 hover:bg-green-50' ?>">
                                                <?= !empty($u['is_active']) ? 'Deactivate' : 'Activate' ?>
                                            </button>
                                        </form>
                                        <form method="POST" action="<?= url('/admin/users/delete/' . ($u['id'] ?? '')) ?>" onsubmit="return confirm('Permanently delete this user and all their data?')">
                                          <?= csrf() ?>
                                            <button type="submit" class="text-xs px-2 py-1 bg-gray-100 text-gray-600 rounded hover:bg-red-100 hover:text-red-700 transition-colors">Delete</button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Pagination -->
    <?php if ($totalPages > 1): ?>
        <div class="flex justify-center gap-2">
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <a href="<?= url('/admin/users?page=' . $i . ($roleFilter ? '&role=' . $roleFilter : '') . ($approvalFilter ? '&approval=' . $approvalFilter : '')) ?>"
                   class="px-3 py-1.5 rounded-lg text-sm border <?= $i === $page ? 'bg-indigo-600 text-white border-indigo-600' : 'border-gray-300 text-gray-600 hover:bg-gray-50' ?>">
                    <?= $i ?>
                </a>
            <?php endfor; ?>
        </div>
    <?php endif; ?>
</div>
