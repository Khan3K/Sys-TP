<div class="max-w-3xl mx-auto space-y-6">
    <div class="flex items-center justify-between">
        <h1 class="text-2xl font-bold text-gray-900">Export Data</h1>
        <a href="<?= url('/survey/results/' . ($survey['id'] ?? '')) ?>" class="text-indigo-600 hover:underline">Back to Results</a>
    </div>

    <div class="grid grid-cols-2 gap-4">
        <div class="bg-white p-4 rounded-xl shadow-sm border">
            <div class="text-2xl font-bold text-gray-900"><?= $totalResponses ?></div>
            <div class="text-sm text-gray-500">Total Responses</div>
        </div>
        <div class="bg-white p-4 rounded-xl shadow-sm border">
            <div class="text-2xl font-bold text-green-600"><?= $qualityResponses ?></div>
            <div class="text-sm text-gray-500">Quality Responses (>= threshold)</div>
        </div>
    </div>

    <div class="bg-white rounded-xl shadow-sm border p-6">
        <h2 class="text-lg font-semibold mb-4">Export Options</h2>
        <form method="POST" action="<?= url('/export/' . ($survey['id'] ?? '')) ?>">
          <?= csrf() ?>
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">Format</label>
                <div class="grid grid-cols-2 gap-3">
                    <label class="border rounded-lg p-3 text-center cursor-pointer hover:border-indigo-500 has-[:checked]:border-indigo-500 has-[:checked]:bg-indigo-50">
                        <input type="radio" name="format" value="csv" checked class="sr-only">
                        <i class="fas fa-file-csv text-2xl text-green-600"></i>
                        <div class="text-sm mt-1">CSV</div>
                    </label>
                    <label class="border rounded-lg p-3 text-center cursor-pointer hover:border-indigo-500 has-[:checked]:border-indigo-500 has-[:checked]:bg-indigo-50">
                        <input type="radio" name="format" value="json" class="sr-only">
                        <i class="fas fa-file-code text-2xl text-blue-600"></i>
                        <div class="text-sm mt-1">JSON</div>
                    </label>
                </div>
            </div>

            <div class="mb-6">
                <label class="block text-sm font-medium text-gray-700 mb-2">Data Filter</label>
                <select name="quality_filter" class="w-full px-4 py-2 border rounded-lg">
                    <option value="all">All Responses</option>
                    <option value="quality_only">Quality Responses Only (>= threshold)</option>
                    <option value="flagged">Flagged Responses Only</option>
                </select>
            </div>

            <button type="submit" class="bg-indigo-600 text-white px-6 py-2 rounded-lg hover:bg-indigo-700">
                <i class="fas fa-download mr-2"></i>Generate Export
            </button>
        </form>
    </div>

    <div class="bg-white rounded-xl shadow-sm border">
        <div class="p-4 border-b">
            <h2 class="font-semibold">Export History</h2>
        </div>
        <?php
        $exports = \Core\Database::getInstance()->fetchAll(
            "SELECT * FROM export_history WHERE survey_id = ? ORDER BY created_at DESC LIMIT 10",
            [$survey['id'] ?? '']
        );
        ?>
        <?php if (empty($exports)): ?>
            <div class="p-4 text-center text-gray-500 text-sm">No exports yet</div>
        <?php else: ?>
            <div class="divide-y">
                <?php foreach ($exports as $e): ?>
                    <div class="p-3 flex items-center justify-between text-sm">
                        <div>
                            <span class="font-medium uppercase"><?= $e['format'] ?? '' ?></span>
                            <span class="text-gray-500 ml-2"><?= $e['row_count'] ?? '' ?> rows</span>
                        </div>
                        <div class="flex items-center gap-2">
                            <span class="text-gray-400"><?= $e['created_at'] ?? '' ?></span>
                            <?php if (!empty($e['file_path']) && file_exists($e['file_path'])): ?>
                                <a href="<?= url('/export/download/' . ($e['id'] ?? '')) ?>" class="text-indigo-600 hover:underline">Download</a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>
