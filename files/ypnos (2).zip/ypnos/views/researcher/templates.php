<div class="max-w-6xl mx-auto space-y-8">
    <!-- Hero Header -->
    <div class="slide-up text-center md:text-left">
        <div class="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-indigo-50/80 border border-indigo-200/50 text-indigo-700 text-xs font-medium mb-3 animate-fade-in">
            <i class="fas fa-sparkles text-indigo-500"></i>
            <?= count($templates) ?> professional templates
        </div>
        <h1 class="text-3xl sm:text-4xl font-bold text-gray-900 tracking-tight">Survey Templates</h1>
        <p class="text-gray-500 text-sm sm:text-base mt-2 max-w-2xl mx-auto md:mx-0">Choose a smart template with pre-built questions and quality protections for maximum data accuracy</p>
    </div>

    <!-- Category Filter Tabs -->
    <div class="flex flex-wrap gap-2 animate-fade-in-up" style="animation-delay:0.1s" id="category-filters">
        <button class="filter-btn px-4 py-2 text-sm font-medium rounded-xl transition-all duration-200 bg-gray-900 text-white shadow-md" data-category="all" onclick="filterTemplates('all', this)">
            <i class="fas fa-th-large mr-1.5"></i>All
        </button>
        <?php $cats = \Helpers\SurveyTemplates::categories(); ?>
        <?php foreach ($cats as $ck => $cv): ?>
        <button class="filter-btn px-4 py-2 text-sm font-medium rounded-xl transition-all duration-200 bg-gray-100 text-gray-600 hover:bg-gray-200 hover:text-gray-800" data-category="<?= $ck ?>" onclick="filterTemplates('<?= $ck ?>', this)">
            <i class="fas <?= $cv['icon'] ?> mr-1.5"></i><?= $cv['label'] ?>
        </button>
        <?php endforeach; ?>
    </div>

    <!-- Stats Bar -->
    <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 animate-fade-in-up" style="animation-delay:0.15s">
        <div class="glass-card rounded-xl p-4 text-center">
            <div class="text-2xl font-bold text-gray-900"><?= count($templates) ?></div>
            <div class="text-xs text-gray-500 mt-0.5">Templates</div>
        </div>
        <div class="glass-card rounded-xl p-4 text-center">
            <div class="text-2xl font-bold text-emerald-600"><?= array_sum(array_map(function($t) { return count($t['questions'] ?? []); }, $templates)) ?></div>
            <div class="text-xs text-gray-500 mt-0.5">Total Questions</div>
        </div>
        <div class="glass-card rounded-xl p-4 text-center">
            <div class="text-2xl font-bold text-amber-600"><?= count(array_filter($templates, fn($t) => ($t['difficulty'] ?? 'easy') === 'hard')) ?></div>
            <div class="text-xs text-gray-500 mt-0.5">Rigorous</div>
        </div>
        <div class="glass-card rounded-xl p-4 text-center">
            <div class="text-2xl font-bold text-blue-600"><?= round(array_sum(array_map(fn($t) => $t['accuracy_score'] ?? 0, $templates)) / max(count($templates), 1)) ?>%</div>
            <div class="text-xs text-gray-500 mt-0.5">Avg Accuracy</div>
        </div>
    </div>

    <!-- Template Grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6" id="template-grid">
        <?php $delay = 0.2; ?>
        <?php foreach ($templates as $key => $tpl): ?>
        <?php
            $catInfo = $cats[$tpl['category'] ?? 'feedback'] ?? ['label' => 'General', 'icon' => 'fa-folder', 'color' => 'gray'];
            $diffInfo = \Helpers\SurveyTemplates::difficultyLevels()[$tpl['difficulty'] ?? 'easy'];
            $qCount = count($tpl['questions'] ?? []);
            $color = $tpl['color'] ?? 'gray';
            $accScore = $tpl['accuracy_score'] ?? 85;
            $accColor = \Helpers\SurveyTemplates::accuracyColor($accScore);
            $accBg = \Helpers\SurveyTemplates::accuracyBg($accScore);
            $accBar = \Helpers\SurveyTemplates::accuracyBar($accScore);
        ?>
        <div class="template-card rounded-2xl bg-white border border-gray-200/80 overflow-hidden hover:shadow-xl hover:border-<?= $color ?>-300/50 transition-all duration-300 animate-fade-in-up cursor-pointer group" style="animation-delay:<?= $delay ?>s" data-category="<?= $tpl['category'] ?? 'feedback' ?>" onclick="openPreview('<?= $key ?>')">
            <!-- Top accent bar -->
            <div class="h-1.5 bg-gradient-to-r from-<?= $color ?>-500 to-<?= $color ?>-400"></div>

            <div class="p-5 sm:p-6">
                <!-- Header -->
                <div class="flex items-start gap-4">
                    <div class="w-14 h-14 rounded-2xl bg-gradient-to-br from-<?= $color ?>-50 to-<?= $color ?>-100 flex items-center justify-center flex-shrink-0 shadow-sm group-hover:scale-110 transition-transform duration-300">
                        <i class="fas <?= $tpl['icon'] ?? 'fa-file' ?> text-<?= $color ?>-600 text-xl"></i>
                    </div>
                    <div class="flex-1 min-w-0">
                        <div class="flex items-center gap-2 flex-wrap">
                            <h3 class="text-lg font-bold text-gray-900 group-hover:text-<?= $color ?>-700 transition-colors"><?= htmlspecialchars($tpl['name'] ?? '') ?></h3>
                            <span class="px-2 py-0.5 text-[10px] font-semibold rounded-full uppercase tracking-wider <?= $catInfo['color'] === 'purple' ? 'bg-purple-50 text-purple-700 border border-purple-200' : ($catInfo['color'] === 'blue' ? 'bg-blue-50 text-blue-700 border border-blue-200' : 'bg-emerald-50 text-emerald-700 border border-emerald-200') ?>">
                                <?= $catInfo['label'] ?>
                            </span>
                        </div>
                        <p class="text-sm text-gray-500 mt-1 line-clamp-2 leading-relaxed"><?= htmlspecialchars($tpl['description'] ?? '') ?></p>
                    </div>
                </div>

                <!-- Meta row -->
                <div class="flex items-center gap-3 mt-4 flex-wrap text-xs text-gray-500">
                    <span class="inline-flex items-center gap-1"><i class="far fa-file-alt text-gray-400"></i><?= $qCount ?> questions</span>
                    <span class="inline-flex items-center gap-1"><i class="far fa-clock text-gray-400"></i>~<?= $tpl['estimated_minutes'] ?? 3 ?> min</span>
                    <span class="inline-flex items-center gap-1 <?= $diffInfo['color'] ?>"><i class="fas <?= $diffInfo['icon'] ?>"></i><?= $diffInfo['label'] ?></span>
                    <?php if (!empty($tpl['popularity']) && $tpl['popularity'] === 'high'): ?>
                    <span class="inline-flex items-center gap-1 text-amber-600"><i class="fas fa-fire"></i>Popular</span>
                    <?php endif; ?>
                </div>

                <!-- Accuracy Score Bar -->
                <div class="mt-4 flex items-center gap-3">
                    <div class="flex-1">
                        <div class="flex justify-between text-xs mb-1">
                            <span class="text-gray-500 font-medium">Accuracy</span>
                            <span class="font-bold <?= $accColor ?>"><?= $accScore ?>%</span>
                        </div>
                        <div class="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                            <div class="h-full rounded-full <?= $accBar ?> transition-all duration-700 ease-out" style="width:<?= $accScore ?>%"></div>
                        </div>
                    </div>
                    <span class="px-2.5 py-1 text-xs rounded-full font-medium <?= $accBg ?> <?= $accColor ?> border border-transparent">Data Quality</span>
                </div>

                <!-- Question Preview -->
                <div class="mt-4 pt-4 border-t border-gray-100">
                    <div class="flex items-center justify-between mb-2">
                        <span class="text-xs font-semibold text-gray-500 uppercase tracking-wider">Preview Questions</span>
                        <span class="text-xs text-gray-400">+<?= max(0, $qCount - 3) ?> more</span>
                    </div>
                    <div class="space-y-1.5">
                        <?php foreach (array_slice($tpl['questions'] ?? [], 0, 3) as $q): ?>
                        <div class="flex items-center gap-2 text-xs text-gray-600">
                            <span class="px-1.5 py-0.5 rounded bg-gray-100 text-gray-500 font-mono text-[10px] uppercase tracking-wider"><?= str_replace('_', ' ', $q['type'] ?? '') ?></span>
                            <span class="truncate"><?= htmlspecialchars($q['question_text'] ?? '') ?></span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Quality Tags -->
                <div class="mt-4 flex flex-wrap gap-1.5">
                    <?php $shownQc = 0; ?>
                    <?php foreach (($tpl['quality'] ?? []) as $qcKey => $qcVal): ?>
                        <?php if (is_bool($qcVal) && $qcVal && !in_array($qcKey, ['min_time_seconds', 'min_text_length']) && $shownQc < 4): ?>
                        <?php $shownQc++; ?>
                        <span class="px-2 py-0.5 text-[10px] rounded-full bg-indigo-50 text-indigo-600 border border-indigo-200/50 font-medium"><?= ucfirst(str_replace('_', ' ', $qcKey)) ?></span>
                        <?php endif; ?>
                    <?php endforeach; ?>
                    <?php if (!empty($tpl['quality']['min_time_seconds'] ?? '')): ?>
                    <span class="px-2 py-0.5 text-[10px] rounded-full bg-gray-100 text-gray-500 border border-gray-200">Min <?= ($tpl['quality']['min_time_seconds'] ?? '') ?>s</span>
                    <?php endif; ?>
                    <?php if (count(array_filter($tpl['quality'] ?? [], 'is_bool')) > 4): ?>
                    <span class="px-2 py-0.5 text-[10px] rounded-full bg-gray-100 text-gray-500">+<?= count(array_filter($tpl['quality'] ?? [], 'is_bool')) - $shownQc ?></span>
                    <?php endif; ?>
                </div>

                <!-- Actions -->
                <div class="mt-5 pt-4 border-t border-gray-100 flex items-center justify-between">
                    <div class="flex items-center gap-2 text-xs text-gray-400">
                        <i class="fas fa-magic"></i>
                        <span>Click to preview</span>
                    </div>
                    <div class="flex gap-2">
                        <button onclick="event.stopPropagation(); useTemplate('<?= $key ?>')" class="px-4 py-2 bg-<?= $color ?>-600 text-white text-sm font-medium rounded-xl hover:bg-<?= $color ?>-700 transition-all shadow-sm hover:shadow-md inline-flex items-center gap-1.5">
                            <i class="fas fa-rocket text-xs"></i> Use
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <?php $delay += 0.05; ?>
        <?php endforeach; ?>
    </div>

    <!-- Empty State -->
    <div id="empty-state" class="hidden text-center py-16 animate-fade-in">
        <div class="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <i class="fas fa-search text-3xl text-gray-400"></i>
        </div>
        <h3 class="text-xl font-bold text-gray-900 mb-1">No templates found</h3>
        <p class="text-gray-500 text-sm">Try a different category or <button onclick="filterTemplates('all', document.querySelector('[data-category=\"all\"]'))" class="text-indigo-600 hover:underline font-medium">view all</button></p>
    </div>
</div>

<!-- Preview Modal -->
<div id="preview-modal" class="fixed inset-0 z-50 flex items-center justify-center p-4 hidden" onclick="closePreview(event)">
    <div class="absolute inset-0 bg-black/40 backdrop-blur-sm"></div>
    <div class="relative w-full max-w-2xl max-h-[85vh] bg-white rounded-2xl shadow-2xl overflow-y-auto animate-scale-in" onclick="event.stopPropagation()" id="preview-content">
        <!-- loading state -->
        <div class="p-10 text-center" id="preview-loading">
            <div class="w-12 h-12 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin mx-auto"></div>
            <p class="text-gray-500 mt-3">Loading template...</p>
        </div>
    </div>
</div>

<script>
// Category Filtering
function filterTemplates(category, btn) {
    document.querySelectorAll('.filter-btn').forEach(b => {
        b.classList.remove('bg-gray-900', 'text-white', 'shadow-md');
        b.classList.add('bg-gray-100', 'text-gray-600');
    });
    if (btn) {
        btn.classList.remove('bg-gray-100', 'text-gray-600');
        btn.classList.add('bg-gray-900', 'text-white', 'shadow-md');
    }
    let visible = 0;
    document.querySelectorAll('.template-card').forEach(card => {
        if (category === 'all' || card.dataset.category === category) {
            card.style.display = '';
            card.style.animation = 'none';
            card.offsetHeight;
            card.style.animation = '';
            visible++;
        } else {
            card.style.display = 'none';
        }
    });
    document.getElementById('empty-state').classList.toggle('hidden', visible > 0);
}

// Templates data for preview
const templatesData = <?= json_encode($templates, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;

function openPreview(key) {
    const modal = document.getElementById('preview-modal');
    const container = document.getElementById('preview-content');
    const loading = document.getElementById('preview-loading');
    modal.classList.remove('hidden');
    loading.style.display = '';

    const tpl = templatesData[key];
    if (!tpl) return;

    const cats = <?= json_encode(\Helpers\SurveyTemplates::categories()) ?>;
    const diffs = <?= json_encode(\Helpers\SurveyTemplates::difficultyLevels()) ?>;
    const catInfo = cats[tpl.category || 'feedback'] || { label: 'General', icon: 'fa-folder', color: 'gray' };
    const diffInfo = diffs[tpl.difficulty || 'easy'] || { label: 'Easy', icon: 'fa-thermometer-quarter', color: 'text-emerald-600' };
    const qCount = (tpl.questions || []).length;
    const accScore = tpl.accuracy_score || 85;
    const color = tpl.color || 'gray';

    let qcHtml = '';
    let qcCount = 0;
    for (const [k, v] of Object.entries(tpl.quality || {})) {
        if (typeof v === 'boolean' && v && !['min_time_seconds','min_text_length'].includes(k)) {
            qcHtml += `<span class="px-2.5 py-1 text-xs rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200 font-medium capitalize">${k.replace(/_/g, ' ')}</span>`;
            qcCount++;
        }
    }
    if (tpl.quality?.min_time_seconds) {
        qcHtml += `<span class="px-2.5 py-1 text-xs rounded-full bg-gray-100 text-gray-600 border border-gray-200">Min ${tpl.quality.min_time_seconds}s</span>`;
    }

    let questionsHtml = '';
    (tpl.questions || []).forEach((q, i) => {
        const isAttn = q.is_attention_check ? '<span class="px-1.5 py-0.5 text-[10px] rounded bg-amber-50 text-amber-700 border border-amber-200 font-medium"><i class="fas fa-eye mr-0.5"></i>Attention</span>' : '';
        const isTrap = q.is_trap ? '<span class="px-1.5 py-0.5 text-[10px] rounded bg-red-50 text-red-700 border border-red-200 font-medium"><i class="fas fa-skull mr-0.5"></i>Trap</span>' : '';
        const isSpeed = q.is_speed_bump ? '<span class="px-1.5 py-0.5 text-[10px] rounded bg-orange-50 text-orange-700 border border-orange-200 font-medium"><i class="fas fa-road mr-0.5"></i>Speed Bump</span>' : '';
        const req = q.is_required ? '<span class="text-red-400 ml-1">*</span>' : '';
        const opts = q.options ? `<span class="text-xs text-gray-400 ml-2">(${q.options.length} options)</span>` : '';
        questionsHtml += `<div class="flex items-start gap-3 p-3 rounded-xl hover:bg-gray-50 transition-colors ${i % 2 === 0 ? 'bg-gray-50/30' : ''}">
            <span class="flex-shrink-0 w-6 h-6 rounded-full bg-${color}-100 text-${color}-700 flex items-center justify-center text-xs font-bold">${i+1}</span>
            <div class="min-w-0">
                <div class="flex items-center gap-1.5 flex-wrap text-sm font-medium text-gray-900">${q.question_text || ''}${req}</div>
                <div class="flex items-center gap-1.5 mt-1 flex-wrap">
                    <span class="px-1.5 py-0.5 text-[10px] rounded bg-gray-100 text-gray-500 font-mono uppercase tracking-wider">${q.type.replace(/_/g, ' ')}</span>
                    ${isAttn}${isTrap}${isSpeed}${opts}
                </div>
            </div>
        </div>`;
    });

    loading.style.display = 'none';
    container.innerHTML = `
        <div class="sticky top-0 bg-white/95 backdrop-blur-sm border-b border-gray-100 px-6 py-4 flex items-center justify-between z-10">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-${color}-50 to-${color}-100 flex items-center justify-center">
                    <i class="fas ${tpl.icon || 'fa-file'} text-${color}-600"></i>
                </div>
                <div>
                    <h2 class="text-lg font-bold text-gray-900">${escapeHtml(tpl.name || '')}</h2>
                    <p class="text-xs text-gray-500">${catInfo.label} &middot; ${diffInfo.label} &middot; ~${tpl.estimated_minutes || 3} min</p>
                </div>
            </div>
            <button onclick="closePreview()" class="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-xl transition-colors">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="p-6 space-y-5">
            <p class="text-sm text-gray-600 leading-relaxed">${escapeHtml(tpl.description || '')}</p>

            <div class="flex items-center gap-4">
                <div class="flex-1">
                    <div class="flex justify-between text-xs mb-1"><span class="text-gray-500 font-medium">Accuracy Score</span><span class="font-bold text-${color}-600">${accScore}%</span></div>
                    <div class="w-full h-2.5 bg-gray-100 rounded-full overflow-hidden"><div class="h-full rounded-full bg-${color}-500" style="width:${accScore}%"></div></div>
                </div>
                <div class="text-center px-4 py-2 rounded-xl bg-gray-50 border border-gray-200">
                    <div class="text-xl font-bold text-gray-900">${qCount}</div>
                    <div class="text-xs text-gray-500">Questions</div>
                </div>
            </div>

            <div>
                <h3 class="text-sm font-semibold text-gray-700 mb-2 flex items-center gap-1.5"><i class="fas fa-shield-alt text-indigo-500"></i>Quality Protections</h3>
                <div class="flex flex-wrap gap-1.5">${qcHtml}</div>
            </div>

            <div>
                <h3 class="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-1.5"><i class="far fa-file-alt text-gray-500"></i>Questions (${qCount})</h3>
                <div class="space-y-1">${questionsHtml}</div>
            </div>

            <div class="pt-4 border-t border-gray-100 flex gap-3">
                <button onclick="closePreview(); useTemplate('${key}')" class="flex-1 py-3 bg-${color}-600 text-white font-medium rounded-xl hover:bg-${color}-700 transition-all shadow-sm text-sm text-center">
                    <i class="fas fa-rocket mr-1.5"></i>Use This Template
                </button>
                <button onclick="closePreview()" class="px-6 py-3 border border-gray-300 text-gray-700 font-medium rounded-xl hover:bg-gray-50 transition-all text-sm">
                    Cancel
                </button>
            </div>
        </div>
    `;
}

function closePreview(e) {
    if (e && e.target !== e.currentTarget && !e.isTrusted) return;
    const modal = document.getElementById('preview-modal');
    modal.classList.add('hidden');
    document.getElementById('preview-content').innerHTML = '<div class="p-10 text-center" id="preview-loading"><div class="w-12 h-12 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin mx-auto"></div><p class="text-gray-500 mt-3">Loading template...</p></div>';
}

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') document.getElementById('preview-modal').classList.add('hidden');
});

function useTemplate(key) {
    window.location.href = '<?= url('/survey/create') ?>?template=' + key;
}

function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
}
</script>
