<div class="space-y-6">
    <div class="flex items-center justify-between">
        <div>
            <h1 class="text-2xl font-bold text-gray-900"><i class="fas fa-flask text-indigo-500 mr-2"></i>Research Ground</h1>
            <p class="text-gray-500 text-sm mt-1">Import survey data, analyze, transform, and visualize</p>
        </div>
        <button type="button" onclick="document.getElementById('create-modal').classList.remove('hidden')" class="inline-flex items-center gap-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-5 py-2.5 rounded-xl hover:from-indigo-700 hover:to-purple-700 transition-all shadow-sm text-sm font-medium">
            <i class="fas fa-plus"></i>New Project
        </button>
    </div>

    <?php if (empty($projects)): ?>
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
            <div class="w-20 h-20 bg-gradient-to-br from-indigo-50 to-purple-50 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <i class="fas fa-flask text-3xl text-indigo-400"></i>
            </div>
            <h2 class="text-xl font-bold text-gray-900 mb-2">No research projects yet</h2>
            <p class="text-gray-500 mb-6">Create a project, import survey data, and start exploring.</p>
            <button type="button" onclick="document.getElementById('create-modal').classList.remove('hidden')" class="inline-flex items-center gap-2 bg-indigo-600 text-white px-6 py-2.5 rounded-xl hover:bg-indigo-700 transition-all">
                <i class="fas fa-plus"></i>Create Project
            </button>
        </div>
    <?php else: ?>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <?php foreach ($projects as $p): ?>
                <a href="<?= url('/research/' . $p['id']) ?>" class="group bg-white rounded-xl border border-gray-200 p-5 hover:border-indigo-300 hover:shadow-md transition-all">
                    <div class="flex items-start justify-between mb-3">
                        <div class="w-10 h-10 bg-gradient-to-br from-indigo-100 to-purple-100 rounded-xl flex items-center justify-center text-indigo-600 group-hover:scale-110 transition-transform">
                            <i class="fas fa-flask"></i>
                        </div>
                        <span class="text-xs px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-600 border border-indigo-100 font-medium"><?= (int)$p['survey_count'] ?> surveys</span>
                    </div>
                    <h3 class="font-semibold text-gray-900 group-hover:text-indigo-600 transition-colors"><?= htmlspecialchars($p['name']) ?></h3>
                    <?php if ($p['description']): ?>
                        <p class="text-xs text-gray-500 mt-1 line-clamp-2"><?= htmlspecialchars($p['description']) ?></p>
                    <?php endif; ?>
                    <div class="flex items-center gap-3 mt-3 text-[10px] text-gray-400">
                        <span><i class="far fa-chart-bar mr-1"></i><?= (int)$p['viz_count'] ?> viz</span>
                        <span><i class="far fa-calendar mr-1"></i><?= date('M j', strtotime($p['updated_at'])) ?></span>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<!-- Create Modal -->
<div id="create-modal" class="fixed inset-0 z-50 hidden flex items-center justify-center p-4" style="background:rgba(0,0,0,0.5);backdrop-filter:blur(4px)">
    <div class="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 animate-scale-in">
        <div class="flex items-center justify-between mb-4">
            <h3 class="text-lg font-bold text-gray-900"><i class="fas fa-flask text-indigo-500 mr-2"></i>New Research Project</h3>
            <button type="button" onclick="this.closest('#create-modal').classList.add('hidden')" class="w-8 h-8 rounded-lg hover:bg-gray-100 flex items-center justify-center text-gray-400"><i class="fas fa-times"></i></button>
        </div>
        <form method="POST" action="<?= url('/research/create') ?>">
          <?= csrf() ?>
            <?= csrf() ?>
            <div class="space-y-4">
                <div>
                    <label class="block text-xs font-medium text-gray-600 mb-1">Project Name <span class="text-red-400">*</span></label>
                    <input type="text" name="name" required maxlength="255" class="w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-indigo-500" placeholder="e.g., Customer Satisfaction Analysis">
                </div>
                <div>
                    <label class="block text-xs font-medium text-gray-600 mb-1">Description</label>
                    <textarea name="description" rows="3" class="w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-indigo-500" placeholder="What are you investigating?"></textarea>
                </div>
            </div>
            <div class="flex gap-3 mt-6">
                <button type="submit" class="flex-1 bg-indigo-600 text-white px-4 py-2.5 rounded-xl hover:bg-indigo-700 transition-all text-sm font-medium"><i class="fas fa-plus mr-1.5"></i>Create Project</button>
                <button type="button" onclick="this.closest('#create-modal').classList.add('hidden')" class="px-4 py-2.5 rounded-xl border border-gray-200 text-gray-600 hover:bg-gray-50 transition-all text-sm">Cancel</button>
            </div>
        </form>
    </div>
</div>
