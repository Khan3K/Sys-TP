<div class="space-y-6">
    <div class="flex items-center justify-between">
        <div>
            <div class="flex items-center gap-2">
                <a href="<?= url('/research') ?>" class="text-gray-400 hover:text-gray-600 transition-colors"><i class="fas fa-arrow-left text-sm"></i></a>
                <h1 class="text-xl font-bold text-gray-900"><i class="fas fa-flask text-indigo-500 mr-2"></i><?= htmlspecialchars($project['name']) ?></h1>
            </div>
            <?php if ($project['description']): ?>
                <p class="text-gray-500 text-xs mt-0.5 ml-7"><?= htmlspecialchars($project['description']) ?></p>
            <?php endif; ?>
        </div>
        <div class="flex gap-2">
            <button type="button" onclick="document.getElementById('import-modal').classList.remove('hidden')" class="px-3 py-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-all text-xs font-medium flex items-center gap-1.5"><i class="fas fa-download"></i> Import Survey</button>
            <form method="POST" action="<?= url('/research/delete/' . $project['id']) ?>" onsubmit="return confirm('Delete this project and all its data?')">
              <?= csrf() ?>
                <button type="submit" class="px-3 py-2 border border-red-200 text-red-500 rounded-xl hover:bg-red-50 transition-all text-xs font-medium flex items-center gap-1.5"><i class="fas fa-trash"></i></button>
            </form>
        </div>
    </div>

    <!-- Tab Navigation -->
    <div class="segment-tabs" id="research-tabs">
        <button type="button" class="segment-tab active" data-tab="data" onclick="switchTab('data')"><i class="fas fa-table"></i> Data</button>
        <button type="button" class="segment-tab" data-tab="filter" onclick="switchTab('filter')"><i class="fas fa-filter"></i> Filter</button>
        <button type="button" class="segment-tab" data-tab="transform" onclick="switchTab('transform')"><i class="fas fa-wand-magic-sparkles"></i> Transform</button>
        <button type="button" class="segment-tab" data-tab="viz" onclick="switchTab('viz')"><i class="fas fa-chart-pie"></i> Visualize</button>
    </div>

    <!-- === TAB: DATA === -->
    <div id="tab-data" class="tab-content">
        <?php if (empty($sources)): ?>
            <div class="bg-white rounded-xl border border-gray-200 p-12 text-center">
                <div class="w-16 h-16 bg-gray-50 rounded-2xl flex items-center justify-center mx-auto mb-3">
                    <i class="fas fa-database text-2xl text-gray-300"></i>
                </div>
                <h3 class="text-lg font-semibold text-gray-900 mb-1">No data imported</h3>
                <p class="text-sm text-gray-500 mb-4">Import survey data to start exploring.</p>
                <button type="button" onclick="document.getElementById('import-modal').classList.remove('hidden')" class="inline-flex items-center gap-2 bg-indigo-600 text-white px-5 py-2 rounded-xl hover:bg-indigo-700 transition-all text-sm"><i class="fas fa-download"></i> Import Survey</button>
            </div>
        <?php else: ?>
            <!-- Data Sources -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 mb-4">
                <?php foreach ($sources as $src): ?>
                    <div class="bg-white rounded-xl border border-gray-200 p-4">
                        <div class="flex items-start justify-between">
                            <div class="flex-1 min-w-0">
                                <div class="flex items-center gap-1.5">
                                    <i class="fas fa-clipboard-list text-indigo-400 text-xs"></i>
                                    <span class="font-medium text-sm text-gray-900 truncate"><?= htmlspecialchars($src['survey_title']) ?></span>
                                </div>
                                <div class="flex items-center gap-2 mt-1.5 text-[10px] text-gray-500">
                                    <span><i class="fas fa-question-circle mr-0.5"></i><?= $src['question_count'] ?> questions</span>
                                    <span><i class="fas fa-reply-all mr-0.5"></i><?= $src['response_count'] ?> responses</span>
                                </div>
                                <span class="text-[9px] text-gray-400 block mt-0.5">Imported <?= date('M j, Y', strtotime($src['imported_at'])) ?></span>
                            </div>
                            <form method="POST" action="<?= url('/research/' . $project['id'] . '/source/' . $src['id'] . '/remove') ?>" onsubmit="return confirm('Remove this survey from the project?')">
                              <?= csrf() ?>
                                <button type="submit" class="w-6 h-6 rounded-lg hover:bg-red-50 flex items-center justify-center text-gray-300 hover:text-red-500 transition-colors"><i class="fas fa-times text-[10px]"></i></button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Data Table / Browser -->
            <div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
                <div class="px-4 py-3 border-b border-gray-100 flex items-center justify-between">
                    <div class="flex items-center gap-2">
                        <i class="fas fa-table text-gray-400 text-xs"></i>
                        <span class="text-sm font-semibold text-gray-700">Data Browser</span>
                        <span class="text-[10px] text-gray-400" id="data-row-count"></span>
                    </div>
                    <div class="flex items-center gap-2">
                        <input type="text" id="data-search" placeholder="Search data..." class="w-48 px-2.5 py-1.5 rounded-lg text-xs border border-gray-200 focus:ring-2 focus:ring-indigo-500" oninput="filterDataTable()">
                        <select id="data-survey-filter" class="px-2 py-1.5 rounded-lg text-xs border border-gray-200 focus:ring-2 focus:ring-indigo-500" onchange="renderDataTable()">
                            <option value="all">All Surveys</option>
                            <?php foreach ($sources as $src): ?>
                                <option value="<?= $src['survey_id'] ?>"><?= htmlspecialchars($src['survey_title']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="overflow-x-auto" style="max-height:500px;overflow-y:auto">
                    <table class="w-full text-xs" id="data-table">
                        <thead class="bg-gray-50 sticky top-0">
                            <tr id="data-table-header"></tr>
                        </thead>
                        <tbody id="data-table-body"></tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- === TAB: FILTER === -->
    <div id="tab-filter" class="tab-content hidden">
        <div class="bg-white rounded-xl border border-gray-200 p-5">
            <div class="flex items-center gap-2 mb-4">
                <i class="fas fa-filter text-indigo-400"></i>
                <h3 class="text-base font-semibold text-gray-900">Filter Data</h3>
                <span class="text-[10px] text-gray-400">Build filters to narrow down your dataset</span>
            </div>
            <div id="filter-list" class="space-y-2 mb-4"></div>
            <div class="flex gap-2 mb-4">
                <select id="filter-field" class="px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-indigo-500 bg-white">
                    <option value="">Select field...</option>
                </select>
                <select id="filter-operator" class="px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-indigo-500 bg-white">
                    <option value="equals">Equals</option>
                    <option value="not_equals">Not equals</option>
                    <option value="contains">Contains</option>
                    <option value="gt">Greater than</option>
                    <option value="lt">Less than</option>
                    <option value="between">Between</option>
                    <option value="is_empty">Is empty</option>
                    <option value="not_empty">Not empty</option>
                </select>
                <div class="flex-1 relative">
                    <input type="text" id="filter-value" placeholder="Value" class="w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-indigo-500">
                    <div id="filter-value-hint" class="absolute -bottom-4 left-0 right-0"></div>
                </div>
                <input type="text" id="filter-value2" placeholder="Max (between)" class="px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-indigo-500 flex-1 hidden">
                <button type="button" onclick="addFilter()" class="px-4 py-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-all text-sm font-medium"><i class="fas fa-plus"></i> Add</button>
            </div>
            <div class="flex gap-2">
                <button type="button" onclick="applyFilters()" class="px-4 py-2 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 transition-all text-sm font-medium"><i class="fas fa-check mr-1"></i>Apply Filters</button>
                <button type="button" onclick="clearFilters()" class="px-4 py-2 border border-gray-200 text-gray-600 rounded-xl hover:bg-gray-50 transition-all text-sm"><i class="fas fa-undo mr-1"></i>Clear</button>
                <span class="text-xs text-gray-400 self-center ml-2" id="filter-result-count"></span>
            </div>
        </div>
        <div class="mt-4 bg-white rounded-xl border border-gray-200 overflow-hidden hidden" id="filter-results-table-wrap">
            <div class="px-4 py-3 border-b border-gray-100 flex items-center justify-between">
                <span class="text-sm font-semibold text-gray-700"><i class="fas fa-table text-gray-400 mr-2"></i>Filtered Results</span>
            </div>
            <div class="overflow-x-auto" style="max-height:400px;overflow-y:auto">
                <table class="w-full text-xs" id="filter-results-table">
                    <thead class="bg-gray-50 sticky top-0"><tr id="filter-results-header"></tr></thead>
                    <tbody id="filter-results-body"></tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- === TAB: TRANSFORM === -->
    <div id="tab-transform" class="tab-content hidden">
        <div class="bg-white rounded-xl border border-gray-200 p-5">
            <div class="flex items-center gap-2 mb-4">
                <i class="fas fa-wand-magic-sparkles text-purple-400"></i>
                <h3 class="text-base font-semibold text-gray-900">Transform Data</h3>
                <span class="text-[10px] text-gray-400">Shape, pivot, and clean your data</span>
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div class="border border-gray-200 rounded-xl p-4 hover:border-indigo-300 transition-colors">
                    <div class="flex items-center gap-2 mb-2">
                        <span class="w-8 h-8 rounded-lg bg-indigo-50 flex items-center justify-center text-indigo-600"><i class="fas fa-arrows-rotate"></i></span>
                        <h4 class="font-medium text-sm text-gray-900">Pivot Table</h4>
                    </div>
                    <p class="text-[10px] text-gray-500 mb-3">Cross-tabulate questions as rows × columns with aggregate values</p>
                    <div class="space-y-1.5">
                        <select id="pivot-rows" class="w-full px-2 py-1.5 rounded-lg text-xs border border-gray-200 bg-white"><option>Select row field...</option></select>
                        <select id="pivot-cols" class="w-full px-2 py-1.5 rounded-lg text-xs border border-gray-200 bg-white"><option>Select column field...</option></select>
                        <select id="pivot-values" class="w-full px-2 py-1.5 rounded-lg text-xs border border-gray-200 bg-white"><option>Select value field...</option></select>
                        <button type="button" onclick="runPivot()" class="w-full px-3 py-1.5 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-all text-xs font-medium"><i class="fas fa-play mr-1"></i>Run Pivot</button>
                    </div>
                </div>
                <div class="border border-gray-200 rounded-xl p-4 hover:border-indigo-300 transition-colors">
                    <div class="flex items-center gap-2 mb-2">
                        <span class="w-8 h-8 rounded-lg bg-emerald-50 flex items-center justify-center text-emerald-600"><i class="fas fa-chart-simple"></i></span>
                        <h4 class="font-medium text-sm text-gray-900">Summary Stats</h4>
                    </div>
                    <p class="text-[10px] text-gray-500 mb-3">Count, average, min, max, distribution for any question</p>
                    <div class="space-y-1.5">
                        <select id="stats-field" class="w-full px-2 py-1.5 rounded-lg text-xs border border-gray-200 bg-white"><option>Select field...</option></select>
                        <button type="button" onclick="runSummary()" class="w-full px-3 py-1.5 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-all text-xs font-medium"><i class="fas fa-play mr-1"></i>Run Summary</button>
                    </div>
                </div>
                <div class="border border-gray-200 rounded-xl p-4 hover:border-indigo-300 transition-colors">
                    <div class="flex items-center gap-2 mb-2">
                        <span class="w-8 h-8 rounded-lg bg-amber-50 flex items-center justify-center text-amber-600"><i class="fas fa-broom"></i></span>
                        <h4 class="font-medium text-sm text-gray-900">Clean Data</h4>
                    </div>
                    <p class="text-[10px] text-gray-500 mb-3">Remove duplicates, filter outliers, normalize values</p>
                    <div class="space-y-1.5">
                        <button type="button" onclick="removeDuplicates()" class="w-full px-3 py-1.5 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-all text-xs font-medium"><i class="fas fa-copy mr-1"></i>Remove Duplicates</button>
                        <button type="button" onclick="removeOutliers()" class="w-full px-3 py-1.5 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-all text-xs font-medium"><i class="fas fa-chart-line mr-1"></i>Remove Outliers</button>
                        <button type="button" onclick="exportFilteredCSV()" class="w-full px-3 py-1.5 bg-gray-800 text-white rounded-lg hover:bg-gray-900 transition-all text-xs font-medium"><i class="fas fa-download mr-1"></i>Export CSV</button>
                    </div>
                </div>
            </div>
            <div id="transform-results" class="mt-4 hidden">
                <div class="bg-gray-50 rounded-xl border border-gray-200 p-4">
                    <div class="flex items-center justify-between mb-2">
                        <h4 class="text-sm font-semibold text-gray-700">Results</h4>
                        <button type="button" onclick="document.getElementById('transform-results').classList.add('hidden')" class="text-gray-400 hover:text-gray-600"><i class="fas fa-times"></i></button>
                    </div>
                    <div id="transform-results-body"></div>
                </div>
            </div>
        </div>
    </div>

    <!-- === TAB: VISUALIZE === -->
    <div id="tab-viz" class="tab-content hidden">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <!-- Chart Builder -->
            <div class="lg:col-span-1 bg-white rounded-xl border border-gray-200 p-5">
                <div class="flex items-center gap-2 mb-4">
                    <i class="fas fa-chart-pie text-pink-400"></i>
                    <h3 class="text-base font-semibold text-gray-900">Chart Builder</h3>
                </div>

                <div class="space-y-3">
                    <div>
                        <label class="block text-xs font-medium text-gray-600 mb-1">Chart Name</label>
                        <input type="text" id="viz-name" class="w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-pink-500" placeholder="My Chart">
                    </div>
                    <div>
                        <label class="block text-xs font-medium text-gray-600 mb-1">Chart Type</label>
                        <div class="grid grid-cols-3 gap-1.5" id="chart-type-grid">
                            <button type="button" class="chart-type-btn px-2 py-2 rounded-lg text-[9px] font-medium border-2 border-pink-500 bg-pink-50 text-pink-700 flex flex-col items-center gap-0.5" data-chart="bar" onclick="selectChartType('bar', this)">
                                <i class="fas fa-chart-bar text-xs"></i><span>Bar</span>
                            </button>
                            <button type="button" class="chart-type-btn px-2 py-2 rounded-lg text-[9px] font-medium border-2 border-transparent bg-gray-50 text-gray-600 hover:bg-gray-100 flex flex-col items-center gap-0.5" data-chart="pie" onclick="selectChartType('pie', this)">
                                <i class="fas fa-chart-pie text-xs"></i><span>Pie</span>
                            </button>
                            <button type="button" class="chart-type-btn px-2 py-2 rounded-lg text-[9px] font-medium border-2 border-transparent bg-gray-50 text-gray-600 hover:bg-gray-100 flex flex-col items-center gap-0.5" data-chart="line" onclick="selectChartType('line', this)">
                                <i class="fas fa-chart-line text-xs"></i><span>Line</span>
                            </button>
                            <button type="button" class="chart-type-btn px-2 py-2 rounded-lg text-[9px] font-medium border-2 border-transparent bg-gray-50 text-gray-600 hover:bg-gray-100 flex flex-col items-center gap-0.5" data-chart="doughnut" onclick="selectChartType('doughnut', this)">
                                <i class="fas fa-circle text-xs"></i><span>Doughnut</span>
                            </button>
                            <button type="button" class="chart-type-btn px-2 py-2 rounded-lg text-[9px] font-medium border-2 border-transparent bg-gray-50 text-gray-600 hover:bg-gray-100 flex flex-col items-center gap-0.5" data-chart="radar" onclick="selectChartType('radar', this)">
                                <i class="fas fa-star-of-life text-xs"></i><span>Radar</span>
                            </button>
                            <button type="button" class="chart-type-btn px-2 py-2 rounded-lg text-[9px] font-medium border-2 border-transparent bg-gray-50 text-gray-600 hover:bg-gray-100 flex flex-col items-center gap-0.5" data-chart="polarArea" onclick="selectChartType('polarArea', this)">
                                <i class="fas fa-circle-notch text-xs"></i><span>Polar</span>
                            </button>
                        </div>
                    </div>
                    <div>
                        <label class="block text-xs font-medium text-gray-600 mb-1">Label Field</label>
                        <select id="viz-label" class="w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-pink-500 bg-white"></select>
                    </div>
                    <div>
                        <label class="block text-xs font-medium text-gray-600 mb-1">Value Field</label>
                        <select id="viz-value" class="w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-pink-500 bg-white"></select>
                    </div>
                    <div>
                        <label class="block text-xs font-medium text-gray-600 mb-1">Survey Source</label>
                        <select id="viz-survey" class="w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-pink-500 bg-white" onchange="updateVizFields()">
                            <option value="all">All Surveys</option>
                            <?php foreach ($sources as $src): ?>
                                <option value="<?= $src['survey_id'] ?>"><?= htmlspecialchars($src['survey_title']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label class="block text-xs font-medium text-gray-600 mb-1">Aggregation</label>
                        <select id="viz-aggr" class="w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-pink-500 bg-white">
                            <option value="count">Count</option>
                            <option value="percentage">Percentage</option>
                            <option value="average">Average</option>
                            <option value="sum">Sum</option>
                            <option value="distinct">Distinct Count</option>
                        </select>
                    </div>
                    <button type="button" onclick="renderChart()" class="w-full px-4 py-2.5 bg-gradient-to-r from-pink-500 to-rose-500 text-white rounded-xl hover:from-pink-600 hover:to-rose-600 transition-all text-sm font-medium shadow-sm"><i class="fas fa-play mr-1"></i>Render Chart</button>
                    <form method="POST" action="<?= url('/research/' . $project['id'] . '/viz/save') ?>" id="save-viz-form" class="hidden">
                      <?= csrf() ?>
                        <input type="hidden" name="name" id="save-viz-name">
                        <input type="hidden" name="chart_type" id="save-viz-type">
                        <input type="hidden" name="chart_config" id="save-viz-config">
                        <button type="submit" class="w-full px-4 py-2 border border-emerald-300 text-emerald-700 rounded-xl hover:bg-emerald-50 transition-all text-sm font-medium"><i class="fas fa-save mr-1"></i>Save Chart</button>
                    </form>
                </div>
            </div>

            <!-- Chart Preview + Saved Charts -->
            <div class="lg:col-span-2 space-y-4">
                <div class="bg-white rounded-xl border border-gray-200 p-5">
                    <div class="flex items-center gap-2 mb-3">
                        <i class="fas fa-eye text-gray-400 text-xs"></i>
                        <span class="text-sm font-semibold text-gray-700">Chart Preview</span>
                    </div>
                    <div class="relative" style="height:350px">
                        <canvas id="chart-canvas"></canvas>
                        <div id="chart-empty" class="absolute inset-0 flex items-center justify-center text-gray-400 text-sm">
                            <div class="text-center"><i class="fas fa-chart-bar text-3xl mb-2 text-gray-200"></i><br>Configure and render a chart</div>
                        </div>
                    </div>
                </div>

                <?php if (!empty($visualizations)): ?>
                <div class="bg-white rounded-xl border border-gray-200 p-5">
                    <div class="flex items-center gap-2 mb-3">
                        <i class="fas fa-save text-gray-400 text-xs"></i>
                        <span class="text-sm font-semibold text-gray-700">Saved Charts</span>
                    </div>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <?php foreach ($visualizations as $v): ?>
                            <div class="border border-gray-200 rounded-xl p-3">
                                <div class="flex items-center justify-between mb-2">
                                    <span class="text-xs font-semibold text-gray-800"><?= htmlspecialchars($v['name']) ?></span>
                                    <div class="flex gap-1">
                                        <button type="button" onclick="loadSavedViz(<?= $v['id'] ?>)" class="w-6 h-6 rounded-lg hover:bg-indigo-50 flex items-center justify-center text-gray-400 hover:text-indigo-600 transition-colors" title="Load"><i class="fas fa-eye text-[10px]"></i></button>
                                        <form method="POST" action="<?= url('/research/' . $project['id'] . '/viz/' . $v['id'] . '/delete') ?>" onsubmit="return confirm('Delete this chart?')">
                                          <?= csrf() ?>
                                            <button type="submit" class="w-6 h-6 rounded-lg hover:bg-red-50 flex items-center justify-center text-gray-400 hover:text-red-500 transition-colors" title="Delete"><i class="fas fa-trash text-[10px]"></i></button>
                                        </form>
                                    </div>
                                </div>
                                <span class="text-[9px] px-1.5 py-0.5 rounded bg-gray-100 text-gray-600 font-medium"><?= ucfirst($v['chart_type']) ?></span>
                                <span class="text-[9px] text-gray-400 ml-1"><?= date('M j', strtotime($v['created_at'])) ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Import Modal -->
<div id="import-modal" class="fixed inset-0 z-50 hidden flex items-center justify-center p-4" style="background:rgba(0,0,0,0.5);backdrop-filter:blur(4px)">
    <div class="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 animate-scale-in">
        <div class="flex items-center justify-between mb-4">
            <h3 class="text-lg font-bold text-gray-900"><i class="fas fa-download text-indigo-500 mr-2"></i>Import Survey Data</h3>
            <button type="button" onclick="this.closest('#import-modal').classList.add('hidden')" class="w-8 h-8 rounded-lg hover:bg-gray-100 flex items-center justify-center text-gray-400"><i class="fas fa-times"></i></button>
        </div>
        <form method="POST" action="<?= url('/research/' . $project['id'] . '/import') ?>">
          <?= csrf() ?>
            <div class="space-y-4">
                <p class="text-xs text-gray-500">Select a survey to import its questions and responses into this research project.</p>
                <select name="survey_id" required class="w-full px-3 py-2.5 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-indigo-500 bg-white">
                    <option value="">Choose a survey...</option>
                    <?php foreach ($allSurveys as $s): ?>
                        <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['title']) ?> (<?= $s['status'] ?>)</option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="flex gap-3 mt-6">
                <button type="submit" class="flex-1 bg-indigo-600 text-white px-4 py-2.5 rounded-xl hover:bg-indigo-700 transition-all text-sm font-medium"><i class="fas fa-download mr-1.5"></i>Import</button>
                <button type="button" onclick="this.closest('#import-modal').classList.add('hidden')" class="px-4 py-2.5 rounded-xl border border-gray-200 text-gray-600 hover:bg-gray-50 transition-all text-sm">Cancel</button>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.7/dist/chart.umd.min.js"></script>
<script>
// ============================================================
// DATA
// ============================================================
let allQuestions = <?= json_encode($allQuestions) ?>;
let allResponses = <?= json_encode($allResponses) ?>;
let questionMap = <?= json_encode($questionMap) ?>;
let allAnswers = <?= json_encode($allAnswers) ?>;
let allAnswersByResponse = <?= json_encode($allAnswersByResponse) ?>;

let currentChart = null;
let selectedChartType = 'bar';
let activeFilters = [];

// Cache for unified tables
let _unifiedCache = {};
function getUnified(surveyFilter) {
    const key = surveyFilter || 'all';
    if (_unifiedCache[key]) return _unifiedCache[key];
    const rows = [];
    const colSet = new Set(['__id', '__survey', '__status', '__quality', '__date', '__created_at', '__duration']);
    Object.entries(allQuestions).forEach(([sid, qlist]) => {
        if (surveyFilter === 'all' || surveyFilter === sid) {
            qlist.forEach(q => colSet.add('q_' + q.id));
        }
    });
    const columns = Array.from(colSet);
    Object.entries(allResponses).forEach(([sid, rlist]) => {
        if (surveyFilter !== 'all' && surveyFilter !== sid) return;
        rlist.forEach(r => {
            const row = { __id: '#' + r.id, __survey: parseInt(sid), __status: r.status, __quality: r.overall_score || '', __date: r.completed_at ? r.completed_at.substring(0, 10) : '', __created_at: r.created_at || r.completed_at || '', __duration: r.duration_seconds || '' };
            const ans = allAnswersByResponse[r.id] || [];
            ans.forEach(a => { row['q_' + a.question_id] = fmtAnswer(a); });
            rows.push(row);
        });
    });
    _unifiedCache[key] = { rows, columns };
    return _unifiedCache[key];
}

function invalidateCache() { _unifiedCache = {}; }

function fmtAnswer(a) {
    let val = a.answer_value !== null && a.answer_value !== undefined ? a.answer_value : (a.answer_text || '');
    if (typeof val === 'string' && val.startsWith('[')) {
        try { const p = JSON.parse(val); return Array.isArray(p) ? p.join(', ') : val; } catch(e) { return val; }
    }
    return String(val);
}

function getQuestionLabel(qId) { const q = questionMap[qId]; return q ? (q.question_text || q.type || 'Q' + qId) : 'Q' + qId; }
function getQuestionType(qId) { const q = questionMap[qId]; return q ? q.type : 'text'; }

function isNumericType(t) { return ['rating', 'number', 'nps', 'scale', 'slider'].includes(t); }

function getDistinctVals(rows, field) {
    const counts = {};
    rows.forEach(row => {
        const v = (row[field] !== undefined && row[field] !== '') ? row[field] : '(empty)';
        counts[v] = (counts[v] || 0) + 1;
    });
    return Object.entries(counts).sort((a, b) => b[1] - a[1]).map(([label, count]) => ({ label, count }));
}

function tabContent(id) { return document.getElementById('tab-' + id); }
function switchTab(name) {
    document.querySelectorAll('.tab-content').forEach(t => t.classList.add('hidden'));
    document.querySelectorAll('#research-tabs .segment-tab').forEach(t => t.classList.remove('active'));
    const tab = tabContent(name);
    if (tab) tab.classList.remove('hidden');
    const btn = document.querySelector('#research-tabs .segment-tab[data-tab="' + name + '"]');
    if (btn) btn.classList.add('active');
    if (name === 'viz') updateVizFields();
    if (name === 'data') renderDataTable();
    if (name === 'filter') { populateFilterFields(); loadFilterDistributions(); }
}

const COLORS = ['#6366f1','#f59e0b','#10b981','#f43f5e','#06b6d4','#8b5cf6','#ec4899','#f97316','#14b8a6','#ef4444','#84cc16','#a855f7'];

// ============================================================
// DATA TABLE — real answer columns
// ============================================================
function renderDataTable() {
    const surveyFilter = document.getElementById('data-survey-filter').value;
    const { rows, columns } = getUnified(surveyFilter);
    const thead = document.getElementById('data-table-header');
    const tbody = document.getElementById('data-table-body');

    // Filter out meta columns for display
    const displayCols = columns.filter(c => !c.startsWith('__'));
    const allDisplayCols = ['__id', '__survey', '__status', '__quality', '__date', ...displayCols];

    thead.innerHTML = allDisplayCols.map(c => {
        let label = c;
        if (c === '__id') label = 'ID';
        else if (c === '__survey') label = 'Survey';
        else if (c === '__status') label = 'Status';
        else if (c === '__quality') label = 'Quality';
        else if (c === '__date') label = 'Date';
        else if (c.startsWith('q_')) label = getQuestionLabel(c.substring(2));
        return '<th class="px-3 py-2 text-left font-medium text-gray-600 border-b whitespace-nowrap text-[10px]">' + label + '</th>';
    }).join('');

    document.getElementById('data-row-count').textContent = rows.length + ' rows';

    let bodyHtml = rows.map(r => {
        const surveyOpt = document.querySelector('#data-survey-filter option[value="' + r.__survey + '"]');
        const surveyLabel = surveyOpt ? surveyOpt.textContent : 'Survey ' + r.__survey;
        let html = '<tr class="hover:bg-gray-50 border-b border-gray-100">';
        html += '<td class="px-3 py-2 text-gray-500 font-mono text-[10px]">' + r.__id + '</td>';
        html += '<td class="px-3 py-2 text-gray-700 text-[10px]">' + surveyLabel + '</td>';
        html += '<td class="px-3 py-2"><span class="px-1.5 py-0.5 rounded text-[9px] font-medium ' +
            (r.__status === 'completed' || r.__status === 'accepted' ? 'bg-emerald-50 text-emerald-700' : r.__status === 'flagged' ? 'bg-amber-50 text-amber-700' : 'bg-gray-50 text-gray-600') +
            '">' + r.__status + '</span></td>';
        html += '<td class="px-3 py-2 text-[10px]">' + r.__quality + '</td>';
        html += '<td class="px-3 py-2 text-gray-400 text-[10px]">' + r.__date + '</td>';
        displayCols.forEach(c => {
            const val = r[c] !== undefined ? r[c] : '';
            const qId = parseInt(c.substring(2));
            const type = getQuestionType(qId);
            let display = val;
            if (isNumericType(type) && val !== '') display = val;
            html += '<td class="px-3 py-2 text-gray-600 text-[10px] max-w-[160px] truncate" title="' + htmlspecialchars(val) + '">' + htmlspecialchars(display) + '</td>';
        });
        html += '</tr>';
        return html;
    }).join('');
    tbody.innerHTML = bodyHtml || '<tr><td colspan="' + allDisplayCols.length + '" class="text-center py-8 text-gray-400 text-xs">No data</td></tr>';
}

function htmlspecialchars(s) { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }

function filterDataTable() {
    const search = document.getElementById('data-search').value.toLowerCase();
    document.querySelectorAll('#data-table-body tr').forEach(row => {
        row.style.display = row.textContent.toLowerCase().includes(search) ? '' : 'none';
    });
}

// ============================================================
// FILTER — works on real answer data
// ============================================================
function populateFilterFields() {
    const sel = document.getElementById('filter-field');
    sel.innerHTML = '<option value="">Select field...</option>';
    const added = new Set();
    Object.entries(allQuestions).forEach(([sid, qlist]) => {
        qlist.forEach(q => {
            const key = 'q_' + q.id;
            if (!added.has(key)) {
                added.add(key);
                sel.innerHTML += '<option value="' + key + '">' + htmlspecialchars(q.question_text || q.type) + '</option>';
            }
        });
    });
    sel.innerHTML += '<option value="__survey">Survey</option><option value="__status">Status</option><option value="__quality">Quality Score</option>';
}

function loadFilterDistributions() {
    const { rows } = getUnified('all');
    window._filterRows = rows;
    const sel = document.getElementById('filter-field');
    sel.addEventListener('change', function() {
        const field = this.value;
        if (!field) return;
        const dist = getDistinctVals(rows, field);
        const hint = document.getElementById('filter-value-hint');
        if (hint) {
            hint.innerHTML = '<span class="text-[9px] text-gray-400">' + dist.slice(0, 8).map(d => d.label + ' (' + d.count + ')').join(', ') + (dist.length > 8 ? '...' : '') + '</span>';
        }
    });
}

function addFilter() {
    const field = document.getElementById('filter-field').value;
    const op = document.getElementById('filter-operator').value;
    const val = document.getElementById('filter-value').value;
    if (!field || !val) return;
    activeFilters.push({ field, op, val });
    renderFilterList();
    document.getElementById('filter-value').value = '';
}

function renderFilterList() {
    const list = document.getElementById('filter-list');
    list.innerHTML = activeFilters.map((f, i) => {
        const label = f.field.startsWith('q_') ? getQuestionLabel(f.field.substring(2)) : f.field;
        return '<div class="flex items-center gap-2 px-3 py-2 bg-indigo-50 rounded-lg border border-indigo-100 text-xs text-indigo-800">' +
            '<span class="font-medium">' + htmlspecialchars(label) + '</span>' +
            '<span class="text-indigo-400 text-[10px]">' + f.op.replace(/_/g, ' ') + '</span>' +
            '<span class="font-mono text-[10px]">' + htmlspecialchars(f.val) + '</span>' +
            '<button type="button" onclick="activeFilters.splice(' + i + ',1);renderFilterList()" class="ml-auto w-5 h-5 rounded hover:bg-indigo-200 flex items-center justify-center text-indigo-400 hover:text-indigo-700"><i class="fas fa-times text-[9px]"></i></button>' +
            '</div>';
    }).join('');
}

function applyFilters() {
    if (activeFilters.length === 0) {
        document.getElementById('filter-results-table-wrap').classList.add('hidden');
        document.getElementById('filter-result-count').textContent = '';
        return;
    }
    const { rows, columns } = getUnified('all');
    const filtered = rows.filter(r => {
        for (const f of activeFilters) {
            let val = r[f.field] !== undefined ? String(r[f.field]) : '';
            const fval = f.val.toLowerCase();
            const cellVal = val.toLowerCase();
            if (f.op === 'equals' && cellVal !== fval) return false;
            if (f.op === 'not_equals' && cellVal === fval) return false;
            if (f.op === 'contains' && !cellVal.includes(fval)) return false;
            if (f.op === 'gt' && (val === '' || parseFloat(val) <= parseFloat(f.val))) return false;
            if (f.op === 'lt' && (val === '' || parseFloat(val) >= parseFloat(f.val))) return false;
            if (f.op === 'between') {
                const v2 = document.getElementById('filter-value2').value;
                if (val === '' || parseFloat(val) < parseFloat(f.val) || parseFloat(val) > parseFloat(v2)) return false;
            }
            if (f.op === 'is_empty' && val !== '') return false;
            if (f.op === 'not_empty' && val === '') return false;
        }
        return true;
    });

    document.getElementById('filter-result-count').textContent = filtered.length + ' results';
    const wrap = document.getElementById('filter-results-table-wrap');
    if (filtered.length === 0) { wrap.classList.add('hidden'); return; }
    wrap.classList.remove('hidden');

    const displayCols = columns.filter(c => !c.startsWith('__') || c === '__id' || c === '__survey' || c === '__status' || c === '__date');
    const thead = document.getElementById('filter-results-header');
    const tbody = document.getElementById('filter-results-body');

    thead.innerHTML = displayCols.map(c => {
        let label = c;
        if (c === '__id') label = 'ID';
        else if (c === '__survey') label = 'Survey';
        else if (c === '__status') label = 'Status';
        else if (c === '__date') label = 'Date';
        else if (c.startsWith('q_')) label = getQuestionLabel(c.substring(2));
        return '<th class="px-3 py-2 text-left font-medium text-gray-600 border-b text-[10px]">' + label + '</th>';
    }).join('');

    tbody.innerHTML = filtered.map(r => {
        const surveyOpt = document.querySelector('#data-survey-filter option[value="' + r.__survey + '"]');
        const surveyLabel = surveyOpt ? surveyOpt.textContent : 'Survey ' + r.__survey;
        let html = '<tr class="hover:bg-gray-50 border-b border-gray-100">';
        displayCols.forEach(c => {
            if (c === '__id') html += '<td class="px-3 py-2 text-gray-500 font-mono text-[10px]">' + r.__id + '</td>';
            else if (c === '__survey') html += '<td class="px-3 py-2 text-gray-700 text-[10px]">' + surveyLabel + '</td>';
            else if (c === '__status') html += '<td class="px-3 py-2 text-[10px]">' + r.__status + '</td>';
            else if (c === '__date') html += '<td class="px-3 py-2 text-gray-400 text-[10px]">' + r.__date + '</td>';
            else html += '<td class="px-3 py-2 text-gray-600 text-[10px] max-w-[160px] truncate">' + htmlspecialchars(r[c] || '') + '</td>';
        });
        html += '</tr>';
        return html;
    }).join('');
}

function clearFilters() {
    activeFilters = []; renderFilterList();
    document.getElementById('filter-results-table-wrap').classList.add('hidden');
    document.getElementById('filter-result-count').textContent = '';
}

document.addEventListener('DOMContentLoaded', function() {
    const opEl = document.getElementById('filter-operator');
    if (opEl) opEl.addEventListener('change', function() {
        document.getElementById('filter-value2').classList.toggle('hidden', this.value !== 'between');
    });
});

// ============================================================
// TRANSFORM — real summaries & pivot
// ============================================================
function populateTransformFields() {
    [document.getElementById('pivot-rows'), document.getElementById('pivot-cols'), document.getElementById('pivot-values'), document.getElementById('stats-field')].forEach(s => {
        if (!s) return;
        s.innerHTML = '<option value="">Select field...</option>';
        const added = new Set();
        Object.entries(allQuestions).forEach(([sid, qlist]) => {
            qlist.forEach(q => {
                const key = 'q_' + q.id;
                if (!added.has(key)) {
                    added.add(key);
                    s.innerHTML += '<option value="' + key + '">' + htmlspecialchars(q.question_text || q.type) + '</option>';
                }
            });
        });
        if (s.id === 'pivot-values' || s.id === 'stats-field') {
            s.innerHTML += '<option value="__count">Count of responses</option>';
        }
    });
}

function runPivot() {
    const rowField = document.getElementById('pivot-rows').value;
    const colField = document.getElementById('pivot-cols').value;
    const valField = document.getElementById('pivot-values').value;
    if (!rowField || !colField) { alert('Select row and column fields'); return; }

    const { rows } = getUnified('all');
    const pivot = {};
    const rowLabels = new Set();
    const colLabels = new Set();

    rows.forEach(r => {
        const rv = r[rowField] || '(empty)';
        const cv = r[colField] || '(empty)';
        rowLabels.add(rv);
        colLabels.add(cv);
        const key = rv + '|||' + cv;
        pivot[key] = (pivot[key] || 0) + 1;
    });

    const rowArr = Array.from(rowLabels).sort();
    const colArr = Array.from(colLabels).sort();

    let html = '<div class="overflow-x-auto"><table class="w-full text-xs border-collapse border border-gray-200">';
    html += '<thead><tr class="bg-gray-50"><th class="px-2 py-1.5 border border-gray-200 text-left font-medium text-gray-600">' + htmlspecialchars(getQuestionLabel(rowField.substring(2))) + '</th>';
    colArr.forEach(c => { html += '<th class="px-2 py-1.5 border border-gray-200 text-center font-medium text-gray-600">' + htmlspecialchars(c) + '</th>'; });
    html += '<th class="px-2 py-1.5 border border-gray-200 text-center font-medium text-gray-600">Total</th></tr></thead><tbody>';
    rowArr.forEach(rv => {
        let rowTotal = 0;
        html += '<tr class="hover:bg-gray-50"><td class="px-2 py-1.5 border border-gray-200 font-medium text-gray-700">' + htmlspecialchars(rv) + '</td>';
        colArr.forEach(cv => {
            const count = pivot[rv + '|||' + cv] || 0;
            rowTotal += count;
            html += '<td class="px-2 py-1.5 border border-gray-200 text-center text-gray-600">' + (count || '-') + '</td>';
        });
        html += '<td class="px-2 py-1.5 border border-gray-200 text-center font-medium text-gray-700">' + rowTotal + '</td></tr>';
    });
    html += '</tbody></table></div>';
    if (rowArr.length === 0) html = '<div class="text-sm text-gray-400 text-center py-4">No data for pivot</div>';

    const body = document.getElementById('transform-results-body');
    body.innerHTML = html;
    document.getElementById('transform-results').classList.remove('hidden');
}

function runSummary() {
    const field = document.getElementById('stats-field').value;
    if (!field) { alert('Select a field'); return; }
    const { rows } = getUnified('all');
    const values = rows.map(r => r[field]).filter(v => v !== undefined && v !== '');

    if (field === '__count') {
        const body = document.getElementById('transform-results-body');
        body.innerHTML = '<div class="grid grid-cols-2 sm:grid-cols-4 gap-3">' +
            '<div class="bg-white rounded-lg border border-gray-200 p-3 text-center"><div class="text-2xl font-bold text-gray-900">' + rows.length + '</div><div class="text-[10px] text-gray-500">Total Responses</div></div>' +
            '<div class="bg-white rounded-lg border border-gray-200 p-3 text-center"><div class="text-2xl font-bold text-gray-900">' + Object.keys(questionMap).length + '</div><div class="text-[10px] text-gray-500">Questions</div></div>' +
            '<div class="bg-white rounded-lg border border-gray-200 p-3 text-center"><div class="text-2xl font-bold text-gray-900">' + Object.keys(allResponses).length + '</div><div class="text-[10px] text-gray-500">Surveys</div></div>' +
            '<div class="bg-white rounded-lg border border-gray-200 p-3 text-center"><div class="text-2xl font-bold text-gray-900">' + allAnswers.length + '</div><div class="text-[10px] text-gray-500">Total Answers</div></div>' +
            '</div>';
        document.getElementById('transform-results').classList.remove('hidden');
        return;
    }

    // Detect numeric
    const qId = parseInt(field.substring(2));
    const type = getQuestionType(qId);
    const numeric = isNumericType(type) || values.every(v => !isNaN(parseFloat(v)) && isFinite(v));
    const dist = getDistinctVals(rows, field);
    const total = values.length;

    let statsHtml = '';
    if (numeric && values.length > 0) {
        const nums = values.map(parseFloat).filter(v => !isNaN(v));
        const sum = nums.reduce((a, b) => a + b, 0);
        const avg = sum / nums.length;
        const sorted = [...nums].sort((a, b) => a - b);
        const min = sorted[0];
        const max = sorted[sorted.length - 1];
        const median = sorted.length % 2 === 0 ? (sorted[sorted.length/2 - 1] + sorted[sorted.length/2]) / 2 : sorted[Math.floor(sorted.length/2)];

        statsHtml = '<div class="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">' +
            '<div class="bg-white rounded-lg border border-gray-200 p-3 text-center"><div class="text-lg font-bold text-gray-900">' + total + '</div><div class="text-[10px] text-gray-500">Count</div></div>' +
            '<div class="bg-white rounded-lg border border-gray-200 p-3 text-center"><div class="text-lg font-bold text-gray-900">' + avg.toFixed(2) + '</div><div class="text-[10px] text-gray-500">Average</div></div>' +
            '<div class="bg-white rounded-lg border border-gray-200 p-3 text-center"><div class="text-lg font-bold text-gray-900">' + min + '</div><div class="text-[10px] text-gray-500">Min</div></div>' +
            '<div class="bg-white rounded-lg border border-gray-200 p-3 text-center"><div class="text-lg font-bold text-gray-900">' + max + '</div><div class="text-[10px] text-gray-500">Max</div></div>' +
            '</div>' +
            '<div class="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">' +
            '<div class="bg-white rounded-lg border border-gray-200 p-3 text-center"><div class="text-lg font-bold text-gray-900">' + median.toFixed(2) + '</div><div class="text-[10px] text-gray-500">Median</div></div>' +
            '<div class="bg-white rounded-lg border border-gray-200 p-3 text-center"><div class="text-lg font-bold text-gray-900">' + nums.length + '</div><div class="text-[10px] text-gray-500">Numeric Values</div></div>' +
            '<div class="bg-white rounded-lg border border-gray-200 p-3 text-center"><div class="text-lg font-bold text-gray-900">' + (total - nums.length) + '</div><div class="text-[10px] text-gray-500">Non-numeric</div></div>' +
            '<div class="bg-white rounded-lg border border-gray-200 p-3 text-center"><div class="text-lg font-bold text-gray-900">' + Object.keys(dist).length + '</div><div class="text-[10px] text-gray-500">Unique Values</div></div>' +
            '</div>';
    }

    // Distribution bar
    const topVals = dist.slice(0, 15);
    const maxCount = topVals.length > 0 ? topVals[0].count : 1;
    statsHtml += '<div class="bg-white rounded-lg border border-gray-200 p-3"><div class="text-xs font-semibold text-gray-700 mb-2">Distribution (top ' + topVals.length + ')</div>';
    statsHtml += '<div class="space-y-1">';
    topVals.forEach(d => {
        const pct = ((d.count / total) * 100).toFixed(1);
        const barW = (d.count / maxCount) * 100;
        statsHtml += '<div class="flex items-center gap-2">' +
            '<span class="text-[10px] text-gray-600 w-24 truncate text-right" title="' + htmlspecialchars(d.label) + '">' + htmlspecialchars(d.label.length > 20 ? d.label.substring(0, 18) + '...' : d.label) + '</span>' +
            '<div class="flex-1 bg-gray-100 rounded-full h-3 overflow-hidden"><div class="bg-indigo-500 h-full rounded-full transition-all" style="width:' + barW + '%"></div></div>' +
            '<span class="text-[10px] text-gray-500 w-12 text-right">' + d.count + ' (' + pct + '%)</span>' +
            '</div>';
    });
    statsHtml += '</div></div>';

    const label = field.startsWith('q_') ? getQuestionLabel(field.substring(2)) : field;
    const body = document.getElementById('transform-results-body');
    body.innerHTML = '<div class="mb-2"><span class="text-sm font-semibold text-gray-700">' + htmlspecialchars(label) + '</span><span class="text-[10px] text-gray-400 ml-2">' + (numeric ? 'Numeric' : 'Text') + ' field</span></div>' + statsHtml;
    document.getElementById('transform-results').classList.remove('hidden');
}

function removeDuplicates() {
    const { rows } = getUnified('all');
    const seen = new Set();
    const uniq = [];
    rows.forEach(r => {
        const sig = Object.entries(r).filter(([k]) => k.startsWith('q_')).map(([,v]) => String(v)).join('|');
        if (!seen.has(sig)) { seen.add(sig); uniq.push(r); }
    });
    const removed = rows.length - uniq.length;
    const body = document.getElementById('transform-results-body');
    body.innerHTML = '<div class="bg-emerald-50 border border-emerald-200 rounded-lg p-4 text-xs text-emerald-700"><i class="fas fa-check-circle mr-1"></i>Found <strong>' + removed + '</strong> duplicate response' + (removed !== 1 ? 's' : '') + ' (keeping ' + uniq.length + ' unique). Export for permanent deduplication.</div>';
    document.getElementById('transform-results').classList.remove('hidden');
}

function removeOutliers() {
    const { rows } = getUnified('all');
    // Check all numeric fields for outliers (IQR method)
    const outliers = [];
    Object.keys(questionMap).forEach(qId => {
        const field = 'q_' + qId;
        const type = getQuestionType(qId);
        if (!isNumericType(type)) return;
        const vals = rows.map(r => parseFloat(r[field])).filter(v => !isNaN(v)).sort((a, b) => a - b);
        if (vals.length < 4) return;
        const q1 = vals[Math.floor(vals.length * 0.25)];
        const q3 = vals[Math.floor(vals.length * 0.75)];
        const iqr = q3 - q1;
        const lower = q1 - 1.5 * iqr;
        const upper = q3 + 1.5 * iqr;
        const fieldOutliers = vals.filter(v => v < lower || v > upper);
        if (fieldOutliers.length > 0) {
            outliers.push({ field: getQuestionLabel(qId), count: fieldOutliers.length, lower: lower.toFixed(2), upper: upper.toFixed(2) });
        }
    });
    let html;
    if (outliers.length === 0) {
        html = '<div class="bg-emerald-50 border border-emerald-200 rounded-lg p-4 text-xs text-emerald-700"><i class="fas fa-check-circle mr-1"></i>No outliers detected in numeric fields.</div>';
    } else {
        html = '<div class="bg-amber-50 border border-amber-200 rounded-lg p-4 text-xs text-amber-700"><i class="fas fa-info-circle mr-1"></i>Outliers detected in ' + outliers.length + ' field' + (outliers.length > 1 ? 's' : '') + ':</div>';
        html += '<div class="mt-2 space-y-1">' + outliers.map(o =>
            '<div class="text-xs text-gray-600 flex items-center gap-2"><span class="font-medium">' + o.field + '</span><span class="text-gray-400">' + o.count + ' outliers (outside ' + o.lower + '–' + o.upper + ')</span></div>'
        ).join('') + '</div>';
    }
    const body = document.getElementById('transform-results-body');
    body.innerHTML = html;
    document.getElementById('transform-results').classList.remove('hidden');
}

function exportFilteredCSV() {
    const surveyFilter = document.getElementById('data-survey-filter').value;
    const { rows, columns } = getUnified(surveyFilter);
    const displayCols = columns.filter(c => c !== '__created_at' && c !== '__duration');
    const headers = displayCols.map(c => {
        if (c === '__id') return 'Response ID';
        if (c === '__survey') return 'Survey';
        if (c === '__status') return 'Status';
        if (c === '__quality') return 'Quality Score';
        if (c === '__date') return 'Date';
        if (c.startsWith('q_')) return getQuestionLabel(c.substring(2));
        return c;
    });
    let csv = headers.map(h => '"' + String(h).replace(/"/g, '""') + '"').join(',') + '\n';
    rows.forEach(r => {
        csv += displayCols.map(c => {
            let val = r[c] !== undefined ? String(r[c]) : '';
            return '"' + val.replace(/"/g, '""') + '"';
        }).join(',') + '\n';
    });
    const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'research-data-export.csv';
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

// ============================================================
// DATA PROFILING — auto stats for all fields
// ============================================================
function runDataProfiling() {
    const { rows } = getUnified('all');
    if (rows.length === 0) return;
    const container = document.createElement('div');
    container.className = 'bg-white rounded-xl border border-gray-200 p-4 mb-4';
    container.innerHTML = '<div class="flex items-center gap-2 mb-3"><i class="fas fa-chart-simple text-indigo-400 text-xs"></i><span class="text-sm font-semibold text-gray-700">Data Profile</span><span class="text-[10px] text-gray-400">' + rows.length + ' responses</span></div>';
    let profileHtml = '<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">';

    Object.keys(questionMap).forEach(qId => {
        const field = 'q_' + qId;
        const vals = rows.map(r => r[field]).filter(v => v !== undefined && v !== '');
        const total = vals.length;
        const type = getQuestionType(qId);
        const label = getQuestionLabel(qId);
        const numeric = isNumericType(type) || vals.every(v => !isNaN(parseFloat(v)) && isFinite(v));
        const dist = getDistinctVals(rows, field);
        const unique = dist.length;

        let summary = '';
        if (numeric && vals.length > 0) {
            const nums = vals.map(parseFloat).filter(v => !isNaN(v));
            const avg = nums.reduce((a, b) => a + b, 0) / nums.length;
            const sorted = [...nums].sort((a, b) => a - b);
            summary = '<span class="text-[9px] text-gray-400">Avg ' + avg.toFixed(1) + ' · Range ' + sorted[0] + '–' + sorted[sorted.length - 1] + '</span>';
        } else {
            const top = dist[0];
            summary = '<span class="text-[9px] text-gray-400">' + unique + ' unique · Top: ' + (top ? htmlspecialchars(top.label.length > 15 ? top.label.substring(0, 13) + '...' : top.label) : '—') + '</span>';
        }

        profileHtml += '<div class="border border-gray-100 rounded-lg p-2.5 hover:border-indigo-200 transition-colors">' +
            '<div class="flex items-center justify-between mb-0.5">' +
            '<span class="text-[10px] font-medium text-gray-700 truncate" title="' + htmlspecialchars(label) + '">' + htmlspecialchars(label.length > 25 ? label.substring(0, 23) + '...' : label) + '</span>' +
            '<span class="text-[9px] px-1 py-0.5 rounded bg-gray-100 text-gray-500">' + type + '</span>' +
            '</div>' +
            '<div class="flex items-center gap-2 text-[10px]"><span class="font-semibold text-gray-800">' + total + '</span><span class="text-gray-300">/</span>' + summary + '</div>' +
            '</div>';
    });
    profileHtml += '</div>';
    container.innerHTML += profileHtml;

    // Insert after data sources
    const dataSection = document.querySelector('#tab-data .grid');
    if (dataSection) dataSection.after(container);
}

// ============================================================
// VISUALIZATION — real answer distributions
// ============================================================
function updateVizFields() {
    const surveyId = document.getElementById('viz-survey').value;
    const labelSel = document.getElementById('viz-label');
    const valSel = document.getElementById('viz-value');
    labelSel.innerHTML = ''; valSel.innerHTML = '';

    const added = new Set();
    const process = (qlist) => {
        qlist.forEach(q => {
            const key = 'q_' + q.id;
            if (!added.has(key)) {
                added.add(key);
                const label = q.question_text || q.type;
                labelSel.innerHTML += '<option value="' + key + '">' + htmlspecialchars(label) + '</option>';
                valSel.innerHTML += '<option value="' + key + '">' + htmlspecialchars(label) + '</option>';
            }
        });
    };
    if (surveyId === 'all') Object.values(allQuestions).forEach(qlist => process(qlist));
    else if (allQuestions[surveyId]) process(allQuestions[surveyId]);
}

function selectChartType(type, btn) {
    selectedChartType = type;
    document.querySelectorAll('.chart-type-btn').forEach(b => {
        b.classList.remove('border-pink-500', 'bg-pink-50', 'text-pink-700');
        b.classList.add('border-transparent', 'bg-gray-50', 'text-gray-600');
    });
    btn.classList.remove('border-transparent', 'bg-gray-50', 'text-gray-600');
    btn.classList.add('border-pink-500', 'bg-pink-50', 'text-pink-700');
}

function renderChart() {
    const name = document.getElementById('viz-name').value.trim() || 'Untitled Chart';
    const labelField = document.getElementById('viz-label').value;
    const valField = document.getElementById('viz-value').value;
    const surveyId = document.getElementById('viz-survey').value;
    const aggr = document.getElementById('viz-aggr').value;

    if (!labelField || !valField) { alert('Select label and value fields'); return; }

    const { rows } = getUnified(surveyId === 'all' ? 'all' : surveyId);

    // Build label distribution
    const dist = getDistinctVals(rows, labelField).slice(0, 20);

    let labels = dist.map(d => d.label);
    let values;

    if (aggr === 'count' || aggr === 'percentage') {
        const total = dist.reduce((s, d) => s + d.count, 0);
        values = dist.map(d => aggr === 'percentage' ? parseFloat(((d.count / total) * 100).toFixed(1)) : d.count);
    } else if (aggr === 'distinct') {
        values = dist.map(d => d.count);
    } else {
        // average/sum of valField grouped by labelField
        const grouped = {};
        rows.forEach(r => {
            const lv = (r[labelField] !== undefined && r[labelField] !== '') ? r[labelField] : '(empty)';
            const vv = parseFloat(r[valField]);
            if (!isNaN(vv)) {
                if (!grouped[lv]) grouped[lv] = [];
                grouped[lv].push(vv);
            }
        });
        labels = Object.keys(grouped);
        values = labels.map(l => {
            const nums = grouped[l];
            return aggr === 'sum' ? nums.reduce((a, b) => a + b, 0) : nums.reduce((a, b) => a + b, 0) / nums.length;
        });
    }

    if (labels.length === 0) { alert('No data for selected fields'); return; }

    const colors = COLORS.slice(0, labels.length);

    const ctx = document.getElementById('chart-canvas').getContext('2d');
    if (currentChart) currentChart.destroy();
    document.getElementById('chart-empty').classList.add('hidden');

    const config = {
        type: selectedChartType,
        data: {
            labels: labels,
            datasets: [{
                label: name,
                data: values,
                backgroundColor: selectedChartType === 'line' ? '#6366f1' : colors,
                borderColor: selectedChartType === 'line' ? '#6366f1' : colors,
                borderWidth: 1,
                fill: selectedChartType === 'line'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: selectedChartType !== 'bar' && selectedChartType !== 'line' },
                tooltip: {
                    callbacks: {
                        label: function(ctx) {
                            let val = ctx.parsed.y !== undefined ? ctx.parsed.y : ctx.parsed.r;
                            if (aggr === 'percentage') return val + '%';
                            return val;
                        }
                    }
                }
            },
            scales: selectedChartType === 'bar' || selectedChartType === 'line' ? {
                y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.05)' } },
                x: { grid: { display: false } }
            } : undefined
        }
    };

    currentChart = new Chart(ctx, config);

    document.getElementById('save-viz-form').classList.remove('hidden');
    document.getElementById('save-viz-name').value = name;
    document.getElementById('save-viz-type').value = selectedChartType;
    document.getElementById('save-viz-config').value = JSON.stringify({ labelField, valField, surveyId, aggr, labels, values });
}

function loadSavedViz(vizId) {
    window.location.hash = 'viz';
    switchTab('viz');
}

// ============================================================
// TIMELINE — response volume over time
// ============================================================
function renderTimeline() {
    const { rows } = getUnified('all');
    const dates = {};
    rows.forEach(r => {
        if (r.__created_at) {
            const d = r.__created_at.substring(0, 10);
            dates[d] = (dates[d] || 0) + 1;
        }
    });
    const sorted = Object.entries(dates).sort((a, b) => a[0].localeCompare(b[0]));
    if (sorted.length < 2) return;

    // Add timeline mini-chart inline
    const container = document.createElement('div');
    container.className = 'bg-white rounded-xl border border-gray-200 p-4 mb-4';
    container.innerHTML = '<div class="flex items-center gap-2 mb-3"><i class="fas fa-chart-line text-emerald-400 text-xs"></i><span class="text-sm font-semibold text-gray-700">Response Timeline</span></div>' +
        '<div style="height:120px"><canvas id="timeline-canvas"></canvas></div>';

    const dataSection = document.querySelector('#tab-data .overflow-x-auto');
    if (dataSection && dataSection.closest('.bg-white')) {
        dataSection.closest('.bg-white').before(container);
    } else if (dataSection) {
        dataSection.before(container);
    }

    const ctx = document.getElementById('timeline-canvas').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: sorted.map(d => d[0]),
            datasets: [{
                label: 'Responses',
                data: sorted.map(d => d[1]),
                borderColor: '#10b981',
                backgroundColor: 'rgba(16,185,129,0.1)',
                fill: true,
                tension: 0.3,
                pointRadius: 3,
                pointBackgroundColor: '#10b981'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.04)' }, ticks: { font: { size: 9 } } },
                x: { grid: { display: false }, ticks: { font: { size: 9 }, maxTicksLimit: 10 } }
            }
        }
    });
}

// ============================================================
// INIT
// ============================================================
const hasData = document.getElementById('data-table-header') !== null;
populateFilterFields();
populateTransformFields();
if (hasData) {
    renderDataTable();
    runDataProfiling();
    renderTimeline();
}

setTimeout(function() {
    if (window.location.hash === '#viz') switchTab('viz');
}, 100);
</script>

