<div class="space-y-6">
    <div class="flex items-center justify-between">
        <div>
            <h1 class="text-2xl font-bold text-gray-900">Researcher Dashboard</h1>
            <p class="text-gray-500 text-sm mt-1">Manage your surveys and monitor data quality</p>
        </div>
        <a href="<?= url('/survey/create') ?>" class="inline-flex items-center gap-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-5 py-2.5 rounded-xl hover:from-indigo-700 hover:to-purple-700 transition-all shadow-sm text-sm font-medium">
            <i class="fas fa-plus"></i>New Survey
        </a>
    </div>

    <a href="<?= url('/research') ?>" class="group block bg-gradient-to-r from-indigo-50 to-purple-50 border border-indigo-100 hover:border-indigo-200 rounded-xl p-4 hover:shadow-lg transition-all">
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center text-white shadow-sm group-hover:scale-110 group-hover:rotate-3 transition-all"><i class="fas fa-flask"></i></div>
            <div class="flex-1">
                <div class="font-semibold text-gray-900 group-hover:text-indigo-600 transition-colors">Research Ground</div>
                <div class="text-xs text-gray-500">Analyze, filter, transform, and visualize your response data</div>
            </div>
            <div class="w-8 h-8 rounded-lg bg-white/60 flex items-center justify-center group-hover:bg-white group-hover:translate-x-1 transition-all">
                <i class="fas fa-arrow-right text-indigo-400 group-hover:text-indigo-600 text-sm"></i>
            </div>
        </div>
    </a>

    <div class="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div class="bg-white p-5 rounded-xl shadow-sm border border-gray-200 hover:shadow-md hover:border-blue-200 transition-all hover:-translate-y-0.5">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center text-blue-600"><i class="fas fa-clipboard-list"></i></div>
                <div>
                    <div class="text-2xl font-bold text-gray-900"><?= ($stats['total_surveys'] ?? 0) ?></div>
                    <div class="text-xs text-gray-500">Total Surveys</div>
                </div>
            </div>
        </div>
        <div class="bg-white p-5 rounded-xl shadow-sm border border-gray-200 hover:shadow-md hover:border-emerald-200 transition-all hover:-translate-y-0.5">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 bg-green-50 rounded-xl flex items-center justify-center text-green-600"><i class="fas fa-play-circle"></i></div>
                <div>
                    <div class="text-2xl font-bold text-green-600"><?= ($stats['active_surveys'] ?? 0) ?></div>
                    <div class="text-xs text-gray-500">Active</div>
                </div>
            </div>
        </div>
        <div class="bg-white p-5 rounded-xl shadow-sm border border-gray-200 hover:shadow-md hover:border-purple-200 transition-all hover:-translate-y-0.5">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 bg-purple-50 rounded-xl flex items-center justify-center text-purple-600"><i class="fas fa-reply-all"></i></div>
                <div>
                    <div class="text-2xl font-bold text-purple-600"><?= ($stats['total_responses'] ?? 0) ?></div>
                    <div class="text-xs text-gray-500">Total Responses</div>
                </div>
            </div>
        </div>
        <div class="bg-white p-5 rounded-xl shadow-sm border border-gray-200 hover:shadow-md hover:border-amber-200 transition-all hover:-translate-y-0.5">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 bg-amber-50 rounded-xl flex items-center justify-center text-amber-600"><i class="fas fa-check-double"></i></div>
                <div>
                    <div class="text-2xl font-bold <?= ($stats['quality_rate'] ?? 0) >= 80 ? 'text-emerald-600' : (($stats['quality_rate'] ?? 0) >= 50 ? 'text-amber-600' : 'text-red-600') ?>"><?= ($stats['quality_rate'] ?? 0) ?>%</div>
                    <div class="text-xs text-gray-500">Quality Rate</div>
                </div>
            </div>
        </div>
    </div>

    <!-- Surveys -->
    <?php if (empty($surveys)): ?>
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
            <div class="w-20 h-20 bg-gradient-to-br from-indigo-50 to-purple-50 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <i class="fas fa-clipboard-list text-3xl text-indigo-400"></i>
            </div>
            <h2 class="text-xl font-bold text-gray-900 mb-2">No surveys yet</h2>
            <p class="text-gray-500 mb-6">Create your first survey and start collecting quality data.</p>
            <a href="<?= url('/survey/create') ?>" class="inline-flex items-center gap-2 bg-indigo-600 text-white px-6 py-2.5 rounded-xl hover:bg-indigo-700 transition-all">
                <i class="fas fa-plus"></i>Create Survey
            </a>
        </div>
    <?php else: ?>
        <div class="bg-white rounded-xl shadow-sm border border-gray-200">
            <div class="p-4 border-b border-gray-100">
                <h2 class="font-semibold text-gray-900">Your Surveys</h2>
            </div>
            <div class="divide-y divide-gray-100">
                <?php foreach ($surveys as $s): ?>
                    <div class="px-4 sm:px-5 py-3.5 flex items-center justify-between hover:bg-indigo-50/30 transition-colors group">
                        <div class="min-w-0 flex-1">
                            <div class="flex items-center gap-2.5 flex-wrap">
                                <a href="<?= url('/survey/edit/' . ($s['id'] ?? '')) ?>" class="font-semibold text-gray-900 hover:text-indigo-600 transition-colors truncate group-hover:text-indigo-600">
                                    <?= htmlspecialchars($s['title'] ?? '') ?>
                                </a>
                                <span class="px-2 py-0.5 text-xs rounded-full font-medium
                                    <?= ($s['status'] ?? '') === 'active' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : (($s['status'] ?? '') === 'draft' ? 'bg-gray-50 text-gray-600 border border-gray-200' : 'bg-amber-50 text-amber-700 border border-amber-200') ?>">
                                    <?= ucfirst(($s['status'] ?? '')) ?>
                                </span>
                            </div>
                            <div class="flex items-center gap-4 mt-1.5 text-xs text-gray-500">
                                <span class="flex items-center gap-1"><i class="fas fa-reply-all text-gray-300"></i><?= $s['total_responses'] ?? 0 ?> responses</span>
                                <span class="flex items-center gap-1"><i class="fas fa-check-circle text-emerald-300"></i><?= $s['quality_responses'] ?? 0 ?> quality</span>
                                <?php if ((($s['avg_quality'] ?? '') ?? null) !== null): ?>
                                    <span class="flex items-center gap-1 text-indigo-500"><i class="fas fa-chart-line"></i><?= ($s['avg_quality'] ?? '') ?> avg</span>
                                <?php endif; ?>
                                <?php if ((float)($s['min_reputation'] ?? 0) > 0): ?>
                                    <span class="flex items-center gap-1"><i class="fas fa-shield-alt text-amber-300"></i>Min <?= number_format((float)($s['min_reputation'] ?? 0), 1) ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="flex items-center gap-0.5 ml-4 opacity-60 group-hover:opacity-100 transition-opacity">
                            <a href="<?= url('/survey/view/' . ($s['id'] ?? '')) ?>" class="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors" title="Preview"><i class="fas fa-eye"></i></a>
                            <a href="<?= url('/survey/edit/' . ($s['id'] ?? '')) ?>" class="p-2 text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors" title="Edit"><i class="fas fa-pen"></i></a>
                            <a href="<?= url('/survey/results/' . ($s['id'] ?? '')) ?>" class="p-2 text-gray-400 hover:text-purple-600 hover:bg-purple-50 rounded-lg transition-colors" title="Results"><i class="fas fa-chart-bar"></i></a>
                            <a href="<?= url('/quality/' . ($s['id'] ?? '')) ?>" class="p-2 text-gray-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors" title="Quality"><i class="fas fa-check-double"></i></a>
                            <a href="<?= url('/export/' . ($s['id'] ?? '')) ?>" class="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors" title="Export"><i class="fas fa-download"></i></a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Recent Responses -->
        <?php if (!empty($stats['recent_responses'])): ?>
        <div class="bg-white rounded-xl shadow-sm border border-gray-200">
            <div class="p-4 border-b border-gray-100">
                <h2 class="font-semibold text-gray-900">Recent Responses</h2>
            </div>
            <div class="divide-y divide-gray-100">
                <?php foreach ($stats['recent_responses'] as $r): ?>
                    <div class="p-3.5 flex items-center justify-between text-sm">
                        <div>
                            <span class="font-medium text-gray-900"><?= htmlspecialchars($r['survey_title'] ?? '') ?></span>
                            <span class="text-gray-500 ml-2">#<?= ($r['id'] ?? '') ?></span>
                        </div>
                        <div class="flex items-center gap-2">
                            <span class="text-xs text-gray-400"><?= date('M j, H:i', strtotime(($r['created_at'] ?? ''))) ?></span>
                            <span class="px-2 py-0.5 text-xs rounded-full font-medium
                                <?= ($r['status'] ?? '') === 'completed' ? 'bg-blue-50 text-blue-700' : (($r['status'] ?? '') === 'flagged' ? 'bg-amber-50 text-amber-700' : 'bg-gray-50 text-gray-600') ?>">
                                <?= ucfirst(($r['status'] ?? '')) ?>
                            </span>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
    <?php endif; ?>
</div>
