<div class="max-w-3xl mx-auto">
  <div class="text-center mb-12 slide-up">
    <div class="w-20 h-20 mx-auto rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center mb-6 shadow-lg">
      <i class="fas fa-pen-fancy text-white text-3xl"></i>
    </div>
    <h1 class="text-3xl font-bold text-gray-900 mb-2">Create a New Survey</h1>
    <p class="text-gray-500 text-lg max-w-xl mx-auto">Choose how you want to engage your respondents — traditional form or AI-powered conversation</p>
  </div>

  <div class="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
    <!-- Form Survey Card -->
    <a href="<?= url('/survey/create/form') ?>" class="group block glass-card rounded-2xl p-8 overflow-hidden border-2 border-indigo-200/50 hover:border-indigo-400 hover:shadow-xl hover:shadow-indigo-200/30 transition-all duration-300 animate-fade-in-up" style="animation-delay:0.1s">
      <div class="flex items-center gap-3 mb-6">
        <span class="w-14 h-14 rounded-2xl bg-gradient-to-br from-indigo-100 to-indigo-200 flex items-center justify-center group-hover:scale-110 transition-transform duration-300 group-hover:bg-gradient-to-br group-hover:from-indigo-500 group-hover:to-indigo-600">
          <i class="fas fa-wpforms text-indigo-600 text-3xl group-hover:text-white transition-colors duration-300"></i>
        </span>
        <div>
          <h2 class="text-xl font-bold text-gray-900 group-hover:text-indigo-700 transition-colors">Form Survey</h2>
          <p class="text-gray-500 text-sm mt-1">Classic step-by-step questionnaire</p>
        </div>
      </div>
      <p class="text-gray-500 text-sm mb-6">Build traditional surveys with 24+ question types, conditional logic, skip patterns, and advanced validation.</p>
      <div class="flex flex-wrap gap-2 mb-6">
        <span class="text-[10px] px-2.5 py-1 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200 font-medium">24+ question types</span>
        <span class="text-[10px] px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 font-medium">Logic & skip</span>
        <span class="text-[10px] px-2.5 py-1 rounded-full bg-purple-50 text-purple-700 border border-purple-200 font-medium">Drag reorder</span>
        <span class="text-[10px] px-2.5 py-1 rounded-full bg-amber-50 text-amber-700 border border-amber-200 font-medium">Bulk import</span>
        <span class="text-[10px] px-2.5 py-1 rounded-full bg-pink-50 text-pink-700 border border-pink-200 font-medium">AI assistant</span>
      </div>
      <div class="pt-4 border-t border-indigo-100 flex items-center justify-between text-sm">
        <span class="text-gray-500">Best for:</span>
        <span class="font-semibold text-indigo-600">Traditional data collection</span>
      </div>
    </a>

    <!-- Chat Survey Card -->
    <a href="<?= url('/survey/create/chat') ?>" class="group block glass-card rounded-2xl p-8 overflow-hidden border-2 border-emerald-200/50 hover:border-emerald-400 hover:shadow-xl hover:shadow-emerald-200/30 transition-all duration-300 animate-fade-in-up" style="animation-delay:0.2s">
      <div class="flex items-center gap-3 mb-6">
        <span class="w-14 h-14 rounded-2xl bg-gradient-to-br from-emerald-100 to-emerald-200 flex items-center justify-center group-hover:scale-110 transition-transform duration-300 group-hover:bg-gradient-to-br group-hover:from-emerald-500 group-hover:to-emerald-600">
          <i class="fas fa-comment-dots text-emerald-600 text-3xl group-hover:text-white transition-colors duration-300"></i>
        </span>
        <div>
          <h2 class="text-xl font-bold text-gray-900 group-hover:text-emerald-700 transition-colors">Chat Survey</h2>
          <p class="text-gray-500 text-sm mt-1">AI-powered conversational experience</p>
        </div>
      </div>
      <p class="text-gray-500 text-sm mb-6">Create intelligent conversations that adapt in real-time. AI asks follow-ups, analyzes sentiment, and keeps respondents engaged.</p>
      <div class="flex flex-wrap gap-2 mb-6">
        <span class="text-[10px] px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 font-medium">AI driven</span>
        <span class="text-[10px] px-2.5 py-1 rounded-full bg-purple-50 text-purple-700 border border-purple-200 font-medium">Adaptive flow</span>
        <span class="text-[10px] px-2.5 py-1 rounded-full bg-pink-50 text-pink-700 border border-pink-200 font-medium">Sentiment aware</span>
        <span class="text-[10px] px-2.5 py-1 rounded-full bg-blue-50 text-blue-700 border border-blue-200 font-medium">Follow-up depth</span>
        <span class="text-[10px] px-2.5 py-1 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200 font-medium">Injection safe</span>
      </div>
      <div class="pt-4 border-t border-emerald-100 flex items-center justify-between text-sm">
        <span class="text-gray-500">Best for:</span>
        <span class="font-semibold text-emerald-600">Qualitative insights</span>
      </div>
    </a>
  </div>

  <div class="mt-12 text-center">
    <p class="text-gray-400 text-sm">Not sure which to choose? <a href="#" class="text-indigo-600 hover:text-indigo-700 font-medium">Learn more about survey types</a></p>
  </div>
</div>

<style>
@keyframes fade-in-up {
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
}
.animate-fade-in-up { animation: fade-in-up 0.5s ease-out forwards; }
</style>