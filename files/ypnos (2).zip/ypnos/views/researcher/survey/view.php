<div class="max-w-3xl mx-auto">
    <div class="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 mb-6">
        <div class="flex items-center justify-between">
            <div>
                <div class="flex items-center gap-2 mb-1">
                    <h1 class="text-2xl font-bold text-gray-900"><?= htmlspecialchars($survey['title'] ?? '') ?></h1>
                    <?php if (($surveyType ?? 'form') === 'chat'): ?>
                        <span class="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-100 text-emerald-700"><i class="fas fa-comment-dots mr-1"></i>Chat</span>
                    <?php endif; ?>
                </div>
                <p class="text-gray-500 mt-1"><?= htmlspecialchars($survey['description'] ?? '') ?></p>
            </div>
            <div class="text-right">
                <span class="px-3 py-1 text-sm rounded-full font-medium
                    <?= ($survey['status'] ?? '') === 'active' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : (($survey['status'] ?? '') === 'draft' ? 'bg-gray-50 text-gray-600 border border-gray-200' : 'bg-amber-50 text-amber-700 border border-amber-200') ?>">
                    <?= ucfirst($survey['status'] ?? '') ?>
                </span>
                <?php if ((float)($survey['min_reputation'] ?? 0) > 0): ?>
                    <div class="mt-1.5 text-xs text-amber-600"><i class="fas fa-shield-alt mr-1"></i>Min rep: <?= number_format((float)($survey['min_reputation'] ?? 0), 1) ?></div>
                <?php endif; ?>
            </div>
        </div>
        <div class="flex items-center gap-4 mt-4 text-sm text-gray-400">
            <span><i class="far fa-question-circle mr-1.5"></i><?= count($questions ?? []) ?> <?= ($surveyType ?? 'form') === 'chat' ? 'nodes' : 'questions' ?></span>
            <span><i class="fas fa-tachometer-alt mr-1.5"></i>Threshold: <?= $survey['quality_threshold'] ?? '70' ?></span>
        </div>
        <?php if (($surveyType ?? 'form') === 'chat' && !empty($chatConfig)): ?>
        <div class="flex flex-wrap gap-3 mt-4 text-xs text-gray-500">
            <?php if (!empty($chatConfig['intro_message'])): ?>
                <span><i class="fas fa-wavefare text-emerald-400 mr-1"></i>Intro: <?= htmlspecialchars(mb_substr($chatConfig['intro_message'], 0, 60)) ?><?= mb_strlen($chatConfig['intro_message']) > 60 ? '...' : '' ?></span>
            <?php endif; ?>
            <?php if (!empty($chatConfig['tone'])): ?>
                <span><i class="fas fa-robot text-emerald-400 mr-1"></i>Tone: <?= htmlspecialchars($chatConfig['tone']) ?></span>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>

    <div class="bg-white rounded-2xl shadow-sm border border-gray-200">
        <div class="p-4 border-b border-gray-100 flex items-center justify-between">
            <h2 class="font-bold text-gray-900"><?= ($surveyType ?? 'form') === 'chat' ? 'Conversation Flow' : 'Questions' ?></h2>
            <span class="text-xs text-gray-400"><?= count($questions) ?> total</span>
        </div>
        <?php if (empty($questions)): ?>
            <div class="p-8 text-center text-gray-500">No <?= ($surveyType ?? 'form') === 'chat' ? 'conversation nodes' : 'questions' ?> yet</div>
        <?php else: ?>
            <div class="divide-y divide-gray-100">
                <?php foreach ($questions as $i => $q): ?>
                    <div class="p-4 hover:bg-gray-50/50 transition-colors">
                        <div class="flex items-start gap-3">
                            <span class="flex-shrink-0 w-7 h-7 rounded-full <?= ($surveyType ?? 'form') === 'chat' ? 'bg-emerald-100 text-emerald-700' : 'bg-indigo-100 text-indigo-700' ?> flex items-center justify-center text-xs font-bold"><?= $i + 1 ?></span>
                            <div class="min-w-0 flex-1">
                                <p class="font-medium text-gray-900 text-sm"><?= htmlspecialchars($q['question_text'] ?? '') ?></p>
                                <div class="flex items-center gap-2 mt-1.5">
                                    <span class="px-2 py-0.5 text-xs rounded-full bg-gray-100 text-gray-600"><?= str_replace('_', ' ', $q['type'] ?? '') ?></span>
                                    <?php if (!empty($q['is_required'])): ?>
                                        <span class="text-xs text-red-400">Required</span>
                                    <?php endif; ?>
                                    <?php if (!empty($q['is_attention_check'])): ?>
                                        <span class="px-2 py-0.5 text-xs bg-amber-50 text-amber-700 border border-amber-200 rounded-full">Attention Check</span>
                                    <?php endif; ?>
                                    <?php if (!empty($q['is_trap'])): ?>
                                        <span class="px-2 py-0.5 text-xs bg-red-50 text-red-700 border border-red-200 rounded-full">Trap</span>
                                    <?php endif; ?>
                                </div>
                                <?php if (!empty($q['options_json']) && $options = json_decode($q['options_json'], true)): ?>
                                    <div class="mt-2 flex flex-wrap gap-1.5">
                                        <?php foreach ($options as $opt): ?>
                                            <span class="px-2.5 py-1 text-xs bg-gray-50 border border-gray-200 rounded-lg"><?= htmlspecialchars($opt) ?></span>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <div class="mt-6 flex gap-2">
        <a href="<?= url('/survey/edit/' . ($survey['id'] ?? '')) ?>" class="px-5 py-2.5 border border-gray-300 rounded-xl hover:bg-gray-50 transition-colors text-sm font-medium">Edit Survey</a>
        <?php if (($surveyType ?? 'form') !== 'chat'): ?>
        <a href="<?= url('/survey/' . ($survey['id'] ?? '')) ?>/questions/add" class="px-5 py-2.5 border border-gray-300 rounded-xl hover:bg-gray-50 transition-colors text-sm font-medium">Add Question</a>
        <?php endif; ?>
        <a href="<?= url('/survey/take/' . ($survey['id'] ?? '')) ?>" class="px-5 py-2.5 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-colors text-sm font-medium">Preview as Respondent</a>
    </div>
</div>