<?php
$questions = $questions ?? [];
$isFormMode = ($surveyType ?? "form") === "form";
?>
<div class="max-w-7xl mx-auto">
  <!-- Header -->
  <div class="flex items-center justify-between flex-wrap gap-3 mb-6 slide-up">
    <div class="flex items-center gap-4">
      <div class="w-12 h-12 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white text-lg shadow-lg shadow-indigo-200"><i class="fas fa-pen-ruler"></i></div>
      <div>
        <div class="flex items-center gap-2.5 flex-wrap">
          <h1 class="text-xl font-bold text-gray-900"><?= htmlspecialchars(
              $survey["title"] ?? "",
          ) ?></h1>
          <span id="survey-mode-badge-top" class="px-2.5 py-0.5 rounded-full text-[10px] font-semibold <?= !$isFormMode
              ? "bg-emerald-100 text-emerald-700"
              : "bg-blue-100 text-blue-700" ?> shadow-sm"><i class="fas <?= !$isFormMode
     ? "fa-comment-dots"
     : "fa-wpforms" ?> mr-1"></i><?= !$isFormMode ? "Chat" : "Form" ?></span>
          <?php
          $status = $survey["status"] ?? "draft";
          $statusColors = [
              "draft" => "bg-gray-100 text-gray-700",
              "active" => "bg-emerald-100 text-emerald-700",
              "closed" => "bg-red-100 text-red-700",
              "archived" => "bg-slate-100 text-slate-700",
          ];
          ?>
          <span class="px-2.5 py-0.5 rounded-full text-xs font-medium <?= $statusColors[
              $status
          ] ?? $statusColors["draft"] ?>"><?= ucfirst($status) ?></span>
        </div>
        <p class="text-gray-500 text-xs mt-0.5"><?= !$isFormMode
            ? "Configure AI, design conversation flow, and customize the experience"
            : "Drag-drop questions, configure AI, and customize the respondent experience" ?></p>
      </div>
    </div>
    <div class="flex gap-2">
      <button type="button" onclick="toggleKbHelp()" class="px-3 py-2 bg-white border border-gray-200 rounded-xl hover:bg-gray-50 hover:border-gray-300 transition-all text-xs font-medium flex items-center gap-1.5 shadow-sm"><i class="fas fa-keyboard text-gray-400"></i> Shortcuts</button>
      <a href="<?= url(
          "/survey/view/" . ($survey["id"] ?? ""),
      ) ?>" class="px-3 py-2 bg-white border border-gray-200 rounded-xl hover:bg-gray-50 hover:border-gray-300 transition-all text-xs font-medium flex items-center gap-1.5 shadow-sm"><i class="fas fa-external-link-alt text-gray-400"></i> Preview</a>
    </div>
  </div>

  <form method="POST" action="<?= url(
      "/survey/edit/" . ($survey["id"] ?? ""),
  ) ?>" id="survey-form" class="grid grid-cols-1 lg:grid-cols-3 gap-6">
    <?= csrf() ?>
    <input type="hidden" name="questions_json" id="questions-json" value="">
    <input type="hidden" name="theme_config" id="theme-config-input" value="">

    <!-- Left Column -->
    <div class="lg:col-span-2 space-y-5">

      <!-- ===== SHARED: Always visible ===== -->

      <?php $qcArr = $survey["quality_config"] ?? []; ?>
      <!-- === SURVEY IDENTITY === -->
      <div class="bg-white rounded-2xl p-5 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
        <div class="flex items-center justify-between mb-4">
          <div class="flex items-center gap-3">
            <span class="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white shadow-lg shadow-indigo-200"><i class="fas fa-pencil-ruler text-lg"></i></span>
            <div>
              <h2 class="text-base font-bold text-gray-900">Survey Identity</h2>
              <p class="text-[10px] text-gray-400">Name and describe your survey</p>
            </div>
          </div>
          <button type="button" onclick="toggleSection('eb-settings', this)" class="text-xs text-gray-400 hover:text-gray-600 transition-all"><i class="fas fa-chevron-up"></i></button>
        </div>
        <div id="eb-settings">
          <div class="mb-4">
            <input type="text" name="title" id="survey-title" value="<?= htmlspecialchars(
                $survey["title"] ?? "",
            ) ?>" required maxlength="500" class="w-full px-4 py-3 rounded-xl text-base font-semibold border border-gray-200 focus:ring-2 focus:ring-indigo-500 bg-white/70 backdrop-blur-sm transition-all" placeholder="Give your survey a clear title...">
          </div>
          <div class="mb-4">
            <textarea name="description" id="survey-desc" rows="2" class="w-full px-4 py-3 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-indigo-500 bg-white/70 backdrop-blur-sm transition-all resize-none" placeholder="Briefly describe what this survey is about..."><?= htmlspecialchars(
                $survey["description"] ?? "",
            ) ?></textarea>
          </div>
        </div>
      </div>

      <!-- === SURVEY MODE === -->
      <div class="bg-white rounded-2xl p-5 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
        <div class="flex items-center justify-between mb-4">
          <div class="flex items-center gap-3">
            <span class="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-sky-500 flex items-center justify-center text-white shadow-lg shadow-indigo-200"><i class="fas fa-cog text-lg"></i></span>
            <div>
              <h2 class="text-base font-bold text-gray-900">Survey Mode</h2>
              <p class="text-[10px] text-gray-400">Choose how respondents interact with your survey</p>
            </div>
          </div>
          <button type="button" onclick="toggleSection('eb-mode-body', this)" class="text-xs text-gray-400 hover:text-gray-600 transition-all"><i class="fas fa-chevron-up"></i></button>
        </div>
        <div id="eb-mode-body">
          <div class="flex gap-4">
            <label class="flex-1 cursor-pointer group">
              <input type="radio" name="survey_type" value="form" class="hidden peer" <?= $isFormMode
                  ? "checked"
                  : "" ?> onchange="toggleSurveyMode('form')">
              <div class="p-5 rounded-2xl border-2 border-gray-200 peer-checked:border-indigo-500 peer-checked:bg-indigo-50/50 hover:border-indigo-300 hover:bg-indigo-50/20 transition-all text-center group-hover:shadow-md">
                <div class="w-12 h-12 mx-auto rounded-2xl bg-gradient-to-br from-indigo-100 to-indigo-200 flex items-center justify-center mb-3 shadow-sm">
                  <i class="fas fa-wpforms text-indigo-600 text-xl"></i>
                </div>
                <p class="text-sm font-bold text-gray-800 mb-1">Form Survey</p>
                <p class="text-[10px] text-gray-400">Traditional step-by-step<br>questions with validation</p>
              </div>
            </label>
            <label class="flex-1 cursor-pointer group">
              <input type="radio" name="survey_type" value="chat" class="hidden peer" <?= $isFormMode
                  ? ""
                  : "checked" ?> onchange="toggleSurveyMode('chat')">
              <div class="p-5 rounded-2xl border-2 border-gray-200 peer-checked:border-emerald-500 peer-checked:bg-emerald-50/50 hover:border-emerald-300 hover:bg-emerald-50/20 transition-all text-center group-hover:shadow-md">
                <div class="w-12 h-12 mx-auto rounded-2xl bg-gradient-to-br from-emerald-100 to-teal-200 flex items-center justify-center mb-3 shadow-sm">
                  <i class="fas fa-comment-dots text-emerald-600 text-xl"></i>
                </div>
                <p class="text-sm font-bold text-gray-800 mb-1">Chat Survey</p>
                <p class="text-[10px] text-gray-400">AI-powered conversational<br>interview experience</p>
              </div>
            </label>
          </div>
        </div>
      </div>

      <!-- === STATUS & VISIBILITY === -->
      <div class="bg-white rounded-2xl p-5 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
        <div class="flex items-center justify-between mb-4">
          <div class="flex items-center gap-3">
            <span class="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-orange-500 flex items-center justify-center text-white shadow-lg shadow-amber-200"><i class="fas fa-toggle-on text-lg"></i></span>
            <div>
              <h2 class="text-base font-bold text-gray-900">Status & Visibility</h2>
              <p class="text-[10px] text-gray-400">Control when and how your survey is accessible</p>
            </div>
          </div>
          <button type="button" onclick="toggleSection('eb-vis-body', this)" class="text-xs text-gray-400 hover:text-gray-600 transition-all"><i class="fas fa-chevron-up"></i></button>
        </div>
        <div id="eb-vis-body">
          <div class="flex flex-wrap gap-2 mb-4">
            <?php
            $statuses = [
                "draft" => [
                    "label" => "Draft",
                    "icon" => "fa-pen",
                    "color" => "gray",
                ],
                "active" => [
                    "label" => "Active",
                    "icon" => "fa-play",
                    "color" => "emerald",
                ],
                "closed" => [
                    "label" => "Closed",
                    "icon" => "fa-stop",
                    "color" => "red",
                ],
            ];
            foreach ($statuses as $sk => $sv): ?>
            <label class="flex-1 min-w-[80px] flex flex-col items-center gap-1 p-3 border-2 rounded-xl cursor-pointer transition-all text-center has-[:checked]:border-<?= $sv[
                "color"
            ] ?>-500 has-[:checked]:bg-<?= $sv["color"] ?>-50/60 <?= $status ===
$sk
    ? "border-" . $sv["color"] . "-500 bg-" . $sv["color"] . "-50/60"
    : "border-gray-200" ?>">
              <input type="radio" name="status" value="<?= $sk ?>" <?= $status ===
$sk
    ? "checked"
    : "" ?> class="hidden">
              <span class="w-8 h-8 rounded-lg bg-<?= $sv[
                  "color"
              ] ?>-100 flex items-center justify-center text-<?= $sv[
    "color"
] ?>-600 text-sm"><i class="fas <?= $sv["icon"] ?>"></i></span>
              <span class="text-xs font-semibold text-gray-800"><?= $sv[
                  "label"
              ] ?></span>
            </label>
            <?php endforeach;
            ?>
          </div>
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label class="block text-xs font-medium text-gray-600 mb-1"><i class="fas fa-play-circle text-emerald-500 mr-1"></i>Opens At</label>
              <input type="datetime-local" name="starts_at" value="<?= !empty(
                  $survey["starts_at"]
              )
                  ? str_replace(
                      " ",
                      "T",
                      date("Y-m-d H:i", strtotime($survey["starts_at"])),
                  )
                  : "" ?>" class="w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-indigo-500 bg-white/70">
            </div>
            <div>
              <label class="block text-xs font-medium text-gray-600 mb-1"><i class="fas fa-stop-circle text-red-400 mr-1"></i>Closes At</label>
              <input type="datetime-local" name="ends_at" value="<?= !empty(
                  $survey["ends_at"]
              )
                  ? str_replace(
                      " ",
                      "T",
                      date("Y-m-d H:i", strtotime($survey["ends_at"])),
                  )
                  : "" ?>" class="w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-indigo-500 bg-white/70">
            </div>
          </div>
        </div>
      </div>

      <!-- === WHO CAN RESPOND === -->
      <div class="bg-white rounded-2xl p-5 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
        <div class="flex items-center justify-between mb-4">
          <div class="flex items-center gap-3">
            <span class="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-white shadow-lg shadow-emerald-200"><i class="fas fa-users text-lg"></i></span>
            <div>
              <h2 class="text-base font-bold text-gray-900">Who Can Respond?</h2>
              <p class="text-[10px] text-gray-400">Set access rules and authentication</p>
            </div>
          </div>
          <button type="button" onclick="toggleSection('eb-access-body', this)" class="text-xs text-gray-400 hover:text-gray-600 transition-all"><i class="fas fa-chevron-down"></i></button>
        </div>
        <div id="eb-access-body" style="max-height:0px;overflow:hidden">
          <div class="grid grid-cols-2 sm:grid-cols-5 gap-2 mb-4" id="auth-picker">
            <?php
            $authOptions = [
                "anyone" => [
                    "icon" => "fa-globe",
                    "label" => "Anyone",
                    "desc" => "No login needed",
                    "color" => "emerald",
                    "badge" => "Anonymous",
                ],
                "password" => [
                    "icon" => "fa-lock",
                    "label" => "Password",
                    "desc" => "Shared password",
                    "color" => "amber",
                    "badge" => "Protected",
                ],
                "email" => [
                    "icon" => "fa-envelope",
                    "label" => "Email",
                    "desc" => "Email verification",
                    "color" => "blue",
                    "badge" => "Verified",
                ],
                "google" => [
                    "icon" => "fa-google",
                    "label" => "Google",
                    "desc" => "Google login only",
                    "color" => "red",
                    "badge" => "OAuth",
                ],
                "any_account" => [
                    "icon" => "fa-user-check",
                    "label" => "Any Account",
                    "desc" => "Any registered user",
                    "color" => "purple",
                    "badge" => "Account",
                ],
            ];
            foreach ($authOptions as $aKey => $aOpt): ?>
            <label class="auth-card flex flex-col items-center gap-1.5 p-3 border-2 rounded-xl cursor-pointer transition-all duration-200 hover:border-<?= $aOpt[
                "color"
            ] ?>-300 hover:bg-<?= $aOpt[
    "color"
] ?>-50/30 has-[:checked]:border-<?= $aOpt[
    "color"
] ?>-500 has-[:checked]:bg-<?= $aOpt[
    "color"
] ?>-50/60 has-[:checked]:shadow-sm text-center <?= ($qcArr["auth_type"] ??
    "anyone") ===
$aKey
    ? "border-" . $aOpt["color"] . "-500 bg-" . $aOpt["color"] . "-50/60"
    : "border-gray-200" ?>">
              <input type="radio" name="qc[auth_type]" value="<?= $aKey ?>" <?= ($qcArr[
    "auth_type"
] ??
    "anyone") ===
$aKey
    ? "checked"
    : "" ?> class="hidden">
              <span class="w-9 h-9 rounded-xl bg-<?= $aOpt[
                  "color"
              ] ?>-100 flex items-center justify-center text-<?= $aOpt[
    "color"
] ?>-600 text-sm"><i class="fab <?= $aKey === "google"
    ? "fa-google"
    : "fas " . $aOpt["icon"] ?>"></i></span>
              <span class="text-[11px] font-semibold text-gray-800 leading-tight"><?= $aOpt[
                  "label"
              ] ?></span>
              <span class="text-[9px] text-gray-400 leading-tight"><?= $aOpt[
                  "desc"
              ] ?></span>
              <span class="text-[8px] font-medium px-1.5 py-0.5 rounded-full bg-<?= $aOpt[
                  "color"
              ] ?>-100 text-<?= $aOpt["color"] ?>-700 mt-auto"><?= $aOpt[
    "badge"
] ?></span>
            </label>
            <?php endforeach;
            ?>
          </div>
          <div id="eb-password-field-wrap" class="<?= ($qcArr["auth_type"] ??
              "anyone") ===
          "password"
              ? ""
              : "hidden" ?> mb-3">
            <label class="block text-xs font-medium text-gray-600 mb-1"><i class="fas fa-key text-amber-500 mr-1"></i>Access Password</label>
            <div class="flex gap-2">
              <input type="text" name="access_password" class="flex-1 px-3 py-2 rounded-xl text-sm border border-amber-200 focus:ring-2 focus:ring-amber-500 bg-white/70" placeholder="<?= !empty(
                  $survey["access_password"]
              )
                  ? "Change password (leave blank to keep)"
                  : "Set a password..." ?>">
              <button type="button" onclick="var inp=this.previousElementSibling;inp.type=inp.type==='password'?'text':'password';this.classList.toggle('text-amber-500')" class="px-3 py-2 text-gray-400 hover:text-amber-500 transition-colors text-sm"><i class="fas fa-eye"></i></button>
            </div>
            <?php if (!empty($survey["access_password"])): ?>
            <label class="flex items-center gap-1.5 mt-1.5 text-[11px] text-gray-500 cursor-pointer">
              <input type="checkbox" name="access_password_clear" value="1" class="rounded text-red-500 w-3.5 h-3.5"> Remove current password
            </label>
            <?php endif; ?>
          </div>
          <div class="flex items-center gap-3 flex-wrap">
            <div class="flex-1 min-w-[140px]">
              <label class="block text-xs font-medium text-gray-600 mb-1"><i class="fas fa-chart-bar text-gray-400 mr-1"></i>Max Responses</label>
              <input type="number" name="max_responses" value="<?= $survey[
                  "max_responses"
              ] ??
                  "" ?>" placeholder="Unlimited" class="w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-indigo-500 bg-white/70">
            </div>
            <div class="flex-1 min-w-[140px]">
              <label class="block text-xs font-medium text-gray-600 mb-1"><i class="fas fa-star text-gray-400 mr-1"></i>Min Reputation</label>
              <div class="flex items-center gap-2">
                <input type="range" name="min_reputation_range" id="eb-min-rep-range" value="<?= (int) ($survey[
                    "min_reputation"
                ] ??
                    0) ?>" min="0" max="100" class="flex-1 accent-indigo-500" oninput="document.getElementById('eb-min-rep-val').textContent=this.value;document.getElementById('eb-min-rep-input').value=this.value">
                <span class="text-sm font-bold text-indigo-600 w-8 text-right" id="eb-min-rep-val"><?= (int) ($survey[
                    "min_reputation"
                ] ?? 0) ?></span>
                <input type="hidden" name="min_reputation" id="eb-min-rep-input" value="<?= (int) ($survey[
                    "min_reputation"
                ] ?? 0) ?>">
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- === BRANDING === -->
      <?php
      $tc = $survey["theme_config"] ?? [];
      $tTheme = $tc["theme"] ?? "indigo";
      $tBg = $tc["background"] ?? "glass";
      $tLogo = $tc["logo_url"] ?? "";
      $tCard = $tc["card_style"] ?? "glass";
      $tRadius = $tc["question_border_radius"] ?? "xl";
      $tShadow = $tc["question_shadow"] ?? "lg";
      $tFont = $tc["font_family"] ?? "inherit";
      $tAnim = $tc["question_animation"] ?? "slide-up";
      $tCSS = $tc["custom_css"] ?? "";
      $tBgType = $tc["bg_type"] ?? "gradient";
      $tBgValue = $tc["bg_value"] ?? "";
      $tBgImg = $tc["bg_image"] ?? "";
      $tBgVid = $tc["bg_video"] ?? "";
      ?>
      <div class="bg-white rounded-2xl p-5 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
        <div class="flex items-center justify-between mb-4">
          <div class="flex items-center gap-3">
            <span class="w-10 h-10 rounded-xl bg-gradient-to-br from-pink-500 to-rose-600 flex items-center justify-center text-white shadow-lg shadow-pink-200"><i class="fas fa-palette text-lg"></i></span>
            <div>
              <h2 class="text-base font-bold text-gray-900">Branding</h2>
              <p class="text-[10px] text-gray-400">Customize colors, fonts, and visual style</p>
            </div>
          </div>
          <button type="button" onclick="toggleSection('eb-branding', this)" class="text-xs text-gray-400 hover:text-gray-600"><i class="fas fa-chevron-down"></i></button>
        </div>
        <div id="eb-branding" style="max-height:0px;overflow:hidden">
          <div class="mb-3">
            <label class="block text-xs font-medium text-gray-600 mb-1">Logo URL</label>
            <div class="flex gap-2">
              <input type="text" id="logo-url" value="<?= htmlspecialchars(
                  $tLogo,
              ) ?>" class="flex-1 glass-input w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-pink-500" placeholder="https://your-logo.png" oninput="updatePreview()">
              <div id="logo-preview" class="w-10 h-10 rounded-xl bg-gray-100 flex items-center justify-center overflow-hidden border flex-shrink-0">
                <?php if ($tLogo): ?><img src="<?= htmlspecialchars(
    $tLogo,
) ?>" class="h-full w-full object-contain"><?php else: ?><i class="fas fa-image text-gray-400 text-sm"></i><?php endif; ?>
              </div>
            </div>
          </div>
          <div class="mb-3">
            <label class="block text-xs font-medium text-gray-600 mb-1.5">Theme Color</label>
            <div class="flex gap-2 flex-wrap" id="theme-picker">
              <?php
              $themes = [
                  "indigo" => "bg-indigo-500",
                  "emerald" => "bg-emerald-500",
                  "amber" => "bg-amber-500",
                  "rose" => "bg-rose-500",
                  "cyan" => "bg-cyan-500",
                  "violet" => "bg-violet-500",
                  "teal" => "bg-teal-500",
                  "red" => "bg-red-500",
                  "orange" => "bg-orange-500",
                  "pink" => "bg-pink-500",
                  "blue" => "bg-blue-500",
                  "slate" => "bg-slate-500",
              ];
              foreach ($themes as $tk => $tc2): ?>
              <button type="button" class="theme-btn w-8 h-8 <?= $tc2 ?> rounded-xl border-2 <?= $tk ===
 $tTheme
     ? "border-gray-900 ring-2 ring-offset-2 ring-gray-900"
     : "border-transparent hover:border-gray-400" ?> transition-all" data-theme="<?= $tk ?>" onclick="selectTheme('<?= $tk ?>', this)"></button>
              <?php endforeach;
              ?>
            </div>
          </div>
          <div class="mb-3">
            <label class="block text-xs font-medium text-gray-600 mb-1.5">Background</label>
            <div class="flex gap-2 flex-wrap" id="bg-picker">
              <?php
              $bgs = [
                  "glass" => [
                      "label" => "Glass",
                      "class" =>
                          "bg-gradient-to-br from-gray-50 via-indigo-50/30 to-purple-50/30 border-gray-200",
                  ],
                  "warm" => [
                      "label" => "Warm",
                      "class" =>
                          "bg-gradient-to-br from-amber-50 via-orange-50/30 to-rose-50/30 border-amber-200",
                  ],
                  "cool" => [
                      "label" => "Cool",
                      "class" =>
                          "bg-gradient-to-br from-sky-50 via-blue-50/30 to-cyan-50/30 border-sky-200",
                  ],
                  "dark" => [
                      "label" => "Dark",
                      "class" =>
                          "bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 border-gray-700 text-white",
                  ],
                  "mountain" => [
                      "label" => "Mtn",
                      "class" =>
                          "bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 border-indigo-800 text-white",
                  ],
                  "sunset" => [
                      "label" => "Sun",
                      "class" =>
                          "bg-gradient-to-br from-orange-600 via-rose-600 to-purple-800 border-orange-700 text-white",
                  ],
                  "ocean" => [
                      "label" => "Ocean",
                      "class" =>
                          "bg-gradient-to-br from-cyan-600 via-blue-700 to-indigo-900 border-cyan-800 text-white",
                  ],
                  "forest" => [
                      "label" => "Forest",
                      "class" =>
                          "bg-gradient-to-br from-emerald-800 via-green-700 to-teal-800 border-emerald-900 text-white",
                  ],
                  "midnight" => [
                      "label" => "Mid",
                      "class" =>
                          "bg-gradient-to-br from-slate-900 via-gray-900 to-zinc-900 border-slate-800 text-white",
                  ],
                  "lavender" => [
                      "label" => "Lav",
                      "class" =>
                          "bg-gradient-to-br from-violet-300 via-fuchsia-200 to-pink-300 border-violet-400",
                  ],
                  "peach" => [
                      "label" => "Pch",
                      "class" =>
                          "bg-gradient-to-br from-amber-200 via-orange-200 to-rose-300 border-amber-300",
                  ],
                  "particles" => [
                      "label" => "Prts",
                      "class" =>
                          "bg-gradient-to-br from-gray-900 via-indigo-900 to-gray-900 border-gray-800 text-white",
                  ],
              ];
              foreach ($bgs as $bk => $bg): ?>
              <button type="button" class="bg-btn w-8 h-8 <?= $bg[
                  "class"
              ] ?> rounded-xl border-2 <?= $bk === $tBg
     ? "border-gray-900 ring-2 ring-offset-2 ring-gray-900"
     : "border-transparent hover:border-gray-400" ?> transition-all text-[7px] font-bold flex items-center justify-center <?= in_array(
     $bk,
     ["dark", "mountain", "sunset", "ocean", "forest", "midnight", "particles"],
 )
     ? "text-white"
     : "text-gray-500" ?>" data-bg="<?= $bk ?>" onclick="selectBg('<?= $bk ?>', this)" title="<?= $bg[
    "label"
] ?>"><?= $bg["label"] ?></button>
              <?php endforeach;
              ?>
            </div>
          </div>
          <div class="mb-3">
            <label class="block text-xs font-medium text-gray-600 mb-1.5">Card Style</label>
            <div class="flex gap-2 flex-wrap" id="card-style-picker">
              <?php
              $cardStyles = [
                  "glass" => "Glass",
                  "solid" => "Solid",
                  "bordered" => "Bordered",
                  "ghost" => "Ghost",
                  "dark-glass" => "DkGlass",
                  "neumorphic" => "Neumo",
                  "gradient" => "Grad",
              ];
              foreach ($cardStyles as $csKey => $csLabel): ?>
              <button type="button" class="card-style-btn px-3 py-1.5 rounded-lg text-[10px] font-medium border-2 <?= $csKey ===
              $tCard
                  ? "border-gray-900 ring-2 ring-offset-2 ring-gray-900"
                  : "border-gray-200 hover:border-indigo-300 hover:bg-indigo-50" ?> transition-all" data-cardstyle="<?= $csKey ?>" onclick="selectCardStyle('<?= $csKey ?>', this)"><?= $csLabel ?></button>
              <?php endforeach;
              ?>
            </div>
          </div>
          <div class="mb-3">
            <label class="block text-xs font-medium text-gray-600 mb-1.5">Border Radius</label>
            <div class="flex gap-2 flex-wrap" id="radius-picker">
              <?php
              $radii = [
                  "none" => "None",
                  "sm" => "SM",
                  "md" => "MD",
                  "lg" => "LG",
                  "xl" => "XL",
                  "2xl" => "2XL",
                  "3xl" => "3XL",
                  "full" => "Full",
              ];
              $radiusClasses = [
                  "none" => "",
                  "sm" => "rounded-sm",
                  "md" => "rounded-md",
                  "lg" => "rounded-lg",
                  "xl" => "rounded-xl",
                  "2xl" => "rounded-2xl",
                  "3xl" => "rounded-3xl",
                  "full" => "rounded-full",
              ];
              foreach ($radii as $rk => $rl):
                  $rClass = $radiusClasses[$rk]; ?>
              <button type="button" class="radius-btn px-3 py-1.5 rounded-lg text-[10px] font-medium border-2 <?= $rk ===
              $tRadius
                  ? "border-gray-900 ring-2 ring-offset-2 ring-gray-900"
                  : "border-gray-200 hover:border-indigo-300 hover:bg-indigo-50" ?> transition-all <?= $rClass ?>" data-radius="<?= $rk ?>" onclick="selectRadius('<?= $rk ?>', this)"><?= $rl ?></button>
              <?php
              endforeach;
              ?>
            </div>
          </div>
          <div class="mb-3">
            <label class="block text-xs font-medium text-gray-600 mb-1.5">Shadow</label>
            <div class="flex gap-2 flex-wrap" id="shadow-picker">
              <?php
              $shadows = [
                  "none" => "None",
                  "sm" => "SM",
                  "md" => "MD",
                  "lg" => "LG",
                  "xl" => "XL",
                  "2xl" => "2XL",
                  "inner" => "Inner",
              ];
              foreach ($shadows as $sk => $sl): ?>
              <button type="button" class="shadow-btn px-3 py-1.5 rounded-lg text-[10px] font-medium border-2 <?= $sk ===
              $tShadow
                  ? "border-gray-900 ring-2 ring-offset-2 ring-gray-900"
                  : "border-gray-200 hover:border-indigo-300 hover:bg-indigo-50" ?> transition-all <?= $sk ===
 "none"
     ? ""
     : ($sk === "inner"
         ? "shadow-inner"
         : "shadow-" .
             $sk) ?>" data-shadow="<?= $sk ?>" onclick="selectShadow('<?= $sk ?>', this)"><?= $sl ?></button>
              <?php endforeach;
              ?>
            </div>
          </div>
          <div class="mb-3">
            <label class="block text-xs font-medium text-gray-600 mb-1.5">Font Family</label>
            <select id="font-family" class="w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-pink-500 bg-white" onchange="updatePreview()">
              <option value="inherit" <?= $tFont === "inherit"
                  ? "selected"
                  : "" ?>>System Default</option>
              <option value="Inter" <?= $tFont === "Inter"
                  ? "selected"
                  : "" ?>>Inter</option>
              <option value="DM Sans" <?= $tFont === "DM Sans"
                  ? "selected"
                  : "" ?>>DM Sans</option>
              <option value="Plus Jakarta Sans" <?= $tFont ===
              "Plus Jakarta Sans"
                  ? "selected"
                  : "" ?>>Plus Jakarta Sans</option>
              <option value="Georgia" <?= $tFont === "Georgia"
                  ? "selected"
                  : "" ?>>Georgia (Serif)</option>
              <option value="Courier New" <?= $tFont === "Courier New"
                  ? "selected"
                  : "" ?>>Courier New (Mono)</option>
              <option value="Nunito" <?= $tFont === "Nunito"
                  ? "selected"
                  : "" ?>>Nunito</option>
              <option value="Poppins" <?= $tFont === "Poppins"
                  ? "selected"
                  : "" ?>>Poppins</option>
            </select>
          </div>
          <div class="mb-3">
            <label class="block text-xs font-medium text-gray-600 mb-1.5">Question Animation</label>
            <select id="question-animation" class="w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-pink-500 bg-white" onchange="updatePreview()">
              <option value="slide-up" <?= $tAnim === "slide-up"
                  ? "selected"
                  : "" ?>>Slide Up</option>
              <option value="fade-in" <?= $tAnim === "fade-in"
                  ? "selected"
                  : "" ?>>Fade In</option>
              <option value="scale-in" <?= $tAnim === "scale-in"
                  ? "selected"
                  : "" ?>>Scale In</option>
              <option value="slide-left" <?= $tAnim === "slide-left"
                  ? "selected"
                  : "" ?>>Slide Left</option>
              <option value="flip" <?= $tAnim === "flip"
                  ? "selected"
                  : "" ?>>Flip</option>
              <option value="bounce" <?= $tAnim === "bounce"
                  ? "selected"
                  : "" ?>>Bounce</option>
              <option value="none" <?= $tAnim === "none"
                  ? "selected"
                  : "" ?>>None</option>
            </select>
          </div>
          <div class="mb-3">
            <label class="block text-xs font-medium text-gray-600 mb-1.5">Custom CSS</label>
            <textarea id="custom-css" class="w-full px-3 py-2 rounded-xl text-xs font-mono border border-gray-200 focus:ring-2 focus:ring-pink-500 bg-white/70 backdrop-blur-sm transition-all resize-y" rows="3" placeholder="/* Custom CSS overrides */" oninput="updatePreview()"><?= htmlspecialchars(
                $tCSS,
            ) ?></textarea>
          </div>
          <div class="mb-3">
            <label class="block text-xs font-medium text-gray-600 mb-1.5">Background Type</label>
            <div class="flex gap-2 flex-wrap mb-2" id="bg-type-picker">
              <?php
              $bgTypes = [
                  "gradient" => "Gradient",
                  "solid" => "Solid",
                  "image" => "Image",
                  "video" => "Video",
              ];
              foreach ($bgTypes as $btKey => $btLabel): ?>
              <button type="button" class="bg-type-btn px-3 py-1.5 rounded-lg text-[10px] font-medium border-2 <?= $btKey ===
              $tBgType
                  ? "border-gray-900 ring-2 ring-offset-2 ring-gray-900"
                  : "border-gray-200 hover:border-indigo-300 hover:bg-indigo-50" ?> transition-all" data-bgtype="<?= $btKey ?>" onclick="selectBgType('<?= $btKey ?>', this)"><?= $btLabel ?></button>
              <?php endforeach;
              ?>
            </div>
            <div id="bg-type-value" class="<?= in_array($tBgType, [
                "solid",
                "gradient",
            ])
                ? ""
                : "hidden" ?>">
              <input type="text" id="bg-value" value="<?= htmlspecialchars(
                  $tBgValue,
              ) ?>" class="w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-pink-500 bg-white" placeholder="Solid hex color or gradient CSS value" oninput="updatePreview()">
            </div>
            <div id="bg-type-image" class="<?= $tBgType === "image"
                ? ""
                : "hidden" ?>">
              <input type="text" id="bg-image" value="<?= htmlspecialchars(
                  $tBgImg,
              ) ?>" class="w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-pink-500 bg-white" placeholder="https://your-background-image.jpg" oninput="updatePreview()">
            </div>
            <div id="bg-type-video" class="<?= $tBgType === "video"
                ? ""
                : "hidden" ?>">
              <input type="text" id="bg-video" value="<?= htmlspecialchars(
                  $tBgVid,
              ) ?>" class="w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-pink-500 bg-white" placeholder="https://your-background-video.mp4" oninput="updatePreview()">
            </div>
          </div>
        </div>
      </div>

      <!-- ===== FORM SURVEY EDIT ZONE ===== -->
      <div id="form-edit-zone" <?= $isFormMode
          ? ""
          : 'style="display:none"' ?> class="<?= $isFormMode
     ? ""
     : "hidden" ?> space-y-5">

      <!-- === QUESTION BUILDER === -->
      <div class="bg-white rounded-2xl p-5 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
        <div class="flex items-center justify-between mb-4">
          <div class="flex items-center gap-3">
            <span class="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-white shadow-lg shadow-emerald-200"><i class="fas fa-list-ul text-lg"></i></span>
            <div>
              <h2 class="text-base font-bold text-gray-900">Questions</h2>
              <p class="text-[11px] text-gray-400" id="q-count-label"></p>
            </div>
          </div>
          <div class="flex gap-1.5">
            <button type="button" onclick="undo()" id="btn-undo" class="w-8 h-8 rounded-xl border border-gray-200 text-gray-400 hover:text-indigo-600 hover:border-indigo-300 hover:bg-indigo-50 transition-all flex items-center justify-center disabled:opacity-30 disabled:cursor-not-allowed" disabled title="Undo (Ctrl+Z)"><i class="fas fa-undo text-xs"></i></button>
            <button type="button" onclick="redo()" id="btn-redo" class="w-8 h-8 rounded-xl border border-gray-200 text-gray-400 hover:text-indigo-600 hover:border-indigo-300 hover:bg-indigo-50 transition-all flex items-center justify-center disabled:opacity-30 disabled:cursor-not-allowed" disabled title="Redo (Ctrl+Shift+Z)"><i class="fas fa-redo text-xs"></i></button>
          </div>
        </div>

        <!-- Search + Quick-add -->
        <div class="flex flex-wrap gap-2 mb-4">
          <div class="relative flex-1 min-w-[200px]">
            <i class="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-300 text-xs"></i>
            <input type="text" id="q-search" placeholder="Search types or questions...  (press / to focus)" class="w-full pl-8 pr-8 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-emerald-500 bg-white/80 backdrop-blur-sm" oninput="filterQuestions(this.value)">
            <button type="button" onclick="document.getElementById('q-search').value='';filterQuestions('')" class="absolute right-2 top-1/2 -translate-y-1/2 w-5 h-5 rounded-full bg-gray-100 text-gray-400 hover:bg-gray-200 hover:text-gray-600 flex items-center justify-center text-[8px] hidden" id="q-search-clear"><i class="fas fa-times"></i></button>
          </div>
          <button type="button" onclick="openCustomModal()" class="px-4 py-2 rounded-xl text-sm font-medium bg-gradient-to-r from-gray-800 to-gray-900 text-white hover:from-indigo-600 hover:to-purple-600 transition-all flex items-center gap-1.5 shadow-sm"><i class="fas fa-plus-circle"></i> Custom</button>
          <button type="button" onclick="toggleBank()" class="px-3 py-2 rounded-xl text-sm font-medium border border-gray-200 text-gray-600 hover:bg-indigo-50 hover:border-indigo-300 hover:text-indigo-700 transition-all flex items-center gap-1.5"><i class="fas fa-database"></i> Bank</button>
          <button type="button" onclick="openBulkImport()" class="px-3 py-2 rounded-xl text-sm font-medium border border-gray-200 text-gray-600 hover:bg-lime-50 hover:border-lime-300 hover:text-lime-700 transition-all flex items-center gap-1.5"><i class="fas fa-list"></i> Bulk</button>
        </div>
        <div class="flex gap-1.5 mb-4 overflow-x-auto pb-1 scrollbar-thin" id="qx-grid">
          <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAdd('text')" data-type="text"><i class="fas fa-font"></i> Text</button>
          <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-amber-50 text-amber-700 border border-amber-200 hover:bg-amber-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAdd('rating')" data-type="rating"><i class="fas fa-star"></i> Rating</button>
          <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-blue-50 text-blue-700 border border-blue-200 hover:bg-blue-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAdd('yes_no')" data-type="yes_no"><i class="fas fa-check-circle"></i> Yes/No</button>
          <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-purple-50 text-purple-700 border border-purple-200 hover:bg-purple-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAdd('mcq_single')" data-type="mcq_single"><i class="fas fa-circle-dot"></i> Single</button>
          <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-fuchsia-50 text-fuchsia-700 border border-fuchsia-200 hover:bg-fuchsia-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAdd('mcq_multiple')" data-type="mcq_multiple"><i class="fas fa-list-check"></i> Multi</button>
          <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-cyan-50 text-cyan-700 border border-cyan-200 hover:bg-cyan-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAdd('email')" data-type="email"><i class="fas fa-at"></i> Email</button>
          <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-rose-50 text-rose-700 border border-rose-200 hover:bg-rose-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAdd('date')" data-type="date"><i class="fas fa-calendar"></i> Date</button>
          <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-teal-50 text-teal-700 border border-teal-200 hover:bg-teal-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAdd('phone')" data-type="phone"><i class="fas fa-phone"></i> Phone</button>
          <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-blue-50 text-blue-700 border border-blue-200 hover:bg-blue-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAdd('number')" data-type="number"><i class="fas fa-hashtag"></i> Number</button>
          <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-orange-50 text-orange-700 border border-orange-200 hover:bg-orange-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAdd('dropdown')" data-type="dropdown"><i class="fas fa-chevron-down"></i> Dropdown</button>
          <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-violet-50 text-violet-700 border border-violet-200 hover:bg-violet-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAdd('likert5')" data-type="likert5"><i class="fas fa-grip-lines"></i> Likert 5</button>
          <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-violet-50 text-violet-700 border border-violet-200 hover:bg-violet-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAdd('likert7')" data-type="likert7"><i class="fas fa-grip-lines"></i> Likert 7</button>
          <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-pink-50 text-pink-700 border border-pink-200 hover:bg-pink-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAdd('slider')" data-type="slider"><i class="fas fa-sliders"></i> Slider</button>
          <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-gray-50 text-gray-700 border border-gray-200 hover:bg-gray-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAdd('matrix')" data-type="matrix"><i class="fas fa-table"></i> Matrix</button>
          <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-sky-50 text-sky-700 border border-sky-200 hover:bg-sky-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAdd('file_upload')" data-type="file_upload"><i class="fas fa-upload"></i> Upload</button>
          <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-stone-50 text-stone-700 border border-stone-200 hover:bg-stone-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAdd('textarea')" data-type="textarea"><i class="fas fa-paragraph"></i> Long Text</button>
          <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-sky-50 text-sky-700 border border-sky-200 hover:bg-sky-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAdd('url')" data-type="url"><i class="fas fa-link"></i> URL</button>
          <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-red-50 text-red-700 border border-red-200 hover:bg-red-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAdd('nps')" data-type="nps"><i class="fas fa-chart-bar"></i> NPS</button>
          <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-amber-50 text-amber-700 border border-amber-200 hover:bg-amber-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAdd('ranking')" data-type="ranking"><i class="fas fa-list-ol"></i> Ranking</button>
          <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-lime-50 text-lime-700 border border-lime-200 hover:bg-lime-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAdd('multi_text')" data-type="multi_text"><i class="fas fa-list"></i> Multi Text</button>
          <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-yellow-50 text-yellow-700 border border-yellow-200 hover:bg-yellow-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAdd('address')" data-type="address"><i class="fas fa-map-marker-alt"></i> Address</button>
          <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-rose-50 text-rose-700 border border-rose-200 hover:bg-rose-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAdd('time')" data-type="time"><i class="fas fa-clock"></i> Time</button>
          <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-fuchsia-50 text-fuchsia-700 border border-fuchsia-200 hover:bg-fuchsia-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAdd('datetime')" data-type="datetime"><i class="fas fa-calendar-alt"></i> Date/Time</button>
          <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-pink-50 text-pink-700 border border-pink-200 hover:bg-pink-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAdd('color')" data-type="color"><i class="fas fa-palette"></i> Color</button>
          <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-cyan-50 text-cyan-700 border border-cyan-200 hover:bg-cyan-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAdd('percentage')" data-type="percentage"><i class="fas fa-percent"></i> Percentage</button>
          <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-indigo-50 text-indigo-700 border border-indigo-200 hover:bg-indigo-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAdd('signature')" data-type="signature"><i class="fas fa-pen-fancy"></i> Signature</button>
          <span class="text-[9px] text-gray-300 self-center pl-1 flex-shrink-0">Press <kbd class="px-1 py-0.5 bg-gray-100 rounded text-[9px] font-mono">Q</kbd></span>
        </div>

        <!-- Questions list -->
        <div id="q-list" class="space-y-2 min-h-[60px]">
          <div id="q-empty" class="text-center py-8 border-2 border-dashed border-gray-200 rounded-xl">
            <i class="fas fa-plus-circle text-gray-300 text-2xl mb-2"></i>
            <p class="text-xs text-gray-400">No questions yet — press <kbd class="px-1 py-0.5 bg-gray-100 rounded text-[10px] font-mono">Q</kbd> or click a button above</p>
          </div>
        </div>
      </div>

      <!-- === QUALITY CONTROLS === -->
      <div class="bg-white rounded-2xl p-5 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
        <div class="flex items-center justify-between mb-4">
          <div class="flex items-center gap-3">
            <span class="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white shadow-lg shadow-indigo-200"><i class="fas fa-shield-alt text-lg"></i></span>
            <div>
              <h2 class="text-base font-bold text-gray-900">Quality Controls</h2>
              <p class="text-[10px] text-gray-400">Anti-bot, validation, and response integrity</p>
            </div>
          </div>
          <button type="button" onclick="toggleSection('eb-qc', this)" class="text-xs text-gray-400 hover:text-gray-600"><i class="fas fa-chevron-down"></i></button>
        </div>
        <div id="eb-qc" style="max-height:0px;overflow:hidden">
          <?php $qThreshold = $survey["quality_threshold"] ?? 70; ?>
          <div class="mb-4 p-3 bg-gradient-to-r from-indigo-50/60 to-purple-50/60 border border-indigo-100 rounded-xl">
            <div class="flex items-center justify-between flex-wrap gap-2">
              <div class="flex items-center gap-2">
                <span class="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white text-xs shadow-sm"><i class="fas fa-tachometer-alt"></i></span>
                <div>
                  <div class="text-xs font-bold text-gray-800">Quality Threshold</div>
                  <span class="text-[10px] text-gray-500">Minimum quality score to accept responses</span>
                </div>
              </div>
              <div class="flex items-center gap-2">
                <input type="range" name="quality_threshold_range" id="eb-qt-range" value="<?= (int) $qThreshold ?>" min="0" max="100" class="w-28 accent-indigo-600" oninput="var v=this.value;document.getElementById('eb-qt-val').textContent=v+'%';document.getElementById('eb-qt-input').value=v">
                <span class="text-lg font-extrabold text-indigo-600 w-10 text-right" id="eb-qt-val"><?= (int) $qThreshold ?>%</span>
                <input type="hidden" name="quality_threshold" id="eb-qt-input" value="<?= (int) $qThreshold ?>">
              </div>
            </div>
          </div>

          <?php $qcCheck = function ($k) use ($qcArr) {
              return !empty($qcArr[$k]);
          }; ?>

          <div class="mb-3">
            <div class="flex items-center gap-2 mb-2">
              <span class="w-6 h-6 rounded-lg bg-red-100 flex items-center justify-center text-red-600 text-[10px]"><i class="fas fa-robot"></i></span>
              <span class="text-xs font-bold text-gray-700">Anti-Bot & Security</span>
              <span class="text-[9px] text-gray-400">Block automated submissions</span>
            </div>
            <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-1.5">
              <?php
              $qcCats = [
                  [
                      "k" => "honeypot",
                      "l" => "Honeypot",
                      "d" => "Hidden field traps bots",
                      "c" => "red",
                  ],
                  [
                      "k" => "captcha",
                      "l" => "Math CAPTCHA",
                      "d" => "Simple math puzzle",
                      "c" => "red",
                  ],
                  [
                      "k" => "ip_rate_limit",
                      "l" => "IP Rate Limit",
                      "d" => "Block repeat IPs",
                      "c" => "red",
                  ],
                  [
                      "k" => "browser_fingerprint",
                      "l" => "Fingerprint",
                      "d" => "Unique browser ID",
                      "c" => "red",
                  ],
                  [
                      "k" => "vpn_detection",
                      "l" => "VPN Detection",
                      "d" => "Flag proxy users",
                      "c" => "red",
                  ],
              ];
              foreach ($qcCats as $qcItem): ?>
              <label class="flex items-center gap-2 px-2.5 py-2 border border-gray-200 rounded-xl cursor-pointer transition-all hover:bg-red-50/30 has-[:checked]:border-red-400 has-[:checked]:bg-red-50/50">
                <input type="checkbox" name="qc[<?= $qcItem[
                    "k"
                ] ?>]" value="1" <?= $qcCheck($qcItem["k"])
    ? "checked"
    : "" ?> class="rounded text-red-600 focus:ring-red-500">
                <div class="min-w-0">
                  <div class="text-[11px] font-medium text-gray-800"><?= $qcItem[
                      "l"
                  ] ?></div>
                  <span class="text-[9px] text-gray-400 block"><?= $qcItem[
                      "d"
                  ] ?></span>
                </div>
              </label>
              <?php endforeach;
              ?>
            </div>
          </div>

          <div class="mb-3">
            <div class="flex items-center gap-2 mb-2">
              <span class="w-6 h-6 rounded-lg bg-emerald-100 flex items-center justify-center text-emerald-600 text-[10px]"><i class="fas fa-check-double"></i></span>
              <span class="text-xs font-bold text-gray-700">Response Quality</span>
              <span class="text-[9px] text-gray-400">Ensure honest, thoughtful answers</span>
            </div>
            <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-1.5">
              <?php
              $qcCats = [
                  [
                      "k" => "prevent_duplicates",
                      "l" => "Block Duplicates",
                      "d" => "One response per user",
                      "c" => "emerald",
                  ],
                  [
                      "k" => "detect_straightline",
                      "l" => "Straight-Line",
                      "d" => "Same answer pattern",
                      "c" => "emerald",
                  ],
                  [
                      "k" => "validate_input",
                      "l" => "Input Validation",
                      "d" => "Email/phone format",
                      "c" => "emerald",
                  ],
                  [
                      "k" => "ai_detection",
                      "l" => "AI Detection",
                      "d" => "Flag GPT/etc answers",
                      "c" => "emerald",
                  ],
                  [
                      "k" => "language_consistency",
                      "l" => "Language Check",
                      "d" => "Consistent language",
                      "c" => "emerald",
                  ],
              ];
              foreach ($qcCats as $qcItem): ?>
              <label class="flex items-center gap-2 px-2.5 py-2 border border-gray-200 rounded-xl cursor-pointer transition-all hover:bg-emerald-50/30 has-[:checked]:border-emerald-400 has-[:checked]:bg-emerald-50/50">
                <input type="checkbox" name="qc[<?= $qcItem[
                    "k"
                ] ?>]" value="1" <?= $qcCheck($qcItem["k"])
    ? "checked"
    : "" ?> class="rounded text-emerald-600 focus:ring-emerald-500">
                <div class="min-w-0">
                  <div class="text-[11px] font-medium text-gray-800"><?= $qcItem[
                      "l"
                  ] ?></div>
                  <span class="text-[9px] text-gray-400 block"><?= $qcItem[
                      "d"
                  ] ?></span>
                </div>
              </label>
              <?php endforeach;
              ?>
            </div>
          </div>

          <div class="mb-3">
            <div class="flex items-center gap-2 mb-2">
              <span class="w-6 h-6 rounded-lg bg-amber-100 flex items-center justify-center text-amber-600 text-[10px]"><i class="fas fa-eye"></i></span>
              <span class="text-xs font-bold text-gray-700">Focus & Integrity</span>
              <span class="text-[9px] text-gray-400">Prevent cheating and distractions</span>
            </div>
            <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-1.5">
              <?php
              $qcCats = [
                  [
                      "k" => "prevent_back_nav",
                      "l" => "Prevent Back",
                      "d" => "Disable back button",
                      "c" => "amber",
                  ],
                  [
                      "k" => "prevent_copy_paste",
                      "l" => "No Copy-Paste",
                      "d" => "Disable paste",
                      "c" => "amber",
                  ],
                  [
                      "k" => "track_tab_switches",
                      "l" => "Track Tabs",
                      "d" => "Detect tab switches",
                      "c" => "amber",
                  ],
                  [
                      "k" => "require_attention",
                      "l" => "Attention Check",
                      "d" => "Mandatory focus test",
                      "c" => "amber",
                  ],
                  [
                      "k" => "fullscreen_mode",
                      "l" => "Fullscreen",
                      "d" => "Force fullscreen",
                      "c" => "amber",
                  ],
                  [
                      "k" => "disable_rightclick",
                      "l" => "No Right-Click",
                      "d" => "Disable menu",
                      "c" => "amber",
                  ],
                  [
                      "k" => "confirm_answers",
                      "l" => "Confirm Answers",
                      "d" => "Review before submit",
                      "c" => "amber",
                  ],
              ];
              foreach ($qcCats as $qcItem): ?>
              <label class="flex items-center gap-2 px-2.5 py-2 border border-gray-200 rounded-xl cursor-pointer transition-all hover:bg-amber-50/30 has-[:checked]:border-amber-400 has-[:checked]:bg-amber-50/50">
                <input type="checkbox" name="qc[<?= $qcItem[
                    "k"
                ] ?>]" value="1" <?= $qcCheck($qcItem["k"])
    ? "checked"
    : "" ?> class="rounded text-amber-600 focus:ring-amber-500">
                <div class="min-w-0">
                  <div class="text-[11px] font-medium text-gray-800"><?= $qcItem[
                      "l"
                  ] ?></div>
                  <span class="text-[9px] text-gray-400 block"><?= $qcItem[
                      "d"
                  ] ?></span>
                </div>
              </label>
              <?php endforeach;
              ?>
            </div>
          </div>

          <div class="mb-3">
            <div class="flex items-center gap-2 mb-2">
              <span class="w-6 h-6 rounded-lg bg-purple-100 flex items-center justify-center text-purple-600 text-[10px]"><i class="fas fa-gamepad"></i></span>
              <span class="text-xs font-bold text-gray-700">Progression & Gamification</span>
              <span class="text-[9px] text-gray-400">Engage respondents with game-like features</span>
            </div>
            <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-1.5">
              <?php
              $qcCats = [
                  [
                      "k" => "sequential_unlock",
                      "l" => "Sequential Unlock",
                      "d" => "One at a time",
                      "c" => "purple",
                  ],
                  [
                      "k" => "quiz_mode",
                      "l" => "Quiz Mode",
                      "d" => "Scoring + lives",
                      "c" => "purple",
                  ],
                  [
                      "k" => "shuffle_questions",
                      "l" => "Shuffle Questions",
                      "d" => "Random order",
                      "c" => "purple",
                  ],
                  [
                      "k" => "shuffle_options",
                      "l" => "Shuffle Options",
                      "d" => "Random choices",
                      "c" => "purple",
                  ],
                  [
                      "k" => "allow_resume",
                      "l" => "Allow Resume",
                      "d" => "Save & continue",
                      "c" => "purple",
                  ],
                  [
                      "k" => "time_per_question",
                      "l" => "Time Per Q",
                      "d" => "Per-question timer",
                      "c" => "purple",
                  ],
              ];
              foreach ($qcCats as $qcItem): ?>
              <label class="flex items-center gap-2 px-2.5 py-2 border border-gray-200 rounded-xl cursor-pointer transition-all hover:bg-purple-50/30 has-[:checked]:border-purple-400 has-[:checked]:bg-purple-50/50">
                <input type="checkbox" name="qc[<?= $qcItem[
                    "k"
                ] ?>]" value="1" <?= $qcCheck($qcItem["k"])
    ? "checked"
    : "" ?> class="rounded text-purple-600 focus:ring-purple-500">
                <div class="min-w-0">
                  <div class="text-[11px] font-medium text-gray-800"><?= $qcItem[
                      "l"
                  ] ?></div>
                  <span class="text-[9px] text-gray-400 block"><?= $qcItem[
                      "d"
                  ] ?></span>
                </div>
              </label>
              <?php endforeach;
              ?>
            </div>
          </div>

          <div class="mb-3">
            <div class="flex items-center gap-2 mb-2">
              <span class="w-6 h-6 rounded-lg bg-blue-100 flex items-center justify-center text-blue-600 text-[10px]"><i class="fas fa-microchip"></i></span>
              <span class="text-xs font-bold text-gray-700">Advanced Verification</span>
              <span class="text-[9px] text-gray-400">Extra identity & location checks</span>
            </div>
            <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-1.5">
              <?php
              $qcCats = [
                  [
                      "k" => "email_domain_verify",
                      "l" => "Email Domain",
                      "d" => "Verify email domain",
                      "c" => "blue",
                  ],
                  [
                      "k" => "geo_timezone_check",
                      "l" => "Timezone Check",
                      "d" => "Match IP timezone",
                      "c" => "blue",
                  ],
              ];
              foreach ($qcCats as $qcItem): ?>
              <label class="flex items-center gap-2 px-2.5 py-2 border border-gray-200 rounded-xl cursor-pointer transition-all hover:bg-blue-50/30 has-[:checked]:border-blue-400 has-[:checked]:bg-blue-50/50">
                <input type="checkbox" name="qc[<?= $qcItem[
                    "k"
                ] ?>]" value="1" <?= $qcCheck($qcItem["k"])
    ? "checked"
    : "" ?> class="rounded text-blue-600 focus:ring-blue-500">
                <div class="min-w-0">
                  <div class="text-[11px] font-medium text-gray-800"><?= $qcItem[
                      "l"
                  ] ?></div>
                  <span class="text-[9px] text-gray-400 block"><?= $qcItem[
                      "d"
                  ] ?></span>
                </div>
              </label>
              <?php endforeach;
              ?>
            </div>
          </div>

          <?php
          $qPass = $qcArr["quiz_pass_score"] ?? 70;
          $qLives = $qcArr["quiz_lives"] ?? 3;
          $qTimer = $qcArr["quiz_timer_per_q"] ?? 30;
          $qShow = !empty($qcArr["quiz_show_answers"]);
          ?>
          <div id="quiz-settings-eb" class="hidden mb-3 p-4 bg-gradient-to-r from-purple-50/80 to-indigo-50/80 border border-purple-200 rounded-xl">
            <div class="flex items-center gap-2 mb-3">
              <span class="w-7 h-7 rounded-lg bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center text-white text-xs shadow-sm"><i class="fas fa-gamepad"></i></span>
              <span class="text-xs font-bold text-gray-800">Quiz Mode Settings</span>
              <span class="text-[9px] text-purple-500 ml-auto"><i class="fas fa-lightbulb"></i> Engage respondents with gamification</span>
            </div>
            <div class="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div>
                <label class="block text-[10px] font-medium text-gray-600 mb-0.5">Passing Score (%)</label>
                <input type="number" name="qc[quiz_pass_score]" value="<?= $qPass ?>" min="0" max="100" class="w-full px-2 py-1.5 rounded-lg text-sm border border-purple-200 focus:ring-2 focus:ring-purple-500 bg-white">
              </div>
              <div>
                <label class="block text-[10px] font-medium text-gray-600 mb-0.5">Lives / Attempts</label>
                <input type="number" name="qc[quiz_lives]" value="<?= $qLives ?>" min="1" max="10" class="w-full px-2 py-1.5 rounded-lg text-sm border border-purple-200 focus:ring-2 focus:ring-purple-500 bg-white">
              </div>
              <div>
                <label class="block text-[10px] font-medium text-gray-600 mb-0.5">Timer Per Q (sec)</label>
                <input type="number" name="qc[quiz_timer_per_q]" value="<?= $qTimer ?>" min="5" max="600" class="w-full px-2 py-1.5 rounded-lg text-sm border border-purple-200 focus:ring-2 focus:ring-purple-500 bg-white">
              </div>
              <div class="flex items-end pb-1">
                <label class="flex items-center gap-1.5 text-[10px] text-gray-600 cursor-pointer">
                  <input type="checkbox" name="qc[quiz_show_answers]" value="1" <?= $qShow
                      ? "checked"
                      : "" ?> class="rounded text-purple-600 focus:ring-purple-500"> Show correct answers
                </label>
              </div>
            </div>
            <div class="flex items-center gap-3 mt-2 text-[9px] text-gray-400">
              <span><i class="fas fa-trophy text-amber-400"></i> Scoring: correct = +1, wrong = lose life</span>
              <span><i class="fas fa-lock text-purple-400"></i> Sequential: each question unlocks the next</span>
              <span><i class="fas fa-fire text-orange-400"></i> Streak bonus: 3+ correct in a row</span>
            </div>
          </div>

          <div class="grid grid-cols-2 sm:grid-cols-5 gap-3">
            <div>
              <label class="block text-[10px] font-medium text-gray-500 mb-0.5">Min Time (sec)</label>
              <input type="number" name="qc[min_time_seconds]" value="<?= $qcArr[
                  "min_time_seconds"
              ] ??
                  30 ?>" min="0" max="3600" class="w-full px-2.5 py-1.5 rounded-lg text-sm border border-gray-200 focus:ring-2 focus:ring-indigo-500 bg-white/70">
            </div>
            <div>
              <label class="block text-[10px] font-medium text-gray-500 mb-0.5">Min Text Length</label>
              <input type="number" name="qc[min_text_length]" value="<?= $qcArr[
                  "min_text_length"
              ] ??
                  10 ?>" min="0" max="1000" class="w-full px-2.5 py-1.5 rounded-lg text-sm border border-gray-200 focus:ring-2 focus:ring-indigo-500 bg-white/70">
            </div>
            <div>
              <label class="block text-[10px] font-medium text-gray-500 mb-0.5">Inactivity Timeout</label>
              <input type="number" name="qc[inactivity_timeout]" value="<?= $qcArr[
                  "inactivity_timeout"
              ] ??
                  300 ?>" min="0" max="3600" class="w-full px-2.5 py-1.5 rounded-lg text-sm border border-gray-200 focus:ring-2 focus:ring-indigo-500 bg-white/70">
            </div>
            <div>
              <label class="block text-[10px] font-medium text-gray-500 mb-0.5">Warn Before (sec)</label>
              <input type="number" name="qc[inactivity_warn_before]" value="<?= $qcArr[
                  "inactivity_warn_before"
              ] ??
                  30 ?>" min="5" max="300" class="w-full px-2.5 py-1.5 rounded-lg text-sm border border-gray-200 focus:ring-2 focus:ring-indigo-500 bg-white/70">
            </div>
            <div>
              <label class="block text-[10px] font-medium text-gray-500 mb-0.5">Max Idle (sec)</label>
              <input type="number" name="qc[max_idle_seconds]" value="<?= $qcArr[
                  "max_idle_seconds"
              ] ??
                  300 ?>" min="0" max="3600" class="w-full px-2.5 py-1.5 rounded-lg text-sm border border-gray-200 focus:ring-2 focus:ring-indigo-500 bg-white/70">
            </div>
          </div>
        </div>
      </div>
    </div><!-- /form-edit-zone -->

    <!-- ===== CHAT SURVEY EDIT ZONE ===== -->
    <div id="chat-edit-zone" <?= $isFormMode
        ? 'style="display:none"'
        : "" ?> class="<?= $isFormMode ? "hidden" : "" ?> space-y-5">

      <!-- AI Engine Config -->
      <div class="bg-white rounded-2xl p-5 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
        <div class="flex items-center justify-between mb-4">
          <div class="flex items-center gap-3">
            <span class="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-purple-200"><i class="fas fa-brain text-lg"></i></span>
            <div>
              <h2 class="text-base font-bold text-gray-900">AI Engine</h2>
              <p class="text-[10px] text-gray-400">Configure the AI that powers your chat survey</p>
            </div>
          </div>
          <button type="button" onclick="toggleSection('ce-ai', this)" class="text-xs text-gray-400 hover:text-gray-600"><i class="fas fa-chevron-up"></i></button>
        </div>
        <div id="ce-ai">
          <div class="space-y-2 mb-4" id="ce-providers">
            <button type="button" onclick="selectAIProvider('none')" id="eb-ai-p-none" class="px-3 py-2 rounded-xl text-[10px] font-medium border-2 transition-all text-gray-400 border-gray-200 bg-gray-50 hover:border-gray-300 hover:text-gray-600"><i class="fas fa-ban mr-1"></i>None</button>
            <div class="flex items-center gap-1.5 mt-3 mb-1.5"><span class="w-1.5 h-1.5 rounded-full bg-emerald-400"></span><span class="text-[9px] font-semibold text-emerald-600 uppercase tracking-wider">Free — No API Key Needed</span><span class="flex-1 border-t border-dashed border-emerald-200/50"></span></div>
            <div class="flex gap-1.5 overflow-x-auto pb-1">
              <button type="button" onclick="selectAIProvider('puter')" id="eb-ai-p-puter" class="flex-shrink-0 px-3 py-2 rounded-xl text-[10px] font-medium border-2 transition-all text-emerald-600 border-emerald-200 bg-emerald-50 hover:border-emerald-400 hover:bg-emerald-100"><i class="fas fa-bolt mr-1"></i>Puter (Free Gemini)</button>
              <button type="button" onclick="selectAIProvider('pollinations')" id="eb-ai-p-pollinations" class="flex-shrink-0 px-3 py-2 rounded-xl text-[10px] font-medium border-2 transition-all text-orange-600 border-orange-200 bg-orange-50 hover:border-orange-400 hover:bg-orange-100"><i class="fas fa-cloud mr-1"></i>Pollinations (Free AI)</button>
            </div>
            <div class="flex items-center gap-1.5 mt-2 mb-1.5"><span class="w-1.5 h-1.5 rounded-full bg-amber-400"></span><span class="text-[9px] font-semibold text-amber-600 uppercase tracking-wider">API Key Required</span><span class="flex-1 border-t border-dashed border-amber-200/50"></span></div>
            <div class="flex gap-1.5 overflow-x-auto pb-1">
              <button type="button" onclick="selectAIProvider('gemini')" id="eb-ai-p-gemini" class="flex-shrink-0 px-3 py-2 rounded-xl text-[10px] font-medium border-2 transition-all text-blue-600 border-blue-200 bg-blue-50 hover:border-blue-400 hover:bg-blue-100"><i class="fas fa-sparkles mr-1"></i>Gemini API</button>
              <button type="button" onclick="selectAIProvider('openai')" id="eb-ai-p-openai" class="flex-shrink-0 px-3 py-2 rounded-xl text-[10px] font-medium border-2 transition-all text-sky-600 border-sky-200 bg-sky-50 hover:border-sky-400 hover:bg-sky-100"><i class="fab fa-openai mr-1"></i>OpenAI</button>
              <button type="button" onclick="selectAIProvider('claude')" id="eb-ai-p-claude" class="flex-shrink-0 px-3 py-2 rounded-xl text-[10px] font-medium border-2 transition-all text-rose-600 border-rose-200 bg-rose-50 hover:border-rose-400 hover:bg-rose-100"><i class="fas fa-feather mr-1"></i>Claude</button>
              <button type="button" onclick="selectAIProvider('deepseek')" id="eb-ai-p-deepseek" class="flex-shrink-0 px-3 py-2 rounded-xl text-[10px] font-medium border-2 transition-all text-violet-600 border-violet-200 bg-violet-50 hover:border-violet-400 hover:bg-violet-100"><i class="fas fa-dragon mr-1"></i>DeepSeek</button>
            </div>
          </div>
          <div id="eb-ai-config-fields" class="space-y-3">
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div class="sm:col-span-1">
                <label class="block text-[10px] font-medium text-gray-500 mb-1">Model</label>
                <select id="eb-ai-model" class="w-full px-2.5 py-2.5 rounded-xl text-xs border border-gray-200 bg-white shadow-sm focus:ring-2 focus:ring-purple-300 outline-none">
                  <option value="">Default</option>
                </select>
              </div>
              <div class="sm:col-span-1">
                <label class="block text-[10px] font-medium text-gray-500 mb-1">API Key <span id="ce-key-badge" class="text-[8px] px-1.5 py-0.5 rounded-full bg-gray-100 text-gray-500 font-medium">Not needed</span></label>
                <input type="password" id="eb-ai-api-key" class="w-full px-2.5 py-2.5 rounded-xl text-xs border border-gray-200 bg-white shadow-sm focus:ring-2 focus:ring-purple-300 outline-none" placeholder="Paste your API key here">
              </div>
              <div class="sm:col-span-1">
                <label class="block text-[10px] font-medium text-gray-500 mb-1">Max Tokens: <span id="ce-tokens-val" class="font-bold text-purple-600">200</span></label>
                <input type="range" id="eb-ai-max-tokens" min="50" max="3000" step="50" value="200" class="w-full accent-purple-500 mt-2" oninput="document.getElementById('ce-tokens-val').textContent=this.value">
              </div>
            </div>
            <div>
              <label class="block text-[10px] font-medium text-gray-500 mb-1">System Prompt <span class="text-gray-300 font-normal">— Tells the AI how to behave</span></label>
              <textarea id="eb-ai-system-prompt" rows="2" class="w-full px-3 py-2.5 rounded-xl text-xs border border-gray-200 bg-white shadow-sm focus:ring-2 focus:ring-purple-300 outline-none resize-none" placeholder="You are a friendly survey AI interviewer...">You are a helpful survey AI. Ask questions one at a time. Be conversational and adapt to the respondent's answers.</textarea>
            </div>
            <div class="flex flex-wrap items-center gap-3">
              <span class="text-[10px] font-medium text-gray-500">Capabilities:</span>
              <label class="inline-flex items-center gap-1.5 text-[10px] text-gray-600 bg-gray-50 px-2.5 py-1.5 rounded-lg border border-gray-100 cursor-pointer hover:border-purple-200 hover:bg-purple-50/30 transition-all has-[:checked]:border-purple-300 has-[:checked]:bg-purple-50 has-[:checked]:text-purple-700"><input type="checkbox" id="eb-ai-cap-sentiment" checked class="rounded border-gray-300 text-purple-500 w-3 h-3"> Sentiment</label>
              <label class="inline-flex items-center gap-1.5 text-[10px] text-gray-600 bg-gray-50 px-2.5 py-1.5 rounded-lg border border-gray-100 cursor-pointer hover:border-emerald-200 hover:bg-emerald-50/30 transition-all has-[:checked]:border-emerald-300 has-[:checked]:bg-emerald-50 has-[:checked]:text-emerald-700"><input type="checkbox" id="eb-ai-cap-followup" checked class="rounded border-gray-300 text-emerald-500 w-3 h-3"> Follow-ups</label>
              <label class="inline-flex items-center gap-1.5 text-[10px] text-gray-600 bg-gray-50 px-2.5 py-1.5 rounded-lg border border-gray-100 cursor-pointer hover:border-amber-200 hover:bg-amber-50/30 transition-all has-[:checked]:border-amber-300 has-[:checked]:bg-amber-50 has-[:checked]:text-amber-700"><input type="checkbox" id="eb-ai-cap-summarize" checked class="rounded border-gray-300 text-amber-500 w-3 h-3"> Summarize</label>
              <label class="inline-flex items-center gap-1.5 text-[10px] text-gray-600 bg-gray-50 px-2.5 py-1.5 rounded-lg border border-gray-100 cursor-pointer hover:border-blue-200 hover:bg-blue-50/30 transition-all has-[:checked]:border-blue-300 has-[:checked]:bg-blue-50 has-[:checked]:text-blue-700"><input type="checkbox" id="eb-ai-cap-context" checked class="rounded border-gray-300 text-blue-500 w-3 h-3"> Context</label>
            </div>
            <div id="eb-ai-provider-note" class="text-[10px] text-gray-400 bg-gray-50 rounded-xl px-3 py-2.5 border border-gray-100 flex items-start gap-2">
              <i class="fas fa-info-circle text-blue-400 mt-0.5"></i>
              <span>Select a provider above. <strong>Free options</strong> (Puter, Pollinations) need no API key. Puter provides free Gemini via client-side JS. <strong>API providers</strong> (Gemini API, OpenAI, Claude, DeepSeek) need a valid API key.</span>
            </div>
          </div>
          <input type="hidden" name="ai_config" id="eb-ai-config-input" value="<?= htmlspecialchars(
              $aiConfigJson ?? "",
          ) ?>">
        </div>
      </div>

      <!-- Conversation Flow -->
      <div class="bg-white rounded-2xl p-5 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
        <div class="flex items-center justify-between mb-4">
          <div class="flex items-center gap-3">
            <span class="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-white shadow-lg shadow-emerald-200"><i class="fas fa-comment-dots text-lg"></i></span>
            <div>
              <h2 class="text-base font-bold text-gray-900">Conversation Flow</h2>
              <p class="text-[10px] text-gray-400">Design the chat experience from start to finish</p>
            </div>
          </div>
          <button type="button" onclick="toggleSection('ce-flow', this)" class="text-xs text-gray-400 hover:text-gray-600"><i class="fas fa-chevron-up"></i></button>
        </div>
        <div id="ce-flow">
          <div class="grid grid-cols-2 gap-4 mb-4">
            <div>
              <label class="block text-xs font-medium text-gray-600 mb-1.5"><i class="fas fa-wavefare text-emerald-400 mr-1"></i>Intro Message</label>
              <textarea id="eb-chat-intro" rows="3" class="w-full px-3 py-2.5 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-emerald-300 outline-none resize-none transition-all bg-white shadow-sm" placeholder="Hi! I'm an AI assistant. I'd like to ask you a few questions..."><?= htmlspecialchars(
                  $survey["chat_config"]["intro_message"] ?? "",
              ) ?></textarea>
            </div>
            <div>
              <label class="block text-xs font-medium text-gray-600 mb-1.5"><i class="fas fa-robot text-emerald-400 mr-1"></i>Persona</label>
              <select id="eb-chat-tone" class="w-full px-3 py-2.5 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-emerald-300 outline-none transition-all bg-white shadow-sm">
                <option value="neutral" <?= ($survey["chat_config"]["tone"] ??
                    "neutral") ===
                "neutral"
                    ? "selected"
                    : "" ?>>🧑 Neutral</option>
                <option value="friendly" <?= ($survey["chat_config"]["tone"] ??
                    "") ===
                "friendly"
                    ? "selected"
                    : "" ?>>😊 Friendly</option>
                <option value="formal" <?= ($survey["chat_config"]["tone"] ??
                    "") ===
                "formal"
                    ? "selected"
                    : "" ?>>👔 Formal</option>
                <option value="empathetic" <?= ($survey["chat_config"][
                    "tone"
                ] ??
                    "") ===
                "empathetic"
                    ? "selected"
                    : "" ?>>🤗 Empathetic</option>
                <option value="professional" <?= ($survey["chat_config"][
                    "tone"
                ] ??
                    "") ===
                "professional"
                    ? "selected"
                    : "" ?>>💼 Professional</option>
                <option value="casual" <?= ($survey["chat_config"]["tone"] ??
                    "") ===
                "casual"
                    ? "selected"
                    : "" ?>>😎 Casual</option>
              </select>
              <div class="mt-3">
                <label class="block text-xs font-medium text-gray-600 mb-1.5"><i class="fas fa-thermometer-half text-emerald-400 mr-1"></i>Temperature: <span id="ce-temp-val" class="font-bold text-emerald-600">0.7</span></label>
                <input type="range" id="ce-temperature" min="0" max="2" step="0.1" value="0.7" class="w-full accent-emerald-500" oninput="document.getElementById('ce-temp-val').textContent=this.value">
                <div class="flex justify-between text-[9px] text-gray-400 mt-0.5"><span>Precise</span><span>Creative</span></div>
              </div>
            </div>
          </div>
          <div>
            <div class="flex items-center justify-between mb-3">
              <div class="flex items-center gap-2">
                <label class="text-xs font-semibold text-gray-700">Question Flow</label>
                <span class="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700 text-[9px] font-medium" id="ce-node-count">0 nodes</span>
                <span class="text-[9px] text-gray-400 hidden sm:inline">Drag to reorder, click to edit</span>
              </div>
              <button type="button" onclick="addChatNode()" class="px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-white text-[10px] font-medium hover:from-emerald-600 hover:to-teal-600 transition-all shadow-sm shadow-emerald-200 flex items-center gap-1.5 hover:shadow-md hover:shadow-emerald-200/40 active:scale-95"><i class="fas fa-plus text-[8px]"></i>Add Node</button>
            </div>
            <div class="flex gap-1.5 mb-4 overflow-x-auto pb-1 scrollbar-thin" id="ce-qx-grid">
              <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAddChat('text')" data-type="text"><i class="fas fa-font"></i> Text</button>
              <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-amber-50 text-amber-700 border border-amber-200 hover:bg-amber-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAddChat('rating')" data-type="rating"><i class="fas fa-star"></i> Rating</button>
              <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-blue-50 text-blue-700 border border-blue-200 hover:bg-blue-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAddChat('yes_no')" data-type="yes_no"><i class="fas fa-check-circle"></i> Yes/No</button>
              <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-purple-50 text-purple-700 border border-purple-200 hover:bg-purple-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAddChat('mcq_single')" data-type="mcq_single"><i class="fas fa-circle-dot"></i> Single</button>
              <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-fuchsia-50 text-fuchsia-700 border border-fuchsia-200 hover:bg-fuchsia-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAddChat('mcq_multiple')" data-type="mcq_multiple"><i class="fas fa-list-check"></i> Multi</button>
              <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-cyan-50 text-cyan-700 border border-cyan-200 hover:bg-cyan-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAddChat('email')" data-type="email"><i class="fas fa-at"></i> Email</button>
              <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-rose-50 text-rose-700 border border-rose-200 hover:bg-rose-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAddChat('date')" data-type="date"><i class="fas fa-calendar"></i> Date</button>
              <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-teal-50 text-teal-700 border border-teal-200 hover:bg-teal-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAddChat('phone')" data-type="phone"><i class="fas fa-phone"></i> Phone</button>
              <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-blue-50 text-blue-700 border border-blue-200 hover:bg-blue-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAddChat('number')" data-type="number"><i class="fas fa-hashtag"></i> Number</button>
              <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-orange-50 text-orange-700 border border-orange-200 hover:bg-orange-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAddChat('dropdown')" data-type="dropdown"><i class="fas fa-chevron-down"></i> Dropdown</button>
              <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-violet-50 text-violet-700 border border-violet-200 hover:bg-violet-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAddChat('likert5')" data-type="likert5"><i class="fas fa-grip-lines"></i> Likert 5</button>
              <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-violet-50 text-violet-700 border border-violet-200 hover:bg-violet-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAddChat('likert7')" data-type="likert7"><i class="fas fa-grip-lines"></i> Likert 7</button>
              <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-pink-50 text-pink-700 border border-pink-200 hover:bg-pink-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAddChat('slider')" data-type="slider"><i class="fas fa-sliders"></i> Slider</button>
              <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-gray-50 text-gray-700 border border-gray-200 hover:bg-gray-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAddChat('matrix')" data-type="matrix"><i class="fas fa-table"></i> Matrix</button>
              <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-sky-50 text-sky-700 border border-sky-200 hover:bg-sky-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAddChat('file_upload')" data-type="file_upload"><i class="fas fa-upload"></i> Upload</button>
              <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-stone-50 text-stone-700 border border-stone-200 hover:bg-stone-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAddChat('textarea')" data-type="textarea"><i class="fas fa-paragraph"></i> Long Text</button>
              <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-sky-50 text-sky-700 border border-sky-200 hover:bg-sky-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAddChat('url')" data-type="url"><i class="fas fa-link"></i> URL</button>
              <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-red-50 text-red-700 border border-red-200 hover:bg-red-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAddChat('nps')" data-type="nps"><i class="fas fa-chart-bar"></i> NPS</button>
              <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-amber-50 text-amber-700 border border-amber-200 hover:bg-amber-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAddChat('ranking')" data-type="ranking"><i class="fas fa-list-ol"></i> Ranking</button>
              <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-lime-50 text-lime-700 border border-lime-200 hover:bg-lime-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAddChat('multi_text')" data-type="multi_text"><i class="fas fa-list"></i> Multi Text</button>
              <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-yellow-50 text-yellow-700 border border-yellow-200 hover:bg-yellow-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAddChat('address')" data-type="address"><i class="fas fa-map-marker-alt"></i> Address</button>
              <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-rose-50 text-rose-700 border border-rose-200 hover:bg-rose-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAddChat('time')" data-type="time"><i class="fas fa-clock"></i> Time</button>
              <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-fuchsia-50 text-fuchsia-700 border border-fuchsia-200 hover:bg-fuchsia-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAddChat('datetime')" data-type="datetime"><i class="fas fa-calendar-alt"></i> Date/Time</button>
              <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-pink-50 text-pink-700 border border-pink-200 hover:bg-pink-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAddChat('color')" data-type="color"><i class="fas fa-palette"></i> Color</button>
              <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-cyan-50 text-cyan-700 border border-cyan-200 hover:bg-cyan-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAddChat('percentage')" data-type="percentage"><i class="fas fa-percent"></i> Percentage</button>
              <button type="button" class="qx-btn px-3 py-1.5 rounded-lg text-xs font-medium bg-indigo-50 text-indigo-700 border border-indigo-200 hover:bg-indigo-100 hover:shadow-sm transition-all flex items-center gap-1.5 flex-shrink-0" onclick="quickAddChat('signature')" data-type="signature"><i class="fas fa-pen-fancy"></i> Signature</button>
            </div>
            <div id="eb-chat-nodes" class="min-h-[120px] bg-gray-50/60 rounded-xl p-3 space-y-1">
              <div id="eb-chat-nodes-empty" class="flex flex-col items-center justify-center py-12 text-gray-400">
                <div class="w-12 h-12 rounded-2xl bg-emerald-50 border-2 border-dashed border-emerald-200 flex items-center justify-center mb-3"><i class="fas fa-comment-dots text-emerald-300 text-lg"></i></div>
                <span class="text-xs font-medium text-gray-400 mb-1">No chat nodes yet</span>
                <span class="text-[9px] text-gray-300">Click <strong class="text-emerald-500">Add Node</strong> to build your conversation</span>
              </div>
            </div>
          </div>
          <input type="hidden" name="chat_config" id="eb-chat-config-input" value="<?= htmlspecialchars(
              $chatConfigJson ?? "",
          ) ?>">
        </div>
      </div>

      <!-- Chat Behaviors -->
      <div class="bg-white rounded-2xl p-5 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
        <div class="flex items-center justify-between mb-4">
          <div class="flex items-center gap-3">
            <span class="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-orange-500 flex items-center justify-center text-white shadow-lg shadow-amber-200"><i class="fas fa-sliders-h text-lg"></i></span>
            <div>
              <h2 class="text-base font-bold text-gray-900">Behaviors & Rules</h2>
              <p class="text-[10px] text-gray-400">Control how respondents interact with the chat</p>
            </div>
          </div>
          <button type="button" onclick="toggleSection('ce-behaviors', this)" class="text-xs text-gray-400 hover:text-gray-600"><i class="fas fa-chevron-down"></i></button>
        </div>
        <div id="ce-behaviors" style="max-height:0px;overflow:hidden">
          <div class="grid grid-cols-2 gap-3">
            <label class="flex items-center gap-3 px-3 py-3 border border-gray-200 rounded-xl cursor-pointer transition-all hover:border-purple-300 hover:bg-purple-50/30 has-[:checked]:border-purple-400 has-[:checked]:bg-purple-50/50">
              <input type="checkbox" name="qc[sequential_unlock]" value="1" <?= !empty(
                  $qcArr["sequential_unlock"]
              )
                  ? "checked"
                  : "" ?> class="rounded text-purple-600 focus:ring-purple-500 w-4 h-4">
              <div><div class="text-xs font-medium text-gray-800">Sequential Unlock</div><span class="text-[9px] text-gray-400">Reveal questions one at a time</span></div>
            </label>
            <label class="flex items-center gap-3 px-3 py-3 border border-gray-200 rounded-xl cursor-pointer transition-all hover:border-amber-300 hover:bg-amber-50/30 has-[:checked]:border-amber-400 has-[:checked]:bg-amber-50/50">
              <input type="checkbox" name="qc[quiz_mode]" value="1" <?= !empty(
                  $qcArr["quiz_mode"]
              )
                  ? "checked"
                  : "" ?> class="rounded text-amber-600 focus:ring-amber-500 w-4 h-4">
              <div><div class="text-xs font-medium text-gray-800">Quiz Mode</div><span class="text-[9px] text-gray-400">Scoring, lives, and streak bonuses</span></div>
            </label>
            <label class="flex items-center gap-3 px-3 py-3 border border-gray-200 rounded-xl cursor-pointer transition-all hover:border-emerald-300 hover:bg-emerald-50/30 has-[:checked]:border-emerald-400 has-[:checked]:bg-emerald-50/50">
              <input type="checkbox" name="qc[allow_resume]" value="1" <?= !empty(
                  $qcArr["allow_resume"]
              )
                  ? "checked"
                  : "" ?> class="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4">
              <div><div class="text-xs font-medium text-gray-800">Allow Resume</div><span class="text-[9px] text-gray-400">Save progress and continue later</span></div>
            </label>
            <label class="flex items-center gap-3 px-3 py-3 border border-gray-200 rounded-xl cursor-pointer transition-all hover:border-blue-300 hover:bg-blue-50/30 has-[:checked]:border-blue-400 has-[:checked]:bg-blue-50/50">
              <input type="checkbox" name="qc[shuffle_questions]" value="1" <?= !empty(
                  $qcArr["shuffle_questions"]
              )
                  ? "checked"
                  : "" ?> class="rounded text-blue-600 focus:ring-blue-500 w-4 h-4">
              <div><div class="text-xs font-medium text-gray-800">Shuffle Questions</div><span class="text-[9px] text-gray-400">Randomize order for each respondent</span></div>
            </label>
          </div>
          <div id="quiz-settings-ce" class="hidden mt-4 p-4 bg-gradient-to-r from-purple-50/80 to-amber-50/80 border border-purple-200 rounded-xl">
            <div class="flex items-center gap-2 mb-3">
              <span class="w-7 h-7 rounded-lg bg-gradient-to-br from-purple-500 to-amber-500 flex items-center justify-center text-white text-xs"><i class="fas fa-gamepad"></i></span>
              <span class="text-sm font-bold text-gray-800">Quiz Settings</span>
            </div>
            <div class="grid grid-cols-3 gap-3">
              <div><label class="block text-[10px] font-medium text-gray-500 mb-0.5">Pass Score (%)</label><input type="number" name="qc[quiz_pass_score]" value="<?= $qcArr[
                  "quiz_pass_score"
              ] ??
                  70 ?>" min="0" max="100" class="w-full px-3 py-2 rounded-xl text-sm border border-purple-200 bg-white shadow-sm"></div>
              <div><label class="block text-[10px] font-medium text-gray-500 mb-0.5">Lives</label><input type="number" name="qc[quiz_lives]" value="<?= $qcArr[
                  "quiz_lives"
              ] ??
                  3 ?>" min="1" max="10" class="w-full px-3 py-2 rounded-xl text-sm border border-purple-200 bg-white shadow-sm"></div>
              <div><label class="block text-[10px] font-medium text-gray-500 mb-0.5">Timer/Q (sec)</label><input type="number" name="qc[quiz_timer_per_q]" value="<?= $qcArr[
                  "quiz_timer_per_q"
              ] ??
                  30 ?>" min="5" max="600" class="w-full px-3 py-2 rounded-xl text-sm border border-purple-200 bg-white shadow-sm"></div>
            </div>
            <label class="flex items-center gap-2 mt-3 text-xs text-gray-600 bg-white/80 px-3 py-2 rounded-xl border border-purple-100"><input type="checkbox" name="qc[quiz_show_answers]" value="1" <?= !empty(
                $qcArr["quiz_show_answers"]
            )
                ? "checked"
                : "" ?> class="rounded text-purple-600"> Show correct answers after each question</label>
          </div>
        </div>
      </div>
    </div><!-- /chat-edit-zone -->

    <!-- Action Bar -->
      <div class="flex flex-wrap gap-3 items-center bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
        <?php if ($status === "draft"): ?>
        <button type="button" onclick="publishSurvey()" class="bg-gradient-to-r from-emerald-500 to-emerald-600 text-white px-8 py-3 rounded-xl hover:from-emerald-600 hover:to-emerald-700 transition-all font-semibold text-sm shadow-lg shadow-emerald-200 hover:shadow-xl flex items-center gap-2 order-first">
          <i class="fas fa-play"></i> Publish
        </button>
        <?php endif; ?>
        <button type="submit" class="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-6 py-2.5 rounded-xl hover:from-indigo-700 hover:to-purple-700 transition-all font-medium text-sm shadow-md hover:shadow-lg flex items-center gap-2 <?= $status ===
        "draft"
            ? "opacity-80"
            : "" ?>">
          <i class="fas fa-save"></i> Save Changes <span id="submit-q-count" class="text-indigo-200 text-xs"></span>
        </button>
        <div class="flex-1"></div>
        <a href="<?= url(
            "/dashboard",
        ) ?>" class="px-4 py-2.5 bg-white border border-gray-200 rounded-xl text-gray-600 hover:bg-gray-50 hover:border-gray-300 transition-all text-sm shadow-sm flex items-center gap-1.5"><i class="fas fa-arrow-left text-gray-400"></i> Dashboard</a>
        <button type="button" onclick="confirmDelete()" class="px-4 py-2.5 bg-white border border-red-200 text-red-500 rounded-xl hover:bg-red-50 hover:border-red-300 transition-all text-sm shadow-sm flex items-center gap-1.5"><i class="fas fa-trash"></i> Delete</button>
      </div>
    </div>

    <!-- Right Column — Preview -->
    <div class="lg:col-span-1">
      <div class="bg-white rounded-2xl p-5 shadow-sm border border-gray-100 sticky top-24 hover:shadow-md transition-shadow">
        <div class="flex items-center gap-2 mb-3">
          <div class="w-7 h-7 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white text-[10px]"><i class="fas fa-eye"></i></div>
          <span class="text-xs font-bold text-gray-800">Preview</span>
          <span class="text-[10px] text-gray-400 ml-auto" id="preview-q-count"><?php if (
              !$isFormMode
          ) {
              $nodeCount = count($survey["chat_config"]["nodes"] ?? []);
              echo $nodeCount . " node" . ($nodeCount !== 1 ? "s" : "");
          } else {
              echo count($questions) .
                  " question" .
                  (count($questions) !== 1 ? "s" : "");
          } ?></span>
          <button onclick="updatePreviewMode(getSurveyMode())" class="text-[9px] text-indigo-400 hover:text-indigo-600 transition-colors" title="Refresh preview"><i class="fas fa-rotate"></i></button>
        </div>
        <div id="preview-phone" class="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden transition-all duration-500" style="min-height:300px">
          <div id="preview-header" class="px-4 py-3 border-b bg-gradient-to-r from-indigo-500 to-purple-600 transition-all duration-500">
            <div id="preview-logo" class="hidden mb-1"><img id="preview-logo-img" class="h-6 w-auto" alt=""></div>
            <div id="preview-title" class="text-sm font-bold text-white"><?= htmlspecialchars(
                $survey["title"] ?? "Survey Title",
            ) ?></div>
            <div id="preview-desc" class="text-[10px] text-white/70 mt-0.5 line-clamp-1"><?= htmlspecialchars(
                $survey["description"] ?? "",
            ) ?></div>
          </div>
          <div id="preview-body" class="p-4 space-y-3 min-h-[200px]">
            <div class="text-center py-6 text-gray-400 text-xs">
              <i class="fas fa-arrow-up text-lg mb-1"></i><br>
              <?= !$isFormMode
                  ? "Conversation will appear here"
                  : "Questions will appear here" ?>
            </div>
          </div>
        </div>
        <?php if ($status === "active"): ?>
        <?php $surveyId = $survey["id"] ?? 0; ?>
        <div class="mt-3 space-y-2" id="share-section">
          <!-- Direct Link -->
          <div class="bg-gradient-to-r from-emerald-50 to-emerald-100/50 border border-emerald-200 rounded-xl overflow-hidden">
            <div class="p-3">
              <p class="text-[11px] font-semibold text-emerald-800 flex items-center gap-1.5"><i class="fas fa-link text-emerald-600"></i> Survey Live</p>
              <div class="flex gap-1.5 mt-2">
                <div class="relative flex-1">
                  <input type="text" readonly value="<?= url(
                      "/survey/take/" . $surveyId,
                  ) ?>" class="w-full text-[11px] px-2.5 py-2 rounded-lg border border-emerald-200 bg-white font-mono text-emerald-900 pr-8" id="survey-link" onclick="this.select();copyLink()">
                  <button type="button" onclick="copyLink()" class="absolute right-1 top-1/2 -translate-y-1/2 w-6 h-6 rounded-md bg-emerald-600 text-white hover:bg-emerald-700 transition-all flex items-center justify-center text-[9px]" title="Copy link"><i class="fas fa-copy"></i></button>
                </div>
              </div>
            </div>
          </div>

          <!-- Share & Distribute Card -->
          <div class="bg-white border border-gray-200 rounded-xl overflow-hidden">
            <div class="p-3">
              <p class="text-[11px] font-semibold text-gray-800 flex items-center gap-1.5"><i class="fas fa-share-alt text-indigo-500"></i> Share & Distribute</p>
              <p class="text-[9px] text-gray-500 mt-0.5">Generate short links, QR codes, and trackable URLs</p>

              <!-- Generate URL Form -->
              <div class="mt-2 space-y-1.5" id="generate-url-form">
                <div class="flex gap-1.5">
                  <input type="text" placeholder="Custom slug (optional)" id="url-custom-slug" class="flex-1 text-[10px] px-2 py-1.5 rounded-lg border border-gray-200 bg-white focus:border-indigo-300 focus:ring-1 focus:ring-indigo-200 outline-none placeholder-gray-300">
                  <button type="button" onclick="generateShortUrl()" class="px-2.5 py-1.5 rounded-lg bg-indigo-600 text-white text-[10px] font-medium hover:bg-indigo-700 transition-all whitespace-nowrap"><i class="fas fa-bolt mr-1"></i>Generate</button>
                </div>
                <div class="flex gap-1.5 flex-wrap">
                  <input type="text" placeholder="utm_source" id="url-utm-source" class="min-w-[80px] flex-1 text-[9px] px-2 py-1 rounded-lg border border-gray-200 bg-white focus:border-indigo-300 focus:ring-1 focus:ring-indigo-200 outline-none placeholder-gray-300">
                  <input type="text" placeholder="utm_medium" id="url-utm-medium" class="min-w-[80px] flex-1 text-[9px] px-2 py-1 rounded-lg border border-gray-200 bg-white focus:border-indigo-300 focus:ring-1 focus:ring-indigo-200 outline-none placeholder-gray-300">
                  <input type="text" placeholder="utm_campaign" id="url-utm-campaign" class="min-w-[80px] flex-1 text-[9px] px-2 py-1 rounded-lg border border-gray-200 bg-white focus:border-indigo-300 focus:ring-1 focus:ring-indigo-200 outline-none placeholder-gray-300">
                </div>
                <div class="flex items-center gap-1.5 flex-wrap">
                  <input type="password" placeholder="Link password" id="url-password" class="min-w-[80px] flex-1 text-[9px] px-2 py-1 rounded-lg border border-gray-200 bg-white focus:border-indigo-300 focus:ring-1 focus:ring-indigo-200 outline-none placeholder-gray-300">
                  <input type="datetime-local" id="url-expires" class="min-w-[120px] flex-1 text-[9px] px-2 py-1 rounded-lg border border-gray-200 bg-white focus:border-indigo-300 focus:ring-1 focus:ring-indigo-200 outline-none">
                  <input type="number" placeholder="Max uses" id="url-max-uses" class="w-16 text-[9px] px-2 py-1 rounded-lg border border-gray-200 bg-white focus:border-indigo-300 focus:ring-1 focus:ring-indigo-200 outline-none placeholder-gray-300">
                </div>
              </div>

              <!-- Generated URLs List -->
              <div class="mt-2 space-y-1" id="url-list">
                <div class="text-[9px] text-gray-400 text-center py-2" id="url-list-empty">Loading URLs...</div>
              </div>
            </div>
          </div>
        </div>

        <!-- QR Code Modal -->
        <div id="qr-modal" class="fixed inset-0 z-50 hidden flex items-center justify-center" style="background:rgba(0,0,0,0.5)">
          <div class="bg-white rounded-2xl p-5 max-w-xs w-full mx-4 text-center shadow-2xl">
            <p class="text-sm font-bold text-gray-800 mb-2"><i class="fas fa-qrcode text-indigo-500 mr-1"></i> QR Code</p>
            <img id="qr-modal-img" src="" alt="QR Code" class="mx-auto w-48 h-48 rounded-xl border">
            <button type="button" onclick="document.getElementById('qr-modal').classList.add('hidden')" class="mt-3 px-4 py-2 rounded-lg bg-gray-100 text-gray-600 text-xs font-medium hover:bg-gray-200 transition-all">Close</button>
          </div>
        </div>
        <?php endif; ?>
      </div>
    </div>
  </form>
</div>

<!-- Floating AI Button -->
<button id="ai-fab" onclick="toggleAIPanel()" class="fixed bottom-6 right-6 z-30 w-14 h-14 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 text-white shadow-lg hover:shadow-xl hover:from-blue-600 hover:to-purple-700 transition-all flex items-center justify-center text-xl group">
  <i class="fas fa-wand-magic-sparkles"></i>
  <span class="absolute -top-1 -right-1 w-4 h-4 bg-emerald-400 rounded-full flex items-center justify-center text-[8px] text-white shadow-sm">$</span>
  <div class="absolute right-16 top-1/2 -translate-y-1/2 bg-gray-900 text-white text-[10px] px-2.5 py-1 rounded-lg whitespace-nowrap opacity-0 group-hover:opacity-100 transition-all pointer-events-none shadow-lg">AI Assistant</div>
</button>

<!-- QUESTION BANK DRAWER -->
<div id="q-bank-overlay" class="fixed inset-0 z-40 hidden" onclick="toggleBank()" style="background:rgba(0,0,0,0.3)"></div>
<div id="q-bank" class="fixed top-0 right-0 z-50 h-full w-full max-w-sm bg-white shadow-2xl transform translate-x-full transition-transform duration-300 ease-out overflow-y-auto">
  <div class="sticky top-0 bg-white border-b z-10 p-4 flex items-center justify-between">
    <h3 class="text-base font-bold text-gray-900"><i class="fas fa-database text-indigo-500 mr-2"></i>Question Bank</h3>
    <button type="button" onclick="toggleBank()" class="w-8 h-8 rounded-lg hover:bg-gray-100 flex items-center justify-center text-gray-400"><i class="fas fa-times"></i></button>
  </div>
  <div class="p-4 space-y-2" id="q-bank-list">
    <!-- Populated by JS -->
  </div>
</div>

<!-- === CUSTOM QUESTION MODAL === -->
<div id="q-modal" class="fixed inset-0 z-50 hidden flex items-center justify-center p-4" style="background:rgba(0,0,0,0.5);backdrop-filter:blur(4px)">
  <div class="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto animate-scale-in">
    <div class="flex items-center justify-between p-5 border-b sticky top-0 bg-white/95 backdrop-blur z-10 rounded-t-2xl">
      <h3 class="text-base font-bold text-gray-900 flex items-center gap-2">
        <span class="w-8 h-8 rounded-xl bg-gradient-to-br from-emerald-400 to-emerald-600 flex items-center justify-center text-white text-sm shadow-sm"><i class="fas fa-pen"></i></span>
        <span id="modal-title">Add Custom Question</span>
      </h3>
      <button type="button" onclick="closeModal()" class="w-8 h-8 rounded-lg hover:bg-gray-100 flex items-center justify-center text-gray-400 hover:text-gray-600 transition-all"><i class="fas fa-times"></i></button>
    </div>
    <div class="p-5 space-y-5">

      <input type="hidden" id="modal-edit-index" value="-1">

      <!-- Type selector with visual icons -->
      <div>
        <label class="block text-xs font-semibold text-gray-700 mb-2"><i class="fas fa-tag text-gray-400 mr-1"></i>Question Type</label>
        <div class="grid grid-cols-5 gap-1.5" id="modal-type-grid">
          <button type="button" class="modal-type-btn px-2 py-2 rounded-xl text-[10px] font-medium border-2 border-emerald-500 bg-emerald-50 text-emerald-700 transition-all flex flex-col items-center gap-1" data-type="text" onclick="selectModalType('text', this)">
            <i class="fas fa-font text-sm"></i><span>Text</span>
          </button>
          <button type="button" class="modal-type-btn px-2 py-2 rounded-xl text-[10px] font-medium border-2 border-transparent bg-gray-50 text-gray-600 hover:bg-gray-100 transition-all flex flex-col items-center gap-1" data-type="number" onclick="selectModalType('number', this)">
            <i class="fas fa-hashtag text-sm"></i><span>Number</span>
          </button>
          <button type="button" class="modal-type-btn px-2 py-2 rounded-xl text-[10px] font-medium border-2 border-transparent bg-gray-50 text-gray-600 hover:bg-gray-100 transition-all flex flex-col items-center gap-1" data-type="email" onclick="selectModalType('email', this)">
            <i class="fas fa-at text-sm"></i><span>Email</span>
          </button>
          <button type="button" class="modal-type-btn px-2 py-2 rounded-xl text-[10px] font-medium border-2 border-transparent bg-gray-50 text-gray-600 hover:bg-gray-100 transition-all flex flex-col items-center gap-1" data-type="phone" onclick="selectModalType('phone', this)">
            <i class="fas fa-phone text-sm"></i><span>Phone</span>
          </button>
          <button type="button" class="modal-type-btn px-2 py-2 rounded-xl text-[10px] font-medium border-2 border-transparent bg-gray-50 text-gray-600 hover:bg-gray-100 transition-all flex flex-col items-center gap-1" data-type="date" onclick="selectModalType('date', this)">
            <i class="fas fa-calendar text-sm"></i><span>Date</span>
          </button>
          <button type="button" class="modal-type-btn px-2 py-2 rounded-xl text-[10px] font-medium border-2 border-transparent bg-gray-50 text-gray-600 hover:bg-gray-100 transition-all flex flex-col items-center gap-1" data-type="yes_no" onclick="selectModalType('yes_no', this)">
            <i class="fas fa-check-circle text-sm"></i><span>Yes/No</span>
          </button>
          <button type="button" class="modal-type-btn px-2 py-2 rounded-xl text-[10px] font-medium border-2 border-transparent bg-gray-50 text-gray-600 hover:bg-gray-100 transition-all flex flex-col items-center gap-1" data-type="rating" onclick="selectModalType('rating', this)">
            <i class="fas fa-star text-sm"></i><span>Rating</span>
          </button>
          <button type="button" class="modal-type-btn px-2 py-2 rounded-xl text-[10px] font-medium border-2 border-transparent bg-gray-50 text-gray-600 hover:bg-gray-100 transition-all flex flex-col items-center gap-1" data-type="mcq_single" onclick="selectModalType('mcq_single', this)">
            <i class="fas fa-circle-dot text-sm"></i><span>MC Single</span>
          </button>
          <button type="button" class="modal-type-btn px-2 py-2 rounded-xl text-[10px] font-medium border-2 border-transparent bg-gray-50 text-gray-600 hover:bg-gray-100 transition-all flex flex-col items-center gap-1" data-type="mcq_multiple" onclick="selectModalType('mcq_multiple', this)">
            <i class="fas fa-list-check text-sm"></i><span>MC Multi</span>
          </button>
          <button type="button" class="modal-type-btn px-2 py-2 rounded-xl text-[10px] font-medium border-2 border-transparent bg-gray-50 text-gray-600 hover:bg-gray-100 transition-all flex flex-col items-center gap-1" data-type="dropdown" onclick="selectModalType('dropdown', this)">
            <i class="fas fa-chevron-down text-sm"></i><span>Dropdown</span>
          </button>
          <button type="button" class="modal-type-btn px-2 py-2 rounded-xl text-[10px] font-medium border-2 border-transparent bg-gray-50 text-gray-600 hover:bg-gray-100 transition-all flex flex-col items-center gap-1" data-type="likert5" onclick="selectModalType('likert5', this)">
            <i class="fas fa-grip-lines text-sm"></i><span>Likert 5</span>
          </button>
          <button type="button" class="modal-type-btn px-2 py-2 rounded-xl text-[10px] font-medium border-2 border-transparent bg-gray-50 text-gray-600 hover:bg-gray-100 transition-all flex flex-col items-center gap-1" data-type="likert7" onclick="selectModalType('likert7', this)">
            <i class="fas fa-grip-lines text-sm"></i><span>Likert 7</span>
          </button>
          <button type="button" class="modal-type-btn px-2 py-2 rounded-xl text-[10px] font-medium border-2 border-transparent bg-gray-50 text-gray-600 hover:bg-gray-100 transition-all flex flex-col items-center gap-1" data-type="slider" onclick="selectModalType('slider', this)">
            <i class="fas fa-sliders text-sm"></i><span>Slider</span>
          </button>
          <button type="button" class="modal-type-btn px-2 py-2 rounded-xl text-[10px] font-medium border-2 border-transparent bg-gray-50 text-gray-600 hover:bg-gray-100 transition-all flex flex-col items-center gap-1" data-type="matrix" onclick="selectModalType('matrix', this)">
            <i class="fas fa-table text-sm"></i><span>Matrix</span>
          </button>
          <button type="button" class="modal-type-btn px-2 py-2 rounded-xl text-[10px] font-medium border-2 border-transparent bg-gray-50 text-gray-600 hover:bg-gray-100 transition-all flex flex-col items-center gap-1" data-type="file_upload" onclick="selectModalType('file_upload', this)">
            <i class="fas fa-upload text-sm"></i><span>Upload</span>
          </button>
          <button type="button" class="modal-type-btn px-2 py-2 rounded-xl text-[10px] font-medium border-2 border-transparent bg-gray-50 text-gray-600 hover:bg-gray-100 transition-all flex flex-col items-center gap-1" data-type="textarea" onclick="selectModalType('textarea', this)">
            <i class="fas fa-paragraph text-sm"></i><span>Long Text</span>
          </button>
          <button type="button" class="modal-type-btn px-2 py-2 rounded-xl text-[10px] font-medium border-2 border-transparent bg-gray-50 text-gray-600 hover:bg-gray-100 transition-all flex flex-col items-center gap-1" data-type="url" onclick="selectModalType('url', this)">
            <i class="fas fa-link text-sm"></i><span>URL</span>
          </button>
          <button type="button" class="modal-type-btn px-2 py-2 rounded-xl text-[10px] font-medium border-2 border-transparent bg-gray-50 text-gray-600 hover:bg-gray-100 transition-all flex flex-col items-center gap-1" data-type="nps" onclick="selectModalType('nps', this)">
            <i class="fas fa-chart-bar text-sm"></i><span>NPS 0-10</span>
          </button>
          <button type="button" class="modal-type-btn px-2 py-2 rounded-xl text-[10px] font-medium border-2 border-transparent bg-gray-50 text-gray-600 hover:bg-gray-100 transition-all flex flex-col items-center gap-1" data-type="ranking" onclick="selectModalType('ranking', this)">
            <i class="fas fa-list-ol text-sm"></i><span>Ranking</span>
          </button>
          <button type="button" class="modal-type-btn px-2 py-2 rounded-xl text-[10px] font-medium border-2 border-transparent bg-gray-50 text-gray-600 hover:bg-gray-100 transition-all flex flex-col items-center gap-1" data-type="multi_text" onclick="selectModalType('multi_text', this)">
            <i class="fas fa-list text-sm"></i><span>Multi Text</span>
          </button>
          <button type="button" class="modal-type-btn px-2 py-2 rounded-xl text-[10px] font-medium border-2 border-transparent bg-gray-50 text-gray-600 hover:bg-gray-100 transition-all flex flex-col items-center gap-1" data-type="address" onclick="selectModalType('address', this)">
            <i class="fas fa-map-marker-alt text-sm"></i><span>Address</span>
          </button>
          <button type="button" class="modal-type-btn px-2 py-2 rounded-xl text-[10px] font-medium border-2 border-transparent bg-gray-50 text-gray-600 hover:bg-gray-100 transition-all flex flex-col items-center gap-1" data-type="time" onclick="selectModalType('time', this)">
            <i class="fas fa-clock text-sm"></i><span>Time</span>
          </button>
          <button type="button" class="modal-type-btn px-2 py-2 rounded-xl text-[10px] font-medium border-2 border-transparent bg-gray-50 text-gray-600 hover:bg-gray-100 transition-all flex flex-col items-center gap-1" data-type="datetime" onclick="selectModalType('datetime', this)">
            <i class="fas fa-calendar-alt text-sm"></i><span>Date/Time</span>
          </button>
          <button type="button" class="modal-type-btn px-2 py-2 rounded-xl text-[10px] font-medium border-2 border-transparent bg-gray-50 text-gray-600 hover:bg-gray-100 transition-all flex flex-col items-center gap-1" data-type="color" onclick="selectModalType('color', this)">
            <i class="fas fa-palette text-sm"></i><span>Color</span>
          </button>
          <button type="button" class="modal-type-btn px-2 py-2 rounded-xl text-[10px] font-medium border-2 border-transparent bg-gray-50 text-gray-600 hover:bg-gray-100 transition-all flex flex-col items-center gap-1" data-type="percentage" onclick="selectModalType('percentage', this)">
            <i class="fas fa-percent text-sm"></i><span>Percentage</span>
          </button>
          <button type="button" class="modal-type-btn px-2 py-2 rounded-xl text-[10px] font-medium border-2 border-transparent bg-gray-50 text-gray-600 hover:bg-gray-100 transition-all flex flex-col items-center gap-1" data-type="signature" onclick="selectModalType('signature', this)">
            <i class="fas fa-pen-fancy text-sm"></i><span>Signature</span>
          </button>
        </div>
        <select id="modal-type" class="hidden" onchange="toggleModalOptions()"></select>
      </div>

      <!-- Question Text -->
      <div class="bg-gray-50/80 rounded-xl p-4 border border-gray-100">
        <label class="block text-xs font-semibold text-gray-700 mb-1.5"><i class="fas fa-pencil text-gray-400 mr-1"></i>Question Text <span class="text-red-400">*</span></label>
        <textarea id="modal-text" rows="2" class="w-full px-3 py-2.5 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-emerald-500 bg-white resize-none" placeholder="Enter your question here..."></textarea>
      </div>

      <!-- Options (conditional) -->
      <div id="modal-options-wrap" class="hidden bg-gray-50/80 rounded-xl p-4 border border-gray-100">
        <div class="flex items-center justify-between mb-1.5">
          <label class="block text-xs font-semibold text-gray-700"><i class="fas fa-list text-gray-400 mr-1"></i>Options</label>
          <button type="button" onclick="addModalOption()" class="text-[11px] px-2 py-1 rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100 hover:border-emerald-300 transition-all flex items-center gap-1 shadow-sm"><i class="fas fa-plus text-[9px]"></i> Add Option</button>
        </div>
        <div id="modal-options-list" class="space-y-1.5 max-h-48 overflow-y-auto pr-0.5"></div>
        <textarea id="modal-options" class="hidden" rows="3"></textarea>
      </div>

      <!-- Matrix rows/cols (conditional) -->
      <div id="modal-matrix-wrap" class="hidden bg-gray-50/80 rounded-xl p-4 border border-gray-100">
        <label class="block text-xs font-semibold text-gray-700 mb-1.5"><i class="fas fa-table text-gray-400 mr-1"></i>Matrix Layout</label>
        <div class="grid grid-cols-2 gap-3">
          <div>
            <label class="block text-[11px] font-medium text-gray-500 mb-1">Rows <span class="text-[10px] text-gray-400">(one per line)</span></label>
            <textarea id="modal-rows" rows="3" class="w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-emerald-500 bg-white" placeholder="Row 1&#10;Row 2"></textarea>
          </div>
          <div>
            <label class="block text-[11px] font-medium text-gray-500 mb-1">Columns <span class="text-[10px] text-gray-400">(one per line)</span></label>
            <textarea id="modal-columns" rows="3" class="w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-emerald-500 bg-white" placeholder="Col 1&#10;Col 2"></textarea>
          </div>
        </div>
      </div>

      <!-- Validation (conditional) -->
      <div id="modal-validation-wrap" class="hidden bg-gray-50/80 rounded-xl p-4 border border-gray-100">
        <label class="block text-xs font-semibold text-gray-700 mb-1.5"><i class="fas fa-sliders text-gray-400 mr-1"></i>Validation</label>
        <div class="grid grid-cols-3 gap-3">
          <div>
            <label class="block text-[11px] font-medium text-gray-500 mb-0.5">Min Value</label>
            <input type="number" id="modal-min-val" class="w-full px-2.5 py-1.5 rounded-lg text-sm border border-gray-200 focus:ring-2 focus:ring-emerald-500 bg-white" step="any">
          </div>
          <div>
            <label class="block text-[11px] font-medium text-gray-500 mb-0.5">Max Value</label>
            <input type="number" id="modal-max-val" class="w-full px-2.5 py-1.5 rounded-lg text-sm border border-gray-200 focus:ring-2 focus:ring-emerald-500 bg-white" step="any">
          </div>
          <div>
            <label class="block text-[11px] font-medium text-gray-500 mb-0.5">Char Limit</label>
            <input type="number" id="modal-char-limit" class="w-full px-2.5 py-1.5 rounded-lg text-sm border border-gray-200 focus:ring-2 focus:ring-emerald-500 bg-white">
          </div>
        </div>
      </div>

      <!-- Animation Picker -->
      <div class="bg-gradient-to-r from-sky-50 to-indigo-50/50 rounded-xl p-4 border border-sky-100">
        <label class="block text-xs font-semibold text-gray-700 mb-2"><i class="fas fa-sparkles text-sky-500 mr-1"></i>Question Animation</label>
        <p class="text-[10px] text-gray-400 mb-2">Choose how this question appears to respondents</p>
        <div class="grid grid-cols-5 gap-1.5" id="modal-anim-grid">
        </div>
        <div id="anim-preview-box" class="mt-2 p-2 bg-white rounded-lg border border-sky-200 text-center text-[10px] text-gray-400 min-h-[40px] flex items-center justify-center overflow-hidden">
          <span id="anim-preview-text">Select an animation to preview</span>
        </div>
      </div>

      <!-- Accent Color Picker -->
      <div class="bg-gradient-to-r from-pink-50 to-rose-50/50 rounded-xl p-4 border border-pink-100">
        <label class="block text-xs font-semibold text-gray-700 mb-2"><i class="fas fa-palette text-pink-500 mr-1"></i>Accent Color</label>
        <p class="text-[10px] text-gray-400 mb-2">Highlight this question with a custom color</p>
        <div class="flex flex-wrap gap-1.5" id="modal-accent-grid">
        </div>
      </div>

      <!-- Customization fields -->
      <div class="bg-white rounded-xl p-4 border border-gray-200">
        <label class="block text-xs font-semibold text-gray-700 mb-2"><i class="fas fa-sliders-h text-gray-400 mr-1"></i>Question Customization</label>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label class="block text-[11px] font-medium text-gray-500 mb-0.5">Placeholder Text</label>
            <input type="text" id="modal-placeholder" class="w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-emerald-500 bg-white" placeholder="e.g. Type your answer here...">
          </div>
          <div>
            <label class="block text-[11px] font-medium text-gray-500 mb-0.5">Hint / Description</label>
            <input type="text" id="modal-hint" class="w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-emerald-500 bg-white" placeholder="e.g. Choose wisely...">
          </div>
        </div>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-3">
          <div>
            <label class="block text-[11px] font-medium text-gray-500 mb-0.5">Image URL (optional)</label>
            <input type="url" id="modal-image-url" class="w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-emerald-500 bg-white" placeholder="https://example.com/image.jpg">
          </div>
          <div class="flex items-end pb-2">
            <label class="flex items-center gap-2 text-xs px-3 py-2 rounded-lg bg-white border border-gray-200 cursor-pointer hover:border-emerald-300 transition-all has-[:checked]:border-emerald-400 has-[:checked]:bg-emerald-50">
              <input type="checkbox" id="modal-shuffle" class="rounded text-emerald-600 focus:ring-emerald-500"> <i class="fas fa-random text-[10px] text-gray-400"></i> Shuffle Options
            </label>
          </div>
        </div>
      </div>

      <!-- Include Other option for MCQ -->
      <div id="modal-other-wrap" class="hidden bg-gray-50/80 rounded-xl p-4 border border-gray-100">
        <label class="flex items-center gap-2 text-xs cursor-pointer">
          <input type="checkbox" id="modal-include-other" class="rounded text-emerald-600 focus:ring-emerald-500"> <i class="fas fa-pen text-[10px] text-gray-400"></i> Include "Other" option with custom text input
        </label>
      </div>

      <!-- Flags / Options -->
      <div class="bg-gray-50/80 rounded-xl p-4 border border-gray-100">
        <label class="block text-xs font-semibold text-gray-700 mb-2"><i class="fas fa-flag text-gray-400 mr-1"></i>Question Options</label>
        <div id="modal-flags" class="flex flex-wrap gap-2">
          <label class="flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-lg bg-white border border-gray-200 cursor-pointer hover:border-emerald-300 hover:bg-emerald-50/30 transition-all has-[:checked]:border-emerald-400 has-[:checked]:bg-emerald-50 has-[:checked]:text-emerald-700">
            <input type="checkbox" id="modal-required" checked class="rounded text-emerald-600 focus:ring-emerald-500"> <i class="fas fa-asterisk text-[9px] text-gray-400"></i> Required
          </label>
          <label class="flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-lg bg-white border border-gray-200 cursor-pointer hover:border-amber-300 hover:bg-amber-50/30 transition-all has-[:checked]:border-amber-400 has-[:checked]:bg-amber-50 has-[:checked]:text-amber-700">
            <input type="checkbox" id="modal-attention" class="rounded text-amber-600 focus:ring-amber-500"> <i class="fas fa-brain text-[9px] text-gray-400"></i> Attention
          </label>
          <label class="flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-lg bg-white border border-gray-200 cursor-pointer hover:border-red-300 hover:bg-red-50/30 transition-all has-[:checked]:border-red-400 has-[:checked]:bg-red-50 has-[:checked]:text-red-700">
            <input type="checkbox" id="modal-trap" class="rounded text-red-600 focus:ring-red-500"> <i class="fas fa-skull text-[9px] text-gray-400"></i> Trap
          </label>
          <label class="flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-lg bg-white border border-gray-200 cursor-pointer hover:border-orange-300 hover:bg-orange-50/30 transition-all has-[:checked]:border-orange-400 has-[:checked]:bg-orange-50 has-[:checked]:text-orange-700">
            <input type="checkbox" id="modal-speed" class="rounded text-orange-600 focus:ring-orange-500"> <i class="fas fa-gauge-high text-[9px] text-gray-400"></i> Speed
          </label>
          <label class="flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-lg bg-white border border-gray-200 cursor-pointer hover:border-purple-300 hover:bg-purple-50/30 transition-all has-[:checked]:border-purple-400 has-[:checked]:bg-purple-50 has-[:checked]:text-purple-700">
            <input type="checkbox" id="modal-timed" class="rounded text-purple-600 focus:ring-purple-500"> <i class="fas fa-clock text-[9px] text-gray-400"></i> Timed
          </label>
        </div>
        <div id="modal-attention-answer-wrap" class="hidden mt-3">
          <label class="block text-xs font-medium text-gray-600 mb-1"><i class="fas fa-check-double text-amber-500 mr-1"></i>Expected Answer</label>
          <input type="text" id="modal-expected" class="w-full px-3 py-2 rounded-xl text-sm border border-amber-200 focus:ring-2 focus:ring-amber-500 bg-white" placeholder="Correct answer for attention check">
        </div>
        <div id="modal-timed-wrap" class="hidden mt-3">
          <label class="block text-xs font-medium text-gray-600 mb-1"><i class="fas fa-hourglass text-purple-500 mr-1"></i>Time Limit (seconds)</label>
          <input type="number" id="modal-time-limit" value="30" min="1" max="600" class="w-full px-3 py-2 rounded-xl text-sm border border-purple-200 focus:ring-2 focus:ring-purple-500 bg-white">
        </div>
      </div>

      <!-- Live preview within modal -->
      <div class="bg-white rounded-xl border border-gray-200 overflow-hidden shadow-sm">
        <div class="px-3 py-2 bg-gray-50 border-b border-gray-100 text-[10px] font-semibold text-gray-500 flex items-center gap-1.5">
          <i class="fas fa-eye text-gray-400"></i> Question Preview
        </div>
        <div id="modal-preview-body" class="p-3 text-center text-[10px] text-gray-400">
          Fill in the question text to see a preview
        </div>
      </div>

    </div>
    <div class="flex gap-3 p-5 border-t bg-gray-50/80 rounded-b-2xl">
      <button type="button" onclick="saveCustomQuestion()" class="flex-1 bg-gradient-to-r from-emerald-500 to-emerald-600 text-white px-4 py-2.5 rounded-xl hover:from-emerald-600 hover:to-emerald-700 transition-all text-sm font-medium shadow-sm shadow-emerald-200 flex items-center justify-center gap-2"><i class="fas fa-check-circle"></i> Save Question</button>
      <button type="button" onclick="closeModal()" class="px-5 py-2.5 rounded-xl border border-gray-200 text-gray-600 hover:bg-gray-50 transition-all text-sm font-medium flex items-center gap-1.5"><i class="fas fa-times"></i> Cancel</button>
      <span class="hidden sm:inline-flex items-center text-[9px] text-gray-400 self-center"><kbd class="px-1 py-0.5 bg-gray-100 rounded text-[9px] font-mono border border-gray-200 border-b-2">Ctrl</kbd> + <kbd class="px-1 py-0.5 bg-gray-100 rounded text-[9px] font-mono border border-gray-200 border-b-2">Enter</kbd> to save</span>
    </div>
  </div>
</div>

<!-- CHAT NODE EDITOR MODAL -->
<div id="cn-modal" class="fixed inset-0 z-50 hidden flex items-center justify-center p-4" style="background:rgba(0,0,0,0.5);backdrop-filter:blur(4px)">
  <div class="bg-white rounded-2xl shadow-2xl w-full max-w-lg animate-scale-in">
    <div class="flex items-center justify-between p-4 border-b">
      <h3 class="text-sm font-bold text-gray-900 flex items-center gap-2">
        <span class="w-7 h-7 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-white text-xs"><i class="fas fa-comment-dots"></i></span>
        <span id="cn-modal-title">Add Chat Node</span>
      </h3>
      <button type="button" onclick="closeChatNodeModal()" class="w-7 h-7 rounded-lg hover:bg-gray-100 flex items-center justify-center text-gray-400 hover:text-gray-600"><i class="fas fa-times text-sm"></i></button>
    </div>
    <div class="p-4 space-y-4">
      <input type="hidden" id="cn-edit-id" value="">
      <div>
        <label class="block text-xs font-medium text-gray-600 mb-1">Question</label>
        <textarea id="cn-question" rows="2" class="w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-emerald-300 outline-none resize-none" placeholder="Enter your question..."></textarea>
      </div>
      <div class="grid grid-cols-2 gap-3">
        <div>
          <label class="block text-xs font-medium text-gray-600 mb-1">Type</label>
          <select id="cn-type" class="w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-emerald-300 outline-none" onchange="toggleCnOptions()">
            <option value="text">Text</option>
            <option value="number">Number</option>
            <option value="choice">Multiple Choice</option>
            <option value="rating">Rating (1-5)</option>
            <option value="yes_no">Yes/No</option>
          </select>
        </div>
        <div>
          <label class="block text-xs font-medium text-gray-600 mb-1">Follow-up</label>
          <select id="cn-followup" class="w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-emerald-300 outline-none">
            <option value="none">No follow-up</option>
            <option value="shallow">Light probe</option>
            <option value="deep">Deep dive</option>
          </select>
        </div>
      </div>
      <div id="cn-options-wrap" class="hidden">
        <label class="block text-xs font-medium text-gray-600 mb-1">Options <span class="text-gray-300 font-normal">(one per line)</span></label>
        <textarea id="cn-options" rows="3" class="w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-emerald-300 outline-none resize-none" placeholder="Option 1&#10;Option 2&#10;Option 3"></textarea>
      </div>
      <div class="bg-blue-50/50 rounded-xl p-3 border border-blue-100">
        <label class="block text-xs font-medium text-blue-700 mb-2 flex items-center gap-1.5"><i class="fas fa-filter text-blue-500"></i>Answer Scope <span class="font-normal text-blue-400">(optional)</span></label>
        <div class="flex gap-1.5 mb-2.5" id="cn-scope-type-picker">
          <button type="button" data-scope="none" onclick="selectCnScopeType('none',this)" class="cn-scope-btn flex-1 px-2 py-1.5 rounded-lg text-[10px] font-semibold border-2 border-blue-200 bg-white text-blue-500 hover:border-blue-300 transition-all"><i class="fas fa-times mr-0.5"></i>None</button>
          <button type="button" data-scope="absolute" onclick="selectCnScopeType('absolute',this)" class="cn-scope-btn flex-1 px-2 py-1.5 rounded-lg text-[10px] font-semibold border-2 border-gray-200 bg-white text-gray-500 hover:border-blue-300 transition-all"><i class="fas fa-lock mr-0.5"></i>Absolute</button>
          <button type="button" data-scope="set" onclick="selectCnScopeType('set',this)" class="cn-scope-btn flex-1 px-2 py-1.5 rounded-lg text-[10px] font-semibold border-2 border-gray-200 bg-white text-gray-500 hover:border-blue-300 transition-all"><i class="fas fa-layer-group mr-0.5"></i>Set</button>
          <button type="button" data-scope="near" onclick="selectCnScopeType('near',this)" class="cn-scope-btn flex-1 px-2 py-1.5 rounded-lg text-[10px] font-semibold border-2 border-gray-200 bg-white text-gray-500 hover:border-blue-300 transition-all"><i class="fas fa-wave-square mr-0.5"></i>Near</button>
        </div>
        <div id="cn-scope-fields" class="hidden">
          <div id="cn-scope-label-wrap" class="hidden mb-2">
            <label class="block text-[10px] font-medium text-blue-600 mb-0.5">Category Name</label>
            <input type="text" id="cn-scope-label" class="w-full px-2 py-1.5 rounded-lg text-xs border border-blue-200 focus:ring-2 focus:ring-blue-300 outline-none transition-all bg-white" placeholder="e.g. Car Brands, Countries, Emotions...">
          </div>
          <label class="block text-[10px] font-medium text-blue-600 mb-0.5">Accepted Values <span class="font-normal text-blue-400">(one per line)</span></label>
          <textarea id="cn-answer-scope" rows="3" class="w-full px-2 py-1.5 rounded-lg text-xs border border-blue-200 focus:ring-2 focus:ring-blue-300 outline-none resize-none bg-white transition-all" placeholder="Honda&#10;BMW&#10;Toyota"></textarea>
          <p id="cn-scope-hint" class="text-[9px] text-blue-400 mt-1">Only these answers are accepted. Close misspellings require confirmation.</p>
        </div>
      </div>
      <div class="bg-amber-50/50 rounded-xl p-3 border border-amber-100">
        <label class="block text-xs font-medium text-amber-700 mb-2 flex items-center gap-1.5"><i class="fas fa-code-branch text-amber-500"></i>Skip Logic <span class="font-normal text-amber-400">(optional)</span></label>
        <div class="grid grid-cols-3 gap-2">
          <input type="text" id="cn-cond-field" class="px-2 py-1.5 rounded-lg text-xs border border-amber-200 focus:ring-2 focus:ring-amber-300 outline-none" placeholder="Field key">
          <select id="cn-cond-op" class="px-2 py-1.5 rounded-lg text-xs border border-amber-200 focus:ring-2 focus:ring-amber-300 outline-none">
            <option value="equals">equals</option>
            <option value="contains">contains</option>
            <option value="not_contains">not contains</option>
          </select>
          <input type="text" id="cn-cond-val" class="px-2 py-1.5 rounded-lg text-xs border border-amber-200 focus:ring-2 focus:ring-amber-300 outline-none" placeholder="Value">
        </div>
      </div>
    </div>
    <div class="flex gap-3 p-4 border-t bg-gray-50/80 rounded-b-2xl">
      <button type="button" onclick="saveChatNode()" class="flex-1 bg-gradient-to-r from-emerald-500 to-teal-500 text-white px-4 py-2.5 rounded-xl hover:from-emerald-600 hover:to-teal-600 transition-all text-sm font-medium shadow-sm shadow-emerald-200 flex items-center justify-center gap-2"><i class="fas fa-check-circle"></i> Save Node</button>
      <button type="button" onclick="closeChatNodeModal()" class="px-5 py-2.5 rounded-xl border border-gray-200 text-gray-600 hover:bg-gray-50 transition-all text-sm font-medium"><i class="fas fa-times"></i> Cancel</button>
    </div>
  </div>
</div>

<!-- KEYBOARD SHORTCUTS HELP -->
<div id="kb-help" class="fixed inset-0 z-50 hidden flex items-center justify-center p-4" style="background:rgba(0,0,0,0.5);backdrop-filter:blur(4px)" onclick="if(event.target===this)toggleKbHelp()">
  <div class="bg-white rounded-2xl shadow-2xl w-full max-w-sm p-6 animate-scale-in" onclick="event.stopPropagation()">
    <div class="flex items-center justify-between mb-4">
      <h3 class="text-base font-bold text-gray-900"><i class="fas fa-keyboard text-indigo-500 mr-2"></i>Keyboard Shortcuts</h3>
      <button type="button" onclick="toggleKbHelp()" class="w-8 h-8 rounded-lg hover:bg-gray-100 flex items-center justify-center text-gray-400"><i class="fas fa-times"></i></button>
    </div>
    <div class="space-y-2 text-sm">
      <div class="flex justify-between"><kbd class="px-2 py-0.5 bg-gray-100 rounded text-xs font-mono">Q</kbd><span class="text-gray-600">Quick-add Text question</span></div>
      <div class="flex justify-between"><kbd class="px-2 py-0.5 bg-gray-100 rounded text-xs font-mono">Shift+Q</kbd><span class="text-gray-600">Open Custom question modal</span></div>
      <div class="flex justify-between"><kbd class="px-2 py-0.5 bg-gray-100 rounded text-xs font-mono">Ctrl+Z</kbd><span class="text-gray-600">Undo last action</span></div>
      <div class="flex justify-between"><kbd class="px-2 py-0.5 bg-gray-100 rounded text-xs font-mono">Ctrl+Shift+Z</kbd><span class="text-gray-600">Redo</span></div>
      <div class="flex justify-between"><kbd class="px-2 py-0.5 bg-gray-100 rounded text-xs font-mono">E</kbd><span class="text-gray-600">Edit selected question</span></div>
      <div class="flex justify-between"><kbd class="px-2 py-0.5 bg-gray-100 rounded text-xs font-mono">D</kbd><span class="text-gray-600">Duplicate selected</span></div>
      <div class="flex justify-between"><kbd class="px-2 py-0.5 bg-gray-100 rounded text-xs font-mono">Delete</kbd><span class="text-gray-600">Remove selected</span></div>
      <div class="flex justify-between"><kbd class="px-2 py-0.5 bg-gray-100 rounded text-xs font-mono">/</kbd><span class="text-gray-600">Focus question search</span></div>
      <div class="flex justify-between"><kbd class="px-2 py-0.5 bg-gray-100 rounded text-xs font-mono">Ctrl+S</kbd><span class="text-gray-600">Save survey</span></div>
      <div class="flex justify-between"><kbd class="px-2 py-0.5 bg-gray-100 rounded text-xs font-mono">?</kbd><span class="text-gray-600">Toggle this help</span></div>
    </div>
  </div>
</div>

<!-- DELETE CONFIRM MODAL -->
<div id="del-modal" class="fixed inset-0 z-50 hidden flex items-center justify-center p-4" style="background:rgba(0,0,0,0.5);backdrop-filter:blur(4px)">
  <div class="bg-white rounded-2xl shadow-2xl w-full max-w-sm p-6 animate-scale-in">
    <div class="text-center">
      <div class="w-14 h-14 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-3"><i class="fas fa-exclamation-triangle text-red-500 text-xl"></i></div>
      <h3 class="text-lg font-bold text-gray-900 mb-1">Delete Survey?</h3>
      <p class="text-sm text-gray-500 mb-5">This action cannot be undone. All questions and responses will be permanently deleted.</p>
      <div class="flex gap-3">
        <button type="button" onclick="closeDelModal()" class="flex-1 px-4 py-2.5 rounded-xl border border-gray-200 text-gray-600 hover:bg-gray-50 transition-all text-sm">Cancel</button>
        <form method="POST" action="<?= url(
            "/survey/delete/" . ($survey["id"] ?? ""),
        ) ?>" class="flex-1">
          <?= csrf() ?>
          <button type="submit" class="w-full px-4 py-2.5 rounded-xl bg-red-600 text-white hover:bg-red-700 transition-all text-sm font-medium"><i class="fas fa-trash mr-1.5"></i>Delete</button>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Share Survey Modal -->
<?php if (!empty($shareUrl) && !empty($showShareModal)): ?>
<div id="share-modal" class="fixed inset-0 z-50 flex items-center justify-center p-4" style="background:rgba(0,0,0,0.5);backdrop-filter:blur(4px)" onclick="if(event.target===this)closeShareModal()">
  <div class="bg-white rounded-2xl shadow-2xl w-full max-w-md animate-scale-in overflow-hidden">
    <div class="bg-gradient-to-r from-emerald-500 to-emerald-600 px-6 py-5 text-white text-center">
      <div class="w-14 h-14 mx-auto bg-white/20 rounded-full flex items-center justify-center mb-2">
        <i class="fas fa-check text-2xl"></i>
      </div>
      <h3 class="text-lg font-bold"><?= isset($_GET["published"])
          ? "Survey Published!"
          : "Survey Created!" ?></h3>
      <p class="text-sm text-white/80 mt-0.5">Your survey is ready to share with respondents</p>
    </div>
    <div class="p-6">
      <div class="text-center mb-5">
        <label class="block text-xs font-medium text-gray-500 mb-2">Shareable Link</label>
        <div class="flex items-center gap-2">
          <input type="text" id="share-url-input" value="<?= htmlspecialchars(
              $shareUrl,
          ) ?>" readonly class="flex-1 px-3 py-2.5 rounded-xl text-sm font-medium text-emerald-700 bg-emerald-50 border border-emerald-200 focus:outline-none select-all">
          <button type="button" onclick="copyShareUrl()" id="copy-url-btn" class="px-3 py-2.5 rounded-xl bg-emerald-600 text-white hover:bg-emerald-700 transition-all text-sm flex items-center gap-1.5"><i class="fas fa-copy"></i></button>
        </div>
      </div>
      <div class="text-center mb-5">
        <label class="block text-xs font-medium text-gray-500 mb-2">QR Code</label>
        <div class="inline-block p-3 bg-white rounded-xl border border-gray-100 shadow-sm">
          <img src="https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=<?= urlencode(
              $shareUrl,
          ) ?>" alt="QR Code" class="mx-auto w-44 h-44" style="image-rendering:pixelated">
        </div>
        <p class="text-[10px] text-gray-400 mt-1">Scan to open survey on mobile</p>
      </div>
      <div class="flex gap-2">
        <button type="button" onclick="closeShareModal()" class="flex-1 px-4 py-2.5 rounded-xl border border-gray-200 text-gray-600 hover:bg-gray-50 transition-all text-sm font-medium">Close</button>
        <button type="button" onclick="copyShareUrl();closeShareModal()" class="flex-1 px-4 py-2.5 rounded-xl bg-emerald-600 text-white hover:bg-emerald-700 transition-all text-sm font-medium flex items-center justify-center gap-1.5"><i class="fas fa-link"></i> Copy Link</button>
      </div>
    </div>
  </div>
</div>
<?php endif; ?>

<!-- Bulk Import Modal -->
<div id="bulk-modal" class="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 hidden items-center justify-center p-4" onclick="if(event.target===this)closeBulkImport()">
  <div class="bg-white rounded-2xl shadow-2xl max-w-lg w-full animate-scale-in max-h-[90vh] overflow-y-auto" onclick="event.stopPropagation()">
    <div class="flex items-center justify-between p-5 border-b border-gray-100">
      <h3 class="text-base font-bold text-gray-900 flex items-center gap-2">
        <span class="w-8 h-8 rounded-xl bg-gradient-to-br from-lime-400 to-emerald-500 flex items-center justify-center text-white text-sm shadow-sm"><i class="fas fa-list"></i></span>
        Bulk Import Questions
      </h3>
      <button type="button" onclick="closeBulkImport()" class="w-8 h-8 rounded-lg hover:bg-gray-100 flex items-center justify-center text-gray-400 hover:text-gray-600 transition-all"><i class="fas fa-times"></i></button>
    </div>
    <div class="p-5 space-y-4">
      <div>
        <label class="block text-xs font-semibold text-gray-700 mb-1.5"><i class="fas fa-info-circle text-gray-400 mr-1"></i>Format</label>
        <p class="text-[11px] text-gray-400 bg-gray-50 rounded-lg p-2.5 border border-gray-100 leading-relaxed">
          One question per block, separated by blank lines.<br>
          <strong>Format:</strong> <code class="text-emerald-600">Type: Question text</code> followed by options (one per line).<br>
          <strong>Example:</strong><br>
          <code class="text-xs text-gray-600">text: What is your name?<br><br>mcq_single: Favorite color?<br>Red<br>Blue<br>Green<br><br>rating: Rate our service<br>1<br>2<br>3<br>4<br>5</code>
        </p>
      </div>
      <textarea id="bulk-text" rows="8" class="w-full px-4 py-3 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-emerald-500 bg-white font-mono" placeholder="text: What is your name?&#10;&#10;mcq_single: Favorite color?&#10;Red&#10;Blue&#10;Green&#10;&#10;rating: Rate our service"></textarea>
      <div class="flex items-center gap-2 text-xs text-gray-400">
        <i class="fas fa-lightbulb text-amber-400"></i>
        Supported types: text, number, email, phone, textarea, url, yes_no, rating, mcq_single, mcq_multiple, dropdown, nps, ranking, date, time, datetime, color, percentage, signature, slider
      </div>
    </div>
    <div class="flex items-center justify-end gap-2 p-5 border-t border-gray-100 bg-gray-50/50 rounded-b-2xl">
      <button type="button" onclick="closeBulkImport()" class="px-4 py-2 text-sm font-medium text-gray-600 hover:text-gray-800 transition-all">Cancel</button>
      <button type="button" onclick="importBulkQuestions()" class="px-6 py-2.5 text-sm font-medium bg-gradient-to-r from-lime-500 to-emerald-600 text-white rounded-xl hover:from-lime-600 hover:to-emerald-700 transition-all shadow-sm flex items-center gap-1.5"><i class="fas fa-upload"></i> Import Questions</button>
    </div>
  </div>
</div>

<style>
.q-item { animation: qSlideIn 0.35s cubic-bezier(0.4,0,0.2,1) forwards; }
@keyframes qSlideIn { from { opacity:0; transform:translateX(-16px) scale(0.96); } to { opacity:1; transform:translateX(0) scale(1); } }
.q-item-remove { animation: qSlideOut 0.25s ease-in forwards; }
@keyframes qSlideOut { to { opacity:0; transform:translateX(20px) scale(0.94); } }
/* Thin custom scrollbar */
.scrollbar-thin::-webkit-scrollbar { height:4px; }
.scrollbar-thin::-webkit-scrollbar-track { background:transparent; }
.scrollbar-thin::-webkit-scrollbar-thumb { background:#d1d5db; border-radius:99px; }
.scrollbar-thin::-webkit-scrollbar-thumb:hover { background:#9ca3af; }
.scrollbar-thin { scrollbar-width:thin; scrollbar-color:#d1d5db transparent; }

.qx-btn { position:relative; overflow:hidden; }
.qx-btn::after { content:''; position:absolute; inset:0; background:currentColor; opacity:0; transition:opacity 0.2s; }
.qx-btn:hover::after { opacity:0.06; }
.grabbable { cursor:grab; }
.grabbable:active { cursor:grabbing; }
.animate-scale-in { animation:scaleIn 0.2s cubic-bezier(0.4,0,0.2,1) forwards; }
@keyframes scaleIn { from { opacity:0; transform:scale(0.92) translateY(8px); } to { opacity:1; transform:scale(1) translateY(0); } }
#preview-phone * { transition:background-color 0.4s, color 0.3s, border-color 0.3s; }
.theme-btn, .bg-btn { transition:all 0.2s; }
#q-modal { animation:modalFadeIn 0.2s ease-out; }
@keyframes modalFadeIn { from { opacity:0; } to { opacity:1; } }
#eb-settings, #eb-vis-body, #eb-access-body, #eb-qc, #eb-branding { overflow:hidden; transition:max-height 0.35s ease; }
kbd { border:1px solid #e5e7eb; border-bottom-width:2px; }
#q-bank.open { transform:translateX(0); }
/* Animation classes for per-question animations */
.qa-fade { animation:qaFade 0.5s ease-out; }
@keyframes qaFade { from { opacity:0; } to { opacity:1; } }
.qa-slide-up { animation:qaSlideUp 0.5s ease-out; }
@keyframes qaSlideUp { from { opacity:0; transform:translateY(20px); } to { opacity:1; transform:translateY(0); } }
.qa-slide-left { animation:qaSlideLeft 0.5s ease-out; }
@keyframes qaSlideLeft { from { opacity:0; transform:translateX(30px); } to { opacity:1; transform:translateX(0); } }
.qa-scale { animation:qaScale 0.4s ease-out; }
@keyframes qaScale { from { opacity:0; transform:scale(0.8); } to { opacity:1; transform:scale(1); } }
.qa-bounce { animation:qaBounce 0.6s ease-out; }
@keyframes qaBounce { 0% { opacity:0; transform:scale(0.3); } 50% { transform:scale(1.08); } 70% { transform:scale(0.95); } 100% { opacity:1; transform:scale(1); } }
.qa-flip { animation:qaFlip 0.6s ease-out; perspective:600px; }
@keyframes qaFlip { from { opacity:0; transform:rotateX(-90deg); } to { opacity:1; transform:rotateX(0); } }
.qa-blur { animation:qaBlur 0.5s ease-out; }
@keyframes qaBlur { from { opacity:0; filter:blur(8px); } to { opacity:1; filter:blur(0); } }
.qa-drop { animation:qaDrop 0.5s ease-out; }
@keyframes qaDrop { 0% { opacity:0; transform:translateY(-40px) scaleY(0.6); } 60% { transform:translateY(5px) scaleY(1.05); } 100% { opacity:1; transform:translateY(0) scaleY(1); } }
.qa-glow { animation:qaGlow 0.7s ease-out; }
@keyframes qaGlow { 0% { opacity:0; box-shadow:0 0 0 0 rgba(99,102,241,0); } 50% { opacity:0.7; box-shadow:0 0 20px 4px rgba(99,102,241,0.3); } 100% { opacity:1; box-shadow:0 0 0 0 rgba(99,102,241,0); } }
#anim-preview-box .qa-scale,
#anim-preview-box .qa-bounce,
#anim-preview-box .qa-flip,
#anim-preview-box .qa-blur,
#anim-preview-box .qa-drop,
#anim-preview-box .qa-glow { animation-duration:0.4s; animation-iteration-count:1; }

</style>

<script>
// ============================================================
// EXISTING QUESTIONS — loaded from server
// ============================================================
let questions = [];
let qIdCounter = 0;
let undoStack = [];
let redoStack = [];
const MAX_UNDO = 30;
let selectedQIndex = -1;
let formDirty = false;

try {
  const existing = <?= $questionsJson ?? "[]" ?>;
  if (Array.isArray(existing) && existing.length > 0) {
    existing.forEach(q => {
      q.id = ++qIdCounter;
      q.question_text = q.question_text || '';
      q.is_required = !!q.is_required;
      q.is_attention_check = !!q.is_attention_check;
      q.expected_answer = q.expected_answer || null;
      q.is_trap = !!q.is_trap;
      q.is_speed_bump = !!q.is_speed_bump;
      q.is_timed = !!q.is_timed;
      q.time_limit_seconds = q.time_limit_seconds || null;
      q.min_value = q.min_value || null;
      q.max_value = q.max_value || null;
      q.char_limit = q.char_limit || null;
      q.min_length = q.min_length || null;
      q.max_length = q.max_length || null;
      q.allow_paste = q.allow_paste === '1' || q.allow_paste === 1 || q.allow_paste === true;
      q.animation = q.animation || null;
      q.accent_color = q.accent_color || null;
      q.placeholder = q.placeholder || null;
      q.hint = q.hint || null;
      q.image_url = q.image_url || null;
      q.shuffle_options = q.shuffle_options === '1' || q.shuffle_options === 1 || q.shuffle_options === true;
      q.include_other = q.include_other === '1' || q.include_other === 1 || q.include_other === true;
      if (q.options_json) { try { q.options = JSON.parse(q.options_json); } catch(e) { q.options = null; } }
      if (q.rows_json) { try { q.rows = JSON.parse(q.rows_json); } catch(e) { q.rows = null; } }
      delete q.options_json;
      delete q.rows_json;
      delete q.survey_id;
      delete q.created_at;
      questions.push(q);
    });
  }
} catch(e) { console.warn('Failed to load questions', e); }

const qTypeLabels = { text:'Text', number:'Number', email:'Email', phone:'Phone', date:'Date', yes_no:'Yes/No', rating:'Rating', mcq_single:'MC Single', mcq_multiple:'MC Multi', dropdown:'Dropdown', likert5:'Likert 5', likert7:'Likert 7', slider:'Slider', matrix:'Matrix', file_upload:'File Upload', textarea:'Long Text', url:'URL', nps:'NPS 0-10', ranking:'Ranking', multi_text:'Multi Text', address:'Address', time:'Time', datetime:'Date/Time', color:'Color', percentage:'Percentage', signature:'Signature' };
const qTypeColors = { text:'bg-emerald-50 text-emerald-700 border-emerald-200', number:'bg-blue-50 text-blue-700 border-blue-200', email:'bg-cyan-50 text-cyan-700 border-cyan-200', phone:'bg-teal-50 text-teal-700 border-teal-200', date:'bg-rose-50 text-rose-700 border-rose-200', yes_no:'bg-blue-50 text-blue-700 border-blue-200', rating:'bg-amber-50 text-amber-700 border-amber-200', mcq_single:'bg-purple-50 text-purple-700 border-purple-200', mcq_multiple:'bg-fuchsia-50 text-fuchsia-700 border-fuchsia-200', dropdown:'bg-orange-50 text-orange-700 border-orange-200', likert5:'bg-violet-50 text-violet-700 border-violet-200', likert7:'bg-violet-50 text-violet-700 border-violet-200', slider:'bg-pink-50 text-pink-700 border-pink-200', matrix:'bg-gray-50 text-gray-700 border-gray-200', file_upload:'bg-sky-50 text-sky-700 border-sky-200', textarea:'bg-stone-50 text-stone-700 border-stone-200', url:'bg-sky-50 text-sky-700 border-sky-200', nps:'bg-red-50 text-red-700 border-red-200', ranking:'bg-amber-50 text-amber-700 border-amber-200', multi_text:'bg-lime-50 text-lime-700 border-lime-200', address:'bg-yellow-50 text-yellow-700 border-yellow-200', time:'bg-rose-50 text-rose-700 border-rose-200', datetime:'bg-fuchsia-50 text-fuchsia-700 border-fuchsia-200', color:'bg-pink-50 text-pink-700 border-pink-200', percentage:'bg-cyan-50 text-cyan-700 border-cyan-200', signature:'bg-indigo-50 text-indigo-700 border-indigo-200' };
const qTypeIcons = { text:'fa-font', number:'fa-hashtag', email:'fa-at', phone:'fa-phone', date:'fa-calendar', yes_no:'fa-check-circle', rating:'fa-star', mcq_single:'fa-circle-dot', mcq_multiple:'fa-list-check', dropdown:'fa-chevron-down', likert5:'fa-grip-lines', likert7:'fa-grip-lines', slider:'fa-sliders', matrix:'fa-table', file_upload:'fa-upload', textarea:'fa-paragraph', url:'fa-link', nps:'fa-chart-bar', ranking:'fa-list-ol', multi_text:'fa-list', address:'fa-map-marker-alt', time:'fa-clock', datetime:'fa-calendar-alt', color:'fa-palette', percentage:'fa-percent', signature:'fa-pen-fancy' };
const qTypeHexColors = { text:'#10b981', number:'#3b82f6', email:'#06b6d4', phone:'#14b8a6', date:'#f43f5e', yes_no:'#3b82f6', rating:'#f59e0b', mcq_single:'#a855f7', mcq_multiple:'#d946ef', dropdown:'#f97316', likert5:'#8b5cf6', likert7:'#8b5cf6', slider:'#ec4899', matrix:'#6b7280', file_upload:'#0ea5e9', textarea:'#78716c', url:'#0ea5e9', nps:'#ef4444', ranking:'#f59e0b', multi_text:'#84cc16', address:'#eab308', time:'#f43f5e', datetime:'#d946ef', color:'#ec4899', percentage:'#06b6d4', signature:'#6366f1' };
const questionAnimations = [
  { value:'none', label:'None', icon:'fa-ban', desc:'No animation', cls:'' },
  { value:'fade', label:'Fade In', icon:'fa-wind', desc:'Smooth fade from nothing', cls:'qa-fade' },
  { value:'slide-up', label:'Slide Up', icon:'fa-arrow-up', desc:'Slides upward into view', cls:'qa-slide-up' },
  { value:'slide-left', label:'Slide Left', icon:'fa-arrow-left', desc:'Slides in from the right', cls:'qa-slide-left' },
  { value:'scale', label:'Scale In', icon:'fa-expand', desc:'Grows from small to full', cls:'qa-scale' },
  { value:'bounce', label:'Bounce', icon:'fa-basketball', desc:'Bouncy entrance', cls:'qa-bounce' },
  { value:'flip', label:'Flip', icon:'fa-rotate', desc:'3D flip from behind', cls:'qa-flip' },
  { value:'blur', label:'Blur In', icon:'fa-eye-slash', desc:'Sharpens from blur', cls:'qa-blur' },
  { value:'drop', label:'Drop In', icon:'fa-cloud-arrow-down', desc:'Drops from above', cls:'qa-drop' },
  { value:'glow', label:'Glow', icon:'fa-sun', desc:'Glowing fade-in', cls:'qa-glow' },
  { value:'shake', label:'Shake', icon:'fa-circle-notch', desc:'Side-to-side shake', cls:'qa-shake' },
  { value:'pulse', label:'Pulse', icon:'fa-heart', desc:'Pulsing heartbeat effect', cls:'qa-pulse' },
  { value:'swing', label:'Swing', icon:'fa-child', desc:'Swinging pendulum motion', cls:'qa-swing' },
  { value:'wobble', label:'Wobble', icon:'fa-skull', desc:'Wobbly gelatin entrance', cls:'qa-wobble' },
  { value:'zoom', label:'Zoom In', icon:'fa-search-plus', desc:'Zooms from distance', cls:'qa-zoom' },
  { value:'roll', label:'Roll In', icon:'fa-rotate-right', desc:'Rolls in from the side', cls:'qa-roll' },
  { value:'jello', label:'Jello', icon:'fa-hand-peace', desc:'Jiggly gelatin wobble', cls:'qa-jello' },
  { value:'heart-beat', label:'Heart Beat', icon:'fa-heartbeat', desc:'Cardiac pulse effect', cls:'qa-heart-beat' },
  { value:'back-in-down', label:'Back In Down', icon:'fa-arrow-down', desc:'Slides in then settles', cls:'qa-back-in-down' },
  { value:'back-in-up', label:'Back In Up', icon:'fa-arrow-up', desc:'Rises up then settles', cls:'qa-back-in-up' },
  { value:'back-in-left', label:'Back In Left', icon:'fa-arrow-left', desc:'Slides from left then settles', cls:'qa-back-in-left' },
  { value:'back-in-right', label:'Back In Right', icon:'fa-arrow-right', desc:'Slides from right then settles', cls:'qa-back-in-right' },
  { value:'bounce-in-down', label:'Bounce Down', icon:'fa-chevron-down', desc:'Bounces in from top', cls:'qa-bounce-in-down' },
  { value:'bounce-in-left', label:'Bounce Left', icon:'fa-chevron-left', desc:'Bounces in from left', cls:'qa-bounce-in-left' },
  { value:'bounce-in-right', label:'Bounce Right', icon:'fa-chevron-right', desc:'Bounces in from right', cls:'qa-bounce-in-right' },
  { value:'bounce-in-up', label:'Bounce Up', icon:'fa-chevron-up', desc:'Bounces in from bottom', cls:'qa-bounce-in-up' },
  { value:'fade-in-down', label:'Fade Down', icon:'fa-arrow-down', desc:'Fades in from top', cls:'qa-fade-in-down' },
  { value:'fade-in-left', label:'Fade Left', icon:'fa-arrow-left', desc:'Fades in from left', cls:'qa-fade-in-left' },
  { value:'fade-in-right', label:'Fade Right', icon:'fa-arrow-right', desc:'Fades in from right', cls:'qa-fade-in-right' },
  { value:'fade-in-up', label:'Fade Up', icon:'fa-arrow-up', desc:'Fades in from bottom', cls:'qa-fade-in-up' },
  { value:'flip-in-x', label:'Flip X', icon:'fa-rotate', desc:'Flips horizontally', cls:'qa-flip-in-x' },
  { value:'flip-in-y', label:'Flip Y', icon:'fa-rotate', desc:'Flips vertically', cls:'qa-flip-in-y' },
  { value:'light-speed', label:'Light Speed', icon:'fa-bolt', desc:'Fast light-speed entrance', cls:'qa-light-speed' },
  { value:'rotate-in', label:'Rotate In', icon:'fa-sync', desc:'Rotates into view', cls:'qa-rotate-in' },
  { value:'rotate-in-dl', label:'Rotate DL', icon:'fa-undo', desc:'Rotates in from down-left', cls:'qa-rotate-in-dl' },
  { value:'rotate-in-dr', label:'Rotate DR', icon:'fa-redo', desc:'Rotates in from down-right', cls:'qa-rotate-in-dr' },
  { value:'rotate-in-ul', label:'Rotate UL', icon:'fa-undo-alt', desc:'Rotates in from up-left', cls:'qa-rotate-in-ul' },
  { value:'rotate-in-ur', label:'Rotate UR', icon:'fa-redo-alt', desc:'Rotates in from up-right', cls:'qa-rotate-in-ur' },
  { value:'slide-in-down', label:'Slide Down', icon:'fa-arrow-down', desc:'Slides down from top', cls:'qa-slide-in-down' },
  { value:'slide-in-left', label:'Slide Left', icon:'fa-arrow-left', desc:'Slides in from left', cls:'qa-slide-in-left' },
  { value:'zoom-in-down', label:'Zoom Down', icon:'fa-search-plus', desc:'Zooms in from top', cls:'qa-zoom-in-down' },
  { value:'zoom-in-left', label:'Zoom Left', icon:'fa-search-plus', desc:'Zooms in from left', cls:'qa-zoom-in-left' },
  { value:'zoom-in-right', label:'Zoom Right', icon:'fa-search-plus', desc:'Zooms in from right', cls:'qa-zoom-in-right' },
  { value:'zoom-in-up', label:'Zoom Up', icon:'fa-search-plus', desc:'Zooms in from bottom', cls:'qa-zoom-in-up' },
];
const accentColors = [
  { value:'', label:'Auto (by type)', hex:'#6366f1' },
  { value:'#6366f1', label:'Indigo', hex:'#6366f1' },
  { value:'#10b981', label:'Emerald', hex:'#10b981' },
  { value:'#f59e0b', label:'Amber', hex:'#f59e0b' },
  { value:'#f43f5e', label:'Rose', hex:'#f43f5e' },
  { value:'#06b6d4', label:'Cyan', hex:'#06b6d4' },
  { value:'#8b5cf6', label:'Violet', hex:'#8b5cf6' },
  { value:'#3b82f6', label:'Blue', hex:'#3b82f6' },
  { value:'#ec4899', label:'Pink', hex:'#ec4899' },
  { value:'#f97316', label:'Orange', hex:'#f97316' },
  { value:'#14b8a6', label:'Teal', hex:'#14b8a6' },
  { value:'#ef4444', label:'Red', hex:'#ef4444' },
];

// Animation and accent state for the modal
let selectedModalAnimation = 'none';
let selectedModalAccent = '';

// ============================================================
// QUESTION BANK
// ============================================================
const questionBank = [
  { text:'How satisfied are you with our service?', type:'rating', options:['1','2','3','4','5'] },
  { text:'What is your email address?', type:'email' },
  { text:'Do you have any additional comments?', type:'text' },
  { text:'How likely are you to recommend us? (0-10)', type:'rating', options:['0','1','2','3','4','5','6','7','8','9','10'] },
  { text:'What is your age?', type:'number' },
  { text:'Gender', type:'mcq_single', options:['Male','Female','Non-binary','Prefer not to say'] },
  { text:'Which department do you work in?', type:'dropdown', options:['HR','Engineering','Marketing','Sales','Support','Other'] },
  { text:'On a scale of 1-5, how easy was it?', type:'rating', options:['1','2','3','4','5'] },
  { text:'What could we improve?', type:'text' },
  { text:'Would you recommend us?', type:'yes_no' },
  { text:'How did you hear about us?', type:'mcq_single', options:['Social Media','Friend','Search Engine','Advertisement','Other'] },
  { text:'What is your role/title?', type:'text' },
  { text:'How long have you been using our service?', type:'dropdown', options:['Less than 1 month','1-3 months','3-6 months','6-12 months','Over 1 year'] },
  { text:'Which features do you use most?', type:'mcq_multiple', options:['Feature A','Feature B','Feature C','Feature D'] },
  { text:'Rate your overall experience', type:'likert5' },
  { text:'What is your phone number?', type:'phone' },
  { text:'What date did you start?', type:'date' },
  { text:'How would you describe our product in one word?', type:'text' },
  { text:'Would you like to participate in future research?', type:'yes_no' },
  { text:'Any other feedback?', type:'text' },
];

function renderBank() {
  const list = document.getElementById('q-bank-list');
  list.innerHTML = questionBank.map((item, i) => {
    const label = qTypeLabels[item.type] || item.type;
    const icon = qTypeIcons[item.type] || 'fa-circle';
    const color = qTypeHexColors[item.type] || '#6366f1';
    return `<button type="button" onclick="addFromBank(${i})" class="w-full text-left p-3 rounded-xl border border-gray-100 hover:border-indigo-200 hover:bg-indigo-50/50 transition-all group">
      <div class="flex items-center gap-3">
        <span class="w-8 h-8 rounded-lg flex items-center justify-center text-white text-xs flex-shrink-0" style="background:${color}"><i class="fas ${icon}"></i></span>
        <div class="flex-1 min-w-0">
          <div class="text-xs font-medium text-gray-800 truncate">${escapeHtml(item.text)}</div>
          <div class="flex items-center gap-1.5 mt-0.5">
            <span class="text-[9px] px-1 py-0.5 rounded font-medium" style="background:${color}15; color:${color}">${label}</span>
            ${item.options ? '<span class="text-[9px] text-gray-400">' + item.options.length + ' opts</span>' : ''}
          </div>
        </div>
        <div class="w-7 h-7 rounded-lg bg-indigo-100 text-indigo-600 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all ml-auto flex-shrink-0 shadow-sm"><i class="fas fa-plus text-xs"></i></div>
      </div>
    </button>`;
  }).join('');
}

function addFromBank(index) {
  pushUndo();
  const item = questionBank[index];
  const q = { id:++qIdCounter, question_text:item.text, type:item.type, is_required:true, is_attention_check:false, is_trap:false, is_speed_bump:false, is_timed:false, time_limit_seconds:null, min_value:null, max_value:null, char_limit:null, min_length:null, max_length:null, allow_paste:true, options:item.options || null, rows:null, expected_answer:null, animation:null, accent_color:null };
  questions.push(q);
  renderQuestions();
  updatePreviewQuestions();
  selectQuestion(questions.length - 1);
  toggleBank();
}

function toggleBank() {
  const bank = document.getElementById('q-bank');
  const overlay = document.getElementById('q-bank-overlay');
  const isOpen = bank.classList.contains('open');
  if (isOpen) {
    bank.classList.remove('open');
    overlay.classList.add('hidden');
  } else {
    renderBank();
    bank.classList.add('open');
    overlay.classList.remove('hidden');
  }
}

// ============================================================
// UNDO / REDO
// ============================================================
function pushUndo() {
  undoStack.push(JSON.parse(JSON.stringify(questions)));
  if (undoStack.length > MAX_UNDO) undoStack.shift();
  redoStack = [];
  updateUndoButtons();
}

function undo() {
  if (undoStack.length === 0) return;
  redoStack.push(JSON.parse(JSON.stringify(questions)));
  questions = undoStack.pop();
  renderQuestions();
  updatePreviewQuestions();
  updateUndoButtons();
}

function redo() {
  if (redoStack.length === 0) return;
  undoStack.push(JSON.parse(JSON.stringify(questions)));
  questions = redoStack.pop();
  renderQuestions();
  updatePreviewQuestions();
  updateUndoButtons();
}

function updateUndoButtons() {
  const u = document.getElementById('btn-undo');
  const r = document.getElementById('btn-redo');
  if (u) u.disabled = undoStack.length === 0;
  if (r) r.disabled = redoStack.length === 0;
}

// ============================================================
// KEYBOARD SHORTCUTS
// ============================================================
function toggleKbHelp() {
  document.getElementById('kb-help').classList.toggle('hidden');
}

document.addEventListener('keydown', function(e) {
  // Don't trigger shortcuts when typing in inputs
  if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.tagName === 'SELECT') {
    if (e.key === 'Escape') closeModal();
    return;
  }

  const modalOpen = !document.getElementById('q-modal').classList.contains('hidden');
  const bankOpen = document.getElementById('q-bank').classList.contains('open');
  if (modalOpen || bankOpen) {
    if (e.key === 'Escape') { closeModal(); if (bankOpen) toggleBank(); }
    if ((e.key === 'Enter' && (e.ctrlKey || e.metaKey)) && modalOpen) { e.preventDefault(); saveCustomQuestion(); }
    return;
  }

  switch (e.key) {
    case 'q': case 'Q':
      if (e.shiftKey) { openCustomModal(); } else { quickAdd('text'); }
      e.preventDefault(); break;
    case 'z': case 'Z':
      if (e.ctrlKey || e.metaKey) {
        if (e.shiftKey) { redo(); } else { undo(); }
        e.preventDefault();
      }
      break;
    case 's': case 'S':
      if (e.ctrlKey || e.metaKey) { e.preventDefault(); var f=document.getElementById('survey-form'); serializeForm(); f.submit(); }
      break;
    case 'e': case 'E':
      if (selectedQIndex >= 0 && selectedQIndex < questions.length) editQuestion(selectedQIndex);
      e.preventDefault(); break;
    case 'd': case 'D':
      if (selectedQIndex >= 0 && selectedQIndex < questions.length) duplicateQuestion(selectedQIndex);
      e.preventDefault(); break;
    case 'Delete': case 'Backspace':
      if (selectedQIndex >= 0 && selectedQIndex < questions.length) removeQuestion(selectedQIndex);
      e.preventDefault(); break;
    case '/': const qs = document.getElementById('q-search'); if (qs) { qs.focus(); qs.select(); } e.preventDefault(); break;
    case '?':
      toggleKbHelp(); e.preventDefault(); break;
  }
});

// ============================================================
// SELECT / EDIT / DUPLICATE / REMOVE
// ============================================================
function selectQuestion(index) {
  selectedQIndex = index;
  document.querySelectorAll('#q-list .q-item').forEach((el, i) => {
    el.classList.toggle('ring-2', i === index);
    el.classList.toggle('ring-indigo-300', i === index);
  });
  const sel = document.querySelector(`.q-item[data-index="${index}"]`);
  if (sel) sel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function editQuestion(index) {
  openCustomModal(index);
}

function duplicateQuestion(index) {
  pushUndo();
  const orig = questions[index];
  const copy = JSON.parse(JSON.stringify(orig));
  copy.id = ++qIdCounter;
  copy.question_text = orig.question_text + ' (copy)';
  questions.splice(index + 1, 0, copy);
  renderQuestions();
  updatePreviewQuestions();
  selectQuestion(index + 1);
}

function removeQuestion(index) {
  if (selectedQIndex !== index) selectQuestion(index);
  pushUndo();
  const qText = questions[index]?.question_text || 'this question';
  const el = document.querySelector(`.q-item[data-qi="${questions[index].id}"]`);
  if (el) {
    el.classList.add('q-item-remove');
    setTimeout(() => { questions.splice(index,1); renderQuestions(); updatePreviewQuestions(); if (selectedQIndex >= questions.length) selectedQIndex = questions.length - 1; showToast('Removed: "' + qText.substring(0, 40) + '"', 'info'); }, 250);
  } else {
    questions.splice(index,1); renderQuestions(); updatePreviewQuestions();
    if (selectedQIndex >= questions.length) selectedQIndex = questions.length - 1;
  }
}

// ============================================================
// INLINE EDIT — double-click question text to edit directly
// ============================================================
let inlineEditActive = false;
function inlineEditQuestion(index) {
  if (inlineEditActive) return;
  const el = document.querySelector(`.q-item[data-index="${index}"] .cursor-text`);
  if (!el) return;
  inlineEditActive = true;
  const origText = questions[index].question_text;
  const input = document.createElement('input');
  input.type = 'text';
  input.value = origText;
  input.className = 'w-full px-2 py-1 text-xs font-semibold rounded-lg border-2 border-indigo-400 bg-white shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-300';
  input.dataset.orig = origText;
  el.style.display = 'none';
  el.parentNode.insertBefore(input, el.nextSibling);
  input.focus();
  input.select();
  const finish = (save) => {
    inlineEditActive = false;
    const val = input.value.trim();
    if (save && val && val !== origText) {
      pushUndo();
      questions[index].question_text = val;
      renderQuestions();
      updatePreviewQuestions();
      showToast('Question updated', 'success');
    } else {
      input.remove();
      el.style.display = '';
    }
  };
  input.addEventListener('blur', () => finish(true));
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); input.blur(); }
    if (e.key === 'Escape') { e.preventDefault(); input.value = input.dataset.orig; input.blur(); }
  });
}

// ============================================================
// QUICK ADD
// ============================================================
function quickAdd(type) {
  pushUndo();
  const q = { id:++qIdCounter, question_text:getDefaultText(type), type, is_required:true, is_attention_check:false, is_trap:false, is_speed_bump:false, is_timed:false, time_limit_seconds:null, min_value:null, max_value:null, char_limit:null, min_length:null, max_length:null, allow_paste:true, options:null, rows:null, expected_answer:null, animation:null, accent_color:null, placeholder:null, hint:null, image_url:null, shuffle_options:false, include_other:true };
  if (type === 'rating') q.options = ['1','2','3','4','5'];
  if (type === 'mcq_single') q.options = ['Option 1','Option 2','Option 3'];
  if (type === 'mcq_multiple') q.options = ['Option 1','Option 2','Option 3'];
  if (type === 'dropdown') q.options = ['Option 1','Option 2','Option 3'];
  if (type === 'likert5') q.options = ['Strongly Disagree','Disagree','Neutral','Agree','Strongly Agree'];
  if (type === 'likert7') q.options = ['Strongly Disagree','Disagree','Somewhat Disagree','Neutral','Somewhat Agree','Agree','Strongly Agree'];
  if (type === 'ranking') q.options = ['Item 1','Item 2','Item 3','Item 4','Item 5'];
  if (type === 'multi_text') q.options = ['Field 1','Field 2','Field 3'];
  if (type === 'nps') q.question_text = 'How likely are you to recommend us?';
  if (type === 'yes_no') q.question_text = 'Would you recommend this?';
  questions.push(q);
  renderQuestions();
  updatePreviewQuestions();
  selectQuestion(questions.length - 1);
}

function getDefaultText(type) {
  const m = { text:'Enter your answer', number:'Enter a number', email:'Enter your email', phone:'Enter your phone', date:'Select a date', yes_no:'Do you agree?', rating:'Rate your experience', mcq_single:'Choose one option', mcq_multiple:'Choose all that apply', dropdown:'Select from options', likert5:'How satisfied are you?', likert7:'How much do you agree?', slider:'Slide to select', matrix:'Rate each item', file_upload:'Upload a file', textarea:'Type your detailed answer...', url:'https://example.com', nps:'Rate 0-10', ranking:'Drag to reorder', multi_text:'Enter multiple values', address:'Enter your address', time:'Select time', datetime:'Select date & time', color:'Pick a color', percentage:'Select percentage', signature:'Sign above' };
  return m[type] || 'Enter your answer';
}

// ============================================================
// RENDER QUESTIONS
// ============================================================
let qSearchFilter = '';

function filterQuestions(val) {
  qSearchFilter = val.toLowerCase().trim();
  const clearBtn = document.getElementById('q-search-clear');
  if (clearBtn) clearBtn.classList.toggle('hidden', !val);
  document.querySelectorAll('#qx-grid .qx-btn').forEach(btn => {
    const type = btn.dataset.type || '';
    const label = btn.textContent.toLowerCase();
    const match = !qSearchFilter || label.includes(qSearchFilter) || type.includes(qSearchFilter);
    btn.style.display = match ? '' : 'none';
  });
  renderQuestions();
}

function renderQuestions() {
  const list = document.getElementById('q-list');
  const label = document.getElementById('q-count-label');
  const submitCount = document.getElementById('submit-q-count');
  const previewCount = document.getElementById('preview-q-count');

  const filtered = qSearchFilter ? questions.filter((q, i) => {
    const searchText = (q.question_text + ' ' + (qTypeLabels[q.type] || '') + ' ' + q.type).toLowerCase();
    return searchText.includes(qSearchFilter);
  }) : questions;

  if (questions.length === 0) {
    list.innerHTML = '<div id="q-empty" class="text-center py-10 border-2 border-dashed border-gray-200 rounded-xl"><div class="w-12 h-12 bg-gradient-to-br from-indigo-50 to-purple-50 rounded-2xl flex items-center justify-center mx-auto mb-3"><i class="fas fa-plus-circle text-indigo-300 text-lg"></i></div><p class="text-xs text-gray-400">No questions yet — press <kbd class="px-1.5 py-0.5 bg-gray-100 rounded text-[10px] font-mono border border-gray-200 border-b-2">Q</kbd> or click a type above</p></div>';
    label.textContent = 'No questions yet';
    if (submitCount) submitCount.textContent = '';
    if (previewCount) previewCount.textContent = '0 questions';
    return;
  }
  if (qSearchFilter && filtered.length === 0) {
    list.innerHTML = '<div class="text-center py-10 border-2 border-dashed border-gray-200 rounded-xl"><div class="w-12 h-12 bg-gradient-to-br from-amber-50 to-orange-50 rounded-2xl flex items-center justify-center mx-auto mb-3"><i class="fas fa-search text-amber-300 text-lg"></i></div><p class="text-xs text-gray-400">No questions match <strong>"' + escapeHtml(qSearchFilter) + '"</strong></p><button class="mt-2 text-xs text-indigo-500 hover:text-indigo-700 underline" onclick="document.getElementById(\'q-search\').value=\'\';filterQuestions(\'\')">Clear search</button></div>';
    label.textContent = questions.length + ' question' + (questions.length > 1 ? 's' : '') + ' (0 shown)';
    if (submitCount) submitCount.textContent = '(' + questions.length + ' Q)';
    if (previewCount) previewCount.textContent = questions.length + ' question' + (questions.length > 1 ? 's' : '');
    return;
  }

  label.textContent = questions.length + ' question' + (questions.length > 1 ? 's' : '') + (filtered.length !== questions.length ? ' (' + filtered.length + ' shown)' : '');
  if (submitCount) submitCount.textContent = '(' + questions.length + ' Q)';
  if (previewCount) previewCount.textContent = questions.length + ' question' + (questions.length > 1 ? 's' : '');

  let html = '';
  (qSearchFilter ? filtered : questions).forEach((q, fi) => {
    const realIndex = qSearchFilter ? questions.indexOf(q) : fi;
    const i = realIndex;
    const tl = qTypeLabels[q.type] || q.type;
    const ti = qTypeIcons[q.type] || 'fa-circle';
    const tc = qTypeColors[q.type] || 'bg-gray-50 text-gray-700 border-gray-200';
    const isSelected = i === selectedQIndex;
    const accentColor = q.accent_color || qTypeHexColors[q.type] || '#6366f1';
    const animLabel = q.animation && q.animation !== 'none' ? (questionAnimations.find(a=>a.value===q.animation)?.label || q.animation) : null;

    const badges = [];
    if (q.is_required) badges.push('<span class="text-[9px] px-1.5 py-0.5 rounded-full bg-red-50 text-red-600 font-medium border border-red-100"><i class="fas fa-asterisk text-[7px] mr-0.5"></i></span>');
    if (q.is_attention_check) badges.push('<span class="text-[9px] px-1.5 py-0.5 rounded-full bg-amber-50 text-amber-600 font-medium border border-amber-100"><i class="fas fa-brain text-[7px] mr-0.5"></i></span>');
    if (q.is_trap) badges.push('<span class="text-[9px] px-1.5 py-0.5 rounded-full bg-red-50 text-red-600 font-medium border border-red-100"><i class="fas fa-skull text-[7px] mr-0.5"></i></span>');
    if (q.is_speed_bump) badges.push('<span class="text-[9px] px-1.5 py-0.5 rounded-full bg-orange-50 text-orange-600 font-medium border border-orange-100"><i class="fas fa-gauge-high text-[7px] mr-0.5"></i></span>');
    if (q.is_timed) badges.push('<span class="text-[9px] px-1.5 py-0.5 rounded-full bg-purple-50 text-purple-600 font-medium border border-purple-100"><i class="fas fa-clock text-[7px] mr-0.5"></i>'+q.time_limit_seconds+'s</span>');
    if (animLabel) badges.push('<span class="text-[9px] px-1.5 py-0.5 rounded-full bg-sky-50 text-sky-600 font-medium border border-sky-100"><i class="fas fa-sparkles text-[7px] mr-0.5"></i></span>');

    const selectedClass = isSelected ? 'ring-2 ring-indigo-300/40 border-indigo-400 shadow-lg shadow-indigo-100' : 'border-gray-100 hover:border-gray-200 hover:shadow-md';

    html += `<div draggable="true"
      class="q-item flex items-start gap-0 bg-white rounded-xl border ${selectedClass} transition-all duration-200 group overflow-hidden cursor-pointer"
      data-qi="${q.id}" data-index="${i}"
      onclick="selectQuestion(${i})"
      ondragstart="onDragStart(event, ${i})"
      ondragend="onDragEnd(event)"
      ondragover="onDragOver(event)"
      ondrop="onDrop(event, ${i})">
      <div class="w-1.5 self-stretch flex-shrink-0 transition-colors duration-300 rounded-l-xl" style="background:${accentColor}"></div>
      <div class="flex items-center self-stretch px-1.5 text-gray-200 hover:text-indigo-400 transition-colors cursor-grab active:cursor-grabbing select-none" onmousedown="event.stopPropagation()">
        <i class="fas fa-grip-vertical text-sm"></i>
      </div>
      <div class="flex-1 min-w-0 py-2.5 pr-2.5 flex items-center gap-3">
        <span class="inline-flex items-center justify-center w-6 h-6 rounded-lg bg-gray-100 text-[10px] font-bold text-gray-500 flex-shrink-0 shadow-sm">${i+1}</span>
        <div class="flex-1 min-w-0">
          <div class="flex items-center gap-1.5">
            <span class="text-xs font-semibold text-gray-900 break-words leading-relaxed cursor-text hover:text-indigo-600 transition-colors" ondblclick="event.stopPropagation();inlineEditQuestion(${i})" title="Double-click to edit">${escapeHtml(q.question_text)}</span>
            ${q.accent_color ? '<span class="w-2.5 h-2.5 rounded-full inline-block border border-white shadow-sm flex-shrink-0" style="background:'+q.accent_color+'"></span>' : ''}
          </div>
          <div class="flex items-center gap-1 mt-1 flex-wrap">
            <span class="inline-flex items-center gap-1 text-[9px] px-1.5 py-0.5 rounded-md border font-medium ${tc}"><i class="fas ${ti} text-[8px]"></i> ${tl}</span>
            ${badges.join(' ')}
          </div>
        </div>
      </div>
      <div class="flex items-center gap-1 pr-2 opacity-70 group-hover:opacity-100 transition-opacity">
        <button type="button" onmousedown="event.stopPropagation()" onclick="event.stopPropagation();editQuestion(${i})" class="w-7 h-7 rounded-lg bg-white border border-gray-200 text-indigo-500 hover:bg-indigo-50 hover:border-indigo-300 hover:text-indigo-700 hover:shadow-sm transition-all flex items-center justify-center" title="Edit (E)"><i class="fas fa-pen text-[10px]"></i></button>
        <button type="button" onmousedown="event.stopPropagation()" onclick="event.stopPropagation();duplicateQuestion(${i})" class="w-7 h-7 rounded-lg bg-white border border-gray-200 text-emerald-500 hover:bg-emerald-50 hover:border-emerald-300 hover:text-emerald-700 hover:shadow-sm transition-all flex items-center justify-center" title="Duplicate (D)"><i class="fas fa-copy text-[10px]"></i></button>
        <button type="button" onmousedown="event.stopPropagation()" onclick="event.stopPropagation();removeQuestion(${i})" class="w-7 h-7 rounded-lg bg-white border border-gray-200 text-red-400 hover:bg-red-50 hover:border-red-300 hover:text-red-600 hover:shadow-sm transition-all flex items-center justify-center" title="Delete (Del)"><i class="fas fa-trash text-[10px]"></i></button>
      </div>
    </div>`;
  });
  list.innerHTML = html;
}

// ============================================================
// HTML5 DRAG AND DROP
// ============================================================
let dragSourceIndex = -1;
function onDragStart(ev, index) {
  dragSourceIndex = index;
  ev.dataTransfer.effectAllowed = 'move';
  ev.dataTransfer.setData('text/plain', index);
  const el = ev.currentTarget;
  el.style.opacity = '0.5';
  el.classList.add('ring-2', 'ring-indigo-400', 'shadow-lg');
  setTimeout(() => { el.style.opacity = '1'; }, 10);
}
function onDragEnd(ev) {
  document.querySelectorAll('#q-list .q-item').forEach(el => {
    el.style.opacity = '1';
    el.classList.remove('ring-2', 'ring-indigo-400', 'shadow-lg', 'border-indigo-400', 'bg-indigo-50/30');
  });
  dragSourceIndex = -1;
}
function onDragOver(ev) {
  ev.preventDefault();
  ev.dataTransfer.dropEffect = 'move';
  const el = ev.currentTarget;
  document.querySelectorAll('#q-list .q-item').forEach(e => e.classList.remove('border-indigo-400', 'bg-indigo-50/30'));
  el.classList.add('border-indigo-400', 'bg-indigo-50/30');
}
function onDrop(ev, targetIndex) {
  ev.preventDefault();
  if (dragSourceIndex === -1 || dragSourceIndex === targetIndex) return;
  pushUndo();
  const [removed] = questions.splice(dragSourceIndex, 1);
  questions.splice(targetIndex, 0, removed);
  if (selectedQIndex === dragSourceIndex) selectedQIndex = targetIndex;
  else if (selectedQIndex > dragSourceIndex && selectedQIndex <= targetIndex) selectedQIndex--;
  else if (selectedQIndex < dragSourceIndex && selectedQIndex >= targetIndex) selectedQIndex++;
  renderQuestions();
  updatePreviewQuestions();
  onDragEnd(null);
}

// ============================================================
// BRANDING
// ============================================================
let currentTheme = '<?= $tTheme ?>';
let currentBg = '<?= $tBg ?>';
let currentCardStyle = '<?= $tCard ?>';
let currentRadius = '<?= $tRadius ?>';
let currentShadow = '<?= $tShadow ?>';
let currentBgType = '<?= $tBgType ?>';
const themeColors = { indigo:'#6366f1', emerald:'#10b981', amber:'#f59e0b', rose:'#f43f5e', cyan:'#06b6d4', violet:'#8b5cf6', teal:'#14b8a6', red:'#ef4444', orange:'#f97316', pink:'#ec4899', blue:'#3b82f6', slate:'#64748b' };

function selectTheme(key, btn) {
  currentTheme = key;
  document.querySelectorAll('.theme-btn').forEach(b => { b.classList.remove('border-gray-900','ring-2','ring-offset-2','ring-gray-900'); b.classList.add('border-transparent','hover:border-gray-400'); });
  btn.classList.remove('border-transparent','hover:border-gray-400');
  btn.classList.add('border-gray-900','ring-2','ring-offset-2','ring-gray-900');
  updatePreview();
}

function selectBg(key, btn) {
  currentBg = key;
  document.querySelectorAll('.bg-btn').forEach(b => { b.classList.remove('border-gray-900','ring-2','ring-offset-2','ring-gray-900'); b.classList.add('border-transparent','hover:border-gray-400'); });
  btn.classList.remove('border-transparent','hover:border-gray-400');
  btn.classList.add('border-gray-900','ring-2','ring-offset-2','ring-gray-900');
  updatePreview();
}

function selectCardStyle(key, btn) {
  currentCardStyle = key;
  document.querySelectorAll('.card-style-btn').forEach(b => { b.classList.remove('border-gray-900','ring-2','ring-offset-2','ring-gray-900','bg-indigo-50'); b.classList.add('border-gray-200','hover:border-indigo-300','hover:bg-indigo-50'); });
  btn.classList.remove('border-gray-200','hover:border-indigo-300','hover:bg-indigo-50');
  btn.classList.add('border-gray-900','ring-2','ring-offset-2','ring-gray-900');
  updatePreview();
}

function selectRadius(key, btn) {
  currentRadius = key;
  document.querySelectorAll('.radius-btn').forEach(b => { b.classList.remove('border-gray-900','ring-2','ring-offset-2','ring-gray-900','bg-indigo-50'); b.classList.add('border-gray-200','hover:border-indigo-300','hover:bg-indigo-50'); });
  btn.classList.remove('border-gray-200','hover:border-indigo-300','hover:bg-indigo-50');
  btn.classList.add('border-gray-900','ring-2','ring-offset-2','ring-gray-900');
  updatePreview();
}

function selectShadow(key, btn) {
  currentShadow = key;
  document.querySelectorAll('.shadow-btn').forEach(b => { b.classList.remove('border-gray-900','ring-2','ring-offset-2','ring-gray-900','bg-indigo-50'); b.classList.add('border-gray-200','hover:border-indigo-300','hover:bg-indigo-50'); });
  btn.classList.remove('border-gray-200','hover:border-indigo-300','hover:bg-indigo-50');
  btn.classList.add('border-gray-900','ring-2','ring-offset-2','ring-gray-900');
  updatePreview();
}

function selectBgType(key, btn) {
  currentBgType = key;
  document.querySelectorAll('.bg-type-btn').forEach(b => { b.classList.remove('border-gray-900','ring-2','ring-offset-2','ring-gray-900','bg-indigo-50'); b.classList.add('border-gray-200','hover:border-indigo-300','hover:bg-indigo-50'); });
  btn.classList.remove('border-gray-200','hover:border-indigo-300','hover:bg-indigo-50');
  btn.classList.add('border-gray-900','ring-2','ring-offset-2','ring-gray-900');
  document.getElementById('bg-type-value').classList.toggle('hidden', key !== 'solid' && key !== 'gradient');
  document.getElementById('bg-type-image').classList.toggle('hidden', key !== 'image');
  document.getElementById('bg-type-video').classList.toggle('hidden', key !== 'video');
  updatePreview();
}

function updatePreview() {
  const mode = getSurveyMode();
  if (mode !== 'form') return;
  const color = themeColors[currentTheme] || '#6366f1';
  const hdr = document.getElementById('preview-header');
  if (hdr) hdr.style.background = `linear-gradient(135deg, ${color}, ${color}dd)`;
  const logoUrl = document.getElementById('logo-url').value.trim();
  const logoEl = document.getElementById('preview-logo');
  const logoImg = document.getElementById('preview-logo-img');
  if (logoUrl) { logoEl.classList.remove('hidden'); logoImg.src = logoUrl; logoImg.onerror = function(){ logoEl.classList.add('hidden'); }; }
  else { logoEl.classList.add('hidden'); }
  const card = document.getElementById('preview-phone');
  if (card) {
    const cardStyles = { glass:'bg-white/70 backdrop-blur-xl border-white/50', solid:'bg-white border-gray-200', bordered:'bg-white border-2 border-gray-200', ghost:'bg-transparent border-gray-200/30', 'dark-glass':'bg-white/10 backdrop-blur-xl border-white/10', neumorphic:'shadow-[inset_0_-2px_6px_rgba(0,0,0,0.05),0_2px_6px_rgba(0,0,0,0.05)] bg-white border-transparent', gradient:`bg-gradient-to-br from-${currentTheme}-50/80 to-${currentTheme}-100/30 backdrop-blur-xl border-transparent` };
    card.className = 'rounded-xl border overflow-hidden transition-all duration-500 ' + (cardStyles[currentCardStyle] || cardStyles.glass) + ' min-h-[300px]';
    card.style.borderRadius = currentRadius === 'full' ? '9999px' : (currentRadius === '2xl' ? '16px' : (currentRadius === '3xl' ? '24px' : (currentRadius === 'xl' ? '12px' : (currentRadius === 'lg' ? '8px' : (currentRadius === 'md' ? '6px' : (currentRadius === 'sm' ? '4px' : (currentRadius === 'none' ? '0px' : '12px')))))));
  }
}

// ============================================================
// COLLAPSIBLE
// ============================================================
function toggleSection(id, btn) {
  const el = document.getElementById(id);
  if (!el) return;
  if (!el.dataset.fullHeight) el.dataset.fullHeight = el.scrollHeight + 'px';
  if (el.style.maxHeight === '0px' || !el.style.maxHeight || el.style.maxHeight === '') {
    el.style.maxHeight = el.dataset.fullHeight || el.scrollHeight + 'px';
    btn.innerHTML = '<i class="fas fa-chevron-up"></i>';
  } else {
    el.style.maxHeight = el.scrollHeight + 'px';
    requestAnimationFrame(() => { el.style.maxHeight = '0px'; });
    btn.innerHTML = '<i class="fas fa-chevron-down"></i>';
  }
}

// ============================================================
// MODAL
// ============================================================
function selectModalType(type, btn) {
  document.querySelectorAll('.modal-type-btn').forEach(b => {
    b.classList.remove('border-emerald-500', 'bg-emerald-50', 'text-emerald-700');
    b.classList.add('border-transparent', 'bg-gray-50', 'text-gray-600');
  });
  btn.classList.remove('border-transparent', 'bg-gray-50', 'text-gray-600');
  btn.classList.add('border-emerald-500', 'bg-emerald-50', 'text-emerald-700');
  document.getElementById('modal-type').value = type;
  toggleModalOptions();
  updateModalPreview();
}

function initAnimationGrid() {
  const grid = document.getElementById('modal-anim-grid');
  grid.innerHTML = questionAnimations.map(a =>
    `<button type="button" class="anim-btn px-1.5 py-1.5 rounded-lg text-[9px] font-medium border transition-all flex flex-col items-center gap-0.5 ${a.value === 'none' ? 'border-sky-400 bg-sky-50 text-sky-700 shadow-sm' : 'border-gray-200 bg-white text-gray-500 hover:border-sky-300 hover:bg-sky-50/50'}" data-anim="${a.value}" onclick="selectAnimation('${a.value}', this)">
      <i class="fas ${a.icon} text-[10px]"></i>
      <span>${a.label}</span>
    </button>`
  ).join('');
}

function selectAnimation(value, btn) {
  selectedModalAnimation = value;
  document.querySelectorAll('.anim-btn').forEach(b => {
    b.classList.remove('border-sky-400', 'bg-sky-50', 'text-sky-700', 'shadow-sm');
    b.classList.add('border-gray-200', 'bg-white', 'text-gray-500');
  });
  btn.classList.remove('border-gray-200', 'bg-white', 'text-gray-500');
  btn.classList.add('border-sky-400', 'bg-sky-50', 'text-sky-700', 'shadow-sm');
  const box = document.getElementById('anim-preview-box');
  const txt = document.getElementById('anim-preview-text');
  const anim = questionAnimations.find(a => a.value === value);
  txt.textContent = anim ? anim.desc : '';
  box.className = 'mt-2 p-2 bg-white rounded-lg border border-sky-200 text-center text-[10px] min-h-[40px] flex items-center justify-center overflow-hidden';
  if (value !== 'none' && anim && anim.cls) {
    box.classList.add(anim.cls);
  }
}

function initAccentGrid() {
  const grid = document.getElementById('modal-accent-grid');
  grid.innerHTML = accentColors.map(a => {
    const isAuto = a.value === '';
    const selected = a.value === '';
    return `<button type="button" class="accent-btn w-7 h-7 rounded-lg border-2 transition-all flex items-center justify-center ${selected ? 'border-gray-900 ring-2 ring-offset-1 ring-gray-900 scale-110' : 'border-transparent hover:scale-110 hover:shadow-md'}" style="background:${isAuto ? 'conic-gradient(#6366f1,#10b981,#f59e0b,#f43f5e,#06b6d4,#8b5cf6,#6366f1)' : a.hex}" data-value="${a.value}" onclick="selectAccent('${a.value}', this)" title="${a.label}">
      ${isAuto ? '<i class="fas fa-magic text-white text-[8px] drop-shadow"></i>' : ''}
    </button>`;
  }).join('');
}

function selectAccent(value, btn) {
  selectedModalAccent = value;
  document.querySelectorAll('.accent-btn').forEach(b => {
    b.classList.remove('border-gray-900', 'ring-2', 'ring-offset-1', 'ring-gray-900', 'scale-110');
    b.classList.add('border-transparent');
  });
  btn.classList.remove('border-transparent');
  btn.classList.add('border-gray-900', 'ring-2', 'ring-offset-1', 'ring-gray-900', 'scale-110');
  updateModalPreview();
}

function updateModalPreview() {
  const text = document.getElementById('modal-text').value.trim();
  const type = document.getElementById('modal-type').value;
  const preview = document.getElementById('modal-preview-body');
  const label = qTypeLabels[type] || type;
  const icon = qTypeIcons[type] || 'fa-circle';
  const color = selectedModalAccent || qTypeHexColors[type] || '#6366f1';
  const anim = questionAnimations.find(a => a.value === selectedModalAnimation);
  if (!text) {
    preview.innerHTML = '<span class="text-gray-400">Fill in the question text to see a preview</span>';
    return;
  }
  const hasOptions = ['mcq_single','mcq_multiple','dropdown','likert5','likert7','rating'].includes(type);
  preview.innerHTML = `<div class="p-3 rounded-xl border text-left transition-all duration-500 ${anim && anim.cls ? anim.cls : ''}" style="border-color:${color}20; background:${color}08">
    <div class="flex items-center gap-2 mb-2">
      <span class="inline-flex items-center justify-center w-6 h-6 rounded-lg text-white text-[10px] font-bold shadow-sm" style="background:${color}"><i class="fas ${icon}"></i></span>
      <span class="text-xs font-semibold text-gray-800">${escapeHtml(text)}</span>
      <span class="text-[9px] px-1.5 py-0.5 rounded-md font-medium ml-auto" style="background:${color}15; color:${color}">${label}</span>
    </div>
    ${hasOptions ? '<div class="space-y-1 mt-2"><div class="flex items-center gap-2 text-[11px] text-gray-500 py-1 px-2 bg-white rounded-md border border-gray-100"><span class="w-3 h-3 rounded-full border-2 border-gray-300 flex-shrink-0"></span>Sample option 1</div><div class="flex items-center gap-2 text-[11px] text-gray-500 py-1 px-2 bg-white rounded-md border border-gray-100"><span class="w-3 h-3 rounded-full border-2 border-gray-300 flex-shrink-0"></span>Sample option 2</div></div>' : ''}
  </div>`;
}

function openCustomModal(editIndex) {
  document.getElementById('modal-edit-index').value = editIndex !== undefined ? editIndex : -1;
  document.getElementById('modal-title').textContent = editIndex !== undefined ? 'Edit Question' : 'Add Custom Question';
  document.getElementById('q-modal').classList.remove('hidden');
  document.body.style.overflow = 'hidden';
  selectedModalAnimation = 'none';
  selectedModalAccent = '';
  initAnimationGrid();
  initAccentGrid();
  if (editIndex !== undefined && editIndex >= 0) {
    const q = questions[editIndex];
    const typeBtn = document.querySelector(`.modal-type-btn[data-type="${q.type}"]`);
    if (typeBtn) selectModalType(q.type, typeBtn);
    document.getElementById('modal-type').value = q.type;
    document.getElementById('modal-text').value = q.question_text;
    document.getElementById('modal-options').value = q.options ? q.options.join('\n') : '';
    setModalOptions(q.options || []);

    if (q.type === 'matrix') {
      const rowValues = Array.isArray(q.rows) ? q.rows : (q.rows && Array.isArray(q.rows.rows) ? q.rows.rows : []);
      const columnValues = Array.isArray(q.options) ? q.options : (q.rows && Array.isArray(q.rows.columns) ? q.rows.columns : []);
      document.getElementById('modal-rows').value = rowValues.join('\n');
      document.getElementById('modal-columns').value = columnValues.join('\n');
    } else {
      document.getElementById('modal-rows').value = '';
      document.getElementById('modal-columns').value = '';
    }
    document.getElementById('modal-min-val').value = q.min_value || '';
    document.getElementById('modal-max-val').value = q.max_value || '';
    document.getElementById('modal-char-limit').value = q.char_limit || '';
    document.getElementById('modal-required').checked = q.is_required;
    document.getElementById('modal-attention').checked = q.is_attention_check;
    document.getElementById('modal-trap').checked = q.is_trap;
    document.getElementById('modal-speed').checked = q.is_speed_bump;
    document.getElementById('modal-timed').checked = q.is_timed;
    document.getElementById('modal-time-limit').value = q.time_limit_seconds || 30;
    document.getElementById('modal-expected').value = q.expected_answer || '';
    document.getElementById('modal-placeholder').value = q.placeholder || '';
    document.getElementById('modal-hint').value = q.hint || '';
    document.getElementById('modal-image-url').value = q.image_url || '';
    document.getElementById('modal-shuffle').checked = q.shuffle_options || false;
    document.getElementById('modal-include-other').checked = q.include_other === '1' || q.include_other === 1 || q.include_other === true;
    if (q.animation && q.animation !== 'none') {
      selectedModalAnimation = q.animation;
      const animBtn = document.querySelector(`.anim-btn[data-anim="${q.animation}"]`);
      if (animBtn) selectAnimation(q.animation, animBtn);
    }
    if (q.accent_color) {
      selectedModalAccent = q.accent_color;
      const accentBtn = document.querySelector(`.accent-btn[data-value="${q.accent_color}"]`) || document.querySelector(`.accent-btn[value="${q.accent_color}"]`);
      if (accentBtn) selectAccent(q.accent_color, accentBtn);
    }
  } else {
    selectModalType('text', document.querySelector('.modal-type-btn[data-type="text"]'));
    document.getElementById('modal-type').value = 'text';
    document.getElementById('modal-text').value = '';
    document.getElementById('modal-options').value = '';
    setModalOptions([]);
    document.getElementById('modal-rows').value = '';
    document.getElementById('modal-columns').value = '';
    document.getElementById('modal-min-val').value = '';
    document.getElementById('modal-max-val').value = '';
    document.getElementById('modal-char-limit').value = '';
    document.getElementById('modal-required').checked = true;
    document.getElementById('modal-attention').checked = false;
    document.getElementById('modal-trap').checked = false;
    document.getElementById('modal-speed').checked = false;
    document.getElementById('modal-timed').checked = false;
    document.getElementById('modal-time-limit').value = 30;
    document.getElementById('modal-expected').value = '';
    document.getElementById('modal-placeholder').value = '';
    document.getElementById('modal-hint').value = '';
    document.getElementById('modal-image-url').value = '';
    document.getElementById('modal-shuffle').checked = false;
    document.getElementById('modal-include-other').checked = true;
    selectAnimation('none', document.querySelector('.anim-btn[data-anim="none"]'));
    selectAccent('', document.querySelector('.accent-btn:first-child'));
  }
  toggleModalOptions();
  updateModalPreview();
}

function closeModal() { document.getElementById('q-modal').classList.add('hidden'); document.body.style.overflow = ''; }

function saveCustomQuestion() {
  const type = document.getElementById('modal-type').value;
  const text = document.getElementById('modal-text').value.trim();
  if (!text) { document.getElementById('modal-text').focus(); document.getElementById('modal-text').classList.add('ring-2','ring-red-400'); setTimeout(()=>document.getElementById('modal-text').classList.remove('ring-2','ring-red-400'),1500); return; }
  let options = null;
  const optsRaw = document.getElementById('modal-options').value.trim();
  if (optsRaw) options = optsRaw.split('\n').map(s=>s.trim()).filter(Boolean);
  let rows = null;
  if (type === 'matrix') {
    const rowsRaw = document.getElementById('modal-rows').value.trim();
    const colsRaw = document.getElementById('modal-columns').value.trim();
    const matrixRows = rowsRaw ? rowsRaw.split('\n').map(s=>s.trim()).filter(Boolean) : [];
    const matrixCols = colsRaw ? colsRaw.split('\n').map(s=>s.trim()).filter(Boolean) : [];
    rows = matrixRows.length ? matrixRows : null;
    options = matrixCols.length ? matrixCols : null;
  }
  const q = {
    id:++qIdCounter, question_text:text, type,
    is_required:document.getElementById('modal-required').checked,
    is_attention_check:document.getElementById('modal-attention').checked,
    expected_answer:document.getElementById('modal-attention').checked ? document.getElementById('modal-expected').value.trim() : null,
    is_trap:document.getElementById('modal-trap').checked,
    is_speed_bump:document.getElementById('modal-speed').checked,
    is_timed:document.getElementById('modal-timed').checked,
    time_limit_seconds:document.getElementById('modal-timed').checked ? parseInt(document.getElementById('modal-time-limit').value) || 30 : null,
    min_value:document.getElementById('modal-min-val').value || null,
    max_value:document.getElementById('modal-max-val').value || null,
    char_limit:document.getElementById('modal-char-limit').value || null,
    min_length:null, max_length:null, allow_paste:true,
    placeholder: document.getElementById('modal-placeholder').value || null,
    hint: document.getElementById('modal-hint').value || null,
    image_url: document.getElementById('modal-image-url').value || null,
    shuffle_options: document.getElementById('modal-shuffle').checked,
    include_other: document.getElementById('modal-include-other').checked,
    options, rows,
    animation: selectedModalAnimation !== 'none' ? selectedModalAnimation : null,
    accent_color: selectedModalAccent || null,
  };
  const editIndex = parseInt(document.getElementById('modal-edit-index').value);
  pushUndo();
  if (editIndex >= 0 && editIndex < questions.length) { q.id = questions[editIndex].id; questions[editIndex] = q; }
  else { questions.push(q); }
  closeModal(); renderQuestions(); updatePreviewQuestions();
}

// Visual option editor functions
function getModalOptions() {
  var inputs = document.querySelectorAll('.mo-input');
  return Array.from(inputs).map(function(inp) { return inp.value.trim(); }).filter(Boolean);
}
function setModalOptions(opts) {
  var list = document.getElementById('modal-options-list');
  list.innerHTML = '';
  (opts || []).forEach(function(v) { addModalOptionRow(v); });
}
function addModalOption() {
  addModalOptionRow('');
  var last = document.querySelector('#modal-options-list .mo-input:last-child');
  if (last) last.focus();
}
function addModalOptionRow(val) {
  var list = document.getElementById('modal-options-list');
  var div = document.createElement('div');
  div.className = 'flex items-center gap-1 group';
  var i = list.children.length;
  div.innerHTML = '<button type="button" onclick="moveModalOption(this,-1)" class="text-gray-200 hover:text-gray-400 transition-all p-0.5 opacity-0 group-hover:opacity-100"><i class="fas fa-chevron-up text-[8px]"></i></button><button type="button" onclick="moveModalOption(this,1)" class="text-gray-200 hover:text-gray-400 transition-all p-0.5 opacity-0 group-hover:opacity-100"><i class="fas fa-chevron-down text-[8px]"></i></button><input type="text" class="mo-input flex-1 px-2.5 py-1.5 rounded-lg text-sm border border-gray-200 focus:ring-2 focus:ring-emerald-500 bg-white" value="' + val.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;') + '" placeholder="Option ' + (i + 1) + '" oninput="syncModalOptions()"><button type="button" onclick="removeModalOption(this)" class="text-red-200 hover:text-red-500 transition-all p-1 opacity-0 group-hover:opacity-100"><i class="fas fa-times text-[10px]"></i></button>';
  list.appendChild(div);
  syncModalOptions();
}
function removeModalOption(btn) {
  var row = btn.closest('.flex');
  if (!row) return;
  row.remove();
  syncModalOptions();
  reindexModalOptions();
}
function moveModalOption(btn, dir) {
  var row = btn.closest('.flex');
  var parent = row.parentNode;
  var idx = Array.from(parent.children).indexOf(row);
  var target = idx + dir;
  if (target < 0 || target >= parent.children.length) return;
  if (dir < 0) parent.insertBefore(row, parent.children[target]);
  else parent.insertBefore(row, parent.children[target + 1]);
  syncModalOptions();
}
function reindexModalOptions() {
  document.querySelectorAll('.mo-input').forEach(function(inp, i) {
    if (!inp.value.trim()) inp.placeholder = 'Option ' + (i + 1);
  });
}
function syncModalOptions() {
  var vals = getModalOptions();
  document.getElementById('modal-options').value = vals.join('\n');
}

function toggleModalOptions() {
  const type = document.getElementById('modal-type').value;
  const hasOptions = ['mcq_single','mcq_multiple','dropdown','likert5','likert7','rating','ranking','multi_text'].includes(type);
  const isMcq = ['mcq_single','mcq_multiple'].includes(type);
  const isMatrix = type === 'matrix';
  const hasValidation = ['number','slider','text','url','nps','percentage','textarea'].includes(type);
  document.getElementById('modal-options-wrap').classList.toggle('hidden', !hasOptions);
  document.getElementById('modal-other-wrap').classList.toggle('hidden', !isMcq);
  document.getElementById('modal-matrix-wrap').classList.toggle('hidden', !isMatrix);
  document.getElementById('modal-validation-wrap').classList.toggle('hidden', !hasValidation);
  if (type === 'likert5' && !getModalOptions().length) setModalOptions(['Strongly Disagree','Disagree','Neutral','Agree','Strongly Agree']);
  if (type === 'likert7' && !getModalOptions().length) setModalOptions(['Strongly Disagree','Disagree','Somewhat Disagree','Neutral','Somewhat Agree','Agree','Strongly Agree']);
  if (type === 'rating' && !getModalOptions().length) setModalOptions(['1','2','3','4','5']);
  if (type === 'ranking' && !getModalOptions().length) setModalOptions(['Item 1','Item 2','Item 3','Item 4','Item 5']);
  if (type === 'multi_text' && !getModalOptions().length) setModalOptions(['Field 1','Field 2','Field 3']);
  document.getElementById('modal-attention-answer-wrap').classList.toggle('hidden', !document.getElementById('modal-attention').checked);
  document.getElementById('modal-timed-wrap').classList.toggle('hidden', !document.getElementById('modal-timed').checked);
  updateModalPreview();
}

document.addEventListener('change', function(e) {
  if (e.target.id === 'modal-attention') { document.getElementById('modal-attention-answer-wrap').classList.toggle('hidden', !e.target.checked); updateModalPreview(); }
  if (e.target.id === 'modal-timed') document.getElementById('modal-timed-wrap').classList.toggle('hidden', !e.target.checked);
});

document.addEventListener('input', function(e) {
  if (e.target.id === 'modal-text') updateModalPreview();
});

// ============================================================
// PREVIEW
// ============================================================
function updatePreviewQuestions() {
  const body = document.getElementById('preview-body');
  const title = document.getElementById('preview-title');
  const desc = document.getElementById('preview-desc');
  const stitle = document.getElementById('survey-title');
  const sdesc = document.getElementById('survey-desc');
  if (stitle) title.textContent = stitle.value.trim() || 'Survey Title';
  if (sdesc) desc.textContent = sdesc.value.trim() || '';
  if (questions.length === 0) { body.innerHTML = '<div class="text-center py-6 text-gray-400 text-xs"><i class="fas fa-arrow-up text-lg mb-1"></i><br>Questions will appear here</div>'; return; }
  body.innerHTML = questions.map((q, i) => {
    const animCls = q.animation ? (questionAnimations.find(a=>a.value===q.animation)?.cls || '') : '';
    const accent = q.accent_color || qTypeHexColors[q.type] || '#6366f1';
    const icon = qTypeIcons[q.type] || 'fa-circle';
    return `<div class="p-2.5 rounded-lg border ${animCls}" style="border-color:${accent}20; background:${accent}06">
      <div class="flex items-start gap-2">
        <span class="inline-flex items-center justify-center w-5 h-5 rounded-md text-white text-[8px] font-bold flex-shrink-0" style="background:${accent}"><i class="fas ${icon}"></i></span>
        <div class="flex-1 min-w-0">
          <div class="text-[11px] font-medium text-gray-800">${escapeHtml(q.question_text)}</div>
          <div class="flex items-center gap-1.5 mt-0.5">
            <span class="text-[8px] px-1 py-0.5 rounded font-medium" style="background:${accent}15; color:${accent}">${qTypeLabels[q.type] || q.type}</span>
            ${q.is_required ? '<span class="text-[8px] text-red-400">* Required</span>' : ''}
            ${q.animation && q.animation !== 'none' ? '<span class="text-[8px] text-sky-500"><i class="fas fa-sparkles"></i></span>' : ''}
          </div>
        </div>
      </div>
    </div>`;
  }).join('');
}

// ============================================================
// PUBLISH
// ============================================================
function getSurveyMode() {
  const checked = document.querySelector('input[name="survey_type"]:checked');
  return checked ? checked.value : 'form';
}

function getAIProvider() {
  const el = document.querySelector('[id^="eb-ai-p-"].ring-2');
  return el ? el.id.replace('eb-ai-p-', '') : 'none';
}

function serializeForm() {
  const mode = document.querySelector('input[name="survey_type"]:checked');
  const isChat = mode && mode.value === 'chat';
  if (isChat) updateChatConfig();
  const cleanQs = questions.map(q => {
    const c = {
      type: q.type || 'text',
      question_text: q.question_text,
      is_required: !!q.is_required,
      is_attention_check: !!q.is_attention_check,
      is_trap: !!q.is_trap,
      is_speed_bump: !!q.is_speed_bump,
      is_timed: !!q.is_timed,
      allow_paste: !!q.allow_paste,
      min_length: q.min_length ?? null,
      max_length: q.max_length ?? null,
      include_other: q.include_other,
      placeholder: q.placeholder,
      hint: q.hint,
      image_url: q.image_url,
      shuffle_options: !!q.shuffle_options
    };
    if (Array.isArray(q.options)) c.options = q.options;
    if (Array.isArray(q.rows)) c.rows = q.rows;
    if (q.expected_answer !== undefined && q.expected_answer !== null && String(q.expected_answer).trim() !== '') c.expected_answer = q.expected_answer;
    if (q.time_limit_seconds !== undefined && q.time_limit_seconds !== null && q.time_limit_seconds !== '') c.time_limit_seconds = q.time_limit_seconds;
    if (q.min_value !== undefined && q.min_value !== null && q.min_value !== '') c.min_value = q.min_value;
    if (q.max_value !== undefined && q.max_value !== null && q.max_value !== '') c.max_value = q.max_value;
    if (q.char_limit !== undefined && q.char_limit !== null && q.char_limit !== '') c.char_limit = q.char_limit;
    if (q.animation) c.animation = q.animation;
    if (q.accent_color) c.accent_color = q.accent_color;
    if (q.explanation) c.explanation = q.explanation;
    return c;
  });
  document.getElementById('questions-json').value = JSON.stringify(cleanQs);
  document.getElementById('theme-config-input').value = JSON.stringify({
    theme:currentTheme, background:currentBg, logo_url:document.getElementById('logo-url').value.trim(),
    card_style:currentCardStyle, question_border_radius:currentRadius, question_shadow:currentShadow,
    font_family:document.getElementById('font-family').value,
    question_animation:document.getElementById('question-animation').value,
    custom_css:document.getElementById('custom-css').value,
    bg_type:currentBgType, bg_value:document.getElementById('bg-value').value,
    bg_image:document.getElementById('bg-image').value, bg_video:document.getElementById('bg-video').value
  });
}

function publishSurvey() {
  const mode = getSurveyMode();
  if (mode === 'chat' && chatNodes.length === 0) {
    const aiProvider = getAIProvider();
    if (aiProvider === 'none') {
      showToast('Add at least one conversation node or configure an AI provider before publishing', 'error');
      return;
    }
  }
  if (mode !== 'chat' && questions.length === 0) { showToast('Add at least one question before publishing', 'error'); return; }
  const form = document.getElementById('survey-form');
  const activeRadio = document.querySelector('input[name="status"][value="active"]');
  if (activeRadio) activeRadio.checked = true;
  serializeForm();
  form.submit();
}

// ============================================================
// DELETE
// ============================================================
function confirmDelete() { document.getElementById('del-modal').classList.remove('hidden'); }
function closeDelModal() { document.getElementById('del-modal').classList.add('hidden'); }

// ============================================================
// COPY LINK
// ============================================================
function copyLink() {
  const inp = document.getElementById('survey-link');
  if (!inp) return;
  inp.select();
  navigator.clipboard?.writeText(inp.value).then(() => {
    showToast('Link copied to clipboard', 'success');
  }).catch(() => {
    showToast('Press Ctrl+C to copy', 'info');
  });
}

// ============================================================
// COPY SHORT URL
// ============================================================
function copyText(text, msg) {
  navigator.clipboard?.writeText(text).then(() => {
    showToast(msg || 'Copied to clipboard', 'success');
  }).catch(() => {
    showToast('Press Ctrl+C to copy', 'info');
  });
}

function copyShareUrl() {
  const inp = document.getElementById('share-url-input');
  if (!inp) return;
  inp.select();
  navigator.clipboard?.writeText(inp.value).then(() => {
    const btn = document.getElementById('copy-url-btn');
    if (btn) { btn.innerHTML = '<i class="fas fa-check"></i>'; setTimeout(function(){ btn.innerHTML = '<i class="fas fa-copy"></i>'; }, 2000); }
    showToast('Link copied to clipboard', 'success');
  }).catch(() => {
    showToast('Press Ctrl+C to copy', 'info');
  });
}
function closeShareModal() { document.getElementById('share-modal')?.classList.add('hidden'); }

// ============================================================
// SHARE & DISTRIBUTE - URL SHORTENER
// ============================================================
function generateShortUrl() {
  const slug = document.getElementById('url-custom-slug').value.trim();
  const utmSource = document.getElementById('url-utm-source').value.trim();
  const utmMedium = document.getElementById('url-utm-medium').value.trim();
  const utmCampaign = document.getElementById('url-utm-campaign').value.trim();
  const password = document.getElementById('url-password').value;
  const expires = document.getElementById('url-expires').value;
  const maxUses = document.getElementById('url-max-uses').value;

  // Allow generation with or without custom slug

  const formData = new FormData();
  formData.append('_csrf_token', csrfToken);
  if (slug) formData.append('custom_slug', slug);
  if (utmSource) formData.append('utm_source', utmSource);
  if (utmMedium) formData.append('utm_medium', utmMedium);
  if (utmCampaign) formData.append('utm_campaign', utmCampaign);
  if (password) formData.append('url_password', password);
  if (expires) formData.append('expires_at', expires);
  if (maxUses) formData.append('max_uses', maxUses);

  const btn = document.querySelector('#generate-url-form button');
  if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>'; }

  fetch(getBasePath() + '/survey/' + getSurveyId() + '/urls/create', { method:'POST', body:formData })
    .then(r => r.json()).then(d => {
      if (d.error) { showToast(d.error, 'error'); return; }
      showToast('Short URL generated: ' + d.short_code, 'success');
      loadUrls();
      document.getElementById('url-custom-slug').value = '';
      document.getElementById('url-utm-source').value = '';
      document.getElementById('url-utm-medium').value = '';
      document.getElementById('url-utm-campaign').value = '';
      document.getElementById('url-password').value = '';
      document.getElementById('url-expires').value = '';
      document.getElementById('url-max-uses').value = '';
    }).catch(e => {
      showToast('Failed to generate URL: ' + e.message, 'error');
    }).finally(() => {
      if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-bolt mr-1"></i>Generate'; }
    });
}

function getSurveyId() {
  const m = window.location.pathname.match(/\/survey\/edit\/(\d+)/);
  return m ? m[1] : '';
}

function loadUrls() {
  const container = document.getElementById('url-list');
  if (!container) return;
  container.innerHTML = '<div class="text-[9px] text-gray-400 text-center py-2">Loading URLs...</div>';

  const url = getBasePath() + '/survey/' + getSurveyId() + '/urls';
  fetch(url)
    .then(r => {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.json();
    })
    .then(urls => {
      if (!urls.length) {
        container.innerHTML = '<div class="text-[9px] text-gray-400 text-center py-2">No short URLs yet. Generate one above.</div>';
        return;
      }
      const baseUrl = window.location.origin + getBasePath();
      container.innerHTML = urls.map(u => {
        const shortUrl = baseUrl + '/s/' + encodeURIComponent(u.short_code);
        const qrUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=' + encodeURIComponent(shortUrl);
        const expiresLabel = u.expires_at ? 'Expires: ' + u.expires_at.replace('T', ' ') : '';
        const usesLabel = u.max_uses ? (u.use_count + '/' + u.max_uses + ' uses') : (u.use_count + ' uses');
        const statusColor = u.is_active ? 'text-emerald-600' : 'text-red-400';
        const statusIcon = u.is_active ? 'fa-check-circle' : 'fa-times-circle';
        return '<div class="flex items-center gap-1.5 p-1.5 rounded-lg border border-gray-100 hover:bg-gray-50 transition-all ' + (u.is_active ? '' : 'opacity-60') + '">' +
          '<i class="fas ' + statusIcon + ' ' + statusColor + ' text-[9px]"></i>' +
          '<div class="flex-1 min-w-0">' +
            '<div class="flex items-center gap-1">' +
              '<span class="text-[10px] font-mono font-semibold text-indigo-700 truncate">' + u.short_code + '</span>' +
              '<span class="text-[8px] text-gray-400">' + usesLabel + '</span>' +
              (expiresLabel ? '<span class="text-[8px] text-amber-500">' + expiresLabel + '</span>' : '') +
            '</div>' +
          '</div>' +
          '<div class="flex items-center gap-0.5 flex-shrink-0">' +
            '<button type="button" onclick="copyText(\'' + shortUrl.replace(/'/g, "\\'") + '\', \'Short URL copied\')" class="w-6 h-6 rounded-md hover:bg-indigo-50 text-indigo-400 hover:text-indigo-600 transition-all flex items-center justify-center text-[9px]" title="Copy short URL"><i class="fas fa-copy"></i></button>' +
            '<button type="button" onclick="showQr(\'' + qrUrl.replace(/'/g, "\\'") + '\')" class="w-6 h-6 rounded-md hover:bg-indigo-50 text-indigo-400 hover:text-indigo-600 transition-all flex items-center justify-center text-[9px]" title="Show QR code"><i class="fas fa-qrcode"></i></button>' +
            '<button type="button" onclick="toggleUrl(' + u.id + ')" class="w-6 h-6 rounded-md hover:bg-amber-50 text-amber-400 hover:text-amber-600 transition-all flex items-center justify-center text-[9px]" title="' + (u.is_active ? 'Deactivate' : 'Activate') + '"><i class="fas fa-' + (u.is_active ? 'pause' : 'play') + '"></i></button>' +
            '<button type="button" onclick="deleteUrl(' + u.id + ')" class="w-6 h-6 rounded-md hover:bg-red-50 text-red-300 hover:text-red-500 transition-all flex items-center justify-center text-[9px]" title="Delete"><i class="fas fa-trash"></i></button>' +
          '</div>' +
        '</div>';
      }).join('');
    })
    .catch(e => {
      container.innerHTML = '<div class="text-[9px] text-red-400 text-center py-2">Failed to load URLs. <span class="block text-[8px]">' + e.message + '</span></div>';
    });
}

function showQr(qrUrl) {
  document.getElementById('qr-modal-img').src = qrUrl;
  document.getElementById('qr-modal').classList.remove('hidden');
}

function getBasePath() {
  const path = window.location.pathname;
  const m = path.match(/^(\/[^/]+\/[^/]+)/);
  return m ? m[1] : '';
}

const csrfToken = '<?= \Core\Csrf::token() ?>';

function toggleUrl(id) {
  fetch(getBasePath() + '/survey/url/toggle/' + id, {
    method:'POST',
    headers: {'Content-Type':'application/x-www-form-urlencoded'},
    body: '_csrf_token=' + encodeURIComponent(csrfToken)
  })
    .then(r => r.json()).then(d => {
      if (d.success) loadUrls();
    }).catch(() => showToast('Failed to toggle URL', 'error'));
}

function deleteUrl(id) {
  if (!confirm('Delete this short URL?')) return;
  fetch(getBasePath() + '/survey/url/delete/' + id, {
    method:'POST',
    headers: {'Content-Type':'application/x-www-form-urlencoded'},
    body: '_csrf_token=' + encodeURIComponent(csrfToken)
  })
    .then(r => r.json()).then(d => {
      if (d.success) { showToast('URL deleted', 'success'); loadUrls(); }
    }).catch(() => showToast('Failed to delete URL', 'error'));
}

// Load URLs on page load
document.addEventListener('DOMContentLoaded', function() {
  if (document.getElementById('url-list')) loadUrls();
});

// ============================================================
// CHAT SURVEY BUILDER
// ============================================================
let chatNodes = [];
let _toggleTimer = null;

function initChatBuilder() {
  const input = document.getElementById('eb-chat-config-input');
  if (!input) return;
  try {
    const cfg = JSON.parse(input.value || '{}');
    chatNodes = cfg.nodes || [];
  } catch(e) { chatNodes = []; }
  if (document.getElementById('eb-chat-intro')) {
    const cfg = JSON.parse(input.value || '{}');
    document.getElementById('eb-chat-intro').value = cfg.intro_message || '';
    document.getElementById('eb-chat-tone').value = cfg.tone || 'neutral';
  }
  let mode = document.querySelector('input[name="survey_type"]:checked')?.value || 'form';
  toggleSurveyMode(mode);
  renderChatNodes();
  updatePreviewMode(mode);
  // Ensure chat sections are expanded after render
  if (mode === 'chat') {
    ['ce-ai','ce-flow'].forEach(function(id) {
      var el = document.getElementById(id);
      if (el) { el.style.maxHeight = ''; el.dataset.fullHeight = ''; }
    });
    document.querySelectorAll('#chat-edit-zone button i.fa-chevron-down').forEach(function(ic) {
      ic.className = 'fas fa-chevron-up';
    });
  }
}

function convertSurveyModeData(mode) {
  if (mode === 'form' && questions.length === 0 && chatNodes.length > 0) {
    questions = chatNodes.map(function(node) {
      return {
        id: ++qIdCounter,
        question_text: node.question || '',
        type: node.type === 'choice' ? 'mcq_single' : (node.type || 'text'),
        options: Array.isArray(node.options) ? node.options.slice() : null,
        is_required: node.is_required !== false,
        is_attention_check: false,
        is_trap: false,
        is_speed_bump: false,
        is_timed: false,
        allow_paste: true,
        placeholder: node.placeholder || null
      };
    });
    renderQuestions();
    updatePreviewQuestions();
    showToast('Chat nodes converted to form questions', 'success');
  } else if (mode === 'chat' && chatNodes.length === 0 && questions.length > 0) {
    chatNodes = questions.map(function(question, index) {
      return {
        id: 'node_' + Date.now() + '_' + index,
        key: 'q_' + (index + 1),
        question: question.question_text || '',
        type: question.type || 'text',
        options: Array.isArray(question.options) ? question.options.slice() : [],
        is_required: question.is_required !== false,
        follow_up_depth: 'none',
        placeholder: question.placeholder || '',
        answer_scope: [],
        scope_type: 'none',
        scope_label: '',
        condition: null
      };
    });
    renderChatNodes();
    updateChatConfig();
    showToast('Form questions converted to chat nodes', 'success');
  }
}

function toggleSurveyMode(mode) {
  if (_toggleTimer) { clearTimeout(_toggleTimer); _toggleTimer = null; }
  convertSurveyModeData(mode);
  const formZone = document.getElementById('form-edit-zone');
  const chatZone = document.getElementById('chat-edit-zone');
  const topBadge = document.getElementById('survey-mode-badge-top');
  const modeInput = document.querySelector('input[name="survey_type"][value="' + mode + '"]');
  if (modeInput) modeInput.checked = true;
  if (formZone) {
    formZone.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
    formZone.style.opacity = mode === 'form' ? '1' : '0';
    if (mode !== 'form') {
      formZone.classList.add('hidden');
      _toggleTimer = setTimeout(() => { formZone.style.display = 'none'; }, 300);
    } else {
      formZone.classList.remove('hidden');
      formZone.style.display = '';
    }
  }
  if (chatZone) {
    chatZone.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
    chatZone.style.opacity = mode === 'chat' ? '1' : '0';
    if (mode !== 'chat') {
      chatZone.classList.add('hidden');
      _toggleTimer = setTimeout(() => { chatZone.style.display = 'none'; }, 300);
    } else {
      chatZone.classList.remove('hidden');
      chatZone.style.display = '';
      requestAnimationFrame(function() {
        ['ce-ai','ce-flow'].forEach(function(id) {
          var el = document.getElementById(id);
          if (el) {
            el.style.maxHeight = '';
            el.dataset.fullHeight = '';
          }
        });
        document.querySelectorAll('#chat-edit-zone button i.fa-chevron-down').forEach(function(ic) {
          ic.className = 'fas fa-chevron-up';
        });
      });
    }
  }
  if (topBadge) {
    if (mode === 'chat') {
      topBadge.className = 'px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-100 text-emerald-700 shadow-sm';
      topBadge.innerHTML = '<i class="fas fa-comment-dots mr-1"></i>Chat';
    } else {
      topBadge.className = 'px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-blue-100 text-blue-700 shadow-sm';
      topBadge.innerHTML = '<i class="fas fa-wpforms mr-1"></i>Form';
    }
  }
  updatePreviewMode(mode);
  setTimeout(updateAIModeBadge, 50);
}

function updatePreviewMode(mode) {
  const preview = document.getElementById('preview-phone');
  const qCount = document.getElementById('preview-q-count');
  if (!preview) return;
  if (mode === 'chat') {
    const nodeCount = chatNodes.length;
    if (qCount) qCount.textContent = nodeCount + ' node' + (nodeCount !== 1 ? 's' : '');
    preview.innerHTML = '<div class="flex flex-col h-64"><div class="px-4 py-3 border-b bg-gradient-to-r from-emerald-500 to-teal-600 text-white"><div class="text-sm font-bold">' + escHtml(document.getElementById('survey-title')?.value || 'Chat Survey') + '</div><div class="text-[10px] text-white/70">Conversational AI interface</div></div><div class="flex-1 p-4 space-y-3 overflow-y-auto"><div class="flex justify-start"><div class="max-w-[80%] px-3 py-2 rounded-2xl rounded-bl-sm bg-gray-100 text-xs text-gray-700">' + escHtml(document.getElementById('eb-chat-intro')?.value || 'Hi! I\'m an AI assistant...') + '</div></div><div class="flex justify-end"><div class="max-w-[80%] px-3 py-2 rounded-2xl rounded-br-sm bg-emerald-500 text-white text-xs">Respondent answer here</div></div><div class="flex justify-start"><div class="max-w-[80%] px-3 py-2 rounded-2xl rounded-bl-sm bg-gray-100 text-xs text-gray-700">Thanks! Let me ask you another question...</div></div></div></div>';
  } else {
    const qs = questions.length;
    if (qCount) qCount.textContent = qs + ' question' + (qs !== 1 ? 's' : '');
    preview.innerHTML = '<div id="preview-header" class="px-4 py-3 border-b bg-gradient-to-r from-indigo-500 to-purple-600 transition-all duration-500"><div id="preview-logo" class="hidden mb-1"></div><div id="preview-title" class="text-sm font-bold text-white">' + escHtml(document.getElementById('survey-title')?.value || 'Survey Title') + '</div><div id="preview-desc" class="text-[10px] text-white/70 mt-0.5 line-clamp-1">' + escHtml(document.getElementById('survey-desc')?.value || '') + '</div></div><div id="preview-body" class="p-4 space-y-3"><div class="text-xs text-gray-400 text-center py-8">Questions will appear here</div></div>';
  }
  updatePreview();
}

function quickAddChat(type) {
  var id = 'node_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4);
  var defaultText = getDefaultText(type);
  var options = [];
  if (type === 'rating') options = ['1','2','3','4','5'];
  else if (type === 'mcq_single') options = ['Option 1','Option 2','Option 3'];
  else if (type === 'mcq_multiple') options = ['Option 1','Option 2','Option 3'];
  else if (type === 'dropdown') options = ['Option 1','Option 2','Option 3'];
  else if (type === 'likert5') options = ['Strongly Disagree','Disagree','Neutral','Agree','Strongly Agree'];
  else if (type === 'likert7') options = ['Strongly Disagree','Disagree','Somewhat Disagree','Neutral','Somewhat Agree','Agree','Strongly Agree'];
  else if (type === 'ranking') options = ['Item 1','Item 2','Item 3','Item 4','Item 5'];
  else if (type === 'multi_text') options = ['Field 1','Field 2','Field 3'];
  var question = defaultText;
  if (type === 'nps') question = 'How likely are you to recommend us?';
  else if (type === 'yes_no') question = 'Would you recommend this?';
  chatNodes.push({ id, key: 'q_' + (chatNodes.length + 1), question, type, options, answer_scope: [], scope_type: 'none', scope_label: '', follow_up_depth: 'none', placeholder: '', condition: null });
  renderChatNodes();
  updateChatConfig();
}

function addChatNode(data) {
  if (data && data.id) {
    // Import existing node data directly
    const id = data.id;
    const existingIdx = chatNodes.findIndex(n => n.id === id);
    const nodeData = { id, key: data.key || 'q_' + (chatNodes.length + 1), question: data.question || '', type: data.type || 'text', options: data.options || [], answer_scope: Array.isArray(data.answer_scope) ? data.answer_scope : [], scope_type: data.scope_type || 'none', scope_label: data.scope_label || '', follow_up_depth: data.follow_up_depth || 'none', placeholder: data.placeholder || '',
      condition: (data.condition?.field && data.condition?.value) ? { field: data.condition.field, operator: data.condition.operator || 'equals', value: data.condition.value } : null };
    if (existingIdx >= 0) chatNodes[existingIdx] = nodeData;
    else chatNodes.push(nodeData);
    renderChatNodes();
    updateChatConfig();
    return;
  }
  openChatNodeModal(null);
}

function removeChatNode(id) {
  chatNodes = chatNodes.filter(n => n.id !== id);
  renderChatNodes();
  updateChatConfig();
}

function renderChatNodes() {
  var container = document.getElementById('eb-chat-nodes');
  var empty = document.getElementById('eb-chat-nodes-empty');
  var countBadge = document.getElementById('ce-node-count');
  if (!container) return;
  if (chatNodes.length === 0) {
    container.innerHTML = '';
    if (empty) empty.classList.remove('hidden');
    if (countBadge) countBadge.textContent = '0 nodes';
    return;
  }
  if (empty) empty.classList.add('hidden');
  if (countBadge) countBadge.textContent = chatNodes.length + ' node' + (chatNodes.length > 1 ? 's' : '');
  container.innerHTML = chatNodes.map(function(n, i) {
    var typeLabels = { text:'Text', number:'Number', choice:'Multiple Choice', rating:'Rating (1-5)', yes_no:'Yes/No' };
    var followLabels = { none:'No follow-up', shallow:'Light probe', deep:'Deep dive' };
    var qText = escapeHtml(n.question || 'Untitled');
    var isLast = i === chatNodes.length - 1;
    return '<div class="relative">' +
      (!isLast ? '<div class="absolute left-[18px] top-8 bottom-0 w-0.5 bg-gradient-to-b from-emerald-200 to-emerald-100 rounded-full"></div>' : '') +
      '<div class="p-3 rounded-xl border border-emerald-100 bg-white hover:border-emerald-200 hover:shadow-sm hover:shadow-emerald-100/50 transition-all cursor-pointer relative" data-nid="' + n.id + '" onclick="editChatNode(\'' + n.id + '\')">' +
        '<div class="flex items-start gap-2.5">' +
          '<div class="flex flex-col items-center gap-0.5 flex-shrink-0 pt-0.5">' +
            '<span class="w-7 h-7 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-500 text-white text-[10px] font-bold flex items-center justify-center shadow-sm shadow-emerald-200">' + (i + 1) + '</span>' +
          '</div>' +
          '<div class="flex-1 min-w-0">' +
            '<div class="text-xs font-medium text-gray-800 leading-relaxed line-clamp-3">' + qText + '</div>' +
            '<div class="flex items-center gap-1.5 mt-1.5 flex-wrap">' +
              '<span class="px-1.5 py-0.5 rounded-md bg-emerald-50 text-emerald-600 text-[8px] font-medium border border-emerald-100">' + (typeLabels[n.type] || n.type) + '</span>' +
              (n.follow_up_depth && n.follow_up_depth !== 'none' ? '<span class="px-1.5 py-0.5 rounded-md bg-purple-50 text-purple-500 text-[8px] font-medium border border-purple-100">' + (followLabels[n.follow_up_depth] || n.follow_up_depth) + '</span>' : '') +
              (n.options && n.options.length ? '<span class="px-1.5 py-0.5 rounded-md bg-blue-50 text-blue-500 text-[8px] font-medium border border-blue-100">' + n.options.length + ' opt</span>' : '') +
              (n.answer_scope && n.answer_scope.length ? '<span class="px-1.5 py-0.5 rounded-md bg-cyan-50 text-cyan-600 text-[8px] font-medium border border-cyan-100"><i class="fas ' + ({ absolute:'fa-lock', set:'fa-layer-group', near:'fa-wave-square' }[n.scope_type] || 'fa-filter') + '"></i> ' + n.answer_scope.length + ' ' + (n.scope_type || 'absolute') + '</span>' : '') +
            '</div>' +
            (n.condition ? '<div class="mt-1.5 text-[8px] text-amber-600 flex items-center gap-1 bg-amber-50/50 px-1.5 py-0.5 rounded-md border border-amber-100/50 w-fit"><i class="fas fa-code-branch text-[7px]"></i>If "' + escapeHtml(n.condition.field) + '" ' + escapeHtml(n.condition.operator) + ' "' + escapeHtml(n.condition.value) + '"</div>' : '') +
          '</div>' +
          '<div class="flex gap-0.5 flex-shrink-0 pt-1">' +
            '<button type="button" onclick="event.stopPropagation();editChatNode(\'' + n.id + '\')" class="w-6 h-6 rounded-md hover:bg-emerald-100 text-emerald-300 hover:text-emerald-600 transition-all text-[9px]" title="Edit"><i class="fas fa-pen"></i></button>' +
            '<button type="button" onclick="event.stopPropagation();removeChatNode(\'' + n.id + '\')" class="w-6 h-6 rounded-md hover:bg-red-50 text-red-300 hover:text-red-500 transition-all text-[9px]" title="Remove"><i class="fas fa-times"></i></button>' +
          '</div>' +
        '</div>' +
      '</div>' +
    '</div>';
  }).join('');
  updateChatNodeOrder();
}

function updateChatNodeOrder() {
  var items = document.querySelectorAll('#eb-chat-nodes [data-nid]');
  items.forEach(function(el, idx) {
    var numBadge = el.querySelector('.bg-gradient-to-br');
    if (numBadge) numBadge.textContent = (idx + 1);
  });
}

function editChatNode(id) {
  openChatNodeModal(id);
}

// --- Chat Node Modal ---
function openChatNodeModal(nodeId) {
  const isEdit = nodeId && chatNodes.some(function(n) { return n.id === nodeId; });
  document.getElementById('cn-modal-title').textContent = isEdit ? 'Edit Chat Node' : 'Add Chat Node';
  document.getElementById('cn-edit-id').value = isEdit ? nodeId : '';
  if (isEdit) {
    var node = chatNodes.find(function(n) { return n.id === nodeId; });
    document.getElementById('cn-question').value = node.question || '';
    document.getElementById('cn-type').value = node.type || 'text';
    document.getElementById('cn-followup').value = node.follow_up_depth || 'none';
    document.getElementById('cn-options').value = (node.options || []).join('\n');
    document.getElementById('cn-answer-scope').value = (node.answer_scope || []).join('\n');
    document.getElementById('cn-scope-label').value = node.scope_label || '';
    var scopeType = node.scope_type || 'none';
    document.querySelectorAll('.cn-scope-btn').forEach(function(b) {
      b.classList.remove('border-blue-500', 'bg-blue-50', 'text-blue-700', 'ring-2', 'ring-offset-1', 'ring-blue-300');
      b.classList.add('border-gray-200', 'bg-white', 'text-gray-500');
    });
    var activeBtn = document.querySelector('.cn-scope-btn[data-scope="' + scopeType + '"]');
    if (activeBtn) {
      activeBtn.classList.remove('border-gray-200', 'bg-white', 'text-gray-500');
      activeBtn.classList.add('border-blue-500', 'bg-blue-50', 'text-blue-700', 'ring-2', 'ring-offset-1', 'ring-blue-300');
    }
    toggleCnScopeFields(scopeType);
    document.getElementById('cn-cond-field').value = (node.condition && node.condition.field) || '';
    document.getElementById('cn-cond-op').value = (node.condition && node.condition.operator) || 'equals';
    document.getElementById('cn-cond-val').value = (node.condition && node.condition.value) || '';
  } else {
    document.getElementById('cn-question').value = '';
    document.getElementById('cn-type').value = 'text';
    document.getElementById('cn-followup').value = 'none';
    document.getElementById('cn-options').value = '';
    document.getElementById('cn-answer-scope').value = '';
    document.getElementById('cn-scope-label').value = '';
    document.querySelectorAll('.cn-scope-btn').forEach(function(b) {
      b.classList.remove('border-blue-500', 'bg-blue-50', 'text-blue-700', 'ring-2', 'ring-offset-1', 'ring-blue-300');
      b.classList.add('border-gray-200', 'bg-white', 'text-gray-500');
    });
    var noneBtn = document.querySelector('.cn-scope-btn[data-scope="none"]');
    if (noneBtn) {
      noneBtn.classList.remove('border-gray-200', 'bg-white', 'text-gray-500');
      noneBtn.classList.add('border-blue-500', 'bg-blue-50', 'text-blue-700', 'ring-2', 'ring-offset-1', 'ring-blue-300');
    }
    toggleCnScopeFields('none');
    document.getElementById('cn-cond-field').value = '';
    document.getElementById('cn-cond-op').value = 'equals';
    document.getElementById('cn-cond-val').value = '';
  }
  toggleCnOptions();
  document.getElementById('cn-modal').classList.remove('hidden');
  setTimeout(function() { document.getElementById('cn-question').focus(); }, 100);
}

function closeChatNodeModal() {
  document.getElementById('cn-modal').classList.add('hidden');
}

function toggleCnOptions() {
  var type = document.getElementById('cn-type').value;
  document.getElementById('cn-options-wrap').style.display = (type === 'choice' || type === 'rating') ? '' : 'none';
}

function selectCnScopeType(type, btn) {
  document.querySelectorAll('.cn-scope-btn').forEach(function(b) {
    b.classList.remove('border-blue-500', 'bg-blue-50', 'text-blue-700', 'ring-2', 'ring-offset-1', 'ring-blue-300');
    b.classList.add('border-gray-200', 'bg-white', 'text-gray-500');
  });
  btn.classList.remove('border-gray-200', 'bg-white', 'text-gray-500');
  btn.classList.add('border-blue-500', 'bg-blue-50', 'text-blue-700', 'ring-2', 'ring-offset-1', 'ring-blue-300');
  toggleCnScopeFields(type);
}

function toggleCnScopeFields(type) {
  var fields = document.getElementById('cn-scope-fields');
  var labelWrap = document.getElementById('cn-scope-label-wrap');
  var hint = document.getElementById('cn-scope-hint');
  if (type === 'none' || !type) {
    fields.classList.add('hidden');
  } else {
    fields.classList.remove('hidden');
    if (type === 'set') {
      labelWrap.classList.remove('hidden');
    } else {
      labelWrap.classList.add('hidden');
    }
    if (hint) {
      if (type === 'absolute') hint.textContent = 'Only these exact answers are accepted. Close misspellings require confirmation.';
      else if (type === 'set') hint.textContent = 'Category-based validation. AI checks if answer belongs to this category. Exact items get confirmed on misspelling.';
      else if (type === 'near') hint.textContent = 'Lenient matching. Accepts answers that are semantically related to the listed anchors.';
    }
  }
}

function saveChatNode() {
  var editId = document.getElementById('cn-edit-id').value;
  var question = document.getElementById('cn-question').value.trim();
  if (!question) { document.getElementById('cn-question').focus(); return; }
  var type = document.getElementById('cn-type').value;
  var followUp = document.getElementById('cn-followup').value;
  var optionsRaw = document.getElementById('cn-options').value;
  var options = optionsRaw ? optionsRaw.split('\n').map(function(s) { return s.trim(); }).filter(Boolean) : [];
  var scopeRaw = document.getElementById('cn-answer-scope').value;
  var answerScope = scopeRaw ? scopeRaw.split('\n').map(function(s) { return s.trim(); }).filter(Boolean) : [];
  var scopeTypeBtn = document.querySelector('.cn-scope-btn.border-blue-500');
  var scopeType = scopeTypeBtn ? scopeTypeBtn.getAttribute('data-scope') : 'none';
  var scopeLabel = document.getElementById('cn-scope-label').value.trim();
  var condField = document.getElementById('cn-cond-field').value.trim();
  var condOp = document.getElementById('cn-cond-op').value;
  var condVal = document.getElementById('cn-cond-val').value.trim();

  if (editId) {
    var node = chatNodes.find(function(n) { return n.id === editId; });
    if (node) {
      node.question = question;
      node.type = type;
      node.follow_up_depth = followUp;
      node.options = options;
      node.answer_scope = answerScope;
      node.scope_type = scopeType;
      node.scope_label = scopeLabel;
      node.placeholder = '';
      node.condition = (condField && condVal) ? { field: condField, operator: condOp, value: condVal } : null;
    }
  } else {
    var id = 'node_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4);
    var key = 'q_' + (chatNodes.length + 1);
    chatNodes.push({
      id: id, key: key, question: question, type: type, options: options,
      answer_scope: answerScope, scope_type: scopeType, scope_label: scopeLabel,
      follow_up_depth: followUp, placeholder: '',
      condition: (condField && condVal) ? { field: condField, operator: condOp, value: condVal } : null
    });
  }
  closeChatNodeModal();
  renderChatNodes();
  updateChatConfig();
}

function updateChatConfig() {
  const config = {
    nodes: chatNodes,
    intro_message: document.getElementById('eb-chat-intro')?.value || '',
    tone: document.getElementById('eb-chat-tone')?.value || 'neutral'
  };
  document.getElementById('eb-chat-config-input').value = JSON.stringify(config);
}

document.addEventListener('DOMContentLoaded', function() {
  initChatBuilder();
  const chatIntro = document.getElementById('eb-chat-intro');
  if (chatIntro) chatIntro.addEventListener('input', updateChatConfig);
  const chatTone = document.getElementById('eb-chat-tone');
  if (chatTone) chatTone.addEventListener('change', updateChatConfig);
});

// ============================================================
// AI CONFIG
// ============================================================
function selectAIProvider(provider) {
  document.querySelectorAll('[id^="eb-ai-p-"]').forEach(b => {
    b.classList.remove('ring-2', 'ring-purple-400', 'border-purple-400', 'bg-purple-50');
    b.classList.add('opacity-70');
  });
  const btn = document.getElementById('eb-ai-p-' + provider);
  if (btn) {
    btn.classList.remove('opacity-70');
    btn.classList.add('ring-2', 'ring-purple-400', 'border-purple-400', 'bg-purple-50');
  }
  const fields = document.getElementById('eb-ai-config-fields');
  const note = document.getElementById('eb-ai-provider-note');
  const keyField = document.getElementById('eb-ai-api-key');
  const keyBadge = document.getElementById('ce-key-badge');
  const freeProviders = ['pollinations', 'puter'];
  const apiProviders = ['gemini', 'openai', 'claude', 'deepseek'];
  const needsKey = apiProviders.includes(provider);
  if (provider === 'none') {
    fields.classList.add('hidden');
  } else {
    fields.classList.remove('hidden');
    if (keyField) keyField.parentElement.style.display = needsKey ? 'block' : 'none';
    if (keyBadge) {
      keyBadge.textContent = needsKey ? 'Required' : 'Not needed';
      keyBadge.className = 'text-[8px] px-1.5 py-0.5 rounded-full font-medium ' + (needsKey ? 'bg-amber-100 text-amber-600' : 'bg-emerald-100 text-emerald-600');
    }
    const notes = {
      puter: '<i class="fas fa-bolt text-emerald-400 mr-1.5"></i><strong>FREE Gemini via Puter.js</strong> — runs in the respondent\'s browser. No API key needed. Uses <code>puter.ai.chat</code> with model gemini-3.5-flash. Falls back to Pollinations for server-side calls.',
      pollinations: '<i class="fas fa-check-circle text-emerald-400 mr-1.5"></i><strong>100% FREE</strong> — open-source API, no key needed. Great for getting started. May have rate limits.',
      gemini: '<i class="fas fa-key text-amber-400 mr-1.5"></i>Requires a Gemini API key. <a href="https://aistudio.google.com/apikey" target="_blank" class="text-blue-500 underline">Get a free key from Google AI Studio</a>. For free Gemini without a key, use <strong>Puter</strong> above.',
      openai: '<i class="fas fa-key text-amber-400 mr-1.5"></i>Requires an OpenAI API key. <a href="https://platform.openai.com/api-keys" target="_blank" class="text-blue-500 underline">Get one here</a>.',
      claude: '<i class="fas fa-key text-amber-400 mr-1.5"></i>Requires an Anthropic API key. <a href="https://console.anthropic.com/" target="_blank" class="text-blue-500 underline">Get one here</a>.',
      deepseek: '<i class="fas fa-key text-amber-400 mr-1.5"></i>Requires a DeepSeek API key. <a href="https://platform.deepseek.com/" target="_blank" class="text-blue-500 underline">Get one here</a>.',
    };
    if (note) note.innerHTML = notes[provider] || '';
    loadAIModels(provider);
  }
  updateAIConfig();
}

let pendingAIModel = '';

function loadAIModels(provider) {
  const sel = document.getElementById('eb-ai-model');
  if (!sel) return;
  sel.innerHTML = '<option value="">Loading...</option>';
  fetch(getBasePath() + '/api/ai/models', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ provider: provider })
  })
  .then(r => r.json())
  .then(data => {
    const models = data.models || [];
    sel.innerHTML = '<option value="">Default</option>' + models.map(m => '<option value="' + m + '">' + m + '</option>').join('');
    if (pendingAIModel && models.includes(pendingAIModel)) {
      sel.value = pendingAIModel;
      pendingAIModel = '';
    }
  })
  .catch(() => {
    sel.innerHTML = '<option value="">Default</option>';
  });
}

function updateAIConfig() {
  const provider = document.querySelector('[id^="eb-ai-p-"].ring-2')?.id?.replace('eb-ai-p-', '') || 'none';
  const config = {
    provider: provider,
    api_key: document.getElementById('eb-ai-api-key')?.value || '',
    model: document.getElementById('eb-ai-model')?.value || '',
    capabilities: [],
    system_prompt: document.getElementById('eb-ai-system-prompt')?.value || '',
    temperature: parseFloat(document.getElementById('eb-ai-temperature')?.value || 0.7),
    max_tokens: parseInt(document.getElementById('eb-ai-max-tokens')?.value || 200),
  };
  if (document.getElementById('eb-ai-cap-sentiment')?.checked) config.capabilities.push('sentiment');
  if (document.getElementById('eb-ai-cap-followup')?.checked) config.capabilities.push('adaptive_followup');
  if (document.getElementById('eb-ai-cap-summarize')?.checked) config.capabilities.push('summarize');
  if (document.getElementById('eb-ai-cap-context')?.checked) config.capabilities.push('context_awareness');
  document.getElementById('eb-ai-config-input').value = JSON.stringify(config);
}

function initAIConfig() {
  const input = document.getElementById('eb-ai-config-input');
  if (!input || !input.value) return;
  try {
    const cfg = JSON.parse(input.value);
    if (cfg.provider && cfg.provider !== 'none') {
      pendingAIModel = cfg.model || '';
      setTimeout(function() { selectAIProvider(cfg.provider); }, 100);
      if (cfg.api_key) document.getElementById('eb-ai-api-key').value = cfg.api_key;
      if (cfg.system_prompt) document.getElementById('eb-ai-system-prompt').value = cfg.system_prompt;
      if (cfg.temperature) { document.getElementById('eb-ai-temperature').value = cfg.temperature; document.getElementById('eb-ai-temp-val').textContent = cfg.temperature; }
      if (cfg.max_tokens) { document.getElementById('eb-ai-max-tokens').value = cfg.max_tokens; document.getElementById('eb-ai-tokens-val').textContent = cfg.max_tokens; }
      if (cfg.capabilities) {
        if (cfg.capabilities.includes('sentiment')) document.getElementById('eb-ai-cap-sentiment').checked = true;
        if (cfg.capabilities.includes('adaptive_followup')) document.getElementById('eb-ai-cap-followup').checked = true;
        if (cfg.capabilities.includes('summarize')) document.getElementById('eb-ai-cap-summarize').checked = true;
        if (cfg.capabilities.includes('context_awareness')) document.getElementById('eb-ai-cap-context').checked = true;
      }
    }
  } catch(e) {}
}

document.addEventListener('DOMContentLoaded', function() {
  initAIConfig();
  ['eb-ai-api-key','eb-ai-model','eb-ai-system-prompt','eb-ai-temperature','eb-ai-max-tokens',
   'eb-ai-cap-sentiment','eb-ai-cap-followup','eb-ai-cap-summarize','eb-ai-cap-context'].forEach(function(id) {
    const el = document.getElementById(id);
    if (el) el.addEventListener('change', updateAIConfig);
    if (el && (el.type === 'text' || el.type === 'password' || el.tagName === 'TEXTAREA')) {
      el.addEventListener('input', updateAIConfig);
    }
  });
  const tempSlider = document.getElementById('eb-ai-temperature');
  if (tempSlider) {
    tempSlider.addEventListener('input', function() {
      document.getElementById('eb-ai-temp-val').textContent = this.value;
      updateAIConfig();
    });
  }
  const tokensSlider = document.getElementById('eb-ai-max-tokens');
  if (tokensSlider) {
    tokensSlider.addEventListener('input', function() {
      document.getElementById('eb-ai-tokens-val').textContent = this.value;
      updateAIConfig();
    });
  }
});

function showToast(msg, type) {
  const existing = document.querySelector('.toast-notif');
  if (existing) existing.remove();
  const t = document.createElement('div');
  t.className = 'toast-notif fixed bottom-6 right-6 z-[9999] px-4 py-3 rounded-xl shadow-2xl text-sm font-medium transition-all duration-300 translate-y-4 opacity-0 flex items-center gap-2';
  const icons = { success:'fa-check-circle text-emerald-400', error:'fa-exclamation-circle text-red-400', warning:'fa-triangle-exclamation text-amber-300', info:'fa-info-circle text-blue-400' };
  t.innerHTML = '<i class="fas ' + (icons[type] || icons.info) + '"></i> ' + msg;
  if (type === 'success') t.className += ' bg-emerald-900/90 text-white backdrop-blur-md border border-emerald-700/50';
  else if (type === 'error') t.className += ' bg-red-900/90 text-white backdrop-blur-md border border-red-700/50';
  else if (type === 'warning') t.className += ' bg-amber-800/90 text-white backdrop-blur-md border border-amber-600/50';
  else t.className += ' bg-gray-900/90 text-white backdrop-blur-md border border-gray-700/50';
  document.body.appendChild(t);
  requestAnimationFrame(() => { t.classList.remove('translate-y-4', 'opacity-0'); });
  setTimeout(() => { t.classList.add('translate-y-4', 'opacity-0'); setTimeout(() => t.remove(), 300); }, 2500);
}

// ============================================================
// FORM SUBMIT — serialize
// ============================================================
document.getElementById('survey-form').addEventListener('submit', function(e) {
  const mode = document.querySelector('input[name="survey_type"]:checked');
  const isChat = mode && mode.value === 'chat';
  if (!isChat && questions.length === 0) { e.preventDefault(); showToast('Add at least one question before saving', 'error'); return; }
  serializeForm();
  formDirty = false;
  showToast('Saving survey...', 'info');
});

window.addEventListener('beforeunload', function(e) {
  if (formDirty) {
    e.preventDefault();
    e.returnValue = '';
  }
});

document.getElementById('survey-form').addEventListener('input', function() { formDirty = true; });
document.getElementById('survey-form').addEventListener('change', function() { formDirty = true; });
document.getElementById('survey-form').addEventListener('click', function(e) {
  if (e.target.tagName === 'BUTTON' || e.target.closest('button')) formDirty = true;
});

// ============================================================
// LIVE TITLE/DESC SYNC
// ============================================================
const st = document.getElementById('survey-title');
const sd = document.getElementById('survey-desc');
if (st) st.addEventListener('input', updatePreviewQuestions);
if (sd) sd.addEventListener('input', updatePreviewQuestions);

// ============================================================
// QUIZ SETTINGS TOGGLE
// ============================================================
function toggleQuizPanel() {
  const seq = document.querySelector('input[name="qc[sequential_unlock]"]');
  const quiz = document.querySelector('input[name="qc[quiz_mode]"]');
  const panel = document.getElementById('quiz-settings-eb');
  const panelCe = document.getElementById('quiz-settings-ce');
  const show = (seq && seq.checked) || (quiz && quiz.checked);
  if (panel) panel.classList.toggle('hidden', !show);
  if (panelCe) panelCe.classList.toggle('hidden', !show);
}
document.querySelectorAll('input[name^="qc["]').forEach(cb => {
  cb.addEventListener('change', toggleQuizPanel);
});
toggleQuizPanel();

// ============================================================
function togglePasswordFieldEB() {
  const sel = document.querySelector('input[name="qc[auth_type]"]:checked');
  const wrap = document.getElementById('eb-password-field-wrap');
  if (wrap) wrap.classList.toggle('hidden', !sel || sel.value !== 'password');
}
document.querySelectorAll('input[name="qc[auth_type]"]').forEach(r => {
  r.addEventListener('change', togglePasswordFieldEB);
});
togglePasswordFieldEB();

// INIT
// ============================================================
['eb-settings','eb-vis-body','eb-access-body','eb-qc','eb-branding'].forEach(id => {
  const el = document.getElementById(id);
  if (el) el.dataset.fullHeight = el.scrollHeight + 'px';
});

// Initial render
renderQuestions();
updatePreviewQuestions();
updatePreview();
updateUndoButtons();

// Close delete modal on Escape
document.addEventListener('keydown', function(e) {
  if (e.key === 'Escape') { closeModal(); closeDelModal(); }
});

function escapeHtml(str) { if (!str) return ''; const d = document.createElement('div'); d.textContent = str; return d.innerHTML; }

// ============================================================
// BULK IMPORT
// ============================================================
function openBulkImport() {
  document.getElementById('bulk-modal').classList.remove('hidden');
  document.getElementById('bulk-modal').classList.add('flex');
  document.body.style.overflow = 'hidden';
}
function closeBulkImport() {
  document.getElementById('bulk-modal').classList.remove('flex');
  document.getElementById('bulk-modal').classList.add('hidden');
  document.body.style.overflow = '';
}
function importBulkQuestions() {
  const raw = document.getElementById('bulk-text').value.trim();
  if (!raw) { showToast('Paste your questions first.', 'warning'); return; }
  const blocks = raw.split(/\n\s*\n/).filter(b => b.trim());
  let imported = 0;
  const beforeImport = JSON.parse(JSON.stringify(questions));
  blocks.forEach(function(block) {
    const lines = block.split('\n').map(l => l.trim()).filter(l => l);
    if (lines.length === 0) return;
    const firstLine = lines[0];
    const colonIdx = firstLine.indexOf(':');
    if (colonIdx === -1) return;
    const type = firstLine.substring(0, colonIdx).trim().toLowerCase();
    const text = firstLine.substring(colonIdx + 1).trim();
    if (!type || !text) return;
    const validTypes = ['text','number','email','phone','textarea','url','yes_no','rating','mcq_single','mcq_multiple','dropdown','nps','ranking','date','time','datetime','color','percentage','signature','slider','likert5','likert7','matrix','file_upload','multi_text','address'];
    if (!validTypes.includes(type)) return;
    const q = { id:++qIdCounter, question_text:text, type, is_required:true, is_attention_check:false, is_trap:false, is_speed_bump:false, is_timed:false, time_limit_seconds:null, min_value:null, max_value:null, char_limit:null, min_length:null, max_length:null, allow_paste:true, options:null, rows:null, expected_answer:null, animation:null, accent_color:null, placeholder:null, hint:null, image_url:null, shuffle_options:false };
    if (lines.length > 1) {
      const opts = lines.slice(1);
      if (type === 'matrix') {
        const midpoint = Math.ceil(opts.length / 2);
        q.rows = opts.slice(0, midpoint);
        q.options = opts.slice(midpoint);
      } else {
        q.options = opts;
      }
    }
    questions.push(q);
    imported++;
  });
  if (imported > 0) {
    undoStack.push(beforeImport);
    if (undoStack.length > MAX_UNDO) undoStack.shift();
    redoStack = [];
    updateUndoButtons();
    showToast('Imported ' + imported + ' question(s)!', 'success');
    closeBulkImport();
    renderQuestions();
    updatePreviewQuestions();
  } else {
    showToast('No valid questions found. Check the format.', 'error');
  }
}

let lastAISuggestions = [];

function addAISuggestion(index) {
  if (!lastAISuggestions[index]) return;
  pushUndo();
  const s = lastAISuggestions[index];
  const q = {
    id: ++qIdCounter,
    question_text: s.question_text,
    type: s.type,
    is_required: true,
    is_attention_check: false,
    is_trap: false,
    is_speed_bump: false,
    is_timed: false,
    time_limit_seconds: null,
    min_value: null,
    max_value: null,
    char_limit: null,
    min_length: null,
    max_length: null,
    allow_paste: true,
    options: s.options || null,
    rows: null,
    expected_answer: null,
    animation: null,
    accent_color: null,
    placeholder: null,
    hint: null,
    image_url: null,
    shuffle_options: false,
    include_other: true,
  };
  questions.push(q);
  renderQuestions();
  updatePreviewQuestions();
  selectQuestion(questions.length - 1);
  showToast('Question added!', 'success');
}

function refineAISuggestion(index) {
  if (!lastAISuggestions[index]) return;
  const s = lastAISuggestions[index];
  document.getElementById('ai-chat-input').value = 'Can you make the following question better: ' + s.question_text + ' (type: ' + s.type + '). Make it more engaging and clear.';
  document.getElementById('ai-chat-input').focus();
}

// ===== AI Assistant Panel =====
let aiPanelOpen = false;

function toggleAIPanel() {
  aiPanelOpen = !aiPanelOpen;
  document.getElementById('ai-assistant-panel').classList.toggle('translate-x-full', !aiPanelOpen);
  document.getElementById('ai-assistant-overlay').classList.toggle('hidden', !aiPanelOpen);
}

function switchAITab(tab) {
  document.querySelectorAll('.ai-tab').forEach(t => {
    t.classList.remove('border-blue-500', 'text-blue-600');
    t.classList.add('border-transparent', 'text-gray-500');
  });

  const generatePane = document.getElementById('ai-pane-generate');
  const chatPane = document.getElementById('ai-pane-chat');
  if (generatePane) generatePane.classList.add('hidden');
  if (chatPane) chatPane.classList.add('hidden');

  if (tab === 'generate') {
    if (generatePane) generatePane.classList.remove('hidden');
    const btn = document.querySelector('[onclick="switchAITab(\'generate\')"]');
    if (btn) {
      btn.classList.remove('border-transparent', 'text-gray-500');
      btn.classList.add('border-blue-500', 'text-blue-600');
    }
  } else {
    if (chatPane) chatPane.classList.remove('hidden');
    const btn = document.querySelector('[onclick="switchAITab(\'chat\')"]');
    if (btn) {
      btn.classList.remove('border-transparent', 'text-gray-500');
      btn.classList.add('border-blue-500', 'text-blue-600');
    }
  }
}

function addFromAIGen(index) {
  const items = window._lastAIGen;
  if (!items || !items[index]) return;
  const q = items[index];
  pushUndo();
  const newQ = {
    id: ++qIdCounter,
    question_text: q.question_text || '',
    type: q.type || 'text',
    is_required: true,
    is_attention_check: false, is_trap: false, is_speed_bump: false, is_timed: false,
    time_limit_seconds: null, min_value: null, max_value: null, char_limit: null,
    min_length: null, max_length: null, allow_paste: true,
    options: q.options || null, rows: null, expected_answer: null,
    animation: null, accent_color: null, placeholder: null, hint: null,
    image_url: null, shuffle_options: false, include_other: true,
  };
  questions.push(newQ);
  renderQuestions();
  updatePreviewQuestions();
  selectQuestion(questions.length - 1);
  showToast('Question added!', 'success');
}

function aiChatSend() {
  const input = document.getElementById('ai-chat-input');
  const msg = input.value.trim();
  if (!msg) return;
  input.value = '';

  const chatBox = document.getElementById('ai-chat-box');
  chatBox.innerHTML += '<div class="flex justify-end"><div class="max-w-[85%] px-3 py-2 rounded-2xl bg-blue-500 text-white text-xs">' + escHtml(msg) + '</div></div>';
  chatBox.scrollTop = chatBox.scrollHeight;

  const provider = document.getElementById('ai-panel-provider').value;
  const apiKey = document.getElementById('ai-panel-key').value;
  const model = document.getElementById('ai-panel-model').value;
  const modeGuide = getModePrompt();

  const history = [];
  document.querySelectorAll('#ai-chat-box > div').forEach(d => {
    const textEl = d.querySelector('.bg-blue-500, .bg-gray-100');
    if (!textEl) return;
    const role = d.classList.contains('justify-end') ? 'user' : 'assistant';
    history.push({role: role, content: textEl.textContent});
  });

  const loadingId = 'ai-loading-' + Date.now();
  chatBox.innerHTML += '<div id="' + loadingId + '" class="flex justify-start"><div class="max-w-[85%] px-3 py-2 rounded-2xl bg-gray-100 text-gray-600 text-xs"><i class="fas fa-spinner fa-spin mr-1"></i>Thinking...</div></div>';
  chatBox.scrollTop = chatBox.scrollHeight;

  const freeProviders = ['pollinations', 'puter'];
  const isFreeProvider = freeProviders.includes(provider);

  const request = isFreeProvider
    ? fetch(getBasePath() + '/api/ai/suggest', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ prompt: msg, history: history })
      }).then(r => r.json()).then(data => {
        if (data.success && Array.isArray(data.suggestions) && data.suggestions.length > 0) {
          const top = data.suggestions[0];
          const extra = data.suggestions.slice(1, 3).map(s => '• ' + (s.question_text || '')).filter(Boolean);
          return {
            success: true,
            text: (top.question_text || 'Here is a suggestion.') + (extra.length ? '\n\nMore ideas:\n' + extra.join('\n') : '')
          };
        }
        return { success: false, error: data.error || 'No suggestion generated' };
      })
    : fetch(getBasePath() + '/api/ai/chat', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          provider: provider,
          api_key: apiKey,
          model: model,
          messages: history,
          system_prompt: modeGuide + ' Be concise, practical, and specific to the user\'s survey context.',
          temperature: 0.7,
          max_tokens: 600,
        })
      }).then(r => r.json());

  request
    .then(data => {
      document.getElementById(loadingId)?.remove();
      const reply = data.success ? data.text : ('Error: ' + (data.error || 'Unknown'));
      chatBox.innerHTML += '<div class="flex justify-start"><div class="max-w-[85%] px-3 py-2 rounded-2xl bg-gray-100 text-gray-700 text-xs">' + escHtml(reply) + '</div></div>';
      chatBox.scrollTop = chatBox.scrollHeight;
    })
    .catch(err => {
      document.getElementById(loadingId)?.remove();
      chatBox.innerHTML += '<div class="flex justify-start"><div class="max-w-[85%] px-3 py-2 rounded-2xl bg-red-50 text-red-500 text-xs">Error: ' + escHtml(err.message) + '</div></div>';
    });
}

function updateAIModeBadge() {
  const badge = document.getElementById('ai-mode-badge');
  if (!badge) return;
  const mode = getSurveyMode();
  badge.textContent = mode === 'chat' ? 'Chat Survey' : 'Form Survey';
  badge.className = 'inline-block ml-1 px-1.5 py-0.5 rounded-full text-[8px] font-medium ' +
    (mode === 'chat' ? 'bg-purple-50 text-purple-600' : 'bg-blue-50 text-blue-600');
  const greeting = document.getElementById('ai-greeting-text');
  if (greeting) {
    greeting.textContent = mode === 'chat'
      ? "Hi! I'm your AI assistant for building CHAT surveys. Ask me about conversation flow, AI interviewer tone, branching logic, or quiz mode."
      : "Hi! I'm your AI assistant for building FORM surveys. Ask me about question wording, types, structure, skip logic, or respondent experience.";
  }
}

document.addEventListener('change', function(e) {
  if (e.target && e.target.name === 'survey_type') {
    setTimeout(updateAIModeBadge, 50);
  }
});

setTimeout(updateAIModeBadge, 200);
setTimeout(aiPanelProviderChange, 0);

function aiPanelProviderChange() {
  const p = document.getElementById('ai-panel-provider').value;
  const keyRow = document.getElementById('ai-panel-key-row');
  const hint = document.getElementById('ai-panel-hint');
  const freeProviders = ['pollinations', 'puter'];

  if (freeProviders.includes(p)) {
    keyRow.classList.add('hidden');
    if (p === 'pollinations') hint.innerHTML = '<i class="fas fa-check-circle text-emerald-500 mr-1"></i>100% FREE — no key needed. Uses open-source models via text.pollinations.ai.';
    else hint.innerHTML = '<i class="fas fa-bolt text-emerald-500 mr-1"></i>Free Gemini via Puter.js — runs in browser. Server-side calls fallback to Pollinations.';
  } else {
    keyRow.classList.remove('hidden');
    if (p === 'gemini') hint.innerHTML = '<i class="fas fa-info-circle text-blue-500 mr-1"></i>Free API key from <a href="https://aistudio.google.com/apikey" target="_blank" class="underline">Google AI Studio</a> — generous free tier.';
    else if (p === 'openai') hint.innerHTML = '<i class="fas fa-info-circle text-blue-500 mr-1"></i>Get a key at <a href="https://platform.openai.com/api-keys" target="_blank" class="underline">platform.openai.com</a>';
    else if (p === 'claude') hint.innerHTML = '<i class="fas fa-info-circle text-blue-500 mr-1"></i>Get a key at <a href="https://console.anthropic.com/" target="_blank" class="underline">console.anthropic.com</a>';
    else if (p === 'deepseek') hint.innerHTML = '<i class="fas fa-info-circle text-blue-500 mr-1"></i>Get a key at <a href="https://platform.deepseek.com/" target="_blank" class="underline">platform.deepseek.com</a>';
    else hint.innerHTML = '';
  }

  const models = {pollinations:['openai','llama','deepseek'],puter:['gemini-3.5-flash','gemini-3.1-pro-preview','gpt-4o','claude-sonnet-4-20250514'],gemini:['gemini-2.0-flash','gemini-1.5-pro','gemini-1.5-flash'],openai:['gpt-4o','gpt-4o-mini','gpt-3.5-turbo'],claude:['claude-sonnet-4-20250514','claude-3.5-haiku-20241022'],deepseek:['deepseek-chat','deepseek-reasoner']};
  const sel = document.getElementById('ai-panel-model');
  sel.innerHTML = '';
  (models[p] || []).forEach(m => { const o = document.createElement('option'); o.value = m; o.textContent = m; sel.appendChild(o); });
}

function getModePrompt() {
  const mode = getSurveyMode();
  if (mode === 'chat') {
    return 'You are helping design a conversational CHAT survey. The survey uses an AI interviewer that asks questions one at a time in a natural conversation. Focus on: conversation flow, follow-up questions, branching logic, tone/persona, intro messages, and quiz mode. Generate questions that feel natural in dialogue, not like a traditional form.';
  }
  return 'You are helping design a traditional FORM survey. Focus on: clear unbiased question wording, appropriate question types (rating, MCQ, likert, text, etc.), survey structure, skip logic, and respondent experience. Generate well-structured form questions.';
}

function aiGenerate() {
  const topic = document.getElementById('ai-generate-input').value.trim();
  const count = document.getElementById('ai-generate-count').value;
  const btn = document.getElementById('ai-generate-btn');
  const output = document.getElementById('ai-generate-output');
  const mode = getSurveyMode();

  if (!topic || topic.length < 3) { showToast('Please describe what questions you need', 'warning'); return; }

  btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Generating...';
  output.innerHTML = '<div class="flex items-center gap-2 text-gray-400 text-xs py-4"><i class="fas fa-spinner fa-spin"></i> Generating questions for ' + mode + ' survey...</div>';

  fetch(getBasePath() + '/api/questions/generate', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ text: topic, count: Number(count), mode: mode })
  })
  .then(r => r.json())
  .then(data => {
    btn.disabled = false; btn.innerHTML = '<i class="fas fa-wand-magic-sparkles"></i> Generate';
    if (!data.success) { output.innerHTML = '<div class="text-red-500 text-xs">Error: ' + (data.error || 'Failed') + '</div>'; return; }

    const questions = Array.isArray(data.questions) ? data.questions : [];
    if (questions.length === 0) {
      output.innerHTML = '<div class="text-amber-600 text-xs">No questions generated. Try adding more detail.</div>';
      return;
    }

    output.innerHTML = '';
    questions.forEach((q, i) => {
      const div = document.createElement('div');
      div.className = 'p-3 rounded-xl border border-gray-100 hover:border-blue-200 bg-white transition-all cursor-pointer group';
      div.innerHTML = '<div class="flex items-start gap-2"><span class="text-xs font-bold text-blue-500 mt-0.5">#' + (i+1) + '</span><div class="flex-1 min-w-0"><div class="text-xs font-medium text-gray-800">' + escHtml(q.question_text || '') + '</div><div class="flex items-center gap-1.5 mt-1"><span class="text-[9px] px-1.5 py-0.5 rounded-full bg-blue-50 text-blue-600">' + (q.type || 'text') + '</span>' + (q.explanation ? '<span class="text-[9px] text-gray-400">' + escHtml(q.explanation) + '</span>' : '') + (q.follow_up ? '<span class="text-[9px] text-purple-400">follow-up: ' + escHtml(q.follow_up) + '</span>' : '') + '</div></div><button onclick="addFromAIGen(' + i + ')" class="text-[9px] px-2 py-1 rounded-lg bg-blue-50 text-blue-600 hover:bg-blue-100 opacity-0 group-hover:opacity-100 transition-all flex-shrink-0" data-aiq=\'' + escJson(JSON.stringify(q)) + '\'><i class="fas fa-plus mr-0.5"></i>Add</button></div>';
      output.appendChild(div);
    });
    window._lastAIGen = questions;
    showToast('Generated ' + questions.length + ' ' + mode + ' questions', 'success');
  })
  .catch(err => {
    btn.disabled = false; btn.innerHTML = '<i class="fas fa-wand-magic-sparkles"></i> Generate';
    output.innerHTML = '<div class="text-red-500 text-xs">Request failed: ' + err.message + '</div>';
  });
}

function escHtml(s) { const d = document.createElement('div'); d.textContent = s; return d.innerHTML; }
function escJson(s) { return s.replace(/'/g, "\\'"); }

document.addEventListener('keydown', function(e) {
  if (e.key === 'Escape' && aiPanelOpen) toggleAIPanel();
});
</script>

<!-- AI Assistant Panel -->
<div id="ai-assistant-overlay" class="hidden fixed inset-0 bg-black/20 backdrop-blur-sm z-40 transition-all" onclick="toggleAIPanel()"></div>
<div id="ai-assistant-panel" class="fixed top-0 right-0 h-full w-full max-w-md bg-white shadow-2xl z-50 transform translate-x-full transition-transform duration-300 flex flex-col">
  <!-- Header -->
  <div class="flex items-center justify-between px-5 py-4 border-b border-gray-100">
    <div class="flex items-center gap-2">
      <span class="w-8 h-8 rounded-xl bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white text-sm"><i class="fas fa-wand-magic-sparkles"></i></span>
      <div>
        <div class="text-sm font-bold text-gray-900">AI Assistant</div>
        <div class="text-[10px] text-gray-400">Free — Pick a provider below <span id="ai-mode-badge" class="inline-block ml-1 px-1.5 py-0.5 rounded-full text-[8px] font-medium bg-blue-50 text-blue-600"></span></div>
      </div>
    </div>
    <button onclick="toggleAIPanel()" class="w-8 h-8 rounded-xl hover:bg-gray-100 flex items-center justify-center text-gray-400"><i class="fas fa-times"></i></button>
  </div>

  <!-- Provider Config -->
  <div class="px-5 py-3 border-b border-gray-50 bg-gray-50/50 space-y-2">
    <div class="flex gap-2">
      <select id="ai-panel-provider" onchange="aiPanelProviderChange()" class="flex-1 px-2.5 py-1.5 rounded-lg text-[10px] border border-gray-200 bg-white">
        <option value="pollinations">Pollinations (FREE — no key)</option>
        <option value="puter">Puter (FREE Gemini — browser)</option>
        <option value="gemini" selected>Gemini (needs API key)</option>
        <option value="openai">OpenAI (needs API key)</option>
        <option value="claude">Claude (needs API key)</option>
        <option value="deepseek">DeepSeek (needs API key)</option>
      </select>
      <select id="ai-panel-model" class="px-2.5 py-1.5 rounded-lg text-[10px] border border-gray-200 bg-white">
        <option value="openai">openai</option>
        <option value="llama">llama</option>
        <option value="deepseek">deepseek</option>
      </select>
    </div>
    <div id="ai-panel-key-row">
      <input type="password" id="ai-panel-key" class="w-full px-2.5 py-1.5 rounded-lg text-[10px] border border-gray-200 bg-white" placeholder="API Key from Google AI Studio (free)">
    </div>
    <div id="ai-panel-hint" class="text-[10px] text-gray-500"><i class="fas fa-info-circle text-blue-500 mr-1"></i>Free API key from <a href="https://aistudio.google.com/apikey" target="_blank" class="underline">Google AI Studio</a> — generous free tier.</div>
  </div>

  <!-- Tabs -->
  <div class="flex border-b border-gray-100 px-5">
    <button onclick="switchAITab('generate')" class="ai-tab border-b-2 border-blue-500 text-blue-600 px-4 py-3 text-xs font-medium transition-all">Generate Questions</button>
    <button onclick="switchAITab('chat')" class="ai-tab border-b-2 border-transparent text-gray-500 px-4 py-3 text-xs font-medium transition-all">Chat</button>
  </div>

  <!-- Generate Tab -->
  <div id="ai-pane-generate" class="flex-1 flex flex-col p-5 overflow-y-auto">
    <div class="flex gap-2 mb-3">
      <input type="text" id="ai-generate-input" class="flex-1 px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-blue-500 outline-none" placeholder="What questions do you need? e.g. Customer satisfaction about our new app">
      <select id="ai-generate-count" class="w-16 px-2 py-2 rounded-xl text-xs border border-gray-200 bg-white">
        <option value="3">3</option><option value="5" selected>5</option><option value="8">8</option><option value="10">10</option>
      </select>
    </div>
    <button id="ai-generate-btn" onclick="aiGenerate()" class="w-full px-4 py-2.5 rounded-xl bg-gradient-to-r from-blue-500 to-purple-600 text-white text-sm font-medium hover:from-blue-600 hover:to-purple-700 transition-all shadow-sm mb-4 flex items-center justify-center gap-2">
      <i class="fas fa-wand-magic-sparkles"></i> Generate Questions
    </button>
    <div id="ai-generate-output" class="space-y-2 min-h-[100px]">
      <div class="text-center text-gray-400 text-xs py-8"><i class="fas fa-lightbulb text-2xl mb-2 block opacity-50"></i>Describe your survey topic above and click Generate</div>
    </div>
  </div>

  <!-- Chat Tab -->
  <div id="ai-pane-chat" class="hidden flex-1 flex flex-col">
    <div id="ai-chat-box" class="flex-1 p-5 overflow-y-auto space-y-3">
      <div class="flex justify-start">
        <div class="max-w-[85%] px-3 py-2 rounded-2xl bg-gray-100 text-gray-600 text-xs" id="ai-chat-greeting">
          <span id="ai-greeting-text">Hi! I'm your survey design assistant. Ask me anything about creating better surveys, improving questions, or survey methodology.</span>
        </div>
      </div>
    </div>
    <div class="p-4 border-t border-gray-100">
      <div class="flex gap-2">
        <input type="text" id="ai-chat-input" class="flex-1 px-3 py-2.5 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-blue-500 outline-none" placeholder="Ask anything about your survey..." onkeydown="if(event.key==='Enter')aiChatSend()">
        <button onclick="aiChatSend()" class="px-4 py-2.5 rounded-xl bg-blue-500 text-white hover:bg-blue-600 transition-all text-sm"><i class="fas fa-paper-plane"></i></button>
      </div>
    </div>
  </div>
</div>

<style>
#ai-assistant-panel { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif; }
#ai-assistant-panel ::-webkit-scrollbar { width: 4px; }
#ai-assistant-panel ::-webkit-scrollbar-thumb { background: #ddd; border-radius: 4px; }
#ai-assistant-panel ::-webkit-scrollbar-track { background: transparent; }
#ai-chat-box { scroll-behavior: smooth; }
#ai-chat-box > div { animation: fadeIn 0.2s ease-out; }
@keyframes fadeIn { from { opacity: 0; transform: translateY(4px); } to { opacity: 1; transform: translateY(0); } }
</style>
