<div class="max-w-7xl mx-auto">
  <!-- Header -->
  <div class="flex items-center justify-between flex-wrap gap-3 mb-6 slide-up">
    <div class="flex items-center gap-3">
      <div>
        <div class="flex items-center gap-2">
          <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-emerald-600 flex items-center justify-center shadow-lg shadow-emerald-200">
            <i class="fas fa-comment-dots text-white text-lg"></i>
          </div>
          <div>
            <h1 class="text-xl font-bold text-gray-900">Create Chat Survey</h1>
            <p class="text-gray-500 text-xs mt-0.5">Design an AI-powered conversation</p>
          </div>
        </div>
      </div>
    </div>
    <div class="flex items-center gap-2">
      <span id="auto-save-indicator" class="text-[10px] text-gray-400 flex items-center gap-1"><i class="fas fa-save"></i> <span id="auto-save-text">Ready</span></span>
      <button type="button" onclick="toggleKbHelp()" class="px-3 py-2 border border-gray-200 rounded-xl hover:bg-gray-50 transition-all text-xs font-medium flex items-center gap-1.5"><i class="fas fa-keyboard text-gray-400"></i> Shortcuts</button>
    </div>
  </div>

  <form method="POST" action="<?= url('/survey/create') ?>" id="survey-form" class="grid grid-cols-1 lg:grid-cols-3 gap-6">
    <?= csrf() ?>
    <input type="hidden" name="template_key" id="template-key-input" value="">
    <input type="hidden" name="questions_json" id="questions-json" value="">
    <input type="hidden" name="theme_config" id="theme-config-input" value="">
    <input type="hidden" name="chat_config" id="chat-config-input" value="<?= htmlspecialchars($chatConfigJson ?? '') ?>">
    <input type="hidden" name="ai_config" id="ai-config-input" value="<?= htmlspecialchars($aiConfigJson ?? '') ?>">
    <input type="hidden" name="survey_type" value="chat">

    <!-- Left Column -->
    <div class="lg:col-span-2 space-y-5">

      <!-- === SURVEY IDENTITY === -->
      <div class="glass-card rounded-2xl p-5 overflow-hidden animate-fade-in-up" style="animation-delay:0.05s">
        <div class="flex items-center justify-between mb-4">
          <h2 class="text-base font-bold text-gray-900"><i class="fas fa-pencil-ruler text-emerald-500 mr-2"></i>Survey Identity</h2>
          <button type="button" onclick="toggleSection('ci-identity', this)" class="text-xs text-gray-400 hover:text-gray-600 transition-all"><i class="fas fa-chevron-up"></i></button>
        </div>
        <div id="ci-identity">
          <div class="mb-4">
            <input type="text" name="title" id="survey-title" value="" required maxlength="500" class="w-full px-4 py-3 rounded-xl text-base font-semibold border border-gray-200 focus:ring-2 focus:ring-emerald-500 bg-white/70 backdrop-blur-sm transition-all" placeholder="Give your chat survey a clear title...">
          </div>
          <div class="mb-4">
            <textarea name="description" id="survey-desc" rows="2" class="w-full px-4 py-3 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-emerald-500 bg-white/70 backdrop-blur-sm transition-all resize-none" placeholder="Briefly describe what this conversation is about..."></textarea>
          </div>
        </div>
      </div>

      <!-- === TEMPLATES === -->
      <div class="glass-card rounded-2xl p-5 overflow-hidden animate-fade-in-up" style="animation-delay:0.08s">
        <div class="flex items-center justify-between mb-4">
          <h2 class="text-base font-bold text-gray-900"><i class="fas fa-layer-group text-emerald-500 mr-2"></i>Templates</h2>
          <div class="flex gap-2">
            <button type="button" onclick="showTemplates()" class="text-xs px-3 py-1.5 rounded-lg bg-emerald-100 text-emerald-700 hover:bg-emerald-200 transition-all font-medium flex items-center gap-1"><i class="fas fa-template"></i> Browse Templates</button>
            <button type="button" onclick="toggleSection('ci-templates', this)" class="text-xs text-gray-400 hover:text-gray-600"><i class="fas fa-chevron-down"></i></button>
          </div>
        </div>
        <div id="ci-templates" style="max-height:0px;overflow:hidden">
          <div id="template-cards" class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2 mb-3"></div>
          <p class="text-[10px] text-gray-400">Select a template to pre-populate chat nodes. <button type="button" onclick="showTemplates()" class="text-emerald-600 hover:text-emerald-700 font-medium">Browse all templates</button></p>
        </div>
      </div>

      <!-- === CHAT BUILDER === -->
      <div class="glass-card rounded-2xl p-5 animate-fade-in-up" style="animation-delay:0.1s">
        <div class="flex items-center justify-between mb-4">
          <div>
            <h2 class="text-base font-bold text-gray-900"><i class="fas fa-comments text-emerald-500 mr-2"></i>Chat Builder</h2>
            <p class="text-[11px] text-gray-400 mt-0.5">Design your conversation flow</p>
          </div>
          <div class="flex items-center gap-2">
            <span class="text-xs text-gray-500 font-medium" id="node-count">0 nodes</span>
            <button type="button" onclick="toggleSection('ci-chat-builder', this)" class="text-xs text-gray-400 hover:text-gray-600"><i class="fas fa-chevron-up"></i></button>
          </div>
        </div>
        <div id="ci-chat-builder" style="max-height:none;overflow:visible">
          <div class="mb-4">
            <label class="block text-xs font-medium text-gray-600 mb-1">Intro Message</label>
            <textarea id="chat-intro" rows="2" class="w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-emerald-500 outline-none resize-none transition-all" placeholder="Welcome message for respondents..." oninput="updateChatConfig();updateChatPreview()"><?= htmlspecialchars((json_decode($chatConfigJson ?? '{}', true) ?? [])['intro_message'] ?? '') ?></textarea>
          </div>
          <div class="mb-4">
            <label class="block text-xs font-medium text-gray-600 mb-1">Conversation Tone</label>
            <select id="chat-tone" class="w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-emerald-500 outline-none transition-all" onchange="updateChatConfig();updateChatPreview()">
              <option value="neutral">Neutral</option>
              <option value="friendly">Friendly</option>
              <option value="formal">Formal</option>
              <option value="empathetic">Empathetic</option>
            </select>
          </div>
          <div>
            <div class="flex items-center justify-between mb-2">
              <label class="text-xs font-semibold text-gray-700">Questions / Nodes</label>
              <button type="button" onclick="addChatNode()" class="text-xs px-3 py-1.5 rounded-lg bg-emerald-100 text-emerald-700 hover:bg-emerald-200 transition-all font-medium flex items-center gap-1"><i class="fas fa-plus-circle"></i> Add Question</button>
            </div>
            <div id="chat-nodes-list" class="space-y-2 min-h-[120px] relative">
              <div id="chat-nodes-empty" class="flex flex-col items-center justify-center py-14 border-2 border-dashed border-emerald-200 rounded-xl bg-emerald-50/30">
                <div class="w-16 h-16 mx-auto rounded-2xl bg-emerald-100 flex items-center justify-center mb-3">
                  <i class="fas fa-comment-plus text-emerald-400 text-2xl"></i>
                </div>
                <p class="text-sm text-gray-500 font-semibold">No questions yet</p>
                <p class="text-[11px] text-gray-400 mt-1">Click <strong class="text-emerald-600">Add Question</strong> to start building your chat flow</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- === AI ENGINE CONFIGURATION === -->
      <div class="glass-card rounded-2xl p-5 animate-fade-in-up" style="animation-delay:0.12s">
        <div class="flex items-center justify-between mb-4">
          <h2 class="text-base font-bold text-gray-900"><i class="fas fa-brain text-emerald-500 mr-2"></i>AI Engine Configuration</h2>
          <button type="button" onclick="toggleSection('ci-ai-config', this)" class="text-xs text-gray-400 hover:text-gray-600"><i class="fas fa-chevron-up"></i></button>
        </div>
        <div id="ci-ai-config" style="max-height:none;overflow:visible">
          <div class="flex gap-1.5 mb-4 flex-wrap" id="ai-provider-picker">
            <button type="button" onclick="selectAIProvider('none')" id="ai-p-none" class="flex-1 min-w-[60px] px-2.5 py-2 rounded-lg text-[10px] font-semibold border-2 transition-all text-gray-500 border-gray-200 bg-gray-50/50 hover:border-gray-300"><i class="fas fa-times-circle mr-0.5"></i>None</button>
            <button type="button" onclick="selectAIProvider('browser')" id="ai-p-browser" class="flex-1 min-w-[60px] px-2.5 py-2 rounded-lg text-[10px] font-semibold border-2 transition-all text-emerald-600 border-emerald-200 bg-emerald-50/30 hover:border-emerald-300"><i class="fas fa-globe mr-0.5"></i>Browser <span class="text-[8px] text-emerald-400">Free</span></button>
            <button type="button" onclick="selectAIProvider('pollinations')" id="ai-p-pollinations" class="flex-1 min-w-[60px] px-2.5 py-2 rounded-lg text-[10px] font-semibold border-2 transition-all text-orange-600 border-orange-200 bg-orange-50/30 hover:border-orange-300"><i class="fas fa-cloud mr-0.5"></i>Free API <span class="text-[8px] text-orange-400">No Key</span></button>
            <span class="w-px h-8 bg-gray-200 self-center"></span>
            <button type="button" onclick="selectAIProvider('openai')" id="ai-p-openai" class="flex-1 min-w-[60px] px-2.5 py-2 rounded-lg text-[10px] font-semibold border-2 transition-all text-sky-600 border-sky-200 bg-sky-50/30 hover:border-sky-300"><i class="fab fa-openai mr-0.5"></i>OpenAI</button>
            <button type="button" onclick="selectAIProvider('claude')" id="ai-p-claude" class="flex-1 min-w-[60px] px-2.5 py-2 rounded-lg text-[10px] font-semibold border-2 transition-all text-rose-600 border-rose-200 bg-rose-50/30 hover:border-rose-300"><i class="fas fa-feather mr-0.5"></i>Claude</button>
            <button type="button" onclick="selectAIProvider('gemini')" id="ai-p-gemini" class="flex-1 min-w-[60px] px-2.5 py-2 rounded-lg text-[10px] font-semibold border-2 transition-all text-blue-600 border-blue-200 bg-blue-50/30 hover:border-blue-300"><i class="fas fa-sparkles mr-0.5"></i>Gemini</button>
            <button type="button" onclick="selectAIProvider('deepseek')" id="ai-p-deepseek" class="flex-1 min-w-[60px] px-2.5 py-2 rounded-lg text-[10px] font-semibold border-2 transition-all text-violet-600 border-violet-200 bg-violet-50/30 hover:border-violet-300"><i class="fas fa-dragon mr-0.5"></i>DeepSeek</button>
            <button type="button" onclick="selectAIProvider('puter')" id="ai-p-puter" class="flex-1 min-w-[60px] px-2.5 py-2 rounded-lg text-[10px] font-semibold border-2 transition-all text-emerald-600 border-emerald-300 bg-emerald-50/30 hover:border-emerald-400"><i class="fas fa-bolt mr-0.5"></i>Puter <span class="text-[8px] text-emerald-400">Free</span></button>
          </div>
          <div id="ai-config-fields" class="hidden space-y-3">
            <div class="grid grid-cols-2 gap-3">
              <div>
                <label class="block text-[10px] font-medium text-gray-500 mb-0.5">Model</label>
                <select id="ai-model" class="w-full px-2 py-1.5 rounded-lg text-xs border border-gray-200 focus:ring-2 focus:ring-emerald-500 outline-none transition-all bg-white">
                  <option value="">Default</option>
                </select>
              </div>
              <div>
                <label class="block text-[10px] font-medium text-gray-500 mb-0.5">API Key</label>
                <input type="password" id="ai-api-key" class="w-full px-2 py-1.5 rounded-lg text-xs border border-gray-200 focus:ring-2 focus:ring-emerald-500 outline-none transition-all" placeholder="sk-...">
              </div>
            </div>
            <div class="flex items-center gap-3 flex-wrap">
              <label class="text-[10px] font-medium text-gray-500">Capabilities:</label>
              <label class="inline-flex items-center gap-1 text-[10px] text-gray-600 cursor-pointer"><input type="checkbox" id="ai-cap-sentiment" class="rounded border-gray-300 text-emerald-500 focus:ring-emerald-500" checked> Sentiment Analysis</label>
              <label class="inline-flex items-center gap-1 text-[10px] text-gray-600 cursor-pointer"><input type="checkbox" id="ai-cap-followup" class="rounded border-gray-300 text-emerald-500 focus:ring-emerald-500" checked> Adaptive Follow-ups</label>
              <label class="inline-flex items-center gap-1 text-[10px] text-gray-600 cursor-pointer"><input type="checkbox" id="ai-cap-summarize" class="rounded border-gray-300 text-emerald-500 focus:ring-emerald-500" checked> Summarize</label>
              <label class="inline-flex items-center gap-1 text-[10px] text-gray-600 cursor-pointer"><input type="checkbox" id="ai-cap-context" class="rounded border-gray-300 text-emerald-500 focus:ring-emerald-500" checked> Context Aware</label>
            </div>
            <div>
              <label class="block text-[10px] font-medium text-gray-500 mb-0.5">System Prompt</label>
              <textarea id="ai-system-prompt" rows="2" class="w-full px-2 py-1.5 rounded-lg text-xs border border-gray-200 focus:ring-2 focus:ring-emerald-500 outline-none transition-all resize-none" placeholder="You are a helpful survey assistant..."></textarea>
            </div>
            <div class="grid grid-cols-2 gap-3">
              <div>
                <label class="block text-[10px] font-medium text-gray-500 mb-0.5">Temperature: <span id="ai-temp-val" class="text-emerald-500 font-semibold">0.7</span></label>
                <input type="range" id="ai-temperature" min="0" max="2" step="0.1" value="0.7" class="w-full h-1.5 rounded-lg appearance-none cursor-pointer bg-emerald-100 accent-emerald-500" oninput="document.getElementById('ai-temp-val').textContent=this.value;updateAIConfig()">
              </div>
              <div>
                <label class="block text-[10px] font-medium text-gray-500 mb-0.5">Max Tokens: <span id="ai-tokens-val" class="text-emerald-500 font-semibold">200</span></label>
                <input type="range" id="ai-max-tokens" min="50" max="2000" step="50" value="200" class="w-full h-1.5 rounded-lg appearance-none cursor-pointer bg-emerald-100 accent-emerald-500" oninput="document.getElementById('ai-tokens-val').textContent=this.value;updateAIConfig()">
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- === BRANDING === -->
      <?php $tTheme = 'emerald'; $tBg = 'glass'; $tLogo = ''; $tCard = 'glass'; $tRadius = 'xl'; $tShadow = 'lg'; $tFont = 'inherit'; $tAnim = 'slide-up'; $tCSS = ''; $tBgType = 'gradient'; $tBgValue = ''; $tBgImg = ''; $tBgVid = ''; ?>
      <div class="glass-card rounded-2xl p-5 overflow-hidden animate-fade-in-up" style="animation-delay:0.14s">
        <div class="flex items-center justify-between mb-3">
          <h2 class="text-base font-bold text-gray-900"><i class="fas fa-palette text-pink-500 mr-2"></i>Branding</h2>
          <button type="button" onclick="toggleSection('ci-branding', this)" class="text-xs text-gray-400 hover:text-gray-600"><i class="fas fa-chevron-down"></i></button>
        </div>
        <div id="ci-branding" style="max-height:0px;overflow:hidden">
          <div class="mb-3">
            <label class="block text-xs font-medium text-gray-600 mb-1">Logo URL</label>
            <div class="flex gap-2">
              <input type="text" id="logo-url" value="<?= htmlspecialchars($tLogo) ?>" class="flex-1 glass-input w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-pink-500" placeholder="https://your-logo.png" oninput="updatePreview()">
              <div id="logo-preview" class="w-10 h-10 rounded-xl bg-gray-100 flex items-center justify-center overflow-hidden border flex-shrink-0">
                <?php if ($tLogo): ?><img src="<?= htmlspecialchars($tLogo) ?>" class="h-full w-full object-contain"><?php else: ?><i class="fas fa-image text-gray-400 text-sm"></i><?php endif; ?>
              </div>
            </div>
          </div>
          <div class="mb-3">
            <label class="block text-xs font-medium text-gray-600 mb-1.5">Theme Color</label>
            <div class="flex gap-2 flex-wrap" id="theme-picker">
              <?php $themes = ['indigo'=>'bg-indigo-500','emerald'=>'bg-emerald-500','amber'=>'bg-amber-500','rose'=>'bg-rose-500','cyan'=>'bg-cyan-500','violet'=>'bg-violet-500','teal'=>'bg-teal-500','red'=>'bg-red-500','orange'=>'bg-orange-500','pink'=>'bg-pink-500','blue'=>'bg-blue-500','slate'=>'bg-slate-500']; foreach ($themes as $tk => $tc2): ?>
              <button type="button" class="theme-btn w-8 h-8 <?= $tc2 ?> rounded-xl border-2 <?= $tk === $tTheme ? 'border-gray-900 ring-2 ring-offset-2 ring-gray-900' : 'border-transparent hover:border-gray-400' ?> transition-all" data-theme="<?= $tk ?>" onclick="selectTheme('<?= $tk ?>', this)"></button>
              <?php endforeach; ?>
            </div>
          </div>
          <div class="mb-3">
            <label class="block text-xs font-medium text-gray-600 mb-1.5">Background</label>
            <div class="flex gap-2 flex-wrap" id="bg-picker">
              <?php $bgs = ['glass'=>['label'=>'Glass','class'=>'bg-gradient-to-br from-gray-50 via-indigo-50/30 to-purple-50/30 border-gray-200'],'warm'=>['label'=>'Warm','class'=>'bg-gradient-to-br from-amber-50 via-orange-50/30 to-rose-50/30 border-amber-200'],'cool'=>['label'=>'Cool','class'=>'bg-gradient-to-br from-sky-50 via-blue-50/30 to-cyan-50/30 border-sky-200'],'dark'=>['label'=>'Dark','class'=>'bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 border-gray-700 text-white'],'mountain'=>['label'=>'Mtn','class'=>'bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 border-indigo-800 text-white'],'sunset'=>['label'=>'Sun','class'=>'bg-gradient-to-br from-orange-600 via-rose-600 to-purple-800 border-orange-700 text-white'],'ocean'=>['label'=>'Ocean','class'=>'bg-gradient-to-br from-cyan-600 via-blue-700 to-indigo-900 border-cyan-800 text-white'],'forest'=>['label'=>'Forest','class'=>'bg-gradient-to-br from-emerald-800 via-green-700 to-teal-800 border-emerald-900 text-white'],'midnight'=>['label'=>'Mid','class'=>'bg-gradient-to-br from-slate-900 via-gray-900 to-zinc-900 border-slate-800 text-white'],'lavender'=>['label'=>'Lav','class'=>'bg-gradient-to-br from-violet-300 via-fuchsia-200 to-pink-300 border-violet-400'],'peach'=>['label'=>'Pch','class'=>'bg-gradient-to-br from-amber-200 via-orange-200 to-rose-300 border-amber-300'],'particles'=>['label'=>'Prts','class'=>'bg-gradient-to-br from-gray-900 via-indigo-900 to-gray-900 border-gray-800 text-white']]; foreach ($bgs as $bk => $bg): ?>
              <button type="button" class="bg-btn w-8 h-8 <?= $bg['class'] ?> rounded-xl border-2 <?= $bk === $tBg ? 'border-gray-900 ring-2 ring-offset-2 ring-gray-900' : 'border-transparent hover:border-gray-400' ?> transition-all text-[7px] font-bold flex items-center justify-center <?= in_array($bk,['dark','mountain','sunset','ocean','forest','midnight','particles']) ? 'text-white' : 'text-gray-500' ?>" data-bg="<?= $bk ?>" onclick="selectBg('<?= $bk ?>', this)" title="<?= $bg['label'] ?>"><?= $bg['label'] ?></button>
              <?php endforeach; ?>
            </div>
          </div>
          <div class="mb-3">
            <label class="block text-xs font-medium text-gray-600 mb-1.5">Card Style</label>
            <div class="flex gap-2 flex-wrap" id="card-style-picker">
              <?php $cardStyles = ['glass'=>'Glass','solid'=>'Solid','bordered'=>'Bordered','ghost'=>'Ghost','dark-glass'=>'DkGlass','neumorphic'=>'Neumo','gradient'=>'Grad']; foreach ($cardStyles as $csKey => $csLabel): ?>
              <button type="button" class="card-style-btn px-3 py-1.5 rounded-lg text-[10px] font-medium border-2 <?= $csKey === $tCard ? 'border-gray-900 ring-2 ring-offset-2 ring-gray-900' : 'border-gray-200 hover:border-emerald-300 hover:bg-emerald-50' ?> transition-all" data-cardstyle="<?= $csKey ?>" onclick="selectCardStyle('<?= $csKey ?>', this)"><?= $csLabel ?></button>
              <?php endforeach; ?>
            </div>
          </div>
          <div class="mb-3">
            <label class="block text-xs font-medium text-gray-600 mb-1.5">Border Radius</label>
            <div class="flex gap-2 flex-wrap" id="radius-picker">
              <?php $radii = ['none'=>'None','sm'=>'SM','md'=>'MD','lg'=>'LG','xl'=>'XL','2xl'=>'2XL','3xl'=>'3XL','full'=>'Full']; $radiusClasses = ['none'=>'','sm'=>'rounded-sm','md'=>'rounded-md','lg'=>'rounded-lg','xl'=>'rounded-xl','2xl'=>'rounded-2xl','3xl'=>'rounded-3xl','full'=>'rounded-full']; foreach ($radii as $rk => $rl): $rClass = $radiusClasses[$rk]; ?>
              <button type="button" class="radius-btn px-3 py-1.5 rounded-lg text-[10px] font-medium border-2 <?= $rk === $tRadius ? 'border-gray-900 ring-2 ring-offset-2 ring-gray-900' : 'border-gray-200 hover:border-emerald-300 hover:bg-emerald-50' ?> transition-all <?= $rClass ?>" data-radius="<?= $rk ?>" onclick="selectRadius('<?= $rk ?>', this)"><?= $rl ?></button>
              <?php endforeach; ?>
            </div>
          </div>
          <div class="mb-3">
            <label class="block text-xs font-medium text-gray-600 mb-1.5">Shadow</label>
            <div class="flex gap-2 flex-wrap" id="shadow-picker">
              <?php $shadows = ['none'=>'None','sm'=>'SM','md'=>'MD','lg'=>'LG','xl'=>'XL','2xl'=>'2XL','inner'=>'Inner']; foreach ($shadows as $sk => $sl): ?>
              <button type="button" class="shadow-btn px-3 py-1.5 rounded-lg text-[10px] font-medium border-2 <?= $sk === $tShadow ? 'border-gray-900 ring-2 ring-offset-2 ring-gray-900' : 'border-gray-200 hover:border-emerald-300 hover:bg-emerald-50' ?> transition-all <?= $sk === 'none' ? '' : ($sk === 'inner' ? 'shadow-inner' : 'shadow-'.$sk) ?>" data-shadow="<?= $sk ?>" onclick="selectShadow('<?= $sk ?>', this)"><?= $sl ?></button>
              <?php endforeach; ?>
            </div>
          </div>
          <div class="mb-3">
            <label class="block text-xs font-medium text-gray-600 mb-1.5">Font Family</label>
            <select id="font-family" class="w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-pink-500 bg-white" onchange="updatePreview()">
              <option value="inherit" <?= $tFont === 'inherit' ? 'selected' : '' ?>>System Default</option>
              <option value="Inter" <?= $tFont === 'Inter' ? 'selected' : '' ?>>Inter</option>
              <option value="DM Sans" <?= $tFont === 'DM Sans' ? 'selected' : '' ?>>DM Sans</option>
              <option value="Plus Jakarta Sans" <?= $tFont === 'Plus Jakarta Sans' ? 'selected' : '' ?>>Plus Jakarta Sans</option>
              <option value="Georgia" <?= $tFont === 'Georgia' ? 'selected' : '' ?>>Georgia (Serif)</option>
              <option value="Courier New" <?= $tFont === 'Courier New' ? 'selected' : '' ?>>Courier New (Mono)</option>
              <option value="Nunito" <?= $tFont === 'Nunito' ? 'selected' : '' ?>>Nunito</option>
              <option value="Poppins" <?= $tFont === 'Poppins' ? 'selected' : '' ?>>Poppins</option>
            </select>
          </div>
          <div class="mb-3">
            <label class="block text-xs font-medium text-gray-600 mb-1.5">Animation</label>
            <select id="question-animation" class="w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-pink-500 bg-white" onchange="updatePreview()">
              <option value="slide-up" <?= $tAnim === 'slide-up' ? 'selected' : '' ?>>Slide Up</option>
              <option value="fade-in" <?= $tAnim === 'fade-in' ? 'selected' : '' ?>>Fade In</option>
              <option value="scale-in" <?= $tAnim === 'scale-in' ? 'selected' : '' ?>>Scale In</option>
              <option value="slide-left" <?= $tAnim === 'slide-left' ? 'selected' : '' ?>>Slide Left</option>
              <option value="flip" <?= $tAnim === 'flip' ? 'selected' : '' ?>>Flip</option>
              <option value="bounce" <?= $tAnim === 'bounce' ? 'selected' : '' ?>>Bounce</option>
              <option value="none" <?= $tAnim === 'none' ? 'selected' : '' ?>>None</option>
            </select>
          </div>
          <div class="mb-3">
            <label class="block text-xs font-medium text-gray-600 mb-1.5">Custom CSS</label>
            <textarea id="custom-css" class="w-full px-3 py-2 rounded-xl text-xs font-mono border border-gray-200 focus:ring-2 focus:ring-pink-500 bg-white/70 backdrop-blur-sm transition-all resize-y" rows="3" placeholder="/* Custom CSS overrides */" oninput="updatePreview()"><?= htmlspecialchars($tCSS) ?></textarea>
          </div>
          <div class="mb-3">
            <label class="block text-xs font-medium text-gray-600 mb-1.5">Background Type</label>
            <div class="flex gap-2 flex-wrap mb-2" id="bg-type-picker">
              <?php $bgTypes = ['gradient'=>'Gradient','solid'=>'Solid','image'=>'Image','video'=>'Video']; foreach ($bgTypes as $btKey => $btLabel): ?>
              <button type="button" class="bg-type-btn px-3 py-1.5 rounded-lg text-[10px] font-medium border-2 <?= $btKey === $tBgType ? 'border-gray-900 ring-2 ring-offset-2 ring-gray-900' : 'border-gray-200 hover:border-emerald-300 hover:bg-emerald-50' ?> transition-all" data-bgtype="<?= $btKey ?>" onclick="selectBgType('<?= $btKey ?>', this)"><?= $btLabel ?></button>
              <?php endforeach; ?>
            </div>
            <div id="bg-type-value" class="<?= in_array($tBgType,['solid','gradient']) ? '' : 'hidden' ?>">
              <input type="text" id="bg-value" value="<?= htmlspecialchars($tBgValue) ?>" class="w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-pink-500 bg-white" placeholder="Solid hex color or gradient CSS value" oninput="updatePreview()">
            </div>
            <div id="bg-type-image" class="<?= $tBgType === 'image' ? '' : 'hidden' ?>">
              <input type="text" id="bg-image" value="<?= htmlspecialchars($tBgImg) ?>" class="w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-pink-500 bg-white" placeholder="https://your-background-image.jpg" oninput="updatePreview()">
            </div>
            <div id="bg-type-video" class="<?= $tBgType === 'video' ? '' : 'hidden' ?>">
              <input type="text" id="bg-video" value="<?= htmlspecialchars($tBgVid) ?>" class="w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-pink-500 bg-white" placeholder="https://your-background-video.mp4" oninput="updatePreview()">
            </div>
          </div>
        </div>
      </div>

      <!-- === WHO CAN RESPOND === -->
      <?php $qcArr = $qualityConfig ?? []; $qcCheck = function($k) use ($qcArr) { return !empty($qcArr[$k]); }; ?>
      <div class="glass-card rounded-2xl p-5 overflow-hidden animate-fade-in-up" style="animation-delay:0.16s">
        <div class="flex items-center justify-between mb-4">
          <h2 class="text-base font-bold text-gray-900"><i class="fas fa-users text-emerald-500 mr-2"></i>Who Can Respond?</h2>
          <button type="button" onclick="toggleSection('ci-access', this)" class="text-xs text-gray-400 hover:text-gray-600"><i class="fas fa-chevron-down"></i></button>
        </div>
        <div id="ci-access" style="max-height:0px;overflow:hidden">
          <div class="grid grid-cols-2 sm:grid-cols-5 gap-2 mb-4" id="auth-picker">
            <?php $authOptions = [
              'anyone' => ['icon'=>'fa-globe','label'=>'Anyone','desc'=>'No login needed','color'=>'emerald','badge'=>'Anonymous'],
              'password' => ['icon'=>'fa-lock','label'=>'Password','desc'=>'Shared password','color'=>'amber','badge'=>'Protected'],
              'email' => ['icon'=>'fa-envelope','label'=>'Email','desc'=>'Email verification','color'=>'blue','badge'=>'Verified'],
              'google' => ['icon'=>'fa-google','label'=>'Google','desc'=>'Google login only','color'=>'red','badge'=>'OAuth'],
              'any_account' => ['icon'=>'fa-user-check','label'=>'Any Account','desc'=>'Any registered user','color'=>'purple','badge'=>'Account'],
            ]; foreach ($authOptions as $aKey => $aOpt): ?>
            <label class="auth-card flex flex-col items-center gap-1.5 p-3 border-2 rounded-xl cursor-pointer transition-all duration-200 hover:border-<?= $aOpt['color'] ?>-300 hover:bg-<?= $aOpt['color'] ?>-50/30 has-[:checked]:border-<?= $aOpt['color'] ?>-500 has-[:checked]:bg-<?= $aOpt['color'] ?>-50/60 has-[:checked]:shadow-sm text-center <?= ($qcArr['auth_type'] ?? 'anyone') === $aKey ? 'border-'.$aOpt['color'].'-500 bg-'.$aOpt['color'].'-50/60' : 'border-gray-200' ?>">
              <input type="radio" name="qc[auth_type]" value="<?= $aKey ?>" <?= ($qcArr['auth_type'] ?? 'anyone') === $aKey ? 'checked' : '' ?> class="hidden">
              <span class="w-9 h-9 rounded-xl bg-<?= $aOpt['color'] ?>-100 flex items-center justify-center text-<?= $aOpt['color'] ?>-600 text-sm"><i class="fab <?= $aKey === 'google' ? 'fa-google' : 'fas '.$aOpt['icon'] ?>"></i></span>
              <span class="text-[11px] font-semibold text-gray-800 leading-tight"><?= $aOpt['label'] ?></span>
              <span class="text-[9px] text-gray-400 leading-tight"><?= $aOpt['desc'] ?></span>
              <span class="text-[8px] font-medium px-1.5 py-0.5 rounded-full bg-<?= $aOpt['color'] ?>-100 text-<?= $aOpt['color'] ?>-700 mt-auto"><?= $aOpt['badge'] ?></span>
            </label>
            <?php endforeach; ?>
          </div>
          <div id="ci-password-field-wrap" class="<?= ($qcArr['auth_type'] ?? 'anyone') === 'password' ? '' : 'hidden' ?> mb-3">
            <label class="block text-xs font-medium text-gray-600 mb-1"><i class="fas fa-key text-amber-500 mr-1"></i>Access Password</label>
            <div class="flex gap-2">
              <input type="text" name="access_password" class="flex-1 px-3 py-2 rounded-xl text-sm border border-amber-200 focus:ring-2 focus:ring-amber-500 bg-white/70" placeholder="Set a password...">
              <button type="button" onclick="var inp=this.previousElementSibling;inp.type=inp.type==='password'?'text':'password';this.classList.toggle('text-amber-500')" class="px-3 py-2 text-gray-400 hover:text-amber-500 transition-colors text-sm"><i class="fas fa-eye"></i></button>
            </div>
          </div>
          <div class="flex items-center gap-3 flex-wrap">
            <div class="flex-1 min-w-[140px]">
              <label class="block text-xs font-medium text-gray-600 mb-1"><i class="fas fa-chart-bar text-gray-400 mr-1"></i>Max Responses</label>
              <input type="number" name="max_responses" value="" placeholder="Unlimited" class="w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-emerald-500 bg-white/70">
            </div>
            <div class="flex-1 min-w-[140px]">
              <label class="block text-xs font-medium text-gray-600 mb-1"><i class="fas fa-star text-gray-400 mr-1"></i>Min Reputation</label>
              <div class="flex items-center gap-2">
                <input type="range" name="min_reputation_range" id="ci-min-rep-range" value="0" min="0" max="100" class="flex-1 accent-emerald-500" oninput="document.getElementById('ci-min-rep-val').textContent=this.value;document.getElementById('ci-min-rep-input').value=this.value">
                <span class="text-sm font-bold text-emerald-600 w-8 text-right" id="ci-min-rep-val">0</span>
                <input type="hidden" name="min_reputation" id="ci-min-rep-input" value="0">
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- === STATUS & VISIBILITY === -->
      <div class="glass-card rounded-2xl p-5 overflow-hidden animate-fade-in-up" style="animation-delay:0.18s">
        <div class="flex items-center justify-between mb-4">
          <h2 class="text-base font-bold text-gray-900"><i class="fas fa-toggle-on text-amber-500 mr-2"></i>Status & Visibility</h2>
          <button type="button" onclick="toggleSection('ci-vis-body', this)" class="text-xs text-gray-400 hover:text-gray-600"><i class="fas fa-chevron-down"></i></button>
        </div>
        <div id="ci-vis-body" style="max-height:0px;overflow:hidden">
          <div class="flex flex-wrap gap-2 mb-4">
            <?php $statuses = ['draft'=>['label'=>'Draft','icon'=>'fa-pen','color'=>'gray'],'active'=>['label'=>'Active','icon'=>'fa-play','color'=>'emerald'],'closed'=>['label'=>'Closed','icon'=>'fa-stop','color'=>'red']]; foreach ($statuses as $sk => $sv): ?>
            <label class="flex-1 min-w-[80px] flex flex-col items-center gap-1 p-3 border-2 rounded-xl cursor-pointer transition-all text-center has-[:checked]:border-<?= $sv['color'] ?>-500 has-[:checked]:bg-<?= $sv['color'] ?>-50/60 <?= 'draft' === $sk ? 'border-'.$sv['color'].'-500 bg-'.$sv['color'].'-50/60' : 'border-gray-200' ?>">
              <input type="radio" name="status" value="<?= $sk ?>" <?= 'draft' === $sk ? 'checked' : '' ?> class="hidden">
              <span class="w-8 h-8 rounded-lg bg-<?= $sv['color'] ?>-100 flex items-center justify-center text-<?= $sv['color'] ?>-600 text-sm"><i class="fas <?= $sv['icon'] ?>"></i></span>
              <span class="text-xs font-semibold text-gray-800"><?= $sv['label'] ?></span>
            </label>
            <?php endforeach; ?>
          </div>
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label class="block text-xs font-medium text-gray-600 mb-1"><i class="fas fa-play-circle text-emerald-500 mr-1"></i>Opens At</label>
              <input type="datetime-local" name="starts_at" value="" class="w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-emerald-500 bg-white/70">
            </div>
            <div>
              <label class="block text-xs font-medium text-gray-600 mb-1"><i class="fas fa-stop-circle text-red-400 mr-1"></i>Closes At</label>
              <input type="datetime-local" name="ends_at" value="" class="w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-emerald-500 bg-white/70">
            </div>
          </div>
        </div>
      </div>

      <!-- === QUALITY CONTROLS === -->
      <div class="glass-card rounded-2xl p-5 overflow-hidden animate-fade-in-up" style="animation-delay:0.2s">
        <div class="flex items-center justify-between mb-3">
          <h2 class="text-base font-bold text-gray-900"><i class="fas fa-shield-alt text-emerald-500 mr-2"></i>Quality Controls</h2>
          <button type="button" onclick="toggleSection('ci-qc', this)" class="text-xs text-gray-400 hover:text-gray-600"><i class="fas fa-chevron-down"></i></button>
        </div>
        <div id="ci-qc" style="max-height:0px;overflow:hidden">
          <?php $qThreshold = 70; ?>
          <div class="mb-4 p-3 bg-gradient-to-r from-emerald-50/60 to-emerald-100/60 border border-emerald-200 rounded-xl">
            <div class="flex items-center justify-between flex-wrap gap-2">
              <div class="flex items-center gap-2">
                <span class="w-8 h-8 rounded-lg bg-gradient-to-br from-emerald-500 to-emerald-600 flex items-center justify-center text-white text-xs shadow-sm"><i class="fas fa-tachometer-alt"></i></span>
                <div>
                  <div class="text-xs font-bold text-gray-800">Quality Threshold</div>
                  <span class="text-[10px] text-gray-500">Minimum quality score to accept responses</span>
                </div>
              </div>
              <div class="flex items-center gap-2">
                <input type="range" name="quality_threshold_range" id="ci-qt-range" value="<?= (int)$qThreshold ?>" min="0" max="100" class="w-28 accent-emerald-600" oninput="var v=this.value;document.getElementById('ci-qt-val').textContent=v+'%';document.getElementById('ci-qt-input').value=v">
                <span class="text-lg font-extrabold text-emerald-600 w-10 text-right" id="ci-qt-val"><?= (int)$qThreshold ?>%</span>
                <input type="hidden" name="quality_threshold" id="ci-qt-input" value="<?= (int)$qThreshold ?>">
              </div>
            </div>
          </div>

          <div class="mb-3">
            <div class="flex items-center gap-2 mb-2">
              <span class="w-6 h-6 rounded-lg bg-red-100 flex items-center justify-center text-red-600 text-[10px]"><i class="fas fa-robot"></i></span>
              <span class="text-xs font-bold text-gray-700">Anti-Bot & Security</span>
              <span class="text-[9px] text-gray-400">Block automated submissions</span>
            </div>
            <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-1.5">
              <?php $qcCats = [
                ['k'=>'honeypot','l'=>'Honeypot','d'=>'Hidden field traps bots','c'=>'red'],
                ['k'=>'captcha','l'=>'Math CAPTCHA','d'=>'Simple math puzzle','c'=>'red'],
                ['k'=>'ip_rate_limit','l'=>'IP Rate Limit','d'=>'Block repeat IPs','c'=>'red'],
                ['k'=>'browser_fingerprint','l'=>'Fingerprint','d'=>'Unique browser ID','c'=>'red'],
                ['k'=>'vpn_detection','l'=>'VPN Detection','d'=>'Flag proxy users','c'=>'red'],
              ]; foreach ($qcCats as $qcItem): ?>
              <label class="flex items-center gap-2 px-2.5 py-2 border border-gray-200 rounded-xl cursor-pointer transition-all hover:bg-red-50/30 has-[:checked]:border-red-400 has-[:checked]:bg-red-50/50">
                <input type="checkbox" name="qc[<?= $qcItem['k'] ?>]" value="1" <?= $qcCheck($qcItem['k']) ? 'checked' : '' ?> class="rounded text-red-600 focus:ring-red-500">
                <div class="min-w-0">
                  <div class="text-[11px] font-medium text-gray-800"><?= $qcItem['l'] ?></div>
                  <span class="text-[9px] text-gray-400 block"><?= $qcItem['d'] ?></span>
                </div>
              </label>
              <?php endforeach; ?>
            </div>
          </div>

          <div class="mb-3">
            <div class="flex items-center gap-2 mb-2">
              <span class="w-6 h-6 rounded-lg bg-emerald-100 flex items-center justify-center text-emerald-600 text-[10px]"><i class="fas fa-check-double"></i></span>
              <span class="text-xs font-bold text-gray-700">Response Quality</span>
              <span class="text-[9px] text-gray-400">Ensure honest, thoughtful answers</span>
            </div>
            <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-1.5">
              <?php $qcCats = [
                ['k'=>'prevent_duplicates','l'=>'Block Duplicates','d'=>'One response per user','c'=>'emerald'],
                ['k'=>'detect_straightline','l'=>'Straight-Line','d'=>'Same answer pattern','c'=>'emerald'],
                ['k'=>'validate_input','l'=>'Input Validation','d'=>'Email/phone format','c'=>'emerald'],
                ['k'=>'ai_detection','l'=>'AI Detection','d'=>'Flag GPT/etc answers','c'=>'emerald'],
                ['k'=>'language_consistency','l'=>'Language Check','d'=>'Consistent language','c'=>'emerald'],
              ]; foreach ($qcCats as $qcItem): ?>
              <label class="flex items-center gap-2 px-2.5 py-2 border border-gray-200 rounded-xl cursor-pointer transition-all hover:bg-emerald-50/30 has-[:checked]:border-emerald-400 has-[:checked]:bg-emerald-50/50">
                <input type="checkbox" name="qc[<?= $qcItem['k'] ?>]" value="1" <?= $qcCheck($qcItem['k']) ? 'checked' : '' ?> class="rounded text-emerald-600 focus:ring-emerald-500">
                <div class="min-w-0">
                  <div class="text-[11px] font-medium text-gray-800"><?= $qcItem['l'] ?></div>
                  <span class="text-[9px] text-gray-400 block"><?= $qcItem['d'] ?></span>
                </div>
              </label>
              <?php endforeach; ?>
            </div>
          </div>

          <div class="mb-3">
            <div class="flex items-center gap-2 mb-2">
              <span class="w-6 h-6 rounded-lg bg-amber-100 flex items-center justify-center text-amber-600 text-[10px]"><i class="fas fa-eye"></i></span>
              <span class="text-xs font-bold text-gray-700">Focus & Integrity</span>
              <span class="text-[9px] text-gray-400">Prevent cheating and distractions</span>
            </div>
            <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-1.5">
              <?php $qcCats = [
                ['k'=>'prevent_back_nav','l'=>'Prevent Back','d'=>'Disable back button','c'=>'amber'],
                ['k'=>'prevent_copy_paste','l'=>'No Copy-Paste','d'=>'Disable paste','c'=>'amber'],
                ['k'=>'track_tab_switches','l'=>'Track Tabs','d'=>'Detect tab switches','c'=>'amber'],
                ['k'=>'require_attention','l'=>'Attention Check','d'=>'Mandatory focus test','c'=>'amber'],
                ['k'=>'fullscreen_mode','l'=>'Fullscreen','d'=>'Force fullscreen','c'=>'amber'],
                ['k'=>'disable_rightclick','l'=>'No Right-Click','d'=>'Disable menu','c'=>'amber'],
                ['k'=>'confirm_answers','l'=>'Confirm Answers','d'=>'Review before submit','c'=>'amber'],
              ]; foreach ($qcCats as $qcItem): ?>
              <label class="flex items-center gap-2 px-2.5 py-2 border border-gray-200 rounded-xl cursor-pointer transition-all hover:bg-amber-50/30 has-[:checked]:border-amber-400 has-[:checked]:bg-amber-50/50">
                <input type="checkbox" name="qc[<?= $qcItem['k'] ?>]" value="1" <?= $qcCheck($qcItem['k']) ? 'checked' : '' ?> class="rounded text-amber-600 focus:ring-amber-500">
                <div class="min-w-0">
                  <div class="text-[11px] font-medium text-gray-800"><?= $qcItem['l'] ?></div>
                  <span class="text-[9px] text-gray-400 block"><?= $qcItem['d'] ?></span>
                </div>
              </label>
              <?php endforeach; ?>
            </div>
          </div>

          <div class="mb-3">
            <div class="flex items-center gap-2 mb-2">
              <span class="w-6 h-6 rounded-lg bg-purple-100 flex items-center justify-center text-purple-600 text-[10px]"><i class="fas fa-gamepad"></i></span>
              <span class="text-xs font-bold text-gray-700">Progression & Gamification</span>
              <span class="text-[9px] text-gray-400">Engage respondents with game-like features</span>
            </div>
            <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-1.5">
              <?php $qcCats = [
                ['k'=>'sequential_unlock','l'=>'Sequential Unlock','d'=>'One at a time','c'=>'purple'],
                ['k'=>'quiz_mode','l'=>'Quiz Mode','d'=>'Scoring + lives','c'=>'purple'],
                ['k'=>'shuffle_questions','l'=>'Shuffle Questions','d'=>'Random order','c'=>'purple'],
                ['k'=>'shuffle_options','l'=>'Shuffle Options','d'=>'Random choices','c'=>'purple'],
                ['k'=>'allow_resume','l'=>'Allow Resume','d'=>'Save & continue','c'=>'purple'],
                ['k'=>'time_per_question','l'=>'Time Per Q','d'=>'Per-question timer','c'=>'purple'],
              ]; foreach ($qcCats as $qcItem): ?>
              <label class="flex items-center gap-2 px-2.5 py-2 border border-gray-200 rounded-xl cursor-pointer transition-all hover:bg-purple-50/30 has-[:checked]:border-purple-400 has-[:checked]:bg-purple-50/50">
                <input type="checkbox" name="qc[<?= $qcItem['k'] ?>]" value="1" <?= $qcCheck($qcItem['k']) ? 'checked' : '' ?> class="rounded text-purple-600 focus:ring-purple-500">
                <div class="min-w-0">
                  <div class="text-[11px] font-medium text-gray-800"><?= $qcItem['l'] ?></div>
                  <span class="text-[9px] text-gray-400 block"><?= $qcItem['d'] ?></span>
                </div>
              </label>
              <?php endforeach; ?>
            </div>
          </div>

          <div class="mb-3">
            <div class="flex items-center gap-2 mb-2">
              <span class="w-6 h-6 rounded-lg bg-blue-100 flex items-center justify-center text-blue-600 text-[10px]"><i class="fas fa-microchip"></i></span>
              <span class="text-xs font-bold text-gray-700">Advanced Verification</span>
              <span class="text-[9px] text-gray-400">Extra identity & location checks</span>
            </div>
            <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-1.5">
              <?php $qcCats = [
                ['k'=>'email_domain_verify','l'=>'Email Domain','d'=>'Verify email domain','c'=>'blue'],
                ['k'=>'geo_timezone_check','l'=>'Timezone Check','d'=>'Match IP timezone','c'=>'blue'],
              ]; foreach ($qcCats as $qcItem): ?>
              <label class="flex items-center gap-2 px-2.5 py-2 border border-gray-200 rounded-xl cursor-pointer transition-all hover:bg-blue-50/30 has-[:checked]:border-blue-400 has-[:checked]:bg-blue-50/50">
                <input type="checkbox" name="qc[<?= $qcItem['k'] ?>]" value="1" <?= $qcCheck($qcItem['k']) ? 'checked' : '' ?> class="rounded text-blue-600 focus:ring-blue-500">
                <div class="min-w-0">
                  <div class="text-[11px] font-medium text-gray-800"><?= $qcItem['l'] ?></div>
                  <span class="text-[9px] text-gray-400 block"><?= $qcItem['d'] ?></span>
                </div>
              </label>
              <?php endforeach; ?>
            </div>
          </div>

          <?php $qPass = $qcArr['quiz_pass_score'] ?? 70; $qLives = $qcArr['quiz_lives'] ?? 3; $qTimer = $qcArr['quiz_timer_per_q'] ?? 30; $qShow = !empty($qcArr['quiz_show_answers']); ?>
          <div id="quiz-settings-ci" class="hidden mb-3 p-4 bg-gradient-to-r from-purple-50/80 to-indigo-50/80 border border-purple-200 rounded-xl">
            <div class="flex items-center gap-2 mb-3">
              <span class="w-7 h-7 rounded-lg bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center text-white text-xs shadow-sm"><i class="fas fa-gamepad"></i></span>
              <span class="text-xs font-bold text-gray-800">Quiz Mode Settings</span>
              <span class="text-[9px] text-purple-500 ml-auto"><i class="fas fa-lightbulb"></i> Engage respondents with gamification</span>
            </div>
            <div class="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div>
                <label class="block text-[10px] font-medium text-gray-600 mb-0.5">Passing Score (%)</label>
                <input type="number" name="qc[quiz_pass_score]" value="<?= $qPass ?>" min="0" max="100" class="w-full px-2 py-1.5 rounded-lg text-sm border border-purple-200 focus:ring-2 focus:ring-purple-500 bg-white">
              </div>
              <div>
                <label class="block text-[10px] font-medium text-gray-600 mb-0.5">Lives / Attempts</label>
                <input type="number" name="qc[quiz_lives]" value="<?= $qLives ?>" min="1" max="10" class="w-full px-2 py-1.5 rounded-lg text-sm border border-purple-200 focus:ring-2 focus:ring-purple-500 bg-white">
              </div>
              <div>
                <label class="block text-[10px] font-medium text-gray-600 mb-0.5">Timer Per Q (sec)</label>
                <input type="number" name="qc[quiz_timer_per_q]" value="<?= $qTimer ?>" min="5" max="600" class="w-full px-2 py-1.5 rounded-lg text-sm border border-purple-200 focus:ring-2 focus:ring-purple-500 bg-white">
              </div>
              <div class="flex items-end pb-1">
                <label class="flex items-center gap-1.5 text-[10px] text-gray-600 cursor-pointer">
                  <input type="checkbox" name="qc[quiz_show_answers]" value="1" <?= $qShow ? 'checked' : '' ?> class="rounded text-purple-600 focus:ring-purple-500"> Show correct answers
                </label>
              </div>
            </div>
            <div class="flex items-center gap-3 mt-2 text-[9px] text-gray-400">
              <span><i class="fas fa-trophy text-amber-400"></i> Scoring: correct = +1, wrong = lose life</span>
              <span><i class="fas fa-lock text-purple-400"></i> Sequential: each question unlocks the next</span>
              <span><i class="fas fa-fire text-orange-400"></i> Streak bonus: 3+ correct in a row</span>
            </div>
          </div>

          <div class="grid grid-cols-2 sm:grid-cols-5 gap-3">
            <div>
              <label class="block text-[10px] font-medium text-gray-500 mb-0.5">Min Time (sec)</label>
              <input type="number" name="qc[min_time_seconds]" value="<?= $qcArr['min_time_seconds'] ?? 30 ?>" min="0" max="3600" class="w-full px-2.5 py-1.5 rounded-lg text-sm border border-gray-200 focus:ring-2 focus:ring-emerald-500 bg-white/70">
            </div>
            <div>
              <label class="block text-[10px] font-medium text-gray-500 mb-0.5">Min Text Length</label>
              <input type="number" name="qc[min_text_length]" value="<?= $qcArr['min_text_length'] ?? 10 ?>" min="0" max="1000" class="w-full px-2.5 py-1.5 rounded-lg text-sm border border-gray-200 focus:ring-2 focus:ring-emerald-500 bg-white/70">
            </div>
            <div>
              <label class="block text-[10px] font-medium text-gray-500 mb-0.5">Inactivity Timeout</label>
              <input type="number" name="qc[inactivity_timeout]" value="<?= $qcArr['inactivity_timeout'] ?? 300 ?>" min="0" max="3600" class="w-full px-2.5 py-1.5 rounded-lg text-sm border border-gray-200 focus:ring-2 focus:ring-emerald-500 bg-white/70">
            </div>
            <div>
              <label class="block text-[10px] font-medium text-gray-500 mb-0.5">Warn Before (sec)</label>
              <input type="number" name="qc[inactivity_warn_before]" value="<?= $qcArr['inactivity_warn_before'] ?? 30 ?>" min="5" max="300" class="w-full px-2.5 py-1.5 rounded-lg text-sm border border-gray-200 focus:ring-2 focus:ring-emerald-500 bg-white/70">
            </div>
            <div>
              <label class="block text-[10px] font-medium text-gray-500 mb-0.5">Max Idle (sec)</label>
              <input type="number" name="qc[max_idle_seconds]" value="<?= $qcArr['max_idle_seconds'] ?? 300 ?>" min="0" max="3600" class="w-full px-2.5 py-1.5 rounded-lg text-sm border border-gray-200 focus:ring-2 focus:ring-emerald-500 bg-white/70">
            </div>
          </div>
        </div>
      </div>

      <!-- Action Bar -->
      <div class="flex flex-wrap gap-3 items-center animate-fade-in-up" style="animation-delay:0.25s">
        <button type="submit" class="bg-gradient-to-r from-emerald-500 to-emerald-600 text-white px-6 py-2.5 rounded-xl hover:from-emerald-600 hover:to-emerald-700 transition-all font-medium text-sm shadow-sm hover:shadow-lg shadow-emerald-200 flex items-center gap-2">
          <i class="fas fa-save"></i> Create Chat Survey
        </button>
        <a href="<?= url('/dashboard') ?>" class="px-4 py-2.5 border border-gray-200 rounded-xl text-gray-600 hover:bg-gray-50 transition-all text-sm">Back to Dashboard</a>
      </div>
    </div>

    <!-- Right Column — Chat Preview -->
    <div class="lg:col-span-1">
      <div class="glass-card rounded-2xl p-4 sticky top-24 animate-fade-in-up" style="animation-delay:0.15s">
        <div class="flex items-center gap-2 mb-3">
          <i class="fas fa-mobile-alt text-gray-400 text-xs"></i>
          <span class="text-xs font-semibold text-gray-700">Chat Preview</span>
          <span class="text-[10px] text-gray-400 ml-auto" id="preview-node-count">0 nodes</span>
        </div>
        <div id="preview-phone" class="bg-white rounded-2xl border border-gray-200 shadow-lg overflow-hidden transition-all duration-500" style="min-height:420px;max-width:320px;margin:0 auto">
          <div id="preview-header" class="px-4 py-3 bg-gradient-to-r from-emerald-500 to-emerald-600 transition-all duration-500 flex items-center gap-2">
            <div class="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0">
              <i class="fas fa-comment-dots text-white text-[10px]"></i>
            </div>
            <div class="min-w-0 flex-1">
              <div id="preview-title" class="text-sm font-bold text-white truncate">Chat Survey</div>
              <div id="preview-desc" class="text-[9px] text-white/70 truncate">AI-powered conversation</div>
            </div>
            <div class="flex gap-1">
              <span class="w-1.5 h-1.5 rounded-full bg-white/40"></span>
              <span class="w-1.5 h-1.5 rounded-full bg-white/40"></span>
              <span class="w-1.5 h-1.5 rounded-full bg-white/40"></span>
            </div>
          </div>
          <div id="preview-body" class="p-3 space-y-2 min-h-[280px] max-h-[400px] overflow-y-auto bg-gray-50" style="background:#f9fafb">
            <div class="flex items-start gap-2">
              <div class="w-6 h-6 rounded-full bg-gradient-to-br from-emerald-400 to-emerald-600 flex items-center justify-center text-white text-[9px] font-bold flex-shrink-0 mt-0.5">AI</div>
              <div class="bg-white rounded-2xl rounded-tl-sm px-3 py-2 shadow-sm max-w-[80%]">
                <p class="text-xs text-gray-700" id="preview-bot-msg">Welcome! Let's start the conversation.</p>
              </div>
            </div>
            <div id="preview-thinking" class="flex items-start gap-2 hidden">
              <div class="w-6 h-6 rounded-full bg-gradient-to-br from-emerald-400 to-emerald-600 flex items-center justify-center text-white text-[9px] font-bold flex-shrink-0 mt-0.5">AI</div>
              <div class="bg-white rounded-2xl rounded-tl-sm px-3 py-2 shadow-sm">
                <div class="flex gap-1">
                  <span class="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-bounce" style="animation-delay:0s"></span>
                  <span class="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-bounce" style="animation-delay:0.15s"></span>
                  <span class="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-bounce" style="animation-delay:0.3s"></span>
                </div>
              </div>
            </div>
            <div id="preview-chat-nodes"></div>
          </div>
          <div class="px-3 py-2.5 border-t border-gray-100 bg-white flex items-center gap-2">
            <div class="flex-1 px-3 py-1.5 rounded-full bg-gray-100 text-xs text-gray-400">Type your response...</div>
            <div class="w-7 h-7 rounded-full bg-emerald-500 flex items-center justify-center text-white text-[10px] opacity-50"><i class="fas fa-arrow-up"></i></div>
          </div>
        </div>
      </div>
    </div>
  </form>
</div>

<!-- Chat Node Editor Modal -->
<div id="node-modal" class="fixed inset-0 z-[60] flex items-center justify-center hidden">
  <div class="absolute inset-0 bg-black/40 backdrop-blur-sm" onclick="closeNodeModal()"></div>
  <div class="relative bg-white rounded-2xl shadow-2xl w-full max-w-lg mx-4 max-h-[90vh] overflow-y-auto animate-scale-in">
    <div class="flex items-center justify-between px-5 py-4 border-b border-gray-100">
      <h3 class="text-base font-bold text-gray-900"><i class="fas fa-comment-dots text-emerald-500 mr-2"></i>Edit Chat Node</h3>
      <button type="button" onclick="closeNodeModal()" class="w-8 h-8 rounded-xl hover:bg-gray-100 transition-all text-gray-400 hover:text-gray-600"><i class="fas fa-times"></i></button>
    </div>
    <div class="p-5 space-y-4">
      <div>
        <label class="block text-xs font-medium text-gray-600 mb-1">Question Text</label>
        <textarea id="node-question" rows="2" class="w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-emerald-500 outline-none transition-all resize-none" placeholder="Enter your question..."></textarea>
      </div>
      <div>
        <label class="block text-xs font-medium text-gray-600 mb-1">Response Type</label>
        <select id="node-type" class="w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-emerald-500 outline-none transition-all" onchange="toggleNodeOptions()">
          <option value="text">Text</option>
          <option value="rating">Rating</option>
          <option value="yes_no">Yes / No</option>
          <option value="mcq_single">Multiple Choice (Single)</option>
          <option value="mcq_multiple">Multiple Choice (Multiple)</option>
          <option value="number">Number</option>
          <option value="nps">NPS</option>
          <option value="likert5">Likert 5</option>
        </select>
      </div>
      <div id="node-options-wrap" class="hidden">
        <label class="block text-xs font-medium text-gray-600 mb-1">Options</label>
        <div id="node-options-list" class="space-y-1.5 mb-2"></div>
        <button type="button" onclick="addNodeOption()" class="text-xs px-2 py-1 rounded-lg bg-emerald-100 text-emerald-700 hover:bg-emerald-200 transition-all font-medium"><i class="fas fa-plus mr-0.5"></i>Add Option</button>
      </div>

      <div id="node-validation-wrap" class="hidden">
        <label class="block text-xs font-medium text-gray-600 mb-2">Validation (for Number type)</label>
        <div class="flex items-center gap-2">
          <div class="flex-1">
            <label class="block text-[10px] text-gray-400 mb-0.5">Min Value</label>
            <input type="number" id="node-min-val" step="any" class="w-full px-2 py-1.5 rounded-lg text-xs border border-gray-200 focus:ring-2 focus:ring-emerald-500 outline-none transition-all" placeholder="e.g. 0">
          </div>
          <div class="flex-1">
            <label class="block text-[10px] text-gray-400 mb-0.5">Max Value</label>
            <input type="number" id="node-max-val" step="any" class="w-full px-2 py-1.5 rounded-lg text-xs border border-gray-200 focus:ring-2 focus:ring-emerald-500 outline-none transition-all" placeholder="e.g. 100">
          </div>
        </div>
      </div>

      <div id="node-text-limit-wrap" class="hidden">
        <label class="block text-xs font-medium text-gray-600 mb-2">Text Length Limits</label>
        <div class="flex items-center gap-2">
          <div class="flex-1">
            <label class="block text-[10px] text-gray-400 mb-0.5">Min Length</label>
            <input type="number" id="node-min-length" min="0" class="w-full px-2 py-1.5 rounded-lg text-xs border border-gray-200 focus:ring-2 focus:ring-emerald-500 outline-none transition-all" placeholder="e.g. 10">
          </div>
          <div class="flex-1">
            <label class="block text-[10px] text-gray-400 mb-0.5">Max Length</label>
            <input type="number" id="node-max-length" min="0" class="w-full px-2 py-1.5 rounded-lg text-xs border border-gray-200 focus:ring-2 focus:ring-emerald-500 outline-none transition-all" placeholder="e.g. 500">
          </div>
        </div>
      </div>

      <div class="bg-blue-50/50 rounded-xl p-3 border border-blue-100">
        <label class="block text-xs font-medium text-blue-700 mb-2 flex items-center gap-1.5"><i class="fas fa-filter text-blue-500"></i>Answer Scope <span class="font-normal text-blue-400">(optional)</span></label>
        <div class="flex gap-1.5 mb-2.5" id="scope-type-picker">
          <button type="button" data-scope="none" onclick="selectScopeType('none',this)" class="scope-type-btn flex-1 px-2 py-1.5 rounded-lg text-[10px] font-semibold border-2 border-blue-200 bg-white text-blue-500 hover:border-blue-300 transition-all"><i class="fas fa-times mr-0.5"></i>None</button>
          <button type="button" data-scope="absolute" onclick="selectScopeType('absolute',this)" class="scope-type-btn flex-1 px-2 py-1.5 rounded-lg text-[10px] font-semibold border-2 border-gray-200 bg-white text-gray-500 hover:border-blue-300 transition-all"><i class="fas fa-lock mr-0.5"></i>Absolute</button>
          <button type="button" data-scope="set" onclick="selectScopeType('set',this)" class="scope-type-btn flex-1 px-2 py-1.5 rounded-lg text-[10px] font-semibold border-2 border-gray-200 bg-white text-gray-500 hover:border-blue-300 transition-all"><i class="fas fa-layer-group mr-0.5"></i>Set</button>
          <button type="button" data-scope="near" onclick="selectScopeType('near',this)" class="scope-type-btn flex-1 px-2 py-1.5 rounded-lg text-[10px] font-semibold border-2 border-gray-200 bg-white text-gray-500 hover:border-blue-300 transition-all"><i class="fas fa-wave-square mr-0.5"></i>Near</button>
        </div>
        <div id="scope-fields" class="hidden">
          <div id="scope-label-wrap" class="hidden mb-2">
            <label class="block text-[10px] font-medium text-blue-600 mb-0.5">Category Name</label>
            <input type="text" id="node-scope-label" class="w-full px-2 py-1.5 rounded-lg text-xs border border-blue-200 focus:ring-2 focus:ring-blue-300 outline-none transition-all bg-white" placeholder="e.g. Car Brands, Countries, Emotions...">
          </div>
          <label class="block text-[10px] font-medium text-blue-600 mb-0.5">Accepted Values <span class="font-normal text-blue-400">(one per line)</span></label>
          <textarea id="node-answer-scope" rows="3" class="w-full px-2 py-1.5 rounded-lg text-xs border border-blue-200 focus:ring-2 focus:ring-blue-300 outline-none resize-none bg-white transition-all" placeholder="Honda&#10;BMW&#10;Toyota"></textarea>
          <p id="scope-hint" class="text-[9px] text-blue-400 mt-1">Only these answers are accepted. Close misspellings require confirmation.</p>
        </div>
      </div>

      <div class="pt-3 border-t border-gray-100">
        <h4 class="text-xs font-bold text-gray-700 mb-3 flex items-center gap-1.5"><i class="fas fa-brain text-purple-500"></i> AI Behavior</h4>
        <div class="space-y-3">
          <div class="flex items-center justify-between">
            <label class="text-xs text-gray-600">Enable Sentiment Analysis</label>
            <label class="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" id="node-sentiment" class="sr-only peer">
              <div class="w-9 h-5 bg-gray-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-emerald-300 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-500"></div>
            </label>
          </div>
          <div class="flex items-center justify-between">
            <label class="text-xs text-gray-600">Enable Adaptive Follow-up</label>
            <label class="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" id="node-followup" class="sr-only peer">
              <div class="w-9 h-5 bg-gray-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-emerald-300 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-500"></div>
            </label>
          </div>
          <div>
            <label class="block text-xs text-gray-600 mb-1">Minimum Depth <span class="text-gray-400 font-normal">(follow-up chain length)</span></label>
            <select id="node-depth" class="w-full px-2 py-1.5 rounded-lg text-xs border border-gray-200 focus:ring-2 focus:ring-emerald-500 outline-none transition-all">
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
            </select>
          </div>
          <div>
            <label class="block text-xs text-gray-600 mb-1">Follow-up Question Template</label>
            <textarea id="node-followup-template" rows="2" class="w-full px-2 py-1.5 rounded-lg text-xs border border-gray-200 focus:ring-2 focus:ring-emerald-500 outline-none transition-all resize-none" placeholder="Can you tell me more about..."></textarea>
          </div>
        </div>
      </div>

      <div>
        <label class="block text-xs font-medium text-gray-600 mb-1">Message Animation</label>
        <select id="node-animation" class="w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-emerald-500 outline-none transition-all">
          <option value="slide-up">Slide Up</option>
          <option value="fade-in">Fade In</option>
          <option value="scale-in">Scale In</option>
          <option value="none">None</option>
        </select>
      </div>
      <div class="flex items-center justify-between">
        <label class="text-xs font-medium text-gray-600">Required</label>
        <label class="relative inline-flex items-center cursor-pointer">
          <input type="checkbox" id="node-required" class="sr-only peer">
          <div class="w-9 h-5 bg-gray-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-emerald-300 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-500"></div>
        </label>
      </div>
    </div>
    <div class="flex items-center justify-end gap-2 px-5 py-4 border-t border-gray-100">
      <button type="button" onclick="closeNodeModal()" class="px-4 py-2 text-sm font-medium text-gray-600 hover:bg-gray-100 rounded-xl transition-all">Cancel</button>
      <button type="button" onclick="saveNode()" class="px-4 py-2 text-sm font-medium bg-emerald-600 text-white hover:bg-emerald-700 rounded-xl transition-all flex items-center gap-1.5"><i class="fas fa-check"></i> Save Node</button>
    </div>
  </div>
</div>

<!-- Templates Drawer -->
<div id="templates-drawer" class="fixed inset-0 z-[55] hidden">
  <div class="absolute inset-0 bg-black/30 backdrop-blur-sm" onclick="hideTemplates()"></div>
  <div class="absolute right-0 top-0 h-full w-full max-w-md bg-white shadow-2xl animate-slide-in overflow-y-auto">
    <div class="flex items-center justify-between px-5 py-4 border-b border-gray-100 sticky top-0 bg-white z-10">
      <h3 class="text-base font-bold text-gray-900"><i class="fas fa-layer-group text-emerald-500 mr-2"></i>Chat Templates</h3>
      <button type="button" onclick="hideTemplates()" class="w-8 h-8 rounded-xl hover:bg-gray-100 transition-all text-gray-400 hover:text-gray-600"><i class="fas fa-times"></i></button>
    </div>
    <div class="p-4">
      <div class="mb-3">
        <input type="text" id="template-search" placeholder="Search templates..." class="w-full px-3 py-2 rounded-xl text-sm border border-gray-200 focus:ring-2 focus:ring-emerald-500 outline-none" oninput="filterTemplates(this.value)">
      </div>
      <div id="template-grid" class="space-y-2"></div>
    </div>
  </div>
</div>

<!-- Delete Confirm Modal -->
<div id="delete-modal" class="fixed inset-0 z-[60] flex items-center justify-center hidden">
  <div class="absolute inset-0 bg-black/40 backdrop-blur-sm" onclick="closeDeleteModal()"></div>
  <div class="relative bg-white rounded-2xl shadow-2xl w-full max-w-sm mx-4 p-6 text-center animate-scale-in">
    <div class="w-14 h-14 mx-auto rounded-2xl bg-red-100 flex items-center justify-center mb-4">
      <i class="fas fa-trash-alt text-red-500 text-xl"></i>
    </div>
    <h3 class="text-lg font-bold text-gray-900 mb-2">Delete Node?</h3>
    <p class="text-sm text-gray-500 mb-6">This action cannot be undone. The node will be permanently removed.</p>
    <div class="flex gap-2 justify-center">
      <button type="button" onclick="closeDeleteModal()" class="px-4 py-2 text-sm font-medium text-gray-600 hover:bg-gray-100 rounded-xl transition-all">Cancel</button>
      <button type="button" id="confirm-delete-btn" class="px-4 py-2 text-sm font-medium bg-red-600 text-white hover:bg-red-700 rounded-xl transition-all flex items-center gap-1.5"><i class="fas fa-trash"></i> Delete</button>
    </div>
  </div>
</div>

<style>
.thinking-dots span { display: inline-block; width: 4px; height: 4px; background: #10b981; border-radius: 50%; animation: thinkingBounce 1.4s ease-in-out infinite; }
.thinking-dots span:nth-child(1) { animation-delay: 0s; }
.thinking-dots span:nth-child(2) { animation-delay: 0.2s; }
.thinking-dots span:nth-child(3) { animation-delay: 0.4s; }
@keyframes thinkingBounce { 0%, 80%, 100% { transform: scale(0.6); opacity: 0.4; } 40% { transform: scale(1); opacity: 1; } }

.chat-node-card { transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); position: relative; }
.chat-node-card:hover { transform: translateX(4px); }
.chat-node-card::before { content: ''; position: absolute; left: -16px; top: 50%; width: 12px; height: 2px; background: #d1d5db; }
.chat-node-card:first-child::before { display: none; }
.chat-node-connector { position: absolute; left: -8px; top: -16px; bottom: 50%; width: 2px; background: #d1d5db; }
.chat-node-card:first-child .chat-node-connector { display: none; }

#preview-phone { max-width: 320px; }
#preview-body::-webkit-scrollbar { width: 3px; }
#preview-body::-webkit-scrollbar-thumb { background: #d1d5db; border-radius: 10px; }

/* Collapsible section transitions */
#ci-templates, #ci-chat-builder, #ci-ai-config, #ci-branding, #ci-access, #ci-vis-body, #ci-qc { overflow:hidden; transition:max-height 0.35s ease; }

input[type="range"]::-webkit-slider-thumb { -webkit-appearance: none; height: 16px; width: 16px; border-radius: 50%; background: #10b981; cursor: pointer; }
input[type="range"]::-moz-range-thumb { height: 16px; width: 16px; border-radius: 50%; background: #10b981; cursor: pointer; border: none; }

@keyframes slideInRight { from { transform: translateX(100%); } to { transform: translateX(0); } }
#templates-drawer .absolute.right-0 { animation: slideInRight 0.3s ease-out; }
</style>

<script>
(function() {
  'use strict';

  const $ = function(id) {
    const el = document.getElementById(id);
    return el || null;
  };

  const escapeHtml = function(str) {
    if (!str) return '';
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  };

  // --- Templates ---
  const templates = [
    { key: 'csat', name: 'CSAT Survey', icon: 'fa-smile', desc: 'Customer satisfaction', color: 'emerald', nodes: [
      { question: 'How would you rate your overall experience?', type: 'rating', required: true, sentiment: true, followup: true, depth: 2 },
      { question: 'What did you like most about your experience?', type: 'text', required: false, sentiment: true, followup: false, depth: 1 },
      { question: 'What could we improve?', type: 'text', required: false, sentiment: true, followup: true, depth: 2 },
      { question: 'Would you recommend us to a friend?', type: 'yes_no', required: true, sentiment: false, followup: true, depth: 1 }
    ]},
    { key: 'nps', name: 'NPS Survey', icon: 'fa-chart-bar', desc: 'Net Promoter Score', color: 'emerald', nodes: [
      { question: 'How likely are you to recommend us?', type: 'nps', required: true, sentiment: false, followup: true, depth: 2 },
      { question: 'What is the primary reason for your score?', type: 'text', required: false, sentiment: true, followup: true, depth: 3 },
      { question: 'What could we do to earn a higher score?', type: 'text', required: false, sentiment: true, followup: false, depth: 1 }
    ]},
    { key: 'feedback', name: 'Feedback', icon: 'fa-comment', desc: 'General feedback', color: 'emerald', nodes: [
      { question: 'How was your experience today?', type: 'rating', required: true, sentiment: true, followup: true, depth: 2 },
      { question: 'Tell us more about your experience', type: 'text', required: false, sentiment: true, followup: true, depth: 3 },
      { question: 'Any additional comments?', type: 'text', required: false, sentiment: false, followup: false, depth: 1 }
    ]},
    { key: 'quiz', name: 'Quiz', icon: 'fa-gamepad', desc: 'Knowledge check', color: 'purple', nodes: [
      { question: 'Ready for a quick quiz?', type: 'yes_no', required: true, sentiment: false, followup: false, depth: 1 },
      { question: 'What is the capital of France?', type: 'mcq_single', options: ['London','Paris','Berlin','Madrid'], required: true, sentiment: false, followup: false, depth: 1 },
      { question: 'Which planets are in our solar system?', type: 'mcq_multiple', options: ['Mars','Pluto','Venus','Saturn'], required: true, sentiment: false, followup: false, depth: 1 },
      { question: 'How many continents are there?', type: 'number', required: true, sentiment: false, followup: false, depth: 1 }
    ]},
    { key: 'onboarding', name: 'Onboarding', icon: 'fa-rocket', desc: 'New user onboarding', color: 'blue', nodes: [
      { question: 'Welcome! What brings you here today?', type: 'mcq_single', options: ['Learning','Working','Exploring','Other'], required: true, sentiment: false, followup: true, depth: 2 },
      { question: 'How familiar are you with our platform?', type: 'likert5', required: true, sentiment: false, followup: false, depth: 1 },
      { question: 'What features interest you most?', type: 'text', required: false, sentiment: true, followup: true, depth: 2 }
    ]},
    { key: 'research', name: 'Research', icon: 'fa-flask', desc: 'Academic research', color: 'violet', nodes: [
      { question: 'What is your field of study?', type: 'text', required: true, sentiment: false, followup: true, depth: 2 },
      { question: 'How frequently do you conduct research?', type: 'likert5', required: true, sentiment: false, followup: false, depth: 1 },
      { question: 'What tools do you currently use?', type: 'text', required: false, sentiment: false, followup: true, depth: 2 }
    ]}
  ];

  // --- Theme data ---
  const themeColors = {
    emerald: { from: 'from-emerald-500', to: 'to-emerald-600', bg: 'bg-emerald-500', light: 'bg-emerald-100', text: 'text-emerald-600', ring: 'focus:ring-emerald-500', border: 'border-emerald-500' },
    indigo: { from: 'from-indigo-500', to: 'to-indigo-600', bg: 'bg-indigo-500', light: 'bg-indigo-100', text: 'text-indigo-600', ring: 'focus:ring-indigo-500', border: 'border-indigo-500' },
    amber: { from: 'from-amber-500', to: 'to-amber-600', bg: 'bg-amber-500', light: 'bg-amber-100', text: 'text-amber-600', ring: 'focus:ring-amber-500', border: 'border-amber-500' },
    rose: { from: 'from-rose-500', to: 'to-rose-600', bg: 'bg-rose-500', light: 'bg-rose-100', text: 'text-rose-600', ring: 'focus:ring-rose-500', border: 'border-rose-500' },
    cyan: { from: 'from-cyan-500', to: 'to-cyan-600', bg: 'bg-cyan-500', light: 'bg-cyan-100', text: 'text-cyan-600', ring: 'focus:ring-cyan-500', border: 'border-cyan-500' },
    violet: { from: 'from-violet-500', to: 'to-violet-600', bg: 'bg-violet-500', light: 'bg-violet-100', text: 'text-violet-600', ring: 'focus:ring-violet-500', border: 'border-violet-500' },
    teal: { from: 'from-teal-500', to: 'to-teal-600', bg: 'bg-teal-500', light: 'bg-teal-100', text: 'text-teal-600', ring: 'focus:ring-teal-500', border: 'border-teal-500' },
    red: { from: 'from-red-500', to: 'to-red-600', bg: 'bg-red-500', light: 'bg-red-100', text: 'text-red-600', ring: 'focus:ring-red-500', border: 'border-red-500' },
    orange: { from: 'from-orange-500', to: 'to-orange-600', bg: 'bg-orange-500', light: 'bg-orange-100', text: 'text-orange-600', ring: 'focus:ring-orange-500', border: 'border-orange-500' },
    pink: { from: 'from-pink-500', to: 'to-pink-600', bg: 'bg-pink-500', light: 'bg-pink-100', text: 'text-pink-600', ring: 'focus:ring-pink-500', border: 'border-pink-500' },
    blue: { from: 'from-blue-500', to: 'to-blue-600', bg: 'bg-blue-500', light: 'bg-blue-100', text: 'text-blue-600', ring: 'focus:ring-blue-500', border: 'border-blue-500' },
    slate: { from: 'from-slate-500', to: 'to-slate-600', bg: 'bg-slate-500', light: 'bg-slate-100', text: 'text-slate-600', ring: 'focus:ring-slate-500', border: 'border-slate-500' }
  };

  const bgList = {
    glass: 'bg-gradient-to-br from-gray-50 via-indigo-50/30 to-purple-50/30',
    warm: 'bg-gradient-to-br from-amber-50 via-orange-50/30 to-rose-50/30',
    cool: 'bg-gradient-to-br from-sky-50 via-blue-50/30 to-cyan-50/30',
    dark: 'bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900',
    mountain: 'bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900',
    sunset: 'bg-gradient-to-br from-orange-600 via-rose-600 to-purple-800',
    ocean: 'bg-gradient-to-br from-cyan-600 via-blue-700 to-indigo-900',
    forest: 'bg-gradient-to-br from-emerald-800 via-green-700 to-teal-800',
    midnight: 'bg-gradient-to-br from-slate-900 via-gray-900 to-zinc-900',
    lavender: 'bg-gradient-to-br from-violet-300 via-fuchsia-200 to-pink-300',
    peach: 'bg-gradient-to-br from-amber-200 via-orange-200 to-rose-300',
    particles: 'bg-gradient-to-br from-gray-900 via-indigo-900 to-gray-900'
  };

  // --- State ---
  let chatNodes = [];
  let nodeIdCounter = 0;
  let selectedNodeIndex = -1;
  let deleteTargetIndex = -1;
  let selectedTheme = 'emerald';
  let selectedBg = 'glass';
  let selectedCardStyle = 'glass';
  let selectedRadius = 'xl';
  let selectedShadow = 'lg';
  let selectedFont = 'inherit';
  let selectedAnim = 'slide-up';
  let selectedBgType = 'gradient';

  // AI config state
  let aiProvider = 'pollinations';
  const aiModelOptions = {
    browser: ['Xenova/all-MiniLM-L6-v2'],
    pollinations: ['pollinations/ai'],
    openai: ['gpt-4o-mini', 'gpt-4o'],
    claude: ['claude-3-haiku', 'claude-3-sonnet'],
    gemini: ['gemini-2.0-flash'],
    deepseek: ['deepseek-chat', 'deepseek-reasoner'],
    puter: ['gemini-3.1-pro-preview', 'gpt-4o', 'claude-sonnet-4-20250514', 'claude-3.5-haiku-20241022']
  };

  // Try restoring from PHP-passed JSON
  // --- Render Chat Nodes ---
  const renderChatNodes = function() {
    const list = $('chat-nodes-list');
    const empty = $('chat-nodes-empty');
    const countLabel = $('node-count');
    if (!list) return;

    let html = '';
    for (let i = 0; i < chatNodes.length; i++) {
      const n = chatNodes[i];
      const typeColors = { text:'bg-gray-100 text-gray-700', rating:'bg-amber-100 text-amber-700', yes_no:'bg-blue-100 text-blue-700', mcq_single:'bg-purple-100 text-purple-700', mcq_multiple:'bg-fuchsia-100 text-fuchsia-700', number:'bg-cyan-100 text-cyan-700', nps:'bg-red-100 text-red-700', likert5:'bg-violet-100 text-violet-700' };
      const typeColor = typeColors[n.type] || 'bg-gray-100 text-gray-700';
      const badges = [];
      if (n.sentiment) badges.push('<span class="text-[8px] px-1.5 py-0.5 rounded-full bg-purple-100 text-purple-700 font-medium"><i class="fas fa-heart"></i> Sentiment</span>');
      if (n.followup) badges.push('<span class="text-[8px] px-1.5 py-0.5 rounded-full bg-blue-100 text-blue-700 font-medium"><i class="fas fa-comment-dots"></i> Follow-up</span>');
      if (n.required) badges.push('<span class="text-[8px] px-1.5 py-0.5 rounded-full bg-red-100 text-red-700 font-medium">Required</span>');
      if (n.scope_type && n.scope_type !== 'none' && n.answer_scope && n.answer_scope.length) {
        var scopeIcons = { absolute: 'fa-lock', set: 'fa-layer-group', near: 'fa-wave-square' };
        badges.push('<span class="text-[8px] px-1.5 py-0.5 rounded-full bg-cyan-100 text-cyan-700 font-medium"><i class="fas ' + (scopeIcons[n.scope_type] || 'fa-filter') + '"></i> ' + n.answer_scope.length + ' ' + n.scope_type + '</span>');
      }

      var isLast = i === chatNodes.length - 1;
      html += '<div class="relative">' +
        (!isLast ? '<div class="absolute left-[19px] top-9 bottom-0 w-[2px] bg-gradient-to-b from-emerald-300 to-emerald-100 rounded-full"></div>' : '') +
        '<div class="chat-node-card bg-white rounded-xl border border-gray-200 hover:border-emerald-200 hover:shadow-sm hover:shadow-emerald-100/50 transition-all p-3 relative" data-index="' + i + '">' +
        '<div class="flex items-start gap-2.5">' +
        '<div class="cursor-grab text-gray-300 hover:text-emerald-400 transition-colors flex-shrink-0 pt-1" title="Drag to reorder"><i class="fas fa-grip-vertical text-sm"></i></div>' +
        '<div class="flex-1 min-w-0">' +
        '<div class="flex items-start gap-2">' +
        '<span class="text-sm font-medium text-gray-800 leading-relaxed">' + escapeHtml(n.question || 'Untitled') + '</span>' +
        '<span class="text-[9px] px-1.5 py-0.5 rounded-full font-medium flex-shrink-0 mt-0.5 ' + typeColor + '">' + escapeHtml(n.type || 'text') + '</span>' +
        '</div>' +
        (badges.length ? '<div class="flex items-center gap-1 flex-wrap mt-1">' + badges.join('') + '</div>' : '') +
        '</div>' +
        '<div class="flex items-center gap-0.5 flex-shrink-0 pt-0.5">' +
        '<button type="button" onclick="window._editNode(' + i + ')" class="w-7 h-7 rounded-lg hover:bg-emerald-50 text-gray-400 hover:text-emerald-600 transition-all flex items-center justify-center text-[10px]" title="Edit"><i class="fas fa-pen"></i></button>' +
        '<button type="button" onclick="window._duplicateNode(' + i + ')" class="w-7 h-7 rounded-lg hover:bg-blue-50 text-gray-400 hover:text-blue-600 transition-all flex items-center justify-center text-[10px]" title="Duplicate"><i class="fas fa-copy"></i></button>' +
        '<button type="button" onclick="window._deleteNode(' + i + ')" class="w-7 h-7 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-600 transition-all flex items-center justify-center text-[10px]" title="Delete"><i class="fas fa-trash-alt"></i></button>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '</div>';
    }

    if (chatNodes.length === 0) {
      if (empty) empty.classList.remove('hidden');
      if (countLabel) countLabel.textContent = '0 nodes';
    } else {
      if (empty) empty.classList.add('hidden');
      if (countLabel) countLabel.textContent = chatNodes.length + ' nodes';
    }

    list.innerHTML = html;

    // Make draggable
    const items = list.querySelectorAll('.chat-node-card');
    let dragIndex = -1;
    items.forEach(function(el) {
      const handle = el.querySelector('.cursor-grab');
      if (handle) {
        handle.addEventListener('mousedown', function(e) {
          e.preventDefault();
          dragIndex = parseInt(el.dataset.index);
          el.style.opacity = '0.5';
          const onMove = function(ev) {
            const target = ev.target.closest('.chat-node-card');
            if (target && target !== el) {
              const toIndex = parseInt(target.dataset.index);
              if (toIndex !== dragIndex) {
                moveNode(dragIndex, toIndex);
                dragIndex = toIndex;
              }
            }
          };
          const onUp = function() {
            el.style.opacity = '1';
            document.removeEventListener('mousemove', onMove);
            document.removeEventListener('mouseup', onUp);
          };
          document.addEventListener('mousemove', onMove);
          document.addEventListener('mouseup', onUp);
        });
      }
    });

    updateChatConfig();
    updateChatPreview();
  };

  // --- Node CRUD ---
  const addChatNode = function() {
    const node = {
      id: nodeIdCounter++,
      question: '',
      type: 'text',
      options: [],
      required: false,
      sentiment: false,
      followup: false,
      depth: 1,
      followupTemplate: '',
      animation: 'slide-up',
      scope_type: 'none',
      scope_label: '',
      answer_scope: []
    };
    chatNodes.push(node);
    renderChatNodes();
    openNodeModal(chatNodes.length - 1);
  };

  const editNode = function(index) {
    openNodeModal(index);
  };

  const duplicateNode = function(index) {
    if (index < 0 || index >= chatNodes.length) return;
    const orig = chatNodes[index];
    const copy = JSON.parse(JSON.stringify(orig));
    copy.id = nodeIdCounter++;
    copy.question = orig.question + ' (Copy)';
    chatNodes.splice(index + 1, 0, copy);
    renderChatNodes();
    showToast('Node duplicated', 'success');
  };

  const deleteNode = function(index) {
    selectedNodeIndex = index;
    deleteTargetIndex = index;
    $('delete-modal').classList.remove('hidden');
  };

  const confirmDeleteNode = function() {
    if (deleteTargetIndex >= 0 && deleteTargetIndex < chatNodes.length) {
      chatNodes.splice(deleteTargetIndex, 1);
      renderChatNodes();
      showToast('Node deleted', 'success');
    }
    deleteTargetIndex = -1;
    closeDeleteModal();
  };

  const moveNode = function(from, to) {
    if (from < 0 || to < 0 || from >= chatNodes.length || to >= chatNodes.length) return;
    const item = chatNodes.splice(from, 1)[0];
    chatNodes.splice(to, 0, item);
    renderChatNodes();
  };

  // --- Node Modal ---
  const openNodeModal = function(index) {
    selectedNodeIndex = index;
    const n = chatNodes[index];
    if (!n) return;

    $('node-question').value = n.question || '';
    $('node-type').value = n.type || 'text';
    $('node-sentiment').checked = !!n.sentiment;
    $('node-followup').checked = !!n.followup;
    $('node-depth').value = n.depth || 1;
    $('node-followup-template').value = n.followupTemplate || '';
    $('node-animation').value = n.animation || 'slide-up';
    $('node-required').checked = !!n.required;
    $('node-min-val').value = n.min_value !== undefined && n.min_value !== null ? n.min_value : '';
    $('node-max-val').value = n.max_value !== undefined && n.max_value !== null ? n.max_value : '';
    $('node-min-length').value = n.min_length !== undefined && n.min_length !== null ? n.min_length : '';
    $('node-max-length').value = n.max_length !== undefined && n.max_length !== null ? n.max_length : '';

    var scopeType = n.scope_type || 'none';
    document.querySelectorAll('.scope-type-btn').forEach(function(b) {
      b.classList.remove('border-blue-500', 'bg-blue-50', 'text-blue-700', 'ring-2', 'ring-offset-1', 'ring-blue-300');
      b.classList.add('border-gray-200', 'bg-white', 'text-gray-500');
    });
    var activeBtn = document.querySelector('.scope-type-btn[data-scope="' + scopeType + '"]');
    if (activeBtn) {
      activeBtn.classList.remove('border-gray-200', 'bg-white', 'text-gray-500');
      activeBtn.classList.add('border-blue-500', 'bg-blue-50', 'text-blue-700', 'ring-2', 'ring-offset-1', 'ring-blue-300');
    }
    $('node-scope-label').value = n.scope_label || '';
    $('node-answer-scope').value = (n.answer_scope || []).join('\n');
    toggleScopeFields(scopeType);

    renderNodeOptions();
    toggleNodeOptions();
    $('node-modal').classList.remove('hidden');
  };

  const closeNodeModal = function() {
    $('node-modal').classList.add('hidden');
    selectedNodeIndex = -1;
  };

  const saveNode = function() {
    if (selectedNodeIndex < 0 || selectedNodeIndex >= chatNodes.length) {
      closeNodeModal();
      return;
    }
    const n = chatNodes[selectedNodeIndex];
    n.question = $('node-question').value;
    n.type = $('node-type').value;
    n.sentiment = $('node-sentiment').checked;
    n.followup = $('node-followup').checked;
    n.depth = parseInt($('node-depth').value) || 1;
    n.followupTemplate = $('node-followup-template').value;
    n.animation = $('node-animation').value;
    n.required = $('node-required').checked;

    var minVal = $('node-min-val').value;
    var maxVal = $('node-max-val').value;
    n.min_value = minVal !== '' ? parseFloat(minVal) : null;
    n.max_value = maxVal !== '' ? parseFloat(maxVal) : null;

    var minLen = $('node-min-length').value;
    var maxLen = $('node-max-length').value;
    n.min_length = minLen !== '' ? parseInt(minLen, 10) : null;
    n.max_length = maxLen !== '' ? parseInt(maxLen, 10) : null;

    var scopeTypeBtn = document.querySelector('.scope-type-btn.border-blue-500');
    n.scope_type = scopeTypeBtn ? scopeTypeBtn.dataset.scope : 'none';
    n.scope_label = $('node-scope-label').value.trim();
    var scopeRaw = $('node-answer-scope').value;
    n.answer_scope = scopeRaw ? scopeRaw.split('\n').map(function(s) { return s.trim(); }).filter(Boolean) : [];

    // Save options
    if (n.type === 'mcq_single' || n.type === 'mcq_multiple') {
      const opts = $('node-options-list').querySelectorAll('input');
      n.options = [];
      opts.forEach(function(inp) { if (inp.value.trim()) n.options.push(inp.value.trim()); });
    } else {
      n.options = [];
    }

    renderChatNodes();
    closeNodeModal();
    showToast('Node saved', 'success');
  };

  const renderNodeOptions = function() {
    const list = $('node-options-list');
    const n = selectedNodeIndex >= 0 ? chatNodes[selectedNodeIndex] : null;
    const opts = n && n.options && n.options.length ? n.options : ['Option 1', 'Option 2'];
    let html = '';
    opts.forEach(function(o, i) {
      html += '<div class="flex items-center gap-1.5">';
      html += '<span class="text-gray-400 text-xs w-4">' + (i + 1) + '.</span>';
      html += '<input type="text" value="' + escapeHtml(o) + '" class="flex-1 px-2 py-1.5 rounded-lg text-xs border border-gray-200 focus:ring-2 focus:ring-emerald-500 outline-none" placeholder="Option text">';
      html += '<button type="button" onclick="this.closest(\'div\').remove()" class="w-6 h-6 rounded hover:bg-red-50 text-gray-400 hover:text-red-500 flex items-center justify-center text-[9px]"><i class="fas fa-times"></i></button>';
      html += '</div>';
    });
    list.innerHTML = html;
  };

  const addNodeOption = function() {
    const list = $('node-options-list');
    const div = document.createElement('div');
    div.className = 'flex items-center gap-1.5';
    const idx = list.children.length + 1;
    div.innerHTML = '<span class="text-gray-400 text-xs w-4">' + idx + '.</span><input type="text" value="" class="flex-1 px-2 py-1.5 rounded-lg text-xs border border-gray-200 focus:ring-2 focus:ring-emerald-500 outline-none" placeholder="Option text"><button type="button" onclick="this.closest(\'div\').remove()" class="w-6 h-6 rounded hover:bg-red-50 text-gray-400 hover:text-red-500 flex items-center justify-center text-[9px]"><i class="fas fa-times"></i></button>';
    list.appendChild(div);
  };

  const selectScopeType = function(type, btn) {
    document.querySelectorAll('.scope-type-btn').forEach(function(b) {
      b.classList.remove('border-blue-500', 'bg-blue-50', 'text-blue-700', 'ring-2', 'ring-offset-1', 'ring-blue-300');
      b.classList.add('border-gray-200', 'bg-white', 'text-gray-500');
    });
    btn.classList.remove('border-gray-200', 'bg-white', 'text-gray-500');
    btn.classList.add('border-blue-500', 'bg-blue-50', 'text-blue-700', 'ring-2', 'ring-offset-1', 'ring-blue-300');
    toggleScopeFields(type);
  };

  const toggleScopeFields = function(type) {
    var fields = $('scope-fields');
    var labelWrap = $('scope-label-wrap');
    var hint = $('scope-hint');
    if (type === 'none' || !type) {
      fields.classList.add('hidden');
    } else {
      fields.classList.remove('hidden');
      if (type === 'set') {
        labelWrap.classList.remove('hidden');
      } else {
        labelWrap.classList.add('hidden');
      }
      if (hint) {
        if (type === 'absolute') hint.textContent = 'Only these exact answers are accepted. Close misspellings require confirmation.';
        else if (type === 'set') hint.textContent = 'Category-based validation. AI checks if answer belongs to this category. Exact items get confirmed on misspelling.';
        else if (type === 'near') hint.textContent = 'Lenient matching. Accepts answers that are semantically related to the listed anchors.';
      }
    }
  };

  const toggleNodeOptions = function() {
    const type = $('node-type').value;
    const wrap = $('node-options-wrap');
    const valWrap = $('node-validation-wrap');
    const textWrap = $('node-text-limit-wrap');
    if (type === 'mcq_single' || type === 'mcq_multiple') {
      wrap.classList.remove('hidden');
    } else {
      wrap.classList.add('hidden');
    }
    if (type === 'number') {
      valWrap.classList.remove('hidden');
    } else {
      valWrap.classList.add('hidden');
    }
    if (type === 'text' || type === 'textarea') {
      textWrap.classList.remove('hidden');
    } else {
      textWrap.classList.add('hidden');
    }
  };

  // --- Chat Config ---
  const updateChatConfig = function() {
    const config = {
      nodes: chatNodes,
      intro_message: $('chat-intro') ? $('chat-intro').value : '',
      tone: $('chat-tone') ? $('chat-tone').value : 'neutral'
    };
    const input = $('chat-config-input');
    if (input) input.value = JSON.stringify(config);
    // Also update questions_json for the main form
    const qJson = $('questions-json');
    if (qJson) qJson.value = JSON.stringify(chatNodes);
  };

  // --- Chat Preview ---
  const updateChatPreview = function() {
    const body = $('preview-chat-nodes');
    const countLabel = $('preview-node-count');
    const botMsg = $('preview-bot-msg');
    const thinking = $('preview-thinking');

    if (!body) return;
    if (countLabel) countLabel.textContent = chatNodes.length + ' nodes';

    const intro = $('chat-intro') ? $('chat-intro').value : '';
    if (botMsg) botMsg.textContent = intro || 'Welcome! Let\'s start the conversation.';

    let html = '';
    for (let i = 0; i < chatNodes.length; i++) {
      const n = chatNodes[i];
      const anim = n.animation || 'slide-up';
      let questionText = escapeHtml(n.question || 'Untitled question');
      if (i === 0) {
        html += '<div class="flex items-start gap-2 animate-' + anim + '">';
        html += '<div class="w-6 h-6 rounded-full bg-gradient-to-br from-emerald-400 to-emerald-600 flex items-center justify-center text-white text-[9px] font-bold flex-shrink-0 mt-0.5">AI</div>';
        html += '<div class="bg-white rounded-2xl rounded-tl-sm px-3 py-2 shadow-sm max-w-[80%]"><p class="text-xs text-gray-700">' + questionText + '</p></div>';
        html += '</div>';
      } else {
        html += '<div class="flex items-start gap-2 justify-end">';
        html += '<div class="bg-emerald-500 rounded-2xl rounded-tr-sm px-3 py-2 shadow-sm max-w-[80%]"><p class="text-xs text-white">Sample response</p></div>';
        html += '<div class="w-6 h-6 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-600 text-[9px] font-bold flex-shrink-0 mt-0.5">U</div>';
        html += '</div>';
        html += '<div class="flex items-start gap-2 animate-' + anim + '">';
        html += '<div class="w-6 h-6 rounded-full bg-gradient-to-br from-emerald-400 to-emerald-600 flex items-center justify-center text-white text-[9px] font-bold flex-shrink-0 mt-0.5">AI</div>';
        html += '<div class="bg-white rounded-2xl rounded-tl-sm px-3 py-2 shadow-sm max-w-[80%]"><p class="text-xs text-gray-700">' + questionText + '</p></div>';
        html += '</div>';
      }
    }

    body.innerHTML = html;
    if (thinking) {
      if (chatNodes.length > 0) {
        thinking.classList.remove('hidden');
      } else {
        thinking.classList.add('hidden');
      }
    }
  };

  // --- Templates ---
  const renderTemplateCards = function() {
    const grid = $('template-cards');
    if (!grid) return;
    let html = '';
    templates.forEach(function(t) {
      html += '<div class="template-card p-3 rounded-xl border-2 border-emerald-200/50 hover:border-emerald-400 bg-white/50 hover:bg-white transition-all cursor-pointer text-center" onclick="selectTemplate(\'' + t.key + '\')">';
      html += '<div class="w-10 h-10 mx-auto rounded-xl bg-gradient-to-br from-emerald-100 to-emerald-200 flex items-center justify-center mb-2"><i class="fas ' + t.icon + ' text-emerald-600"></i></div>';
      html += '<div class="text-xs font-semibold text-gray-800">' + escapeHtml(t.name) + '</div>';
      html += '<div class="text-[9px] text-gray-400 mt-0.5">' + escapeHtml(t.desc) + '</div>';
      html += '</div>';
    });
    grid.innerHTML = html;
  };

  const filterTemplates = function(q) {
    const grid = $('template-grid');
    if (!grid) return;
    let html = '';
    const filtered = q ? templates.filter(function(t) { return t.name.toLowerCase().includes(q.toLowerCase()) || t.desc.toLowerCase().includes(q.toLowerCase()); }) : templates;
    filtered.forEach(function(t) {
      html += '<div class="p-4 rounded-xl border-2 border-gray-200 hover:border-emerald-400 bg-white hover:bg-emerald-50/30 transition-all cursor-pointer flex items-center gap-3" onclick="selectTemplate(\'' + t.key + '\');hideTemplates()">';
      html += '<div class="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-100 to-emerald-200 flex items-center justify-center flex-shrink-0"><i class="fas ' + t.icon + ' text-emerald-600"></i></div>';
      html += '<div class="flex-1 min-w-0"><div class="text-sm font-semibold text-gray-800">' + escapeHtml(t.name) + '</div><div class="text-[10px] text-gray-400">' + escapeHtml(t.desc) + '</div></div>';
      html += '<i class="fas fa-chevron-right text-gray-300 text-sm"></i>';
      html += '</div>';
    });
    if (filtered.length === 0) {
      html = '<div class="text-center py-8 text-gray-400 text-xs">No templates found</div>';
    }
    grid.innerHTML = html;
  };

  const selectTemplate = function(key) {
    const t = templates.find(function(t) { return t.key === key; });
    if (!t) return;
    chatNodes = [];
    nodeIdCounter = 0;
    t.nodes.forEach(function(n) {
      const node = {
        id: nodeIdCounter++,
        question: n.question || '',
        type: n.type || 'text',
        options: n.options || [],
        required: n.required || false,
        sentiment: n.sentiment || false,
        followup: n.followup || false,
        depth: n.depth || 1,
        followupTemplate: n.followupTemplate || '',
        animation: 'slide-up',
        scope_type: n.scope_type || 'none',
        scope_label: n.scope_label || '',
        answer_scope: n.answer_scope || []
      };
      chatNodes.push(node);
    });
    renderChatNodes();
    showToast('Template "' + t.name + '" applied', 'success');
    hideTemplates();

    // Set template key
    const tk = $('template-key-input');
    if (tk) tk.value = key;
  };

  const showTemplates = function() {
    $('templates-drawer').classList.remove('hidden');
    filterTemplates('');
  };

  const hideTemplates = function() {
    $('templates-drawer').classList.add('hidden');
  };

  const toggleTemplates = function() {
    if ($('templates-drawer').classList.contains('hidden')) {
      showTemplates();
    } else {
      hideTemplates();
    }
  };

  // --- AI Config ---
  const selectAIProvider = function(provider) {
    aiProvider = provider;
    const buttons = document.querySelectorAll('#ai-provider-picker button');
    buttons.forEach(function(btn) {
      btn.classList.remove('ring-2', 'ring-offset-2', 'ring-gray-900', 'border-gray-900');
    });
    const active = $('ai-p-' + provider);
    if (active) {
      active.classList.add('ring-2', 'ring-offset-2', 'ring-gray-900', 'border-gray-900');
    }
    const fields = $('ai-config-fields');
    if (provider === 'none') {
      fields.classList.add('hidden');
    } else {
      fields.classList.remove('hidden');
    }

    // Show/hide API key field based on provider
    const apiKeyWrap = $('ai-api-key') ? $('ai-api-key').closest('div') : null;
    const apiKeyLabel = apiKeyWrap ? apiKeyWrap.querySelector('label') : null;
    if (provider === 'pollinations' || provider === 'browser' || provider === 'puter') {
      if (apiKeyWrap) apiKeyWrap.classList.add('hidden');
    } else if (provider !== 'none') {
      if (apiKeyWrap) apiKeyWrap.classList.remove('hidden');
      if (apiKeyLabel) apiKeyLabel.textContent = 'API Key';
    }

    // Update model dropdown
    const modelSelect = $('ai-model');
    if (modelSelect) {
      modelSelect.innerHTML = '<option value="">Default</option>';
      if (aiModelOptions[provider]) {
        aiModelOptions[provider].forEach(function(m) {
          const opt = document.createElement('option');
          opt.value = m;
          opt.textContent = m;
          modelSelect.appendChild(opt);
        });
      }
    }

    updateAIConfig();
  };

  const updateAIConfig = function() {
    const config = {
      provider: aiProvider,
      model: $('ai-model') ? $('ai-model').value : '',
      api_key: $('ai-api-key') ? $('ai-api-key').value : '',
      capabilities: {
        sentiment: $('ai-cap-sentiment') ? $('ai-cap-sentiment').checked : false,
        followup: $('ai-cap-followup') ? $('ai-cap-followup').checked : false,
        summarize: $('ai-cap-summarize') ? $('ai-cap-summarize').checked : false,
        context_awareness: $('ai-cap-context') ? $('ai-cap-context').checked : false
      },
      system_prompt: $('ai-system-prompt') ? $('ai-system-prompt').value : '',
      temperature: parseFloat($('ai-temperature') ? $('ai-temperature').value : 0.7),
      max_tokens: parseInt($('ai-max-tokens') ? $('ai-max-tokens').value : 200)
    };
    const input = $('ai-config-input');
    if (input) input.value = JSON.stringify(config);
  };

  // --- Theme / Branding ---
  const selectTheme = function(color, btn) {
    selectedTheme = color;
    document.querySelectorAll('.theme-btn').forEach(function(b) { b.classList.remove('border-gray-900', 'ring-2', 'ring-offset-2', 'ring-gray-900'); b.classList.add('border-transparent'); });
    if (btn) { btn.classList.remove('border-transparent'); btn.classList.add('border-gray-900', 'ring-2', 'ring-offset-2', 'ring-gray-900'); }
    updatePreview();
  };

  const selectBg = function(bg, btn) {
    selectedBg = bg;
    document.querySelectorAll('.bg-btn').forEach(function(b) { b.classList.remove('border-gray-900', 'ring-2', 'ring-offset-2', 'ring-gray-900'); b.classList.add('border-transparent'); });
    if (btn) { btn.classList.remove('border-transparent'); btn.classList.add('border-gray-900', 'ring-2', 'ring-offset-2', 'ring-gray-900'); }
    updatePreview();
  };

  const selectCardStyle = function(style, btn) {
    selectedCardStyle = style;
    document.querySelectorAll('.card-style-btn').forEach(function(b) { b.classList.remove('border-gray-900', 'ring-2', 'ring-offset-2', 'ring-gray-900'); b.classList.add('border-gray-200'); });
    if (btn) { btn.classList.remove('border-gray-200'); btn.classList.add('border-gray-900', 'ring-2', 'ring-offset-2', 'ring-gray-900'); }
    updatePreview();
  };

  const selectRadius = function(radius, btn) {
    selectedRadius = radius;
    document.querySelectorAll('.radius-btn').forEach(function(b) { b.classList.remove('border-gray-900', 'ring-2', 'ring-offset-2', 'ring-gray-900'); b.classList.add('border-gray-200'); });
    if (btn) { btn.classList.remove('border-gray-200'); btn.classList.add('border-gray-900', 'ring-2', 'ring-offset-2', 'ring-gray-900'); }
    updatePreview();
  };

  const selectShadow = function(shadow, btn) {
    selectedShadow = shadow;
    document.querySelectorAll('.shadow-btn').forEach(function(b) { b.classList.remove('border-gray-900', 'ring-2', 'ring-offset-2', 'ring-gray-900'); b.classList.add('border-gray-200'); });
    if (btn) { btn.classList.remove('border-gray-200'); btn.classList.add('border-gray-900', 'ring-2', 'ring-offset-2', 'ring-gray-900'); }
    updatePreview();
  };

  const selectFont = function(font) {
    selectedFont = font;
    updatePreview();
  };

  const selectAnimation = function(anim) {
    selectedAnim = anim;
    updatePreview();
  };

  const selectBgType = function(type, btn) {
    selectedBgType = type;
    document.querySelectorAll('.bg-type-btn').forEach(function(b) { b.classList.remove('border-gray-900', 'ring-2', 'ring-offset-2', 'ring-gray-900'); b.classList.add('border-gray-200'); });
    if (btn) { btn.classList.remove('border-gray-200'); btn.classList.add('border-gray-900', 'ring-2', 'ring-offset-2', 'ring-gray-900'); }
    const v = $('bg-type-value'), img = $('bg-type-image'), vid = $('bg-type-video');
    if (v) { v.classList.toggle('hidden', type !== 'solid' && type !== 'gradient'); }
    if (img) { img.classList.toggle('hidden', type !== 'image'); }
    if (vid) { vid.classList.toggle('hidden', type !== 'video'); }
    updatePreview();
  };

  // --- Preview ---
  const updatePreview = function() {
    const header = $('preview-header');
    const phone = $('preview-phone');
    const titleEl = $('preview-title');
    const descEl = $('preview-desc');
    const logoImg = $('preview-logo-img');

    if (!header) return;

    const tc = themeColors[selectedTheme] || themeColors.emerald;
    header.className = 'px-4 py-3 bg-gradient-to-r ' + tc.from + ' ' + tc.to + ' transition-all duration-500 flex items-center gap-2';

    // Title
    const title = $('survey-title') ? $('survey-title').value : 'Chat Survey';
    if (titleEl) titleEl.textContent = title || 'Chat Survey';

    // Description
    const desc = $('survey-desc') ? $('survey-desc').value : '';
    if (descEl) {
      descEl.textContent = desc || 'AI-powered conversation';
      descEl.classList.toggle('hidden', !desc);
    }

    // Logo
    const logoUrl = $('logo-url') ? $('logo-url').value : '';
    if (logoImg) {
      if (logoUrl) {
        logoImg.src = logoUrl;
        logoImg.parentElement.classList.remove('hidden');
      } else {
        logoImg.parentElement.classList.add('hidden');
      }
    }

    // Font
    if (phone) {
      phone.style.fontFamily = selectedFont || 'inherit';
    }

    // Card style
    if (phone) {
      let cardClasses = 'bg-white rounded-xl border shadow-sm overflow-hidden transition-all duration-500';
      if (selectedCardStyle === 'glass') phone.className = 'bg-white/70 backdrop-blur-lg rounded-xl border border-white/30 shadow-lg overflow-hidden transition-all duration-500';
      else if (selectedCardStyle === 'solid') phone.className = 'bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden transition-all duration-500';
      else if (selectedCardStyle === 'bordered') phone.className = 'bg-white rounded-xl border-2 border-emerald-300 shadow-sm overflow-hidden transition-all duration-500';
      else if (selectedCardStyle === 'ghost') phone.className = 'bg-transparent rounded-xl border border-gray-200 overflow-hidden transition-all duration-500';
      else if (selectedCardStyle === 'dark-glass') phone.className = 'bg-gray-800/80 backdrop-blur-lg rounded-xl border border-gray-700 shadow-lg overflow-hidden transition-all duration-500';
      else if (selectedCardStyle === 'neumorphic') phone.className = 'bg-gray-50 rounded-xl shadow-[8px_8px_16px_#d1d5db,-8px_-8px_16px_#ffffff] overflow-hidden transition-all duration-500';
      else if (selectedCardStyle === 'gradient') phone.className = 'bg-gradient-to-br from-emerald-50 to-emerald-100 rounded-xl border border-emerald-200 shadow-sm overflow-hidden transition-all duration-500';
      else phone.className = cardClasses;
    }

    // Background for body
    const body = $('preview-body');
    if (body) {
      const bgClass = bgList[selectedBg] || bgList.glass;
      body.className = 'p-3 space-y-2 min-h-[280px] max-h-[400px] overflow-y-auto ' + bgClass;
    }

    // Theme config input
    const tcInput = $('theme-config-input');
    if (tcInput) {
      tcInput.value = JSON.stringify({
        theme: selectedTheme,
        background: selectedBg,
        logo_url: logoUrl,
        card_style: selectedCardStyle,
        question_border_radius: selectedRadius,
        question_shadow: selectedShadow,
        font_family: selectedFont,
        question_animation: selectedAnim,
        custom_css: $('custom-css') ? $('custom-css').value : '',
        bg_type: selectedBgType,
        bg_value: $('bg-value') ? $('bg-value').value : '',
        bg_image: $('bg-image') ? $('bg-image').value : '',
        bg_video: $('bg-video') ? $('bg-video').value : ''
      });
    }
  };

  // --- Section Toggle ---
  const toggleSection = function(id, btn) {
    const el = document.getElementById(id);
    if (!el) return;
    
    // Check if currently collapsed: has explicit max-height:0px or max-height:0
    const style = window.getComputedStyle(el);
    const isCollapsed = el.style.maxHeight === '0px' || el.style.maxHeight === '0';
    
    if (isCollapsed) {
      // Expand: temporarily remove constraints to measure full height
      el.style.maxHeight = 'none';
      el.style.overflow = 'visible';
      // Force reflow
      el.offsetHeight;
      const fullHeight = el.scrollHeight + 'px';
      // Store for future toggles
      el.dataset.fullHeight = fullHeight;
      // Now animate from 0 to full height
      el.style.maxHeight = '0px';
      el.style.overflow = 'hidden';
      // Force another reflow before setting the target height
      requestAnimationFrame(function() {
        el.style.maxHeight = fullHeight;
      });
      if (btn) {
        const icon = btn.querySelector('i');
        if (icon) icon.className = 'fas fa-chevron-up';
      }
    } else {
      // Collapse
      if (!el.dataset.fullHeight) {
        el.style.maxHeight = 'none';
        el.style.overflow = 'visible';
        el.offsetHeight;
        el.dataset.fullHeight = el.scrollHeight + 'px';
      }
      el.style.maxHeight = el.scrollHeight + 'px';
      requestAnimationFrame(function() { el.style.maxHeight = '0px'; });
      if (btn) {
        const icon = btn.querySelector('i');
        if (icon) icon.className = 'fas fa-chevron-down';
      }
    }
  };
  window.toggleSection = toggleSection;

  // --- Toast ---
  const showToast = function(msg, type) {
    type = type || 'success';
    const colors = { success: 'bg-emerald-500', error: 'bg-red-500', info: 'bg-blue-500', warning: 'bg-amber-500' };
    const bg = colors[type] || colors.success;
    const toast = document.createElement('div');
    toast.className = 'fixed bottom-6 right-6 z-[100] px-4 py-2.5 rounded-xl text-white text-sm font-medium shadow-lg ' + bg + ' animate-fade-in';
    toast.textContent = msg;
    document.body.appendChild(toast);
    setTimeout(function() { toast.classList.add('opacity-0', 'transition-opacity', 'duration-300'); setTimeout(function() { toast.remove(); }, 300); }, 2500);
  };

  // --- Auto Save ---
  let autoSaveTimer = null;
  const autoSave = function() {
    clearTimeout(autoSaveTimer);
    const indicator = $('auto-save-text');
    if (indicator) indicator.textContent = 'Saving...';
    autoSaveTimer = setTimeout(function() {
      updateChatConfig();
      updateAIConfig();
      updatePreview();
      if (indicator) indicator.textContent = 'Saved';
      setTimeout(function() { if (indicator) indicator.textContent = 'Ready'; }, 2000);
    }, 1000);
  };

  // --- Close Delete Modal ---
  const closeDeleteModal = function() {
    $('delete-modal').classList.add('hidden');
    deleteTargetIndex = -1;
  };

  // --- Keyboard shortcuts ---
  document.addEventListener('keydown', function(e) {
    // N = add node
    if (e.key === 'n' && !e.ctrlKey && !e.metaKey && !e.shiftKey && !e.altKey) {
      const active = document.activeElement;
      if (active && (active.tagName === 'INPUT' || active.tagName === 'TEXTAREA' || active.tagName === 'SELECT')) return;
      e.preventDefault();
      addChatNode();
    }
    // Ctrl+S = save (submit form)
    if ((e.ctrlKey || e.metaKey) && e.key === 's') {
      e.preventDefault();
      updateChatConfig();
      updateAIConfig();
      const form = $('survey-form');
      if (form) form.submit();
    }
    // / = focus search
    if (e.key === '/' && !e.ctrlKey && !e.metaKey && !e.shiftKey && !e.altKey) {
      const active = document.activeElement;
      if (active && (active.tagName === 'INPUT' || active.tagName === 'TEXTAREA' || active.tagName === 'SELECT')) return;
      e.preventDefault();
      showTemplates();
    }
    // Escape = close modals
    if (e.key === 'Escape') {
      if (!$('node-modal').classList.contains('hidden')) closeNodeModal();
      if (!$('templates-drawer').classList.contains('hidden')) hideTemplates();
      if (!$('delete-modal').classList.contains('hidden')) closeDeleteModal();
    }
  });

  // --- Watch for changes on key fields ---
  ['chat-intro', 'chat-tone', 'survey-title', 'survey-desc', 'logo-url', 'custom-css', 'bg-value', 'bg-image', 'bg-video'].forEach(function(id) {
    const el = $(id);
    if (el) {
      el.addEventListener('input', function() { autoSave(); updateChatPreview(); updatePreview(); });
    }
  });

  ['ai-temperature', 'ai-max-tokens', 'ai-model', 'ai-api-key', 'ai-system-prompt'].forEach(function(id) {
    const el = $(id);
    if (el) {
      el.addEventListener('input', function() { updateAIConfig(); autoSave(); });
      el.addEventListener('change', function() { updateAIConfig(); autoSave(); });
    }
  });

  ['font-family', 'question-animation'].forEach(function(id) {
    const el = $(id);
    if (el) {
      el.addEventListener('change', function() { updatePreview(); });
    }
  });

  ['ai-cap-sentiment', 'ai-cap-followup', 'ai-cap-summarize', 'ai-cap-context'].forEach(function(id) {
    const el = $(id);
    if (el) {
      el.addEventListener('change', function() { updateAIConfig(); autoSave(); });
    }
  });

  // --- Expose globals ---
  window.toggleSection = function(id, btn) {
    var el = document.getElementById(id);
    if (!el) return;
    if (!el.dataset.fullHeight) el.dataset.fullHeight = el.scrollHeight + 'px';
    if (el.style.maxHeight === '0px' || !el.style.maxHeight || el.style.maxHeight === '') {
      el.style.maxHeight = el.dataset.fullHeight || el.scrollHeight + 'px';
      btn.innerHTML = '<i class="fas fa-chevron-up"></i>';
    } else {
      el.style.maxHeight = el.scrollHeight + 'px';
      requestAnimationFrame(function() { el.style.maxHeight = '0px'; });
      btn.innerHTML = '<i class="fas fa-chevron-down"></i>';
    }
  };

  window._editNode = editNode;
  window._duplicateNode = duplicateNode;
  window._deleteNode = deleteNode;
  window.selectScopeType = selectScopeType;

  window.addChatNode = addChatNode;
  window.editNode = editNode;
  window.deleteNode = deleteNode;
  window.duplicateNode = duplicateNode;
  window.moveNode = moveNode;
  window.openNodeModal = openNodeModal;
  window.closeNodeModal = closeNodeModal;
  window.saveNode = saveNode;
  window.addNodeOption = addNodeOption;
  window.toggleNodeOptions = toggleNodeOptions;
  window.updateChatConfig = updateChatConfig;
  window.updateChatPreview = updateChatPreview;
  window.selectTemplate = selectTemplate;
  window.showTemplates = showTemplates;
  window.hideTemplates = hideTemplates;
  window.toggleTemplates = toggleTemplates;
  window.selectAIProvider = selectAIProvider;
  window.updateAIConfig = updateAIConfig;
  window.renderTemplateCards = renderTemplateCards;
  window.filterTemplates = filterTemplates;
  window.selectTheme = selectTheme;
  window.selectBg = selectBg;
  window.selectCardStyle = selectCardStyle;
  window.selectRadius = selectRadius;
  window.selectShadow = selectShadow;
  window.selectFont = selectFont;
  window.selectAnimation = selectAnimation;
  window.selectBgType = selectBgType;
  window.updatePreview = updatePreview;
  window.showToast = showToast;
  window.autoSave = autoSave;
  window.closeDeleteModal = closeDeleteModal;
  window.confirmDeleteNode = confirmDeleteNode;
  window.escapeHtml = escapeHtml;
  window.$ = $;

  // --- Restore saved state ---
  try {
    const ccInput = $('chat-config-input');
    if (ccInput && ccInput.value) {
      const parsed = JSON.parse(ccInput.value);
      if (parsed.nodes) chatNodes = parsed.nodes;
      if (parsed.intro_message) $('chat-intro').value = parsed.intro_message;
      if (parsed.tone) $('chat-tone').value = parsed.tone;
      if (chatNodes.length > 0) {
        nodeIdCounter = Math.max.apply(null, chatNodes.map(function(n) { return n.id || 0; })) + 1;
      }
    }
  } catch(e) {}

  try {
    const aiInput = $('ai-config-input');
    if (aiInput && aiInput.value) {
      const parsed = JSON.parse(aiInput.value);
      if (parsed.provider) {
        aiProvider = parsed.provider;
        selectAIProvider(parsed.provider);
      }
      if (parsed.model && $('ai-model')) $('ai-model').value = parsed.model;
      if (parsed.api_key && $('ai-api-key')) $('ai-api-key').value = parsed.api_key;
      if (parsed.capabilities) {
        if (parsed.capabilities.sentiment && $('ai-cap-sentiment')) $('ai-cap-sentiment').checked = true;
        if (parsed.capabilities.followup && $('ai-cap-followup')) $('ai-cap-followup').checked = true;
        if (parsed.capabilities.summarize && $('ai-cap-summarize')) $('ai-cap-summarize').checked = true;
        if (parsed.capabilities.context_awareness && $('ai-cap-context')) $('ai-cap-context').checked = true;
      }
      if (parsed.system_prompt && $('ai-system-prompt')) $('ai-system-prompt').value = parsed.system_prompt;
      if (parsed.temperature !== undefined && $('ai-temperature')) { $('ai-temperature').value = parsed.temperature; $('ai-temp-val').textContent = parsed.temperature; }
      if (parsed.max_tokens !== undefined && $('ai-max-tokens')) { $('ai-max-tokens').value = parsed.max_tokens; $('ai-tokens-val').textContent = parsed.max_tokens; }
    }
  } catch(e) {}

  // Default to Free API if no provider was explicitly set
  if (!aiProvider || aiProvider === 'none') {
    aiProvider = 'pollinations';
  }
  selectAIProvider(aiProvider);

  // --- Init ---
  try {
    renderTemplateCards();
    renderChatNodes();
    updateChatPreview();
    updatePreview();
    updateAIConfig();

    // Confirm delete handler
    const confirmBtn = $('confirm-delete-btn');
    if (confirmBtn) {
      confirmBtn.addEventListener('click', confirmDeleteNode);
    }
  } catch (e) {
    console.error('Chat builder init error:', e);
  }

  // --- Error handlers ---
  window.onerror = function(msg, src, line, col, err) {
    console.error('Chat builder error:', msg, src, line, col, err);
    return true;
  };

  window.addEventListener('unhandledrejection', function(e) {
    console.error('Unhandled promise rejection:', e.reason);
  });

})();
</script>
