<div class="max-w-3xl mx-auto">
    <div class="mb-6">
        <h1 class="text-2xl font-bold text-gray-900">Add Question</h1>
        <p class="text-gray-500 text-sm mt-1">Choose a question type and configure it</p>
    </div>

    <div class="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 sm:p-8">
        <form method="POST" action="<?= url('/survey/' . $surveyId) ?>/questions/add">
            <?= csrf() ?>
            <div class="mb-5">
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Question Type</label>
                <select name="type" id="question-type" class="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 text-sm" onchange="toggleFields()">
                    <option value="text">Text (Short Answer)</option>
                    <option value="number">Number</option>
                    <option value="email">Email</option>
                    <option value="phone">Phone</option>
                    <option value="date">Date</option>
                    <option value="likert5">Likert Scale (1-5)</option>
                    <option value="likert7">Likert Scale (1-7)</option>
                    <option value="mcq_single">Multiple Choice (Single)</option>
                    <option value="mcq_multiple">Multiple Choice (Multiple)</option>
                    <option value="dropdown">Dropdown</option>
                    <option value="rating">Rating (Stars)</option>
                    <option value="slider">Slider</option>
                    <option value="yes_no">Yes / No</option>
                    <option value="matrix">Matrix / Grid</option>
                </select>
            </div>

            <div class="mb-5">
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Question Text <span class="text-red-400">*</span></label>
                <textarea name="question_text" rows="2" required
                    class="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 text-sm"
                    placeholder="Enter your question..."></textarea>
            </div>

            <div id="options-section" class="mb-5 hidden">
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Options (one per line)</label>
                <textarea name="options" rows="4" placeholder="Option 1&#10;Option 2&#10;Option 3"
                    class="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 text-sm"></textarea>
                <p class="text-xs text-gray-400 mt-1">Enter each option on a new line</p>
            </div>

            <div id="matrix-section" class="mb-5 hidden">
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">Rows (one per line)</label>
                        <textarea name="rows" rows="4" placeholder="Row 1&#10;Row 2&#10;Row 3"
                            class="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 text-sm"></textarea>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">Columns (one per line)</label>
                        <textarea name="options" rows="4" placeholder="Column 1&#10;Column 2"
                            class="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 text-sm"></textarea>
                    </div>
                </div>
            </div>

            <div id="validation-section" class="mb-5 hidden">
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">Min Value</label>
                        <input type="number" name="min_value" step="any"
                            class="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 text-sm" placeholder="e.g., 0">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1.5">Max Value</label>
                        <input type="number" name="max_value" step="any"
                            class="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 text-sm" placeholder="e.g., 100">
                    </div>
                </div>
                <div class="mt-3">
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Char Limit</label>
                    <input type="number" name="char_limit"
                        class="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 text-sm" placeholder="e.g., 500">
                </div>
            </div>

            <div id="length-section" class="mb-5 p-4 bg-blue-50 border border-blue-200 rounded-xl hidden">
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-blue-800 mb-1.5">Min Length (chars)</label>
                        <input type="number" name="min_length" min="0"
                            class="w-full px-4 py-2.5 border border-blue-300 rounded-xl focus:ring-2 focus:ring-blue-500 text-sm" placeholder="e.g., 10">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-blue-800 mb-1.5">Max Length (chars)</label>
                        <input type="number" name="max_length" min="0"
                            class="w-full px-4 py-2.5 border border-blue-300 rounded-xl focus:ring-2 focus:ring-blue-500 text-sm" placeholder="e.g., 500">
                    </div>
                </div>
                <p class="text-xs text-blue-600 mt-1">Enforce minimum and/or maximum character length for text answers</p>
            </div>

            <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 mb-5">
                <label class="flex items-center gap-2 p-3 border border-gray-200 rounded-xl cursor-pointer hover:bg-gray-50 transition-all has-[:checked]:border-indigo-500 has-[:checked]:bg-indigo-50/50">
                    <input type="checkbox" name="is_required" checked class="rounded text-indigo-600">
                    <span class="text-sm font-medium">Required</span>
                    <?= help('Respondent must answer this question before submitting. Prevents skipped answers.') ?>
                </label>
                <label class="flex items-center gap-2 p-3 border border-gray-200 rounded-xl cursor-pointer hover:bg-gray-50 transition-all has-[:checked]:border-amber-500 has-[:checked]:bg-amber-50/50">
                    <input type="checkbox" name="is_attention_check" class="rounded text-amber-500" onchange="toggleAttention()">
                    <span class="text-sm font-medium">Attention Check</span>
                    <?= help('A verification question with a known answer. Flags respondents who answer incorrectly as low quality.') ?>
                </label>
                <label class="flex items-center gap-2 p-3 border border-gray-200 rounded-xl cursor-pointer hover:bg-gray-50 transition-all has-[:checked]:border-red-500 has-[:checked]:bg-red-50/50">
                    <input type="checkbox" name="is_trap" class="rounded text-red-500" onchange="toggleAttention()">
                    <span class="text-sm font-medium">Trap Question</span>
                    <?= help('A hidden test question that appears genuine but expects a specific answer. Flags respondents who fail.') ?>
                </label>
                <label class="flex items-center gap-2 p-3 border border-gray-200 rounded-xl cursor-pointer hover:bg-gray-50 transition-all has-[:checked]:border-orange-500 has-[:checked]:bg-orange-50/50">
                    <input type="checkbox" name="is_speed_bump" class="rounded text-orange-500" onchange="toggleAttention()">
                    <span class="text-sm font-medium">Speed Bump</span>
                    <?= help('An intentionally easy question placed after complex ones. If answered incorrectly, respondent may be rushing.') ?>
                </label>
                <label class="flex items-center gap-2 p-3 border border-gray-200 rounded-xl cursor-pointer hover:bg-gray-50 transition-all has-[:checked]:border-purple-500 has-[:checked]:bg-purple-50/50">
                    <input type="checkbox" name="is_timed" class="rounded text-purple-500" onchange="toggleTimed()">
                    <span class="text-sm font-medium">Timed (Freezes)</span>
                    <?= help('Respondent must answer within a time limit. Other questions freeze until answered. Prevents looking up answers.') ?>
                </label>
                <label class="flex items-center gap-2 p-3 border border-gray-200 rounded-xl cursor-pointer hover:bg-gray-50 transition-all has-[:checked]:border-red-500 has-[:checked]:bg-red-50/50">
                    <input type="checkbox" name="allow_paste" checked class="rounded text-red-500">
                    <span class="text-sm font-medium">Allow Paste</span>
                    <?= help('Allow copy-paste on this text field. Uncheck to force manual typing, preventing copied/plagiarized answers.') ?>
                </label>
            </div>

            <div id="timed-fields" class="mb-5 p-4 bg-purple-50 border border-purple-200 rounded-xl hidden">
                <label class="block text-sm font-medium text-purple-800 mb-1.5">Time Limit (seconds)</label>
                <input type="number" name="time_limit_seconds" value="30" min="1" max="600"
                    class="w-full px-4 py-2.5 border border-purple-300 rounded-xl focus:ring-2 focus:ring-purple-500 text-sm">
                <p class="text-xs text-purple-600 mt-1">Respondent must answer within this time. Other questions freeze until answered.</p>
            </div>

            <div id="attention-fields" class="mb-5 p-4 bg-amber-50 border border-amber-200 rounded-xl hidden">
                <label class="block text-sm font-medium text-amber-800 mb-1.5">Expected Answer</label>
                <input type="text" name="expected_answer"
                    class="w-full px-4 py-2.5 border border-amber-300 rounded-xl focus:ring-2 focus:ring-amber-500 text-sm"
                    placeholder="The correct answer for this verification question">
                <p class="text-xs text-amber-600 mt-1">Respondents must match this answer exactly to pass the check</p>
            </div>

            <button type="submit" class="w-full sm:w-auto bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-8 py-3 rounded-xl hover:from-indigo-700 hover:to-purple-700 transition-all font-medium shadow-sm">
                <i class="fas fa-plus mr-2"></i>Add Question
            </button>
        </form>
    </div>
</div>

<script>
function toggleFields() {
    const type = document.getElementById('question-type').value;
    const hasOptions = ['likert5', 'likert7', 'mcq_single', 'mcq_multiple', 'dropdown', 'rating'].includes(type);
    const isMatrix = type === 'matrix';
    const hasValidation = ['number', 'slider', 'text', 'email'].includes(type);
    const hasLength = ['text', 'email', 'phone', 'textarea'].includes(type);

    document.getElementById('options-section').classList.toggle('hidden', !hasOptions || isMatrix);
    document.getElementById('matrix-section').classList.toggle('hidden', !isMatrix);
    document.getElementById('validation-section').classList.toggle('hidden', !hasValidation);
    document.getElementById('length-section').classList.toggle('hidden', !hasLength);

    if (type === 'likert5') {
        document.querySelector('[name="options"]').value = 'Strongly Disagree\nDisagree\nNeutral\nAgree\nStrongly Agree';
    } else if (type === 'likert7') {
        document.querySelector('[name="options"]').value = 'Strongly Disagree\nDisagree\nSlightly Disagree\nNeutral\nSlightly Agree\nAgree\nStrongly Agree';
    } else if (type === 'rating') {
        document.querySelector('[name="options"]').value = '1 Star\n2 Stars\n3 Stars\n4 Stars\n5 Stars';
    }
}

function toggleAttention() {
    const checked = document.querySelector('[name="is_attention_check"]:checked') || document.querySelector('[name="is_trap"]:checked') || document.querySelector('[name="is_speed_bump"]:checked');
    document.getElementById('attention-fields').classList.toggle('hidden', !checked);
}

function toggleTimed() {
    const checked = document.querySelector('[name="is_timed"]:checked');
    document.getElementById('timed-fields').classList.toggle('hidden', !checked);
}

toggleFields();
</script>
