<div class="space-y-6">
    <div class="flex items-center justify-between">
        <div>
            <h1 class="text-2xl font-bold text-gray-900">Results: <?= htmlspecialchars($survey['title'] ?? '') ?></h1>
            <p class="text-gray-500"><?= count($responses ?? []) ?> responses received</p>
        </div>
        <div class="flex gap-2">
            <a href="<?= url('/quality/' . ($survey['id'] ?? '')) ?>" class="px-4 py-2 border rounded-lg hover:bg-gray-50">
                <i class="fas fa-check-double mr-2"></i>Quality Dashboard
            </a>
            <a href="<?= url('/export/' . ($survey['id'] ?? '')) ?>" class="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700">
                <i class="fas fa-download mr-2"></i>Export
            </a>
        </div>
    </div>

    <?php if (($surveyType ?? 'form') === 'chat'): ?>
        <!-- Chat Survey Results -->
        <div class="space-y-4">
            <?php if (empty($responses)): ?>
                <div class="bg-white rounded-xl shadow-sm border p-8 text-center text-gray-500">No responses yet</div>
            <?php else: ?>
                <?php foreach ($responses as $ri => $r): ?>
                    <?php
                    $cd = $r['chat_data_parsed'] ?? [];
                    ?>
                    <div class="bg-white rounded-xl shadow-sm border overflow-hidden">
                        <div class="px-4 py-3 bg-gray-50 border-b flex items-center justify-between">
                            <div class="flex items-center gap-2 sm:gap-3">
                                <span class="text-sm font-medium text-gray-700">Response #<?= $ri + 1 ?></span>
                                <?php if (!empty($r['completed_at'])): ?>
                                    <span class="hidden sm:inline text-xs text-gray-400"><?= date('M j, Y H:i', strtotime($r['completed_at'])) ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="flex items-center gap-2">
                                <?php if (($r['overall_score'] ?? null) !== null): ?>
                                    <span class="px-2 py-0.5 text-xs rounded-full <?= ($r['overall_score'] ?? 0) >= ($survey['quality_threshold'] ?? 70) ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' ?>">
                                        <?= number_format((float)($r['overall_score'] ?? 0), 1) ?>
                                    </span>
                                <?php endif; ?>
                                <span class="px-2 py-0.5 text-xs rounded-full 
                                    <?= ($r['status'] ?? '') === 'accepted' ? 'bg-green-100 text-green-800' : (($r['status'] ?? '') === 'rejected' ? 'bg-red-100 text-red-800' : (($r['status'] ?? '') === 'flagged' ? 'bg-yellow-100 text-yellow-800' : 'bg-gray-100 text-gray-800')) ?>">
                                    <?= $r['status'] ?? '' ?>
                                </span>
                                <a href="<?= url('/quality/' . ($survey['id'] ?? '') . '/response/' . ($r['id'] ?? '')) ?>" class="text-xs text-indigo-600 hover:underline whitespace-nowrap">View Detail</a>
                            </div>
                        </div>
                        <div class="p-4 space-y-3">
                            <?php if (empty($chatNodes) || empty($cd)): ?>
                                <p class="text-sm text-gray-400 text-center py-4">No conversation data available</p>
                            <?php else: ?>
                                <?php foreach ($chatNodes as $ni => $node): ?>
                                    <?php $nodeKey = !empty($node['key']) ? $node['key'] : 'q_' . $ni; ?>
                                    <?php $answer = $cd[$nodeKey] ?? null; ?>
                                    <?php if ($answer !== null): ?>
                                        <div class="flex gap-3">
                                            <div class="flex-1">
                                                <div class="text-xs font-medium text-emerald-700 mb-1">
                                                    <i class="fas fa-comment-dots mr-1"></i><?= htmlspecialchars($node['question'] ?? '') ?>
                                                </div>
                                                <?php if (is_array($answer)): ?>
                                                    <?php foreach ($answer as $ai => $amsg): ?>
                                                        <div class="text-sm text-gray-800 bg-gray-50 rounded-xl px-3 py-2 border border-gray-100 <?= $ai > 0 ? 'mt-1.5' : '' ?>">
                                                            <?= htmlspecialchars($amsg) ?>
                                                            <?php if ($ai < count($answer) - 1): ?>
                                                                <span class="text-xs text-gray-400 ml-1">↳ continued</span>
                                                            <?php endif; ?>
                                                        </div>
                                                    <?php endforeach; ?>
                                                <?php else: ?>
                                                    <div class="text-sm text-gray-800 bg-gray-50 rounded-xl px-3 py-2 border border-gray-100">
                                                        <?= htmlspecialchars($answer) ?>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                                <?php
                                $hasAnswers = false;
                                foreach ($chatNodes as $ni => $node) {
                                    $nk = !empty($node['key']) ? $node['key'] : 'q_' . $ni;
                                    if (isset($cd[$nk])) { $hasAnswers = true; break; }
                                }
                                ?>
                                <?php if (!$hasAnswers): ?>
                                    <p class="text-sm text-gray-400 text-center py-4">No answers recorded</p>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <!-- Form Survey Results (existing table view) -->
        <div class="bg-white rounded-xl shadow-sm border overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead>
                        <tr class="bg-gray-50 border-b">
                            <th class="text-left p-3 font-medium text-gray-700">#</th>
                            <?php foreach ($questions ?? [] as $q): ?>
                                <th class="text-left p-3 font-medium text-gray-700"><?= htmlspecialchars(mb_substr(($q['question_text'] ?? ''), 0, 40)) ?></th>
                            <?php endforeach; ?>
                            <th class="text-left p-3 font-medium text-gray-700">Quality</th>
                            <th class="text-left p-3 font-medium text-gray-700">Status</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y">
                        <?php if (empty($responses)): ?>
                            <tr><td colspan="<?= count($questions ?? []) + 3 ?>" class="p-8 text-center text-gray-500">No responses yet</td></tr>
                        <?php else: ?>
                            <?php foreach ($responses as $ri => $r): ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="p-3 text-gray-500"><?= $ri + 1 ?></td>
                                    <?php foreach ($questions as $q): ?>
                                        <td class="p-3">
                                            <?php
                                            $val = $answersByResponse[$r['id']][$q['id']] ?? '';
                                            if (mb_strlen($val) > 50) $val = mb_substr($val, 0, 50) . '...';
                                            echo htmlspecialchars($val ?: '-');
                                            ?>
                                        </td>
                                    <?php endforeach; ?>
                                    <td class="p-3">
                                        <?php if (($r['overall_score'] ?? null) !== null): ?>
                                            <span class="px-2 py-0.5 text-xs rounded-full <?= ($r['overall_score'] ?? 0) >= ($survey['quality_threshold'] ?? 70) ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' ?>">
                                                <?= $r['overall_score'] ?? '' ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="text-gray-400">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="p-3">
                                        <span class="px-2 py-0.5 text-xs rounded-full 
                                            <?= ($r['status'] ?? '') === 'accepted' ? 'bg-green-100 text-green-800' : (($r['status'] ?? '') === 'rejected' ? 'bg-red-100 text-red-800' : (($r['status'] ?? '') === 'flagged' ? 'bg-yellow-100 text-yellow-800' : 'bg-gray-100 text-gray-800')) ?>">
                                            <?= $r['status'] ?? '' ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
</div>
