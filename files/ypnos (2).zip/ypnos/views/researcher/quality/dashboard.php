<div class="space-y-6">
    <div class="flex items-center justify-between">
        <div>
            <h1 class="text-2xl font-bold text-gray-900">Quality Dashboard</h1>
            <p class="text-gray-500"><?= htmlspecialchars($survey['title'] ?? '') ?> — Threshold: <?= $survey['quality_threshold'] ?? 70 ?></p>
        </div>
        <a href="<?= url('/survey/edit/' . ($survey['id'] ?? '')) ?>" class="text-indigo-600 hover:underline">Back to Survey</a>
    </div>

    <div class="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div class="bg-white p-5 rounded-xl shadow-sm border border-gray-200 hover:shadow-md hover:border-gray-300 transition-all">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 bg-gray-50 rounded-xl flex items-center justify-center text-gray-600"><i class="fas fa-layer-group"></i></div>
                <div>
                    <div class="text-2xl font-bold text-gray-900"><?= $stats['total'] ?? 0 ?></div>
                    <div class="text-xs text-gray-500">Total Responses</div>
                </div>
            </div>
        </div>
        <div class="bg-white p-5 rounded-xl shadow-sm border border-gray-200 hover:shadow-md hover:border-emerald-200 transition-all">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 bg-emerald-50 rounded-xl flex items-center justify-center text-emerald-600"><i class="fas fa-check-circle"></i></div>
                <div>
                    <div class="text-2xl font-bold text-emerald-600"><?= $stats['passed'] ?? 0 ?></div>
                    <div class="text-xs text-gray-500">Passed Quality</div>
                </div>
            </div>
        </div>
        <div class="bg-white p-5 rounded-xl shadow-sm border border-gray-200 hover:shadow-md hover:border-amber-200 transition-all">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 bg-amber-50 rounded-xl flex items-center justify-center text-amber-600"><i class="fas fa-flag"></i></div>
                <div>
                    <div class="text-2xl font-bold text-amber-600"><?= $stats['flagged'] ?? 0 ?></div>
                    <div class="text-xs text-gray-500">Flagged</div>
                </div>
            </div>
        </div>
        <div class="bg-white p-5 rounded-xl shadow-sm border border-gray-200 hover:shadow-md hover:border-purple-200 transition-all">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 bg-purple-50 rounded-xl flex items-center justify-center text-purple-600"><i class="fas fa-chart-line"></i></div>
                <div>
                    <div class="text-2xl font-bold text-purple-600"><?= $stats['avgQuality'] ?? 0 ?></div>
                    <div class="text-xs text-gray-500">Avg Quality Score</div>
                </div>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-2 gap-6">
        <div class="bg-white rounded-xl shadow-sm border p-4">
            <h2 class="font-semibold mb-3">Check Breakdown</h2>
            <?php if (empty($checkBreakdown)): ?>
                <p class="text-gray-500 text-sm">No checks run yet</p>
            <?php else: ?>
                <?php foreach ($checkBreakdown as $type => $data): ?>
                    <div class="mb-2">
                        <div class="flex justify-between text-sm mb-1">
                            <span class="capitalize"><?= str_replace('_', ' ', $type) ?></span>
                            <span class="text-gray-500"><?= $data['passed'] ?? 0 ?>/<?= $data['total'] ?? 0 ?> passed</span>
                        </div>
                        <div class="w-full bg-gray-200 rounded-full h-2">
                            <div class="bg-green-500 h-2 rounded-full" style="width: <?= ($data['total'] ?? 0) > 0 ? (($data['passed'] ?? 0) / ($data['total'] ?? 1)) * 100 : 0 ?>%"></div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <div class="bg-white rounded-xl shadow-sm border p-4">
            <h2 class="font-semibold mb-3">Response Quality Distribution</h2>
            <?php
            $buckets = [0, 0, 0, 0, 0];
            foreach ($responses as $r) {
                $score = $r['overall_score'] ?? -1;
                if ($score < 0) continue;
                if ($score < 20) $buckets[0]++;
                elseif ($score < 40) $buckets[1]++;
                elseif ($score < 60) $buckets[2]++;
                elseif ($score < 80) $buckets[3]++;
                else $buckets[4]++;
            }
            $maxBucket = max($buckets) ?: 1;
            $labels = ['0-20', '21-40', '41-60', '61-80', '81-100'];
            $colors = ['bg-red-500', 'bg-orange-500', 'bg-yellow-500', 'bg-blue-500', 'bg-green-500'];
            foreach ($labels as $i => $label): ?>
                <div class="mb-2">
                    <div class="flex justify-between text-sm mb-1">
                        <span><?= $label ?></span>
                        <span class="text-gray-500"><?= $buckets[$i] ?></span>
                    </div>
                    <div class="w-full bg-gray-200 rounded-full h-3">
                        <div class="<?= $colors[$i] ?> h-3 rounded-full" style="width: <?= ($buckets[$i] / $maxBucket) * 100 ?>%"></div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="bg-white rounded-xl shadow-sm border">
        <div class="p-4 border-b">
            <h2 class="font-semibold">All Responses</h2>
        </div>
        <div class="divide-y">
            <?php if (empty($responses)): ?>
                <div class="p-8 text-center text-gray-500">No responses</div>
            <?php else: ?>
                <?php foreach ($responses as $r): ?>
                    <div class="p-4 flex items-center justify-between hover:bg-gray-50">
                        <div>
                            <div class="text-sm text-gray-500">Response #<?= $r['id'] ?? '' ?></div>
                            <div class="text-sm"><?= $r['completed_at'] ?? 'In progress' ?></div>
                        </div>
                        <div class="flex items-center gap-3">
                            <?php if (($r['overall_score'] ?? null) !== null): ?>
                                <span class="px-3 py-1 text-sm rounded-full font-medium
                                    <?= ($r['overall_score'] ?? 0) >= ($survey['quality_threshold'] ?? 70) ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' ?>">
                                    Score: <?= $r['overall_score'] ?? '' ?>
                                </span>
                            <?php endif; ?>
                            <span class="px-2 py-0.5 text-xs rounded-full 
                                <?= ($r['researcher_verdict'] ?? 'pending') === 'accepted' ? 'bg-green-100 text-green-800' : (($r['researcher_verdict'] ?? 'pending') === 'rejected' ? 'bg-red-100 text-red-800' : 'bg-gray-100 text-gray-800') ?>">
                                <?= $r['researcher_verdict'] ?? 'pending' ?>
                            </span>
                            <a href="<?= url('/quality/' . ($survey['id'] ?? '')) ?>/responses/<?= $r['id'] ?? '' ?>" class="text-indigo-600 hover:underline text-sm">Review</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>
