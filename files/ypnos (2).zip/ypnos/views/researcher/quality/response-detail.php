<div class="max-w-4xl mx-auto space-y-6">
    <div class="flex items-center justify-between">
        <div>
            <h1 class="text-2xl font-bold text-gray-900">Response Detail</h1>
            <p class="text-gray-500">Survey: <?= htmlspecialchars($survey['title'] ?? '') ?></p>
        </div>
        <a href="<?= url('/quality/' . ($survey['id'] ?? '')) ?>" class="text-indigo-600 hover:underline">Back to Quality Dashboard</a>
    </div>

    <div class="grid grid-cols-3 gap-4">
        <div class="bg-white p-4 rounded-xl shadow-sm border border-gray-200 hover:shadow-md transition-all">
            <div class="flex items-center gap-2 mb-1">
                <i class="fas fa-hashtag text-indigo-400 text-xs"></i>
                <div class="text-xs text-gray-500">Response ID</div>
            </div>
            <div class="font-semibold text-gray-900">#<?= $response['id'] ?? '' ?></div>
        </div>
        <div class="bg-white p-4 rounded-xl shadow-sm border border-gray-200 hover:shadow-md transition-all">
            <div class="flex items-center gap-2 mb-1">
                <i class="fas fa-calendar text-indigo-400 text-xs"></i>
                <div class="text-xs text-gray-500">Completed At</div>
            </div>
            <div class="font-semibold text-gray-900"><?= $response['completed_at'] ?? 'N/A' ?></div>
        </div>
        <div class="bg-white p-4 rounded-xl shadow-sm border border-gray-200 hover:shadow-md transition-all">
            <div class="flex items-center gap-2 mb-1">
                <i class="fas fa-hourglass text-indigo-400 text-xs"></i>
                <div class="text-xs text-gray-500">Time Spent</div>
            </div>
            <div class="font-semibold text-gray-900"><?= !empty($response['time_spent_seconds']) ? ($response['time_spent_seconds'] ?? '') . 's' : 'N/A' ?></div>
        </div>
    </div>

    <?php if ($qualityScore): ?>
        <div class="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
            <div class="px-5 py-4 border-b border-gray-100 bg-gray-50/50 flex items-center gap-2">
                <i class="fas fa-chart-bar text-indigo-400"></i>
                <h2 class="font-semibold text-gray-900">Quality Scores</h2>
            </div>
            <div class="p-5">
                <div class="flex items-center gap-4 mb-5 p-4 rounded-xl <?= ($qualityScore['overall_score'] ?? 0) >= ($survey['quality_threshold'] ?? 70) ? 'bg-emerald-50 border border-emerald-200' : 'bg-red-50 border border-red-200' ?>">
                    <div class="w-12 h-12 rounded-xl <?= ($qualityScore['overall_score'] ?? 0) >= ($survey['quality_threshold'] ?? 70) ? 'bg-emerald-100 text-emerald-600' : 'bg-red-100 text-red-600' ?> flex items-center justify-center text-xl">
                        <i class="fas <?= ($qualityScore['overall_score'] ?? 0) >= ($survey['quality_threshold'] ?? 70) ? 'fa-check-circle' : 'fa-exclamation-circle' ?>"></i>
                    </div>
                    <div>
                        <div class="text-3xl font-bold <?= ($qualityScore['overall_score'] ?? 0) >= ($survey['quality_threshold'] ?? 70) ? 'text-emerald-700' : 'text-red-700' ?>"><?= $qualityScore['overall_score'] ?? 0 ?></div>
                        <div class="text-xs <?= ($qualityScore['overall_score'] ?? 0) >= ($survey['quality_threshold'] ?? 70) ? 'text-emerald-600' : 'text-red-600' ?>">Overall Score (threshold: <?= $survey['quality_threshold'] ?? 70 ?>)</div>
                    </div>
                </div>
                <div class="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <?php $subScores = [
                        ['label' => 'Attention', 'key' => 'attention_score', 'icon' => 'fa-eye', 'color' => 'blue'],
                        ['label' => 'Time', 'key' => 'time_score', 'icon' => 'fa-clock', 'color' => 'cyan'],
                        ['label' => 'Pattern', 'key' => 'pattern_score', 'icon' => 'fa-chart-line', 'color' => 'purple'],
                        ['label' => 'Consistency', 'key' => 'consistency_score', 'icon' => 'fa-balance-scale', 'color' => 'indigo'],
                        ['label' => 'Trap', 'key' => 'trap_score', 'icon' => 'fa-bomb', 'color' => 'amber'],
                        ['label' => 'Bot', 'key' => 'bot_score', 'icon' => 'fa-robot', 'color' => 'rose'],
                        ['label' => 'Gibberish', 'key' => 'gibberish_score', 'icon' => 'fa-comment-slash', 'color' => 'orange'],
                        ['label' => 'Relevance', 'key' => 'relevance_score', 'icon' => 'fa-bullseye', 'color' => 'teal'],
                    ]; ?>
                    <?php foreach ($subScores as $ss): ?>
                        <?php $val = $qualityScore[$ss['key']] ?? null; ?>
                        <?php if ($val !== null): ?>
                        <div class="p-3 rounded-xl bg-gray-50 border border-gray-100">
                            <div class="flex items-center gap-2 mb-1">
                                <i class="fas <?= $ss['icon'] ?> text-<?= $ss['color'] ?>-400 text-xs"></i>
                                <span class="text-xs text-gray-500"><?= $ss['label'] ?></span>
                            </div>
                            <span class="text-lg font-bold <?= $val >= 70 ? 'text-emerald-600' : ($val >= 40 ? 'text-amber-600' : 'text-red-600') ?>"><?= $val ?></span>
                        </div>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <div class="bg-white rounded-xl shadow-sm border">
        <div class="p-4 border-b flex items-center justify-between">
            <h2 class="font-semibold">
                <?= !empty($chatAnswers) ? 'Chat Conversation' : 'Answers' ?>
            </h2>
            <?php if (!empty($chatAnswers)): ?>
                <span class="text-xs text-gray-400"><?= count($chatAnswers) ?> responses</span>
            <?php endif; ?>
        </div>
        <div class="divide-y">
            <?php if (!empty($chatAnswers) && !empty($chatNodes)): ?>
                <?php foreach ($chatNodes as $node): ?>
                    <?php $answer = $chatAnswers[$node['key'] ?? ''] ?? null; ?>
                    <?php if ($answer !== null): ?>
                        <div class="p-4">
                            <p class="font-medium text-emerald-700 flex items-center gap-1.5 text-sm">
                                <i class="fas fa-comment-dots text-emerald-500 text-xs"></i><?= htmlspecialchars($node['question'] ?? '') ?>
                            </p>
                            <div class="mt-2 text-gray-800 bg-gray-50 rounded-xl px-3 py-2 border border-gray-100">
                                <?= htmlspecialchars($answer) ?>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; ?>
                <?php if (empty(array_intersect_key(array_flip(array_column($chatNodes, 'key')), $chatAnswers))): ?>
                    <div class="p-6 text-center text-gray-400 text-sm">No answers recorded in this conversation</div>
                <?php endif; ?>
            <?php elseif (!empty($answers)): ?>
                <?php foreach ($answers as $a): ?>
                    <div class="p-4">
                        <p class="font-medium text-gray-900"><?= htmlspecialchars($a['question_text'] ?? '') ?></p>
                        <p class="mt-1 text-gray-700"><?= htmlspecialchars(($a['answer_value'] ?? '') ?: '-') ?></p>
                        <?php if (!empty($a['is_flagged'])): ?>
                            <span class="inline-block mt-1 px-2 py-0.5 text-xs bg-red-100 text-red-800 rounded">Flagged</span>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="p-6 text-center text-gray-400 text-sm">No answers recorded</div>
            <?php endif; ?>
        </div>
    </div>

    <?php if (!empty($qualityLogs)): ?>
        <div class="bg-white rounded-xl shadow-sm border">
            <div class="p-4 border-b">
                <h2 class="font-semibold">Quality Check Logs</h2>
            </div>
            <div class="divide-y">
                <?php foreach ($qualityLogs as $log): ?>
                    <div class="p-3 flex items-center justify-between">
                        <div class="flex items-center gap-2">
                            <?php if (!empty($log['passed'])): ?>
                                <i class="fas fa-check-circle text-green-500"></i>
                            <?php else: ?>
                                <i class="fas fa-times-circle text-red-500"></i>
                            <?php endif; ?>
                            <span class="capitalize"><?= str_replace('_', ' ', $log['check_type'] ?? '') ?></span>
                        </div>
                        <span class="text-sm text-gray-500">Score: <?= $log['score'] ?? 0 ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>

    <div class="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
        <div class="px-5 py-4 border-b border-gray-100 bg-gray-50/50 flex items-center gap-2">
            <i class="fas fa-gavel text-indigo-400"></i>
            <h2 class="font-semibold text-gray-900">Researcher Verdict</h2>
        </div>
        <form method="POST" action="<?= url('/quality/' . ($survey['id'] ?? '')) ?>/verdict/<?= $response['id'] ?? '' ?>" class="p-5">
          <?= csrf() ?>
            <div class="flex gap-4 mb-4">
                <label class="flex-1 flex items-center justify-center gap-2 p-3 border-2 rounded-xl cursor-pointer transition-all has-[:checked]:border-emerald-500 has-[:checked]:bg-emerald-50 border-gray-200 hover:border-gray-300">
                    <input type="radio" name="verdict" value="accepted" <?= ($qualityScore['researcher_verdict'] ?? '') === 'accepted' ? 'checked' : '' ?> class="sr-only">
                    <i class="fas fa-check-circle text-emerald-500"></i>
                    <span class="font-medium text-gray-900">Accept</span>
                </label>
                <label class="flex-1 flex items-center justify-center gap-2 p-3 border-2 rounded-xl cursor-pointer transition-all has-[:checked]:border-red-500 has-[:checked]:bg-red-50 border-gray-200 hover:border-gray-300">
                    <input type="radio" name="verdict" value="rejected" <?= ($qualityScore['researcher_verdict'] ?? '') === 'rejected' ? 'checked' : '' ?> class="sr-only">
                    <i class="fas fa-times-circle text-red-500"></i>
                    <span class="font-medium text-gray-900">Reject</span>
                </label>
                <label class="flex-1 flex items-center justify-center gap-2 p-3 border-2 rounded-xl cursor-pointer transition-all has-[:checked]:border-gray-400 has-[:checked]:bg-gray-50 border-gray-200 hover:border-gray-300">
                    <input type="radio" name="verdict" value="pending" <?= ($qualityScore['researcher_verdict'] ?? 'pending') === 'pending' ? 'checked' : '' ?> class="sr-only">
                    <i class="fas fa-hourglass text-gray-400"></i>
                    <span class="font-medium text-gray-600">Pending</span>
                </label>
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-1.5">Notes <span class="text-xs text-gray-400">(optional)</span></label>
                <textarea name="notes" rows="2" placeholder="Add a note about this verdict..." class="w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-sm"><?= htmlspecialchars($qualityScore['notes'] ?? '') ?></textarea>
            </div>
            <button type="submit" class="inline-flex items-center gap-2 bg-gradient-to-r from-indigo-600 to-indigo-700 text-white px-6 py-2.5 rounded-xl hover:from-indigo-700 hover:to-indigo-800 transition-all text-sm font-medium shadow-sm">
                <i class="fas fa-save"></i> Save Verdict
            </button>
        </form>
    </div>
</div>
