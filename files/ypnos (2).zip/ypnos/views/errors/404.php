<div class="min-h-[70vh] flex items-center justify-center">
    <div class="text-center animate-scale-in">
        <div class="w-24 h-24 bg-gradient-to-br from-indigo-100 to-purple-100 rounded-full flex items-center justify-center mx-auto mb-6 shadow-inner">
            <i class="fas fa-compass text-4xl text-indigo-300"></i>
        </div>
        <h1 class="text-8xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">404</h1>
        <p class="text-xl text-gray-500 mt-2">Page not found</p>
        <p class="text-sm text-gray-400 mt-2 max-w-sm mx-auto">The page you're looking for doesn't exist or has been moved.</p>
        <div class="mt-8 flex items-center justify-center gap-3">
            <a href="javascript:history.back()" class="inline-flex items-center gap-2 px-5 py-2.5 border border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 transition-all text-sm font-medium">
                <i class="fas fa-arrow-left"></i> Go Back
            </a>
            <a href="<?= url('/dashboard') ?>" class="inline-flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-indigo-600 to-indigo-700 text-white rounded-xl hover:from-indigo-700 hover:to-indigo-800 transition-all text-sm font-medium shadow-sm">
                <i class="fas fa-home"></i> Dashboard
            </a>
        </div>
    </div>
</div>
