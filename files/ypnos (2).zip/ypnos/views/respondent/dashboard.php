<div class="space-y-6">
    <!-- Reputation Card -->
    <div class="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-500 rounded-2xl shadow-lg p-6 sm:p-8 text-white relative overflow-hidden">
        <div class="absolute top-0 right-0 w-40 h-40 bg-white/5 rounded-full -mr-10 -mt-10"></div>
        <div class="absolute bottom-0 left-0 w-32 h-32 bg-white/5 rounded-full -ml-8 -mb-8"></div>
        <div class="relative">
            <div class="flex items-start justify-between">
                <div>
                    <p class="text-indigo-200 text-sm font-medium">Your Reputation Score</p>
                    <div class="flex items-baseline gap-2 mt-1">
                        <p class="text-5xl font-bold"><?= number_format($reputation, 1) ?></p>
                        <span class="text-xl <?= $reputationLevel === 'platinum' ? 'text-cyan-300' : ($reputationLevel === 'gold' ? 'text-yellow-300' : ($reputationLevel === 'silver' ? 'text-gray-300' : 'text-amber-300')) ?>">
                            <i class="fas <?= $reputationLevel === 'platinum' ? 'fa-gem' : ($reputationLevel === 'gold' ? 'fa-crown' : ($reputationLevel === 'silver' ? 'fa-medal' : 'fa-shield')) ?>"></i>
                        </span>
                    </div>
                </div>
                <div class="text-right">
                    <div class="text-2xl font-bold"><?= ($stats['quality_rate'] ?? '') ?>%</div>
                    <div class="text-indigo-200 text-xs">Quality Rate</div>
                    <div class="text-lg font-bold mt-1"><?= ($stats['avg_quality'] ?? '') ?></div>
                    <div class="text-indigo-200 text-xs">Avg Score</div>
                </div>
            </div>
            <div class="mt-4 bg-white/20 rounded-full h-2.5">
                <div class="bg-white rounded-full h-2.5 transition-all duration-500" style="width: <?= min(100, $reputation) ?>%"></div>
            </div>
            <div class="flex items-center gap-4 mt-3 text-indigo-200 text-xs">
                <span><i class="fas fa-check-circle mr-1"></i><?= ($stats['completed'] ?? '') ?> completed</span>
                <span><i class="fas fa-trophy mr-1"></i><?= ucfirst($reputationLevel) ?> level</span>
            </div>
        </div>
    </div>

    <!-- Available Surveys -->
    <div>
        <div class="flex items-center justify-between mb-4">
            <h2 class="text-lg font-bold text-gray-900">Available Surveys</h2>
            <?php if (!empty($availableSurveys)): ?>
                <span class="text-xs text-gray-500"><?= count($availableSurveys) ?> available</span>
            <?php endif; ?>
        </div>

        <?php if (empty($availableSurveys)): ?>
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-10 text-center">
                <div class="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i class="fas fa-search text-gray-400 text-2xl"></i>
                </div>
                <p class="text-gray-600 font-medium">No surveys available</p>
                <p class="text-gray-400 text-sm mt-1">Complete more surveys to increase your reputation and unlock more.</p>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <?php foreach ($availableSurveys as $s): ?>
                    <div class="group bg-white rounded-xl shadow-sm border border-gray-200 p-5 hover:shadow-md hover:border-indigo-200 transition-all">
                        <div class="flex items-start justify-between mb-3">
                            <div class="w-10 h-10 bg-gradient-to-br from-indigo-100 to-purple-100 rounded-lg flex items-center justify-center text-indigo-600">
                                <i class="fas fa-clipboard-list"></i>
                            </div>
                            <?php if ((float)($s['min_reputation'] ?? 0) > 0): ?>
                                <span class="px-2 py-0.5 text-xs rounded-full bg-amber-50 text-amber-700 border border-amber-200">
                                    <i class="fas fa-shield-alt mr-0.5"></i><?= number_format((float)($s['min_reputation'] ?? 0), 1) ?>
                                </span>
                            <?php endif; ?>
                        </div>
                        <h3 class="font-semibold text-gray-900 group-hover:text-indigo-600 transition-colors"><?= htmlspecialchars($s['title'] ?? '') ?></h3>
                        <p class="text-sm text-gray-500 mt-1 line-clamp-2 overflow-hidden"><?= htmlspecialchars(mb_substr($s['description'] ?? '', 0, 100)) ?></p>
                        <div class="flex items-center justify-between mt-4 pt-3 border-t border-gray-100">
                            <span class="text-xs text-gray-400">
                                <i class="far fa-file-alt mr-1"></i><?= ($s['current_responses'] ?? 0) ?>/<?= $s['max_responses'] ?? '∞' ?>
                            </span>
                            <a href="<?= url('/survey/take/' . ($s['id'] ?? '')) ?>" class="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 text-white text-sm rounded-lg hover:bg-indigo-700 transition-colors shadow-sm">
                                Take <i class="fas fa-arrow-right text-xs"></i>
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Response History -->
        <div>
            <h2 class="text-lg font-bold text-gray-900 mb-4">Response History</h2>
            <?php if (empty($myResponses)): ?>
                <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center">
                    <i class="fas fa-inbox text-3xl text-gray-300 mb-3"></i>
                    <p class="text-gray-500 text-sm">No surveys taken yet.</p>
                </div>
            <?php else: ?>
                <div class="bg-white rounded-xl shadow-sm border border-gray-200 divide-y divide-gray-100">
                    <?php foreach ($myResponses as $r): ?>
                        <div class="p-4 flex items-center justify-between hover:bg-gray-50 transition-colors">
                            <div class="min-w-0 flex-1">
                                <p class="font-medium text-gray-900 truncate"><?= htmlspecialchars($r['survey_title'] ?? '') ?></p>
                                <div class="flex items-center gap-3 mt-1 text-xs text-gray-500">
                                    <span><i class="far fa-calendar mr-1"></i><?= date('M j, Y', strtotime(($r['created_at'] ?? ''))) ?></span>
                                    <?php if (($r['overall_score'] ?? null) !== null): ?>
                                        <span class="font-medium <?= (float)($r['overall_score'] ?? 0) >= 70 ? 'text-emerald-600' : 'text-red-500' ?>">
                                            <i class="fas <?= (float)($r['overall_score'] ?? 0) >= 70 ? 'fa-check-circle' : 'fa-times-circle' ?> mr-0.5"></i><?= number_format((float)($r['overall_score'] ?? 0), 1) ?>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <span class="px-2.5 py-1 text-xs rounded-full font-medium whitespace-nowrap
                                <?= ($r['status'] ?? '') === 'accepted' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : '' ?>
                                <?= ($r['status'] ?? '') === 'completed' ? 'bg-blue-50 text-blue-700 border border-blue-200' : '' ?>
                                <?= ($r['status'] ?? '') === 'flagged' ? 'bg-amber-50 text-amber-700 border border-amber-200' : '' ?>
                                <?= ($r['status'] ?? '') === 'rejected' ? 'bg-red-50 text-red-700 border border-red-200' : '' ?>
                                <?= ($r['status'] ?? '') === 'in_progress' ? 'bg-gray-50 text-gray-600 border border-gray-200' : '' ?>">
                                <?= ucfirst(($r['status'] ?? '')) ?>
                            </span>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Reputation History -->
        <div>
            <h2 class="text-lg font-bold text-gray-900 mb-4">Reputation History</h2>
            <?php if (empty($reputationHistory)): ?>
                <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center">
                    <i class="fas fa-star text-3xl text-gray-300 mb-3"></i>
                    <p class="text-gray-500 text-sm">No reputation changes yet.</p>
                </div>
            <?php else: ?>
                <div class="bg-white rounded-xl shadow-sm border border-gray-200 divide-y divide-gray-100">
                    <?php foreach ($reputationHistory as $h): ?>
                        <div class="p-3.5 flex items-center justify-between">
                            <div class="flex items-center gap-2 min-w-0">
                                <span class="flex-shrink-0 w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold <?= (float)($h['new_score'] ?? 0) >= (float)($h['old_score'] ?? 0) ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700' ?>">
                                    <i class="fas <?= (float)($h['new_score'] ?? 0) >= (float)($h['old_score'] ?? 0) ? 'fa-arrow-up' : 'fa-arrow-down' ?>"></i>
                                </span>
                                <div class="min-w-0">
                                    <span class="font-medium text-sm <?= (float)($h['new_score'] ?? 0) >= (float)($h['old_score'] ?? 0) ? 'text-emerald-700' : 'text-red-600' ?>">
                                        <?= number_format((float)($h['old_score'] ?? 0), 1) ?> → <?= number_format((float)($h['new_score'] ?? 0), 1) ?>
                                    </span>
                                    <p class="text-xs text-gray-400 truncate"><?= htmlspecialchars($h['change_reason'] ?? '') ?></p>
                                </div>
                            </div>
                            <span class="text-xs text-gray-400 flex-shrink-0"><?= date('M j', strtotime(($h['created_at'] ?? ''))) ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
