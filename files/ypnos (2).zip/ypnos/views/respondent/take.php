<?php
// === ADVANCED THEME ENGINE ===
$themeCfg = [];
if (!empty($survey["theme_config"])) {
    $decoded = is_string($survey["theme_config"])
        ? json_decode($survey["theme_config"], true)
        : $survey["theme_config"];
    if (is_array($decoded)) {
        $themeCfg = $decoded;
    }
}
$t = \Helpers\ComputeTheme::fromConfig($themeCfg);
extract($t);

// Quiz mode check
$isQuiz = !empty($qualityConfig["quiz_mode"]);
$quizLives = (int) ($qualityConfig["quiz_lives"] ?? 3);
$quizPassScore = (int) ($qualityConfig["quiz_pass_score"] ?? 70);
$quizTimerPerQ = (int) ($qualityConfig["quiz_timer_per_q"] ?? 30);
$showAnswers = !empty($qualityConfig["quiz_show_answers"]);
$isSequential = !empty($qualityConfig["sequential_unlock"]) || $isQuiz;
?>

<?php if (!empty($requireGoogle)): ?>
<div class="min-h-[60vh] flex items-center justify-center py-12">
    <div class="w-full max-w-md mx-auto animate-scale-in">
        <div class="relative">
            <div class="absolute -inset-1 bg-gradient-to-r <?= $tc[
                "gradient"
            ] ?> rounded-2xl blur-xl opacity-30"></div>
            <div class="relative glass-card rounded-2xl p-8 text-center">
                <div class="w-16 h-16 bg-gradient-to-br <?= $tc[
                    "gradient"
                ] ?> rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg animate-pulse-soft">
                    <i class="fab fa-google text-2xl text-white"></i>
                </div>
                <h2 class="text-xl font-bold <?= $textColor ?> mb-2">Sign in with Google</h2>
                <p class="text-sm <?= $textMuted ?> mb-6">This survey requires a Google account. Sign in to continue.</p>
                <a href="<?= url("/auth/google") ?>"
                   class="w-full inline-flex items-center justify-center gap-3 bg-white text-gray-700 px-6 py-3 rounded-xl hover:bg-gray-50 transition-all font-medium shadow-lg border border-gray-200 active:scale-[0.98]">
                    <i class="fab fa-google text-red-500 text-lg"></i>
                    Sign in with Google
                </a>
            </div>
        </div>
    </div>
</div>
<?php return;endif; ?>

<?php if (!empty($requirePassword)): ?>
<div class="min-h-[60vh] flex items-center justify-center py-12">
    <div class="w-full max-w-md mx-auto animate-scale-in">
        <div class="relative">
            <div class="absolute -inset-1 bg-gradient-to-r <?= $tc[
                "gradient"
            ] ?> rounded-2xl blur-xl opacity-30"></div>
            <div class="relative glass-card rounded-2xl p-8 text-center">
                <div class="w-16 h-16 bg-gradient-to-br <?= $tc[
                    "gradient"
                ] ?> rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg animate-pulse-soft">
                    <i class="fas fa-lock text-2xl text-white"></i>
                </div>
                <h2 class="text-xl font-bold <?= $textColor ?> mb-2">Password Required</h2>
                <p class="text-sm <?= $textMuted ?> mb-6">This survey is protected. Enter the password to continue.</p>
                <form method="POST" action="<?= url(
                    "/survey/take/" . ($survey["id"] ?? ""),
                ) ?>/auth">
                    <?= csrf() ?>
                    <input type="password" name="survey_password" required autofocus
                        class="w-full px-4 py-3 rounded-xl <?= $inputBg ?> <?= $tc[
     "focus"
 ] ?> text-center text-lg tracking-widest mb-4 transition-all"
                        placeholder="Enter password">
                    <button type="submit" class="w-full bg-gradient-to-r <?= $tc[
                        "btn"
                    ] ?> text-white px-6 py-3 rounded-xl hover:<?= $tc[
     "btnHover"
 ] ?> transition-all font-medium shadow-lg <?= $tc[
     "shadow"
 ] ?> active:scale-[0.98]">
                        <i class="fas fa-unlock mr-2"></i>Unlock Survey
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php return;endif; ?>

<?php if (!empty($requireEmail)): ?>
<div class="min-h-[60vh] flex items-center justify-center py-12">
    <div class="w-full max-w-md mx-auto animate-scale-in">
        <div class="relative">
            <div class="absolute -inset-1 bg-gradient-to-r <?= $tc[
                "gradient"
            ] ?> rounded-2xl blur-xl opacity-30"></div>
            <div class="relative glass-card rounded-2xl p-8 text-center">
                <div class="w-16 h-16 bg-gradient-to-br <?= $tc[
                    "gradient"
                ] ?> rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg animate-pulse-soft">
                    <i class="fas fa-envelope text-2xl text-white"></i>
                </div>
                <h2 class="text-xl font-bold <?= $textColor ?> mb-2">Verify Your Email</h2>
                <p class="text-sm <?= $textMuted ?> mb-6">Enter your email address to receive a verification code.</p>

                <?php if (empty($emailStep) || $emailStep === "send"): ?>
                <form method="POST" action="<?= url(
                    "/survey/take/" . ($survey["id"] ?? ""),
                ) ?>/auth">
                    <?= csrf() ?>
                    <input type="hidden" name="email_action" value="send_code">
                    <input type="email" name="survey_email" required autofocus
                        class="w-full px-4 py-3 rounded-xl <?= $inputBg ?> <?= $tc[
     "focus"
 ] ?> text-center text-lg mb-4 transition-all"
                        placeholder="your@email.com">
                    <button type="submit" class="w-full bg-gradient-to-r <?= $tc[
                        "btn"
                    ] ?> text-white px-6 py-3 rounded-xl hover:<?= $tc[
     "btnHover"
 ] ?> transition-all font-medium shadow-lg <?= $tc[
     "shadow"
 ] ?> active:scale-[0.98]">
                        <i class="fas fa-paper-plane mr-2"></i>Send Verification Code
                    </button>
                </form>
                <?php else: ?>
                <form method="POST" action="<?= url(
                    "/survey/take/" . ($survey["id"] ?? ""),
                ) ?>/auth">
                    <?= csrf() ?>
                    <input type="hidden" name="email_action" value="verify_code">
                    <input type="text" name="verify_code" required autofocus maxlength="6"
                        class="w-full px-4 py-3 rounded-xl <?= $inputBg ?> <?= $tc[
     "focus"
 ] ?> text-center text-lg tracking-widest mb-4 transition-all"
                        placeholder="000000">
                    <button type="submit" class="w-full bg-gradient-to-r <?= $tc[
                        "btn"
                    ] ?> text-white px-6 py-3 rounded-xl hover:<?= $tc[
     "btnHover"
 ] ?> transition-all font-medium shadow-lg <?= $tc[
     "shadow"
 ] ?> active:scale-[0.98]">
                        <i class="fas fa-check mr-2"></i>Verify Code
                    </button>
                </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php return;endif; ?>

<?php if (empty($questions)): ?>
<div class="min-h-[60vh] flex items-center justify-center py-12">
    <div class="text-center animate-scale-in">
        <div class="w-20 h-20 bg-gradient-to-br <?= $tc[
            "gradient"
        ] ?> rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg opacity-50">
            <i class="fas fa-question-circle text-3xl text-white"></i>
        </div>
        <h2 class="text-xl font-bold <?= $textColor ?> mb-2">No Questions Yet</h2>
        <p class="<?= $textMuted ?> text-sm">This survey has no questions configured.</p>
        <a href="<?= url(
            "/dashboard",
        ) ?>" class="mt-6 inline-flex items-center gap-2 <?= $tc[
    "text"
] ?> hover:underline font-medium text-sm">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
    </div>
</div>
<?php return;endif; ?>

<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:opsz@14..32&family=DM+Sans:opsz@9..40&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
:root {
    --theme-hex: <?= $tc["hex"] ?>;
    --theme-hex2: <?= $tc["hex2"] ?>;
    --theme-hex3: <?= $tc["hex3"] ?>;
    --theme-light: <?= $tc["light"] ?>;
    --theme-medium: <?= $tc["medium"] ?>;
    --theme-dark: <?= $tc["dark"] ?? $tc["hex"] ?>;
    --theme-rgb: <?= $tc["rgb"] ?? "99,102,241" ?>;
    --theme-ring: <?= $tc["hex"] ?>;
    --theme-text: <?= $tc["hex"] ?>;
    --is-dark: <?= $isDark ? "1" : "0" ?>;
    --card-radius: <?= $borderRadius === "full"
        ? "9999px"
        : ($borderRadius === "2xl"
            ? "16px"
            : ($borderRadius === "3xl"
                ? "24px"
                : ($borderRadius === "xl"
                    ? "12px"
                    : ($borderRadius === "lg"
                        ? "8px"
                        : ($borderRadius === "md"
                            ? "6px"
                            : ($borderRadius === "sm"
                                ? "4px"
                                : "0px")))))) ?>;
    --card-shadow: <?= $shadowStyle === "2xl"
        ? "0 25px 50px -12px rgba(0,0,0,0.25)"
        : ($shadowStyle === "xl"
            ? "0 20px 25px -5px rgba(0,0,0,0.1)"
            : ($shadowStyle === "lg"
                ? "0 10px 15px -3px rgba(0,0,0,0.1)"
                : ($shadowStyle === "md"
                    ? "0 4px 6px -1px rgba(0,0,0,0.1)"
                    : ($shadowStyle === "sm"
                        ? "0 1px 2px 0 rgba(0,0,0,0.05)"
                        : ($shadowStyle === "inner"
                            ? "inset 0 2px 4px 0 rgba(0,0,0,0.06)"
                            : "none"))))) ?>;
    --font-family: <?= $fontFamily !== "inherit"
        ? "'{$fontFamily}'"
        : "inherit" ?>;
}
* { <?= $fontFamily !== "inherit"
    ? "font-family:'{$fontFamily}',sans-serif"
    : "" ?> }

/* Background styles */
<?php if (
    !empty($bgImageStyle)
): ?>body { <?= $bgImageStyle ?> } .bg-overlay { position:fixed;inset:0;background:rgba(0,0,0,0.3);z-index:-1; }<?php endif; ?>
<?php if (
    !empty($useBgVideo)
): ?>#bg-video { position:fixed;right:0;bottom:0;min-width:100%;min-height:100%;width:auto;height:auto;z-index:-2;object-fit:cover; } .bg-overlay { position:fixed;inset:0;background:rgba(0,0,0,0.4);z-index:-1; }<?php endif; ?>
<?php if (!empty($customCSS)): ?>
<?= $customCSS ?>
<?php endif; ?>

/* ==== 50+ CORE ANIMATIONS ==== */
@keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
@keyframes fadeOut { from { opacity: 1; } to { opacity: 0; } }
@keyframes slideUp { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } }
@keyframes slideDown { from { opacity: 0; transform: translateY(-30px); } to { opacity: 1; transform: translateY(0); } }
@keyframes slideLeft { from { opacity: 0; transform: translateX(30px); } to { opacity: 1; transform: translateX(0); } }
@keyframes slideRight { from { opacity: 0; transform: translateX(-30px); } to { opacity: 1; transform: translateX(0); } }
@keyframes zoomIn { from { opacity: 0; transform: scale(0.7); } to { opacity: 1; transform: scale(1); } }
@keyframes zoomOut { to { opacity: 0; transform: scale(0.7); } }
@keyframes flipX { from { opacity: 0; transform: perspective(400px) rotateX(90deg); } to { opacity: 1; transform: perspective(400px) rotateX(0); } }
@keyframes flipY { from { opacity: 0; transform: perspective(400px) rotateY(90deg); } to { opacity: 1; transform: perspective(400px) rotateY(0); } }
@keyframes rotateIn { from { opacity: 0; transform: rotate(-200deg); } to { opacity: 1; transform: rotate(0); } }
@keyframes bounceIn { 0% { opacity: 0; transform: scale(0.3); } 50% { transform: scale(1.08); } 70% { transform: scale(0.92); } 100% { opacity: 1; transform: scale(1); } }
@keyframes elasticIn { 0% { opacity: 0; transform: scale(0); } 60% { transform: scale(1.1); } 80% { transform: scale(0.95); } 100% { opacity: 1; transform: scale(1); } }
@keyframes swingIn { 0% { opacity: 0; transform: rotate(-15deg) scale(0.8); } 50% { transform: rotate(5deg) scale(1.02); } 100% { opacity: 1; transform: rotate(0) scale(1); } }
@keyframes jackInBox { 0% { opacity: 0; transform: scale(0.1) rotate(30deg); transform-origin: center bottom; } 50% { transform: rotate(-10deg); } 70% { transform: rotate(3deg); } 100% { opacity: 1; transform: scale(1); } }
@keyframes rollIn { from { opacity: 0; transform: translateX(-100%) rotate(-120deg); } to { opacity: 1; transform: translateX(0) rotate(0); } }
@keyframes puffIn { 0% { opacity: 0; transform: scale(2); filter: blur(2px); } 100% { opacity: 1; transform: scale(1); filter: blur(0); } }
@keyframes vanishIn { 0% { opacity: 0; transform: scale(0); transform-origin: 50% 50%; } 100% { opacity: 1; transform: scale(1); } }
@keyframes slideUpFade { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
@keyframes slideDownFade { from { opacity: 0; transform: translateY(-20px); } to { opacity: 1; transform: translateY(0); } }
@keyframes twistIn { 0% { opacity: 0; transform: rotateY(180deg) scale(0.6); } 100% { opacity: 1; transform: rotateY(0) scale(1); } }
@keyframes flipIn { from { opacity: 0; transform: perspective(400px) rotateY(-90deg) scale(0.8); } to { opacity: 1; transform: perspective(400px) rotateY(0) scale(1); } }
/* Emphasis */
@keyframes heartBeat { 0%,100% { transform: scale(1); } 14% { transform: scale(1.3); } 28% { transform: scale(1); } 42% { transform: scale(1.3); } 70% { transform: scale(1); } }
@keyframes pulse { 0%,100% { transform: scale(1); opacity: 1; } 50% { transform: scale(1.05); opacity: 0.8; } }
@keyframes shakeX { 0%,100% { transform: translateX(0); } 10%,30%,50%,70%,90% { transform: translateX(-6px); } 20%,40%,60%,80% { transform: translateX(6px); } }
@keyframes shakeY { 0%,100% { transform: translateY(0); } 10%,30%,50%,70%,90% { transform: translateY(-6px); } 20%,40%,60%,80% { transform: translateY(6px); } }
@keyframes wobble { 0% { transform: translateX(0%); } 15% { transform: translateX(-25%) rotate(-5deg); } 30% { transform: translateX(20%) rotate(3deg); } 45% { transform: translateX(-15%) rotate(-3deg); } 60% { transform: translateX(10%) rotate(2deg); } 100% { transform: translateX(0%); } }
@keyframes jello { 0%,100% { transform: scaleX(1); } 30% { transform: scaleX(1.25) scaleY(0.75); } 40% { transform: scaleX(0.75) scaleY(1.25); } 50% { transform: scaleX(1.15) scaleY(0.85); } 65% { transform: scaleX(0.95) scaleY(1.05); } 75% { transform: scaleX(1.05) scaleY(0.95); } }
@keyframes rubberBand { 0% { transform: scaleX(1); } 30% { transform: scaleX(1.25) scaleY(0.75); } 40% { transform: scaleX(0.75) scaleY(1.25); } 60% { transform: scaleX(1.15) scaleY(0.85); } 100% { transform: scaleX(1) scaleY(1); } }
@keyframes tada { 0% { transform: scaleX(1); } 10%,20% { transform: scaleX(0.9) rotate(-3deg); } 30%,50%,70%,90% { transform: scaleX(1.1) rotate(3deg); } 40%,60%,80% { transform: scaleX(1.1) rotate(-3deg); } 100% { transform: scaleX(1) rotate(0); } }
@keyframes swing { 0% { transform: rotate(0); } 20% { transform: rotate(15deg); } 40% { transform: rotate(-10deg); } 60% { transform: rotate(5deg); } 80% { transform: rotate(-5deg); } 100% { transform: rotate(0); } }
@keyframes bounce { 0%,100% { transform: translateY(0); } 50% { transform: translateY(-15px); } }
@keyframes flash { 0%,50%,100% { opacity: 1; } 25%,75% { opacity: 0.3; } }
@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
/* Exit animations */
@keyframes hinge { 0% { transform-origin: top left; animation-timing-function: ease-in-out; } 20%,60% { transform: rotate(80deg); transform-origin: top left; } 40% { transform: rotate(60deg); } 100% { opacity: 0; transform: translateY(700px); } }
@keyframes rollOut { from { opacity: 1; transform: translateX(0) rotate(0); } to { opacity: 0; transform: translateX(100%) rotate(120deg); } }
@keyframes flipOut { from { opacity: 1; transform: perspective(400px) rotateY(0); } to { opacity: 0; transform: perspective(400px) rotateY(90deg); } }
@keyframes zoomOutDown { 40% { opacity: 1; transform: scale(0.475) translateY(-60px); animation-timing-function: ease-in; } 100% { opacity: 0; transform: scale(0.1) translateY(2000px); transform-origin: center bottom; } }
@keyframes fadeOutUp { from { opacity: 1; transform: translateY(0); } to { opacity: 0; transform: translateY(-20px); } }
@keyframes fadeOutDown { from { opacity: 1; transform: translateY(0); } to { opacity: 0; transform: translateY(20px); } }
@keyframes bounceOut { 0% { transform: scale(1); } 25% { transform: scale(0.95); } 50% { opacity: 1; transform: scale(1.1); } 100% { opacity: 0; transform: scale(0.3); } }
@keyframes slideOutLeft { from { transform: translateX(0); opacity: 1; } to { transform: translateX(-100%); opacity: 0; } }
@keyframes slideOutRight { from { transform: translateX(0); opacity: 1; } to { transform: translateX(100%); opacity: 0; } }
/* Premium */
@keyframes magicEntrance { 0% { opacity: 0; transform: scale(0) rotate(180deg); filter: brightness(0) blur(10px); } 100% { opacity: 1; transform: scale(1) rotate(0); filter: brightness(1) blur(0); } }
@keyframes morphIn { 0% { opacity: 0; border-radius: 50%; transform: scale(0.3) rotate(45deg); } 100% { opacity: 1; border-radius: 0; transform: scale(1) rotate(0); } }
@keyframes portalIn { 0% { opacity: 0; clip-path: circle(0% at 50% 50%); } 100% { opacity: 1; clip-path: circle(100% at 50% 50%); } }
@keyframes glitchIn { 0% { opacity: 0; transform: translate(-10px,10px) skew(10deg); filter: hue-rotate(180deg); } 50% { transform: translate(5px,-5px) skew(-5deg); filter: hue-rotate(-90deg); } 100% { opacity: 1; transform: translate(0) skew(0); filter: none; } }
@keyframes neonPulse { 0%,100% { box-shadow: 0 0 5px var(--theme-hex), 0 0 10px var(--theme-hex); } 50% { box-shadow: 0 0 20px var(--theme-hex), 0 0 40px var(--theme-hex), 0 0 80px var(--theme-hex); } }
/* Frozen states */
@keyframes frozenPulse { 0%,100% { opacity: 0.7; } 50% { opacity: 0.4; } }
@keyframes frozenDim { 0%,100% { filter: brightness(1); } 50% { filter: brightness(0.85); } }
@keyframes frozenShimmer { 0% { background-position: -200% center; } 100% { background-position: 200% center; } }
@keyframes checkmark { 0% { stroke-dashoffset: 100; } 100% { stroke-dashoffset: 0; } }
/* Micro-interactions */
@keyframes float { 0%,100% { transform: translateY(0px); } 50% { transform: translateY(-6px); } }
@keyframes glowPulse { 0%,100% { box-shadow: 0 0 5px rgba(var(--theme-rgb),0.3); } 50% { box-shadow: 0 0 20px rgba(var(--theme-rgb),0.5), 0 0 40px rgba(var(--theme-rgb),0.2); } }
@keyframes confettiFall { 0% { transform: translateY(-10px) rotate(0deg); opacity: 1; } 100% { transform: translateY(100vh) rotate(720deg); opacity: 0; } }
@keyframes progressGlow { 0%,100% { opacity: 0.6; } 50% { opacity: 1; } }
@keyframes scaleCheck { 0% { transform: scale(0); } 50% { transform: scale(1.2); } 100% { transform: scale(1); } }
@keyframes slideInRight { from { opacity: 0; transform: translateX(40px); } to { opacity: 1; transform: translateX(0); } }
@keyframes scaleIn { from { opacity: 0; transform: scale(0.9); } to { opacity: 1; transform: scale(1); } }
@keyframes pulseBorder { 0%,100% { border-color: rgba(var(--theme-rgb),0.2); } 50% { border-color: var(--theme-hex); } }
@keyframes rainbow { 0% { filter: hue-rotate(0deg); } 100% { filter: hue-rotate(360deg); } }

/* Entrance animation classes */
.anim-fade-in { animation: fadeIn 0.4s ease-out both; }
.anim-slide-up { animation: slideUp 0.5s ease-out both; }
.anim-slide-down { animation: slideDown 0.5s ease-out both; }
.anim-slide-left { animation: slideLeft 0.5s ease-out both; }
.anim-slide-right { animation: slideRight 0.5s ease-out both; }
.anim-zoom-in { animation: zoomIn 0.4s ease-out both; }
.anim-zoom-out { animation: zoomOut 0.3s ease-in both; }
.anim-flip-x { animation: flipX 0.6s ease-out both; }
.anim-flip-y { animation: flipY 0.6s ease-out both; }
.anim-rotate-in { animation: rotateIn 0.5s ease-out both; }
.anim-bounce-in { animation: bounceIn 0.7s ease both; }
.anim-elastic-in { animation: elasticIn 0.8s ease both; }
.anim-swing-in { animation: swingIn 0.7s ease both; }
.anim-jack-in-box { animation: jackInBox 0.8s ease both; }
.anim-roll-in { animation: rollIn 0.6s ease-out both; }
.anim-flip-in { animation: flipIn 0.6s ease-out both; }
.anim-twist-in { animation: twistIn 0.7s ease both; }
.anim-puff-in { animation: puffIn 0.5s ease-out both; }
.anim-vanish-in { animation: vanishIn 0.4s ease-out both; }
.anim-slide-up-fade { animation: slideUpFade 0.5s ease-out both; }
.anim-slide-down-fade { animation: slideDownFade 0.5s ease-out both; }
.anim-heart-beat { animation: heartBeat 1s ease both; }
.anim-pulse { animation: pulse 2s ease-in-out infinite; }
.anim-shake-x { animation: shakeX 0.5s ease both; }
.anim-shake-y { animation: shakeY 0.5s ease both; }
.anim-wobble { animation: wobble 1s ease both; }
.anim-jello { animation: jello 1s ease both; }
.anim-rubber-band { animation: rubberBand 1s ease both; }
.anim-tada { animation: tada 1s ease both; }
.anim-swing { animation: swing 1s ease both; }
.anim-bounce { animation: bounce 1s ease infinite; }
.anim-flash { animation: flash 1s ease both; }
.anim-spin { animation: spin 1s linear both; }
.anim-hinge { animation: hinge 1s ease both; }
.anim-roll-out { animation: rollOut 0.6s ease-in both; }
.anim-flip-out { animation: flipOut 0.6s ease-in both; }
.anim-zoom-out-down { animation: zoomOutDown 0.5s ease-in both; }
.anim-fade-out-up { animation: fadeOutUp 0.4s ease-in both; }
.anim-fade-out-down { animation: fadeOutDown 0.4s ease-in both; }
.anim-bounce-out { animation: bounceOut 0.7s ease-in both; }
.anim-slide-out-left { animation: slideOutLeft 0.5s ease-in both; }
.anim-slide-out-right { animation: slideOutRight 0.5s ease-in both; }
.anim-magic-entrance { animation: magicEntrance 1s ease both; }
.anim-morph-in { animation: morphIn 0.8s ease both; }
.anim-portal-in { animation: portalIn 1s ease both; }
.anim-glitch-in { animation: glitchIn 0.6s ease both; }
.anim-neon-pulse { animation: neonPulse 2s ease-in-out infinite; }
.anim-float { animation: float 3s ease-in-out infinite; }
.anim-glow-pulse { animation: glowPulse 2s ease-in-out infinite; }
.anim-progress-glow { animation: progressGlow 2s ease-in-out infinite; }
.anim-rainbow { animation: rainbow 3s linear infinite; }

/* Frozen question states */
.question-frozen { opacity: 0.6; pointer-events: none; position: relative; }
.question-frozen::after { content: '✓'; position: absolute; top: 12px; right: 12px; width: 24px; height: 24px; background: var(--theme-hex); color: #fff; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.15); z-index: 5; }
.question-frozen .frozen-overlay { position: absolute; inset: 0; background: linear-gradient(135deg, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0.3) 100%); backdrop-filter: blur(1px); border-radius: inherit; z-index: 4; }
.question-frozen.anim-pulse-frozen { animation: frozenPulse 2s ease-in-out infinite; }
.question-frozen.anim-dim-frozen { animation: frozenDim 2s ease-in-out infinite; }

/* Stagger animation for children */
.anim-stagger-fade > * { opacity: 0; animation: fadeIn 0.4s ease-out forwards; }
.anim-stagger-fade > *:nth-child(1) { animation-delay: 0.05s; }
.anim-stagger-fade > *:nth-child(2) { animation-delay: 0.1s; }
.anim-stagger-fade > *:nth-child(3) { animation-delay: 0.15s; }
.anim-stagger-fade > *:nth-child(4) { animation-delay: 0.2s; }
.anim-stagger-fade > *:nth-child(5) { animation-delay: 0.25s; }
.anim-stagger-fade > *:nth-child(6) { animation-delay: 0.3s; }
.anim-stagger-fade > *:nth-child(7) { animation-delay: 0.35s; }
.anim-stagger-fade > *:nth-child(8) { animation-delay: 0.4s; }
.anim-stagger-fade > *:nth-child(9) { animation-delay: 0.45s; }
.anim-stagger-fade > *:nth-child(10) { animation-delay: 0.5s; }
.anim-stagger-slide > * { opacity: 0; animation: slideUp 0.5s ease-out forwards; }
.anim-stagger-slide > *:nth-child(1) { animation-delay: 0.05s; }
.anim-stagger-slide > *:nth-child(2) { animation-delay: 0.1s; }
.anim-stagger-slide > *:nth-child(3) { animation-delay: 0.15s; }
.anim-stagger-slide > *:nth-child(4) { animation-delay: 0.2s; }
.anim-stagger-slide > *:nth-child(5) { animation-delay: 0.25s; }
.anim-stagger-slide > *:nth-child(6) { animation-delay: 0.3s; }
.anim-stagger-slide > *:nth-child(7) { animation-delay: 0.35s; }
.anim-stagger-slide > *:nth-child(8) { animation-delay: 0.4s; }
.anim-stagger-slide > *:nth-child(9) { animation-delay: 0.45s; }
.anim-stagger-slide > *:nth-child(10) { animation-delay: 0.5s; }

/* Confetti overlay */
.confetti-piece { position: fixed; width: 10px; height: 10px; z-index: 9999; pointer-events: none; animation: confettiFall linear forwards; }
.confetti-piece:nth-child(odd) { width: 8px; height: 14px; }
@keyframes dropIn { from { opacity: 0; transform: translateY(-60px); } to { opacity: 1; transform: translateY(0); } }
@keyframes blurIn { from { opacity: 0; filter: blur(10px); } to { opacity: 1; filter: blur(0); } }
@keyframes glowIn { from { opacity: 0; filter: blur(5px); } to { opacity: 1; filter: blur(0); } }
@keyframes shakeAnim { 0%, 100% { transform: translateX(0); } 10%, 50%, 90% { transform: translateX(-4px); } 30%, 70% { transform: translateX(4px); } }
@keyframes pulseAnim { 0% { transform: scale(1); } 50% { transform: scale(1.05); } 100% { transform: scale(1); } }
@keyframes swingAnim { 20% { transform: rotate(8deg); } 40% { transform: rotate(-6deg); } 60% { transform: rotate(4deg); } 80% { transform: rotate(-2deg); } 100% { transform: rotate(0deg); } }
@keyframes wobbleAnim { 0% { transform: translateX(0); } 15% { transform: translateX(-16px) rotate(-4deg); } 30% { transform: translateX(8px) rotate(4deg); } 45% { transform: translateX(-8px) rotate(-2deg); } 60% { transform: translateX(4px) rotate(2deg); } 100% { transform: translateX(0); } }
@keyframes zoomIn { from { opacity: 0; transform: scale(0.4); } to { opacity: 1; transform: scale(1); } }
@keyframes rollIn { from { opacity: 0; transform: translateX(-100%) rotate(-120deg); } to { opacity: 1; transform: translateX(0) rotate(0); } }

.anim-fade { animation: fadeIn 0.5s ease-out; }
.anim-slide-up { animation: slideUp 0.5s cubic-bezier(0.4,0,0.2,1); }
.anim-slide-left { animation: slideInRight 0.5s cubic-bezier(0.4,0,0.2,1); }
.anim-scale { animation: scaleIn 0.4s cubic-bezier(0.4,0,0.2,1); }
.anim-bounce { animation: bounceIn 0.6s cubic-bezier(0.68,-0.55,0.27,1.55); }
.anim-flip { animation: flipIn 0.6s ease-out; }
.anim-blur { animation: blurIn 0.5s ease-out; }
.anim-drop { animation: dropIn 0.5s cubic-bezier(0.4,0,0.2,1); }
.anim-glow { animation: glowIn 0.6s ease-out; }
.anim-shake { animation: shakeAnim 0.6s ease-out; }
.anim-pulse { animation: pulseAnim 0.6s ease-out; }
.anim-swing { animation: swingAnim 0.6s ease-out; }
.anim-wobble { animation: wobbleAnim 0.6s ease-out; }
.anim-zoom { animation: zoomIn 0.5s cubic-bezier(0.4,0,0.2,1); }
.anim-roll { animation: rollIn 0.6s ease-out; }

@keyframes jello { 0% { transform: scaleX(1); } 30% { transform: scaleX(1.25) scaleY(0.75); } 40% { transform: scaleX(0.75) scaleY(1.25); } 50% { transform: scaleX(1.15) scaleY(0.85); } 65% { transform: scaleX(0.95) scaleY(1.05); } 75% { transform: scaleX(1.05) scaleY(0.95); } 100% { transform: scaleX(1) scaleY(1); } }
@keyframes heartBeat { 0% { transform: scale(1); } 14% { transform: scale(1.3); } 28% { transform: scale(1); } 42% { transform: scale(1.3); } 70% { transform: scale(1); } }
@keyframes backInDown { 0% { opacity: 0.7; transform: translateY(-1200px) scale(0.7); } 80% { opacity: 0.7; transform: translateY(0px) scale(0.7); } 100% { opacity: 1; transform: scale(1); } }
@keyframes backInUp { 0% { opacity: 0.7; transform: translateY(1200px) scale(0.7); } 80% { opacity: 0.7; transform: translateY(0px) scale(0.7); } 100% { opacity: 1; transform: scale(1); } }
@keyframes backInLeft { 0% { opacity: 0.7; transform: translateX(-2000px) scale(0.7); } 80% { opacity: 0.7; transform: translateX(0px) scale(0.7); } 100% { opacity: 1; transform: scale(1); } }
@keyframes backInRight { 0% { opacity: 0.7; transform: translateX(2000px) scale(0.7); } 80% { opacity: 0.7; transform: translateX(0px) scale(0.7); } 100% { opacity: 1; transform: scale(1); } }
@keyframes bounceInDown { 0% { opacity: 0; transform: translateY(-2000px); } 60% { opacity: 1; transform: translateY(30px); } 80% { transform: translateY(-10px); } 100% { transform: translateY(0); } }
@keyframes bounceInLeft { 0% { opacity: 0; transform: translateX(-2000px); } 60% { opacity: 1; transform: translateX(30px); } 80% { transform: translateX(-10px); } 100% { transform: translateX(0); } }
@keyframes bounceInRight { 0% { opacity: 0; transform: translateX(2000px); } 60% { opacity: 1; transform: translateX(-30px); } 80% { transform: translateX(10px); } 100% { transform: translateX(0); } }
@keyframes bounceInUp { 0% { opacity: 0; transform: translateY(2000px); } 60% { opacity: 1; transform: translateY(-30px); } 80% { transform: translateY(10px); } 100% { transform: translateY(0); } }
@keyframes fadeInDown { from { opacity: 0; transform: translateY(-30px); } to { opacity: 1; transform: translateY(0); } }
@keyframes fadeInLeft { from { opacity: 0; transform: translateX(-30px); } to { opacity: 1; transform: translateX(0); } }
@keyframes fadeInRight { from { opacity: 0; transform: translateX(30px); } to { opacity: 1; transform: translateX(0); } }
@keyframes fadeInUp { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } }
@keyframes flipInX { from { opacity: 0; transform: perspective(400px) rotateX(90deg); } to { opacity: 1; transform: perspective(400px) rotateX(0); } }
@keyframes flipInY { from { opacity: 0; transform: perspective(400px) rotateY(90deg); } to { opacity: 1; transform: perspective(400px) rotateY(0); } }
@keyframes lightSpeedIn { from { opacity: 0; transform: translateX(100%) skewX(-30deg); } to { opacity: 1; transform: translateX(0) skewX(0); } }
@keyframes rotateIn { from { opacity: 0; transform: rotate(-200deg); } to { opacity: 1; transform: rotate(0); } }
@keyframes rotateInDownLeft { from { opacity: 0; transform: rotate(-90deg); transform-origin: left bottom; } to { opacity: 1; transform: rotate(0); transform-origin: left bottom; } }
@keyframes rotateInDownRight { from { opacity: 0; transform: rotate(90deg); transform-origin: right bottom; } to { opacity: 1; transform: rotate(0); transform-origin: right bottom; } }
@keyframes rotateInUpLeft { from { opacity: 0; transform: rotate(90deg); transform-origin: left bottom; } to { opacity: 1; transform: rotate(0); transform-origin: left bottom; } }
@keyframes rotateInUpRight { from { opacity: 0; transform: rotate(-90deg); transform-origin: right bottom; } to { opacity: 1; transform: rotate(0); transform-origin: right bottom; } }
@keyframes slideInDown { from { opacity: 0; transform: translateY(-60px); } to { opacity: 1; transform: translateY(0); } }
@keyframes slideInLeft { from { opacity: 0; transform: translateX(-60px); } to { opacity: 1; transform: translateX(0); } }
@keyframes zoomInDown { from { opacity: 0; transform: scale(0.1) translateY(-1000px); animation-timing-function: cubic-bezier(0.55,0.055,0.675,0.19); } 60% { opacity: 1; transform: scale(0.475) translateY(60px); animation-timing-function: cubic-bezier(0.175,0.885,0.32,1); } }
@keyframes zoomInLeft { from { opacity: 0; transform: scale(0.1) translateX(-2000px); animation-timing-function: cubic-bezier(0.55,0.055,0.675,0.19); } 60% { opacity: 1; transform: scale(0.475) translateX(48px); animation-timing-function: cubic-bezier(0.175,0.885,0.32,1); } }
@keyframes zoomInRight { from { opacity: 0; transform: scale(0.1) translateX(2000px); animation-timing-function: cubic-bezier(0.55,0.055,0.675,0.19); } 60% { opacity: 1; transform: scale(0.475) translateX(-48px); animation-timing-function: cubic-bezier(0.175,0.885,0.32,1); } }
@keyframes zoomInUp { from { opacity: 0; transform: scale(0.1) translateY(1000px); animation-timing-function: cubic-bezier(0.55,0.055,0.675,0.19); } 60% { opacity: 1; transform: scale(0.475) translateY(-60px); animation-timing-function: cubic-bezier(0.175,0.885,0.32,1); } }
@keyframes hinge { 0% { transform: rotate(0); transform-origin: top left; animation-timing-function: ease-in-out; } 20%, 60% { transform: rotate(80deg); transform-origin: top left; animation-timing-function: ease-in-out; } 40%, 80% { transform: rotate(60deg); transform-origin: top left; animation-timing-function: ease-in-out; } 100% { opacity: 0; transform: translateY(700px); } }
@keyframes jackInTheBox { 0% { opacity: 0; transform: scale(0.1) rotate(30deg); transform-origin: center bottom; } 50% { transform: rotate(-10deg); } 70% { transform: rotate(3deg); } 100% { opacity: 1; transform: scale(1) rotate(0); } }
@keyframes bounceOut { 0% { transform: scale(1); } 25% { transform: scale(0.95); } 50% { opacity: 1; transform: scale(1.1); } 100% { opacity: 0; transform: scale(0.3); } }
@keyframes fadeOut { from { opacity: 1; } to { opacity: 0; } }
@keyframes fadeOutDown { from { opacity: 1; transform: translateY(0); } to { opacity: 0; transform: translateY(20px); } }
@keyframes fadeOutLeft { from { opacity: 1; transform: translateX(0); } to { opacity: 0; transform: translateX(-20px); } }
@keyframes fadeOutRight { from { opacity: 1; transform: translateX(0); } to { opacity: 0; transform: translateX(20px); } }
@keyframes fadeOutUp { from { opacity: 1; transform: translateY(0); } to { opacity: 0; transform: translateY(-20px); } }
@keyframes flipOutX { from { opacity: 1; transform: perspective(400px) rotateX(0); } to { opacity: 0; transform: perspective(400px) rotateX(90deg); } }
@keyframes flipOutY { from { opacity: 1; transform: perspective(400px) rotateY(0); } to { opacity: 0; transform: perspective(400px) rotateY(90deg); } }
@keyframes lightSpeedOut { from { opacity: 1; transform: translateX(0) skewX(0); } to { opacity: 0; transform: translateX(100%) skewX(-30deg); } }
@keyframes rotateOut { from { opacity: 1; transform: rotate(0); } to { opacity: 0; transform: rotate(200deg); } }
@keyframes rotateOutDownLeft { from { opacity: 1; transform: rotate(0); transform-origin: left bottom; } to { opacity: 0; transform: rotate(-90deg); transform-origin: left bottom; } }
@keyframes rotateOutDownRight { from { opacity: 1; transform: rotate(0); transform-origin: right bottom; } to { opacity: 0; transform: rotate(90deg); transform-origin: right bottom; } }
@keyframes rotateOutUpLeft { from { opacity: 1; transform: rotate(0); transform-origin: left bottom; } to { opacity: 0; transform: rotate(-90deg); transform-origin: left bottom; } }
@keyframes rotateOutUpRight { from { opacity: 1; transform: rotate(0); transform-origin: right bottom; } to { opacity: 0; transform: rotate(90deg); transform-origin: right bottom; } }
@keyframes slideOutDown { from { opacity: 1; transform: translateY(0); } to { opacity: 0; transform: translateY(60px); } }
@keyframes slideOutLeft { from { opacity: 1; transform: translateX(0); } to { opacity: 0; transform: translateX(-60px); } }
@keyframes slideOutRight { from { opacity: 1; transform: translateX(0); } to { opacity: 0; transform: translateX(60px); } }
@keyframes slideOutUp { from { opacity: 1; transform: translateY(0); } to { opacity: 0; transform: translateY(-60px); } }
@keyframes zoomOut { from { opacity: 1; transform: scale(1); } to { opacity: 0; transform: scale(0.3); } }
@keyframes zoomOutDown { 40% { opacity: 1; transform: scale(0.475) translateY(-60px); animation-timing-function: cubic-bezier(0.55,0.055,0.675,0.19); } 100% { opacity: 0; transform: scale(0.1) translateY(2000px); transform-origin: center bottom; } }
@keyframes zoomOutLeft { 40% { opacity: 1; transform: scale(0.475) translateX(42px); animation-timing-function: cubic-bezier(0.55,0.055,0.675,0.19); } 100% { opacity: 0; transform: scale(0.1) translateX(-2000px); transform-origin: left center; } }
@keyframes zoomOutRight { 40% { opacity: 1; transform: scale(0.475) translateX(-42px); animation-timing-function: cubic-bezier(0.55,0.055,0.675,0.19); } 100% { opacity: 0; transform: scale(0.1) translateX(2000px); transform-origin: right center; } }
/* Global micro-interactions */
.question-card { transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1); }
.question-card:hover { transform: translateY(-2px); }
button, .btn, a.btn, button[type="submit"] { transition: all 0.2s cubic-bezier(0.4,0,0.2,1); }
button:active, .btn:active, button[type="submit"]:active { transform: scale(0.97); }
input, select, textarea { transition: all 0.2s cubic-bezier(0.4,0,0.2,1); }
.glass-card { transition: all 0.3s cubic-bezier(0.4,0,0.2,1); }
.glass-card:hover { transform: translateY(-1px); box-shadow: 0 8px 32px rgba(0,0,0,0.08); }
.q-option { transition: all 0.25s cubic-bezier(0.4,0,0.2,1); }
.q-option:hover { border-color: var(--theme-hex); background: color-mix(in srgb, var(--theme-hex) 5%, transparent); transform: translateY(-1px); }
.q-option:has(input:checked) { border-color: var(--theme-hex); background: color-mix(in srgb, var(--theme-hex) 10%, transparent); box-shadow: 0 0 0 3px color-mix(in srgb, var(--theme-hex) 20%, transparent); transform: translateY(-1px); }
.likert-option { transition: all 0.2s cubic-bezier(0.4,0,0.2,1); }
.likert-option:hover { background: color-mix(in srgb, var(--theme-hex) 10%, transparent); border-color: var(--theme-hex); transform: translateY(-1px); }
.likert-option:has(input:checked) { background: color-mix(in srgb, var(--theme-hex) 20%, transparent); border-color: var(--theme-hex); box-shadow: 0 4px 12px color-mix(in srgb, var(--theme-hex) 30%, transparent); transform: translateY(-1px); }
.likert-option:has(input:checked) .likert-label { color: var(--theme-hex); font-weight: 700; }
.likert-option:has(input:checked) .likert-text { color: var(--theme-hex); }
.star-label { transition: all 0.2s cubic-bezier(0.4,0,0.2,1); }
.star-label:hover { transform: scale(1.25); }
.star-label:hover ~ .star-label i { color: <?= $tc["hex"] ?> !important; }
.star-label i { transition: all 0.2s cubic-bezier(0.4,0,0.2,1); }
input[type="range"] { appearance: none; -webkit-appearance: none; height: 6px; border-radius: 3px; outline: none; }
input[type="range"]::-webkit-slider-thumb { -webkit-appearance: none; width: 22px; height: 22px; border-radius: 50%; background: <?= $tc[
    "hex"
] ?>; cursor: pointer; box-shadow: 0 2px 8px <?= $tc[
    "hex"
] ?>60; transition: all 0.2s cubic-bezier(0.4,0,0.2,1); }
input[type="range"]::-webkit-slider-thumb:hover { transform: scale(1.15); box-shadow: 0 0 0 4px color-mix(in srgb, var(--theme-hex) 25%, transparent); }
input[type="range"]::-moz-range-thumb { width: 22px; height: 22px; border-radius: 50%; background: <?= $tc[
    "hex"
] ?>; cursor: pointer; border: none; }
.progress-glow { box-shadow: 0 0 12px <?= $tc["hex"] ?>60; }
.matrix-cell { transition: all 0.2s cubic-bezier(0.4,0,0.2,1); }
.matrix-cell:hover { background: color-mix(in srgb, var(--theme-hex) 8%, transparent); transform: translateY(-1px); }
.matrix-cell:has(input:checked) { background: color-mix(in srgb, var(--theme-hex) 20%, transparent); }
select option { background: <?= $isDark
    ? "#1f2937"
    : "white" ?>; color: <?= $isDark ? "white" : "#1f2937" ?>; }

/* Question transition overlay */
#q-transition-overlay { position: fixed; inset: 0; z-index: 9998; pointer-events: none; opacity: 0; background: var(--theme-hex); transition: opacity 0.25s cubic-bezier(0.4,0,0.2,1); }
#q-transition-overlay.active { opacity: 0.06; }
#survey-app { animation: fadeIn 0.6s cubic-bezier(0.4,0,0.2,1) both; }
#survey-header { animation: slideDownFade 0.5s cubic-bezier(0.4,0,0.2,1) both; }
.question-card { animation: slideUpFade 0.5s cubic-bezier(0.4,0,0.2,1) both; }
.question-card:nth-child(1) { animation-delay: 0.05s; }
.question-card:nth-child(2) { animation-delay: 0.1s; }
.question-card:nth-child(3) { animation-delay: 0.15s; }
.question-card:nth-child(4) { animation-delay: 0.2s; }
.question-card:nth-child(5) { animation-delay: 0.25s; }
.question-card:nth-child(6) { animation-delay: 0.3s; }
.question-card:nth-child(7) { animation-delay: 0.35s; }
.question-card:nth-child(8) { animation-delay: 0.4s; }
.question-card:nth-child(9) { animation-delay: 0.45s; }
.question-card:nth-child(10) { animation-delay: 0.5s; }
#survey-footer { animation: slideUpFade 0.5s cubic-bezier(0.4,0,0.2,1) both; animation-delay: 0.3s; }
.float-anim { animation: float 3s ease-in-out infinite; }

/* Particle background */
#particles-canvas { position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 0; pointer-events: none; }

/* Question animation classes (per-question) */
.qa-fade { animation: fadeIn 0.5s cubic-bezier(0.4,0,0.2,1); }
.qa-slide-up { animation: slideUp 0.5s cubic-bezier(0.4,0,0.2,1); }
.qa-slide-left { animation: slideInRight 0.5s cubic-bezier(0.4,0,0.2,1); }
.qa-scale { animation: scaleIn 0.4s cubic-bezier(0.4,0,0.2,1); }
.qa-bounce { animation: bounceIn 0.6s cubic-bezier(0.68,-0.55,0.27,1.55); }
.qa-flip { animation: flipIn 0.6s ease-out; }
.qa-blur { animation: blurIn 0.5s ease-out; }
.qa-drop { animation: dropIn 0.5s cubic-bezier(0.4,0,0.2,1); }
.qa-glow { animation: glowIn 0.6s ease-out; }
.qa-zoom { animation: zoomIn 0.5s cubic-bezier(0.4,0,0.2,1); }
.qa-roll { animation: rollIn 0.6s ease-out; }
.qa-jello { animation: jello 0.6s ease-out; }
.qa-heart-beat { animation: heartBeat 0.8s ease-out; }

/* Ripple effect */
.ripple-effect { position: absolute; border-radius: 50%; background: rgba(255,255,255,0.4); transform: scale(0); animation: rippleAnim 0.6s ease-out; pointer-events: none; z-index: 5; }
@keyframes rippleAnim { to { transform: scale(4); opacity: 0; } }
.q-option, button, .powerup-btn { position: relative; overflow: hidden; }

/* Power-up buttons */
.powerup-btn { transition: all 0.3s cubic-bezier(0.4,0,0.2,1); }
.powerup-btn:hover { transform: translateY(-2px) scale(1.05); box-shadow: 0 8px 25px rgba(0,0,0,0.1); }
.powerup-btn:active { transform: scale(0.95); }
.powerup-btn .fa-bolt { animation: boltPulse 0.5s ease-in-out infinite; }
@keyframes boltPulse { 0%,100% { transform: scale(1); } 50% { transform: scale(1.3); } }

/* Quiz feedback transitions */
.quiz-feedback { animation: slideDownFade 0.4s cubic-bezier(0.4,0,0.2,1) both; }
.quiz-feedback.opacity-0 { opacity: 0; transform: translateY(-10px); }

/* Question card entrance */
.question-card { transition: opacity 0.5s cubic-bezier(0.4,0,0.2,1), transform 0.5s cubic-bezier(0.4,0,0.2,1), box-shadow 0.3s ease, border-color 0.3s ease; }
.question-card:hover { box-shadow: 0 8px 30px rgba(0,0,0,0.06); }

/* Burst dots */
@keyframes burstDot { 0% { transform: scale(1); opacity: 1; } 100% { transform: scale(0); opacity: 0; } }

/* Status dots entrance */
.status-dot { transition: all 0.3s cubic-bezier(0.4,0,0.2,1); }

/* Scrollbar */
::-webkit-scrollbar { width: 6px; }
::-webkit-scrollbar-track { background: transparent; }
::-webkit-scrollbar-thumb { background: <?= $tc[
    "hex"
] ?>40; border-radius: 3px; }
::-webkit-scrollbar-thumb:hover { background: <?= $tc["hex"] ?>60; }

/* Prevent cropping/overflow */
#survey-app { min-width: 0; word-break: break-word; overflow-wrap: break-word; }
.question-card { overflow: hidden; }
.question-card img, .question-card svg, .question-card table { max-width: 100%; height: auto; }
.question-card input, .question-card select, .question-card textarea { max-width: 100%; }
.question-card .flex { flex-wrap: wrap; }
.option-label { max-width: 100%; word-break: break-word; }
.overflow-x-auto { -webkit-overflow-scrolling: touch; }

/* Shake animation for incorrect answers */
@keyframes shakeIncorrect { 0%,100% { transform: translateX(0); } 10%,30%,50%,70%,90% { transform: translateX(-4px); } 20%,40%,60%,80% { transform: translateX(4px); } }
.shake { animation: shakeIncorrect 0.5s cubic-bezier(0.4,0,0.2,1); }
</style>
<?php if ($isQuiz): ?>
<style>
/* Score pulse animation */
#quiz-score { transition: all 0.2s cubic-bezier(0.4,0,0.2,1); display: inline-block; }
#quiz-streak { transition: all 0.3s cubic-bezier(0.4,0,0.2,1); }
.streak-fire { animation: streakFire 0.5s ease-out; }
@keyframes streakFire { 0% { transform: scale(1); } 50% { transform: scale(1.5); color: #f97316; } 100% { transform: scale(1); } }
</style>
<?php endif; ?>

<?php if ($bgStyle === "particles"): ?>
<canvas id="particles-canvas"></canvas>
<?php endif; ?>

<div id="q-transition-overlay"></div>
<div class="relative z-10 max-w-3xl mx-auto py-4" id="survey-app">
    <!-- Header -->
    <div class="relative <?= $cardBg ?> rounded-2xl p-5 mb-5 shadow-lg border <?= !empty(
     $qualityConfig["fullscreen_mode"]
 )
     ? "cursor-pointer"
     : "" ?>" id="survey-header">
        <!-- Logo -->
        <?php if (!empty($logoUrl)): ?>
        <div class="flex justify-center mb-3">
            <img src="<?= htmlspecialchars(
                $logoUrl,
            ) ?>" alt="Logo" class="h-10 object-contain float-anim" onerror="this.remove()">
        </div>
        <?php endif; ?>

        <div class="flex items-start justify-between gap-4">
            <div class="flex-1 min-w-0">
                <h1 class="text-2xl font-bold <?= $textColor ?> truncate"><?= htmlspecialchars(
     $survey["title"] ?? "",
 ) ?>
                    <?php if ($isQuiz): ?>
                    <span class="inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-bold <?= $tc[
                        "bg"
                    ] ?> <?= $tc[
     "text"
 ] ?> rounded-full ml-2 align-middle"><i class="fas fa-gamepad"></i> QUIZ</span>
                    <?php endif; ?>
                </h1>
                <p class="<?= $textMuted ?> mt-1 text-sm line-clamp-2"><?= htmlspecialchars(
     $survey["description"] ?? "",
 ) ?></p>
            </div>
            <div class="flex flex-col items-center gap-1.5 flex-shrink-0">
                <div class="bg-gradient-to-br <?= $tc[
                    "gradient"
                ] ?> rounded-xl p-2.5 text-center min-w-[72px] shadow-lg transition-all duration-300" id="timer-box">
                    <div class="text-xl font-bold text-white tabular-nums drop-shadow-sm" id="timer-value">0:00</div>
                    <div class="text-[10px] text-white/70">Elapsed</div>
                </div>
            </div>
        </div>

        <!-- Anti-cheat status bar -->
        <div class="flex items-center gap-2 mt-3 flex-wrap text-[10px]">
            <?php if (!empty($qualityConfig["disable_rightclick"])): ?>
            <span class="px-2 py-0.5 rounded-full bg-red-50/80 text-red-600 border border-red-200/50 flex items-center gap-1"><i class="fas fa-mouse-pointer text-[9px]"></i> Right-click blocked</span>
            <?php endif; ?>
            <?php if (!empty($qualityConfig["prevent_copy_paste"])): ?>
            <span class="px-2 py-0.5 rounded-full bg-amber-50/80 text-amber-600 border border-amber-200/50 flex items-center gap-1" id="paste-badge"><i class="fas fa-paste text-[9px]"></i> Paste blocked</span>
            <?php endif; ?>
            <?php if (!empty($qualityConfig["track_tab_switches"])): ?>
            <span class="px-2 py-0.5 rounded-full bg-purple-50/80 text-purple-600 border border-purple-200/50 flex items-center gap-1"><i class="fas fa-window-restore text-[9px]"></i> Tab switches: <span id="tab-switch-count">0</span></span>
            <?php endif; ?>
            <?php if (!empty($qualityConfig["fullscreen_mode"])): ?>
            <span class="px-2 py-0.5 rounded-full bg-cyan-50/80 text-cyan-600 border border-cyan-200/50 flex items-center gap-1"><i class="fas fa-expand text-[9px]"></i> Fullscreen</span>
            <?php endif; ?>
            <?php if (!empty($resumeCode)): ?>
            <span class="px-2 py-0.5 rounded-full bg-teal-50/80 text-teal-600 border border-teal-200/50 flex items-center gap-1"><i class="fas fa-save text-[9px]"></i> Auto-save on</span>
            <?php endif; ?>
            <?php if (!empty($qualityConfig["prevent_back_nav"])): ?>
            <span class="px-2 py-0.5 rounded-full bg-red-50/80 text-red-600 border border-red-200/50 flex items-center gap-1"><i class="fas fa-arrow-left text-[9px]"></i> Back nav blocked</span>
            <?php endif; ?>
            <?php if (!empty($qualityConfig["time_per_question"])): ?>
            <span class="px-2 py-0.5 rounded-full bg-amber-50/80 text-amber-600 border border-amber-200/50 flex items-center gap-1"><i class="fas fa-hourglass text-[9px]"></i> Timed questions</span>
            <?php endif; ?>
        </div>

        <!-- Quiz mode: lives + score -->
        <?php if ($isQuiz): ?>
        <div class="flex items-center gap-3 mt-3 p-2.5 rounded-xl bg-gradient-to-r from-purple-50/80 to-pink-50/80 border border-purple-200/50">
            <div class="flex items-center gap-2">
                <span class="text-[10px] font-medium text-gray-500">Lives</span>
                <span class="flex gap-0.5" id="quiz-lives">
                    <?php for ($i = 0; $i < $quizLives; $i++): ?>
                    <i class="fas fa-heart text-rose-400 text-sm" data-life="<?= $i ?>"></i>
                    <?php endfor; ?>
                </span>
            </div>
            <div class="w-px h-5 bg-purple-200"></div>
            <div class="flex items-center gap-2">
                <span class="text-[10px] font-medium text-gray-500">Score</span>
                <span class="text-sm font-bold <?= $tc[
                    "text"
                ] ?> tabular-nums" id="quiz-score">0</span>
                <span class="text-[10px] text-gray-400">/ <?= count(
                    $questions,
                ) ?></span>
            </div>
            <div class="w-px h-5 bg-purple-200"></div>
            <div class="flex items-center gap-2">
                <span class="text-[10px] font-medium text-gray-500">Pass</span>
                <span class="text-sm font-bold text-emerald-600"><?= $quizPassScore ?>%</span>
            </div>
            <div class="ml-auto">
                <span class="text-[10px] text-gray-400 flex items-center gap-1"><i class="fas fa-fire text-orange-400"></i> Streak: <span id="quiz-streak" class="font-bold text-orange-500">0</span></span>
            </div>
        </div>
        <?php endif; ?>

        <!-- Info row -->
        <div class="flex items-center gap-3 mt-3 <?= $isDark
            ? "text-gray-400"
            : "text-gray-400" ?> text-xs">
            <span><i class="far fa-clock mr-1"></i><?php
            $qCount = count($questions);
            $totalSec = $qCount * $secondsPerQuestion;
            if ($totalSec < 60):
                $totalSec; ?>s<?php
            else:
                echo floor($totalSec / 60) . "m";
                $rem = $totalSec % 60;
                if ($rem) {
                    echo " " . $rem . "s";
                }
            endif;
            ?></span>
            <span><i class="far fa-question-circle mr-1"></i><span id="question-count"><?= $qCount ?></span> <?= $qCount ===
1
    ? "question"
    : "questions" ?></span>
            <span class="ml-auto font-medium" id="progress-text">0 / <?= count(
                $questions,
            ) ?></span>
        </div>

        <!-- Progress bar -->
        <div class="mt-2.5 w-full bg-gray-200/50 rounded-full h-2 overflow-hidden backdrop-blur-sm">
            <div class="h-2 rounded-full transition-all duration-700 ease-out progress-glow" id="progress-bar" style="width: 0%; background: linear-gradient(90deg, <?= $tc[
                "hex"
            ] ?>, <?= $tc["hex2"] ?>, <?= $tc["hex3"] ?>);"></div>
        </div>

        <!-- Status dots -->
        <div class="flex gap-1.5 mt-2.5 flex-wrap" id="status-dots"></div>
    </div>

    <!-- Question cards -->
    <form method="POST" action="<?= url(
        "/survey/take/" . ($survey["id"] ?? ""),
    ) ?>" id="survey-form" enctype="multipart/form-data">
        <?= csrf() ?>
        <input type="hidden" name="survey_id" value="<?= $survey["id"] ??
            "" ?>">
        <?php if (
            !empty($responseId)
        ): ?><input type="hidden" name="response_id" value="<?= (int) $responseId ?>"><?php endif; ?>
        <div class="space-y-4" id="questions-container">
            <?php foreach ($questions as $i => $q):

                $options = json_decode($q["options_json"] ?? "[]", true);
                $rows = json_decode($q["rows_json"] ?? "[]", true);
                $shuffledOptions = $options;
                if (
                    !empty($qualityConfig["shuffle_options"]) &&
                    !empty($randomSeed) &&
                    !empty($shuffledOptions)
                ) {
                    mt_srand($randomSeed + (int) $q["id"]);
                    for ($j = count($shuffledOptions) - 1; $j > 0; $j--) {
                        $k = mt_rand(0, $j);
                        $tmp = $shuffledOptions[$j];
                        $shuffledOptions[$j] = $shuffledOptions[$k];
                        $shuffledOptions[$k] = $tmp;
                    }
                    mt_srand();
                }
                $qa = $q["animation"] ?? "";
                $qaClass =
                    $qa && $qa !== "none" ? "qa-" . $qa : "anim-slide-up";
                $qAccent = $q["accent_color"] ?? $tc["hex"];
                ?>
            <div class="question-card <?= $cardBg ?> rounded-xl p-5 border relative <?= $i >
     0 && $isSequential
     ? "hidden"
     : "" ?> <?= $qaClass ?>"
                data-qid="<?= $q["id"] ?? "" ?>" data-type="<?= $q["type"] ??
    "" ?>"
                data-required="<?= $q["is_required"] ??
                    "" ?>" data-index="<?= $i ?>"
                <?= !empty($q["is_timed"])
                    ? 'data-timed="1" data-timelimit="' .
                        (int) ($q["time_limit_seconds"] ?? 30) .
                        '"'
                    : "" ?>
                <?= $isSequential ? 'data-sequential="1"' : "" ?>
                <?php if (
                    $isQuiz &&
                    !empty($q["expected_answer"])
                ): ?>data-expected="<?= htmlspecialchars(
    $q["expected_answer"],
    ENT_QUOTES,
) ?>"<?php endif; ?>
                <?php if (
                    $isQuiz &&
                    !empty($q["explanation"])
                ): ?>data-explanation="<?= htmlspecialchars(
    $q["explanation"],
    ENT_QUOTES,
) ?>"<?php endif; ?>
                style="<?= $qAccent
                    ? "--q-accent:" . $qAccent . ";"
                    : "" ?>border-left: 3px solid <?= $qAccent ?:
    $tc["hex"] ?>;">

                <!-- Question header -->
                <div class="flex items-start justify-between mb-3">
                    <label class="font-medium <?= $textColor ?> text-sm leading-relaxed flex items-start gap-2">
                        <span class="inline-flex items-center justify-center w-7 h-7 rounded-full" style="background:<?= $qAccent ?:
                            $tc["hex"] ?>15; color:<?= $qAccent ?:
    $tc[
        "hex"
    ] ?>; font-size:11px; font-weight:700; flex-shrink:0; margin-top:1px;"><?= $i +
    1 ?></span>
                        <span><?= htmlspecialchars($q["question_text"] ?? "") ?>
                            <?php if (
                                !empty($q["is_required"])
                            ): ?><span class="text-red-400">*</span><?php endif; ?>
                        </span>
                    </label>
                    <div class="flex items-center gap-1 ml-2 flex-shrink-0 flex-wrap justify-end">
                        <?php if (!empty($q["is_attention_check"])): ?>
                            <span class="px-2 py-0.5 text-[10px] bg-amber-50 text-amber-700 border border-amber-200 rounded-full"><i class="fas fa-eye mr-0.5"></i>Verify</span>
                        <?php endif; ?>
                        <?php if (!empty($q["is_speed_bump"])): ?>
                            <span class="px-2 py-0.5 text-[10px] bg-orange-50 text-orange-700 border border-orange-200 rounded-full"><i class="fas fa-road mr-0.5"></i>Check</span>
                        <?php endif; ?>
                        <?php if (!empty($q["is_timed"])): ?>
                            <span class="timed-badge px-2 py-0.5 text-[10px] bg-purple-50 text-purple-700 border border-purple-200 rounded-full" data-qid="<?= $q[
                                "id"
                            ] ?? "" ?>">
                                <i class="fas fa-hourglass-half mr-0.5"></i><span class="timed-countdown" data-qid="<?= $q[
                                    "id"
                                ] ?? "" ?>"><?= (int) ($q[
    "time_limit_seconds"
] ?? 30) ?>s</span>
                            </span>
                        <?php endif; ?>
                        <?php if (
                            isset($q["allow_paste"]) &&
                            !$q["allow_paste"]
                        ): ?>
                            <span class="px-2 py-0.5 text-[10px] bg-red-50 text-red-700 border border-red-200 rounded-full"><i class="fas fa-paste mr-0.5"></i></span>
                        <?php endif; ?>
                        <?php if ($isQuiz && !empty($q["expected_answer"])): ?>
                            <span class="px-2 py-0.5 text-[10px] bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-full"><i class="fas fa-check-double mr-0.5"></i>Scored</span>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Validation message -->
                <div class="validation-message text-xs text-red-500 mb-2 hidden flex items-center gap-1 shake">
                    <i class="fas fa-exclamation-circle"></i><span></span>
                </div>

                <!-- Quiz feedback overlay -->
                <div class="quiz-feedback hidden mb-3 p-3 rounded-xl text-sm font-medium transition-all duration-500 flex items-start gap-3 animate-slide-down-fade" style="transform-origin:top">
                    <div class="feedback-icon w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 text-lg"></div>
                    <div class="flex-1 min-w-0">
                        <div class="feedback-title font-bold text-sm"></div>
                        <div class="feedback-detail text-xs mt-1 opacity-80"></div>
                        <div class="feedback-explanation text-xs mt-2 opacity-70 leading-relaxed"></div>
                    </div>
                </div>

                <!-- === QUESTION INPUTS === -->

                <?php if (($q["type"] ?? "") === "textarea"): ?>
                    <textarea name="q_<?= $q["id"] ?? "" ?>"
                        <?= !empty($q["is_required"]) ? "required" : "" ?>
                        class="w-full px-4 py-3 rounded-xl <?= $inputBg ?> border <?= $tc[
     "focus"
 ] ?> transition-all text-sm <?= $isDark ? "text-white" : "" ?>"
                        placeholder="Type your detailed answer..."
                        <?= !empty($q["char_limit"])
                            ? 'maxlength="' . $q["char_limit"] . '"'
                            : "" ?>
                        rows="4"></textarea>

                <?php // If using default numeric labels, show proper agree-disagree scale

                    elseif (
                    in_array($q["type"] ?? "", ["text", "email", "phone"])
                ): ?>
                    <div class="relative">
                        <input type="<?= ($q["type"] ?? "") === "email"
                            ? "email"
                            : (($q["type"] ?? "") === "phone"
                                ? "tel"
                                : "text") ?>"
                            name="q_<?= $q["id"] ?? "" ?>"
                            <?= !empty($q["is_required"]) ? "required" : "" ?>
                            class="w-full px-4 py-3 rounded-xl <?= $inputBg ?> border <?= $tc[
     "focus"
 ] ?> transition-all text-sm <?= $isDark ? "text-white" : "" ?>"
                            placeholder="<?= $q["type"] === "email"
                                ? "your@email.com"
                                : ($q["type"] === "phone"
                                    ? "+1 (555) 000-0000"
                                    : "Type your answer...") ?>"
                            data-validate="<?= $q["type"] ?? "" ?>"
                            <?= !empty($qualityConfig["min_text_length"]) &&
                            ($q["type"] ?? "") === "text"
                                ? 'data-minlen="' .
                                    (int) $qualityConfig["min_text_length"] .
                                    '"'
                                : "" ?>
                            <?= !empty($q["min_length"])
                                ? 'data-minlen="' . (int) $q["min_length"] . '"'
                                : "" ?>
                            <?= !empty($q["max_length"])
                                ? 'maxlength="' . (int) $q["max_length"] . '"'
                                : "" ?>
                            <?= !empty($q["char_limit"])
                                ? 'maxlength="' . $q["char_limit"] . '"'
                                : "" ?>
                            <?= (isset($q["allow_paste"]) &&
                                !$q["allow_paste"]) ||
                            !empty($qualityConfig["prevent_copy_paste"])
                                ? 'onpaste="return false"'
                                : "" ?>
                            <?= !empty($qualityConfig["prevent_copy_paste"])
                                ? 'oncopy="return false" oncut="return false"'
                                : "" ?>
                            autocomplete="off">
                        <span class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-300 text-xs"><i class="fas fa-pen"></i></span>
                    </div>

                <?php elseif (($q["type"] ?? "") === "number"): ?>
                    <input type="number" name="q_<?= $q["id"] ?? "" ?>"
                        <?= !empty($q["is_required"]) ? "required" : "" ?>
                        <?= isset($q["min_value"]) && $q["min_value"] !== null
                            ? 'min="' . $q["min_value"] . '"'
                            : "" ?>
                        <?= isset($q["max_value"]) && $q["max_value"] !== null
                            ? 'max="' . $q["max_value"] . '"'
                            : "" ?>
                        class="w-full px-4 py-3 rounded-xl <?= $inputBg ?> border <?= $tc[
     "focus"
 ] ?> transition-all text-sm"
                        placeholder="Enter a number...">

                <?php elseif (($q["type"] ?? "") === "date"): ?>
                    <input type="date" name="q_<?= $q["id"] ?? "" ?>"
                        <?= !empty($q["is_required"]) ? "required" : "" ?>
                        class="w-full px-4 py-3 rounded-xl <?= $inputBg ?> border <?= $tc[
     "focus"
 ] ?> transition-all text-sm <?= $isDark
     ? "text-white [color-scheme:dark]"
     : "" ?>">

                <?php elseif (($q["type"] ?? "") === "yes_no"): ?>
                    <div class="flex gap-3">
                        <label class="q-option flex-1 flex items-center gap-2.5 px-4 py-3 border-2 rounded-xl cursor-pointer active:scale-[0.98]"
                            style="border-color:rgba(<?= $tc["hex"] ?>,0.2)">
                            <input type="radio" name="q_<?= $q["id"] ??
                                "" ?>" value="Yes" <?= !empty($q["is_required"])
    ? "required"
    : "" ?> class="sr-only">
                            <span class="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-600 flex items-center justify-center text-sm"><i class="fas fa-check"></i></span>
                            <span class="font-medium <?= $textColor ?> text-sm">Yes</span>
                        </label>
                        <label class="q-option flex-1 flex items-center gap-2.5 px-4 py-3 border-2 rounded-xl cursor-pointer active:scale-[0.98]"
                            style="border-color:rgba(<?= $tc["hex"] ?>,0.2)">
                            <input type="radio" name="q_<?= $q["id"] ??
                                "" ?>" value="No" <?= !empty($q["is_required"])
    ? "required"
    : "" ?> class="sr-only">
                            <span class="w-8 h-8 rounded-lg bg-red-100 text-red-600 flex items-center justify-center text-sm"><i class="fas fa-times"></i></span>
                            <span class="font-medium <?= $textColor ?> text-sm">No</span>
                        </label>
                    </div>

                <?php elseif (($q["type"] ?? "") === "mcq_single"): ?>
                    <div class="space-y-2">
                        <?php foreach ($shuffledOptions as $opt): ?>
                        <label class="q-option flex items-center gap-3 p-3 border-2 rounded-xl cursor-pointer active:scale-[0.99]"
                            style="border-color:rgba(<?= $tc["hex"] ?>,0.15)">
                            <input type="radio" name="q_<?= $q["id"] ??
                                "" ?>" value="<?= htmlspecialchars($opt) ?>"
                                <?= !empty($q["is_required"])
                                    ? "required"
                                    : "" ?> class="sr-only mcq-radio">
                            <span class="w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-all" style="border-color:<?= $tc[
                                "hex"
                            ] ?>">
                                <span class="w-2.5 h-2.5 rounded-full transition-all" style="background:<?= $tc[
                                    "hex"
                                ] ?>; opacity:0;"></span>
                            </span>
                            <span class="text-sm <?= $textColor ?>"><?= htmlspecialchars(
    $opt,
) ?></span>
                        </label>
                        <?php endforeach; ?>
                        <?php if (
                            !isset($q["include_other"]) ||
                            $q["include_other"]
                        ): ?>
                        <!-- Other option -->
                        <label class="q-option flex items-center gap-3 p-3 border-2 rounded-xl cursor-pointer active:scale-[0.99]"
                            style="border-color:rgba(<?= $tc["hex"] ?>,0.15)">
                            <input type="radio" name="q_<?= $q["id"] ??
                                "" ?>" value="__other__"
                                <?= !empty($q["is_required"])
                                    ? "required"
                                    : "" ?> class="sr-only mcq-radio mcq-other-radio"
                                onchange="var inp=this.closest('.space-y-2').querySelector('.mcq-other-input');if(this.checked){inp.classList.remove('hidden','opacity-0','scale-95');inp.classList.add('opacity-100','scale-100');inp.focus()}else{inp.classList.add('hidden')}">
                            <span class="w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-all" style="border-color:<?= $tc[
                                "hex"
                            ] ?>">
                                <span class="w-2.5 h-2.5 rounded-full transition-all" style="background:<?= $tc[
                                    "hex"
                                ] ?>; opacity:0;"></span>
                            </span>
                            <span class="text-sm <?= $textColor ?>">Other:</span>
                        </label>
                        <input type="text" class="mcq-other-input hidden w-full px-4 py-2.5 rounded-xl <?= $inputBg ?> border <?= $tc[
     "focus"
 ] ?> transition-all text-sm opacity-0 scale-95"
                            placeholder="Please specify..."
                            oninput="var radio=this.closest('.space-y-2').querySelector('.mcq-other-radio');radio.value='__other__:'+this.value">
                        <?php endif; ?>
                        <!-- Custom options container -->
                        <div id="custom-opts-<?= $q["id"] ?? "" ?>"></div>
                        <button type="button" onclick="addCustomOption(<?= $q[
                            "id"
                        ] ??
                            "0" ?>,'single')" class="w-full py-2 text-xs font-medium text-gray-400 hover:text-<?= $themeColor ?>-600 border-2 border-dashed border-gray-200 hover:border-<?= $themeColor ?>-300 rounded-xl transition-all flex items-center justify-center gap-1.5 group"><i class="fas fa-plus text-[9px] group-hover:rotate-90 transition-transform"></i> Add custom option</button>
                        <script>document.querySelector('#custom-opts-<?= $q[
                            "id"
                        ] ??
                            "" ?>').closest('.space-y-2').querySelectorAll('.mcq-radio').forEach(function(r){r.addEventListener('change',function(){document.getElementById('custom-opts-<?= $q[
    "id"
] ??
    "" ?>').querySelectorAll('input[type=text]').forEach(function(t){t.value='';var cb=t.nextElementSibling;cb.value='';cb.checked=false})})})</script>
                    </div>

                <?php elseif (($q["type"] ?? "") === "dropdown"): ?>
                    <div class="relative">
                        <select name="q_<?= $q["id"] ?? "" ?>" <?= !empty(
    $q["is_required"]
)
    ? "required"
    : "" ?>
                            class="w-full px-4 py-3 rounded-xl <?= $inputBg ?> border <?= $tc[
     "focus"
 ] ?> transition-all text-sm appearance-none cursor-pointer">
                            <option value="">Select an option...</option>
                            <?php foreach ($shuffledOptions as $opt): ?>
                            <option value="<?= htmlspecialchars(
                                $opt,
                            ) ?>"><?= htmlspecialchars($opt) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <span class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none"><i class="fas fa-chevron-down text-xs"></i></span>
                    </div>

                <?php elseif (($q["type"] ?? "") === "mcq_multiple"): ?>
                    <div class="space-y-2">
                        <?php foreach ($shuffledOptions as $opt): ?>
                        <label class="q-option flex items-center gap-3 p-3 border-2 rounded-xl cursor-pointer active:scale-[0.99]"
                            style="border-color:rgba(<?= $tc["hex"] ?>,0.15)">
                            <input type="checkbox" name="q_<?= $q["id"] ??
                                "" ?>[]" value="<?= htmlspecialchars($opt) ?>"
                                class="sr-only mcq-cb">
                            <span class="w-5 h-5 rounded-md border-2 flex items-center justify-center flex-shrink-0 transition-all" style="border-color:<?= $tc[
                                "hex"
                            ] ?>">
                                <span class="transition-all" style="color:<?= $tc[
                                    "hex"
                                ] ?>; opacity:0; font-size:12px;">✓</span>
                            </span>
                            <span class="text-sm <?= $textColor ?>"><?= htmlspecialchars(
    $opt,
) ?></span>
                        </label>
                        <?php endforeach; ?>
                        <?php if (
                            !isset($q["include_other"]) ||
                            $q["include_other"]
                        ): ?>
                        <!-- Other option -->
                        <label class="q-option flex items-center gap-3 p-3 border-2 rounded-xl cursor-pointer active:scale-[0.99]"
                            style="border-color:rgba(<?= $tc["hex"] ?>,0.15)">
                            <input type="checkbox" name="q_<?= $q["id"] ??
                                "" ?>[]" value="__other__"
                                class="sr-only mcq-cb mcq-other-cb"
                                onchange="var inp=this.closest('.space-y-2').querySelector('.mcq-other-input');if(this.checked){inp.classList.remove('hidden','opacity-0','scale-95');inp.classList.add('opacity-100','scale-100');inp.focus()}else{inp.classList.add('hidden')}">
                            <span class="w-5 h-5 rounded-md border-2 flex items-center justify-center flex-shrink-0 transition-all" style="border-color:<?= $tc[
                                "hex"
                            ] ?>">
                                <span class="transition-all" style="color:<?= $tc[
                                    "hex"
                                ] ?>; opacity:0; font-size:12px;">✓</span>
                            </span>
                            <span class="text-sm <?= $textColor ?>">Other:</span>
                        </label>
                        <input type="text" class="mcq-other-input hidden w-full px-4 py-2.5 rounded-xl <?= $inputBg ?> border <?= $tc[
     "focus"
 ] ?> transition-all text-sm opacity-0 scale-95"
                            placeholder="Please specify..."
                            oninput="var cb=this.closest('.space-y-2').querySelector('.mcq-other-cb');cb.value='__other__:'+this.value">
                        <?php endif; ?>
                        <!-- Custom options container -->
                        <div id="custom-opts-<?= $q["id"] ?? "" ?>"></div>
                        <button type="button" onclick="addCustomOption(<?= $q[
                            "id"
                        ] ??
                            "0" ?>,'multiple')" class="w-full py-2 text-xs font-medium text-gray-400 hover:text-<?= $themeColor ?>-600 border-2 border-dashed border-gray-200 hover:border-<?= $themeColor ?>-300 rounded-xl transition-all flex items-center justify-center gap-1.5 group"><i class="fas fa-plus text-[9px] group-hover:rotate-90 transition-transform"></i> Add custom option</button>
                    </div>

                <?php elseif (
                    in_array($q["type"] ?? "", ["likert5", "likert7"])
                ): ?>
                    <?php
                    $likertLabels = $shuffledOptions;
                    if (
                        count($likertLabels) >= 5 &&
                        is_numeric($likertLabels[0] ?? "")
                    ) {
                        $likertLabels =
                            $q["type"] === "likert7"
                                ? [
                                    "Strongly Disagree",
                                    "Disagree",
                                    "Slightly Disagree",
                                    "Neutral",
                                    "Slightly Agree",
                                    "Agree",
                                    "Strongly Agree",
                                ]
                                : [
                                    "Strongly Disagree",
                                    "Disagree",
                                    "Neutral",
                                    "Agree",
                                    "Strongly Agree",
                                ];
                    }
                    ?>
                    <div class="grid gap-2" style="grid-template-columns: repeat(<?= count(
                        $likertLabels,
                    ) ?>, 1fr)">
                        <?php foreach ($likertLabels as $j => $label): ?>
                        <label class="likert-option flex flex-col items-center gap-1.5 p-3 border-2 rounded-xl cursor-pointer text-center transition-all"
                            style="border-color:rgba(<?= $tc["hex"] ?>,0.15)">
                            <input type="radio" name="q_<?= $q["id"] ??
                                "" ?>" value="<?= $j + 1 ?>"
                                <?= !empty($q["is_required"])
                                    ? "required"
                                    : "" ?> class="sr-only">
                            <span class="likert-label text-lg font-bold <?= $textColor ?>"><?= $j +
    1 ?></span>
                            <span class="likert-text text-[10px] leading-tight <?= $textMuted ?>"><?= htmlspecialchars(
    $label,
) ?></span>
                        </label>
                        <?php endforeach; ?>
                    </div>

                <?php elseif (($q["type"] ?? "") === "rating"): ?>
                    <div class="flex justify-center gap-1.5 py-2" id="star-group-<?= $q[
                        "id"
                    ] ?? "" ?>">
                        <?php for ($star = 1; $star <= 5; $star++): ?>
                        <label class="star-label cursor-pointer text-3xl transition-all px-1 <?= $isDark
                            ? "text-gray-500"
                            : "text-gray-300" ?>"
                            data-star="<?= $star ?>">
                            <input type="radio" name="q_<?= $q["id"] ??
                                "" ?>" value="<?= $star ?>"
                                <?= !empty($q["is_required"])
                                    ? "required"
                                    : "" ?> class="sr-only">
                            <i class="far fa-star transition-all duration-200"></i>
                        </label>
                        <?php endfor; ?>
                    </div>
                    <div class="flex justify-between text-[10px] <?= $textMuted ?> px-1 mt-1">
                        <span>Poor</span>
                        <span>Excellent</span>
                    </div>

                <?php elseif (($q["type"] ?? "") === "slider"): ?>
                    <?php
                    $minVal = $q["min_value"] ?? 0;
                    $maxVal = $q["max_value"] ?? 100;
                    $step = $q["step"] ?? 1;
                    ?>
                    <div class="flex items-center gap-4 py-2">
                        <span class="text-sm font-medium <?= $textMuted ?> w-10 text-right tabular-nums"><?= $minVal ?></span>
                        <div class="flex-1">
                            <input type="range" name="q_<?= $q["id"] ?? "" ?>"
                                min="<?= $minVal ?>" max="<?= $maxVal ?>" step="<?= $step ?>"
                                value="<?= (int) (($minVal + $maxVal) / 2) ?>"
                                class="w-full" style="accent-color:<?= $tc[
                                    "hex"
                                ] ?>"
                                oninput="this.nextElementSibling.textContent = this.value">
                            <div class="flex justify-between text-[9px] <?= $textMuted ?> mt-1 px-1">
                                <span><?= htmlspecialchars(
                                    $q["min_label"] ?? "",
                                ) ?></span>
                                <span><?= htmlspecialchars(
                                    $q["max_label"] ?? "",
                                ) ?></span>
                            </div>
                        </div>
                        <span class="text-xl font-bold tabular-nums w-14 text-center" style="color:<?= $tc[
                            "hex"
                        ] ?>"><?= (int) (($minVal + $maxVal) / 2) ?></span>
                    </div>

                <?php elseif (($q["type"] ?? "") === "matrix"): ?>
                    <div class="overflow-x-auto -mx-1">
                        <table class="w-full text-sm border-separate" style="border-spacing:3px;">
                            <thead>
                                <tr>
                                    <th class="p-2 <?= $textMuted ?> font-medium text-left text-xs"></th>
                                    <?php foreach ($shuffledOptions as $col): ?>
                                    <th class="p-2 text-center <?= $textMuted ?> font-medium text-xs"><?= htmlspecialchars(
     $col,
 ) ?></th>
                                    <?php endforeach; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($rows as $row): ?>
                                <tr>
                                    <td class="p-2 <?= $textColor ?> font-medium text-xs"><?= htmlspecialchars(
     $row,
 ) ?></td>
                                    <?php foreach ($shuffledOptions as $col): ?>
                                    <td class="p-1 text-center">
                                        <label class="matrix-cell w-10 h-10 rounded-xl border-2 flex items-center justify-center cursor-pointer transition-all mx-auto"
                                            style="border-color:rgba(<?= $tc[
                                                "hex"
                                            ] ?>,0.15)">
                                            <input type="radio" name="q_<?= $q[
                                                "id"
                                            ] ?? "" ?>_<?= htmlspecialchars(
    $row,
) ?>" value="<?= htmlspecialchars($col) ?>"
                                                <?= !empty($q["is_required"])
                                                    ? "required"
                                                    : "" ?> class="sr-only"
                                                onchange="this.closest('label').style.borderColor='<?= $tc[
                                                    "hex"
                                                ] ?>';this.closest('label').style.background='<?= $tc[
    "light"
] ?>'">
                                            <span class="w-3 h-3 rounded-full transition-all" style="background:<?= $tc[
                                                "hex"
                                            ] ?>;opacity:0;"></span>
                                        </label>
                                    </td>
                                    <?php endforeach; ?>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                <?php elseif (($q["type"] ?? "") === "file_upload"): ?>
                    <div class="border-2 border-dashed rounded-xl p-6 text-center transition-all cursor-pointer hover:bg-gray-50/50"
                        style="border-color:rgba(<?= $tc["hex"] ?>,0.2)"
                        onclick="document.getElementById('file-<?= $q["id"] ??
                            "" ?>').click()">
                        <input type="file" name="q_<?= $q["id"] ??
                            "" ?>" id="file-<?= $q["id"] ?? "" ?>"
                            <?= !empty($q["is_required"])
                                ? "required"
                                : "" ?> class="hidden"
                            onchange="this.closest('div').querySelector('.file-name').textContent = this.files[0]?.name || 'No file selected'">
                        <i class="fas fa-cloud-upload-alt text-2xl" style="color:<?= $tc[
                            "hex"
                        ] ?>"></i>
                        <p class="text-sm <?= $textMuted ?> mt-1">Click to upload or drag & drop</p>
                        <p class="text-xs <?= $textMuted ?> mt-0.5 file-name">No file selected</p>
                    </div>

                <?php elseif (($q["type"] ?? "") === "url"): ?>
                    <div class="relative">
                        <input type="url" name="q_<?= $q["id"] ?? "" ?>"
                            <?= !empty($q["is_required"]) ? "required" : "" ?>
                            class="w-full px-4 py-3 rounded-xl <?= $inputBg ?> border <?= $tc[
     "focus"
 ] ?> transition-all text-sm <?= $isDark ? "text-white" : "" ?>"
                            placeholder="https://example.com"
                            pattern="https?://.+"
                            data-validate="url">
                        <span class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-300 text-xs"><i class="fas fa-link"></i></span>
                    </div>

                <?php elseif (($q["type"] ?? "") === "nps"): ?>
                    <div class="space-y-3">
                        <div class="flex gap-1 justify-center flex-wrap">
                            <?php for ($n = 0; $n <= 10; $n++): ?>
                            <label class="nps-option w-9 h-10 rounded-xl border-2 flex items-center justify-center cursor-pointer transition-all text-sm font-bold"
                                style="border-color:rgba(<?= $tc[
                                    "hex"
                                ] ?>,0.15)"
                                onmouseover="this.style.borderColor='<?= $tc[
                                    "hex"
                                ] ?>';this.style.background='<?= $tc[
    "light"
] ?>'"
                                onmouseout="if(!this.querySelector('input').checked){this.style.borderColor='rgba(<?= $tc[
                                    "hex"
                                ] ?>,0.15)';this.style.background='transparent'}">
                                <input type="radio" name="q_<?= $q["id"] ??
                                    "" ?>" value="<?= $n ?>"
                                    <?= !empty($q["is_required"])
                                        ? "required"
                                        : "" ?> class="sr-only"
                                    onchange="document.querySelectorAll('.nps-option').forEach(function(l){l.style.borderColor='rgba(<?= $tc[
                                        "hex"
                                    ] ?>,0.15)';l.style.background='transparent'});this.closest('.nps-option').style.borderColor='<?= $tc[
    "hex"
] ?>';this.closest('.nps-option').style.background='<?= $tc["light"] ?>'">
                                <span class="<?= $n <= 6
                                    ? "text-rose-500"
                                    : ($n >= 9
                                        ? "text-emerald-500"
                                        : "text-amber-500") ?>"><?= $n ?></span>
                            </label>
                            <?php endfor; ?>
                        </div>
                        <div class="flex justify-between text-[10px] px-1 <?= $textMuted ?>">
                            <span>Not likely (0)</span>
                            <span>Extremely likely (10)</span>
                        </div>
                    </div>

                <?php elseif (($q["type"] ?? "") === "ranking"): ?>
                    <div class="space-y-2 ranking-list" data-qid="<?= $q[
                        "id"
                    ] ?? "" ?>">
                        <?php foreach ($shuffledOptions as $r => $opt): ?>
                        <div class="ranking-item flex items-center gap-3 p-3 border-2 rounded-xl cursor-grab active:cursor-grabbing transition-all"
                            style="border-color:rgba(<?= $tc[
                                "hex"
                            ] ?>,0.15)" draggable="true"
                            data-idx="<?= $r ?>"
                            ondragstart="this.style.opacity='0.5';this.closest('.ranking-list').dataset.dragged=this.dataset.idx"
                            ondragend="this.style.opacity='1';handleRankingDrop(event)"
                            ondrop="event.preventDefault();handleRankingDrop(event)"
                            ondragover="event.preventDefault()">
                            <span class="handle cursor-grab text-gray-300 text-sm"><i class="fas fa-grip-vertical"></i></span>
                            <span class="rank-number w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold"
                                style="background:<?= $tc[
                                    "hex"
                                ] ?>15;color:<?= $tc["hex"] ?>"><?= $r +
    1 ?></span>
                            <span class="text-sm <?= $textColor ?> flex-1"><?= htmlspecialchars(
     $opt,
 ) ?></span>
                            <input type="hidden" name="q_<?= $q["id"] ??
                                "" ?>[]" value="<?= htmlspecialchars($opt) ?>">
                        </div>
                        <?php endforeach; ?>
                    </div>

                <?php elseif (($q["type"] ?? "") === "multi_text"): ?>
                    <div class="space-y-3">
                        <?php foreach ($shuffledOptions as $field): ?>
                        <div class="flex items-center gap-3">
                            <label class="text-xs font-medium <?= $textColor ?> w-24 flex-shrink-0"><?= htmlspecialchars(
     $field,
 ) ?></label>
                            <input type="text" name="q_<?= $q["id"] ??
                                "" ?>_<?= htmlspecialchars($field) ?>"
                                <?= !empty($q["is_required"])
                                    ? "required"
                                    : "" ?>
                                class="flex-1 px-4 py-2.5 rounded-xl <?= $inputBg ?> border <?= $tc[
     "focus"
 ] ?> transition-all text-sm"
                                placeholder="<?= htmlspecialchars($field) ?>">
                        </div>
                        <?php endforeach; ?>
                    </div>

                <?php elseif (($q["type"] ?? "") === "address"): ?>
                    <div class="space-y-3">
                        <input type="text" name="q_<?= $q["id"] ??
                            "" ?>_street" placeholder="Street Address"
                            <?= !empty($q["is_required"]) ? "required" : "" ?>
                            class="w-full px-4 py-2.5 rounded-xl <?= $inputBg ?> border <?= $tc[
     "focus"
 ] ?> transition-all text-sm">
                        <div class="grid grid-cols-3 gap-3">
                            <input type="text" name="q_<?= $q["id"] ??
                                "" ?>_city" placeholder="City"
                                <?= !empty($q["is_required"])
                                    ? "required"
                                    : "" ?>
                                class="w-full px-4 py-2.5 rounded-xl <?= $inputBg ?> border <?= $tc[
     "focus"
 ] ?> transition-all text-sm col-span-2">
                            <input type="text" name="q_<?= $q["id"] ??
                                "" ?>_state" placeholder="State"
                                class="w-full px-4 py-2.5 rounded-xl <?= $inputBg ?> border <?= $tc[
     "focus"
 ] ?> transition-all text-sm">
                        </div>
                        <div class="grid grid-cols-2 gap-3">
                            <input type="text" name="q_<?= $q["id"] ??
                                "" ?>_zip" placeholder="ZIP Code"
                                class="w-full px-4 py-2.5 rounded-xl <?= $inputBg ?> border <?= $tc[
     "focus"
 ] ?> transition-all text-sm">
                            <input type="text" name="q_<?= $q["id"] ??
                                "" ?>_country" placeholder="Country"
                                class="w-full px-4 py-2.5 rounded-xl <?= $inputBg ?> border <?= $tc[
     "focus"
 ] ?> transition-all text-sm">
                        </div>
                    </div>

                <?php elseif (($q["type"] ?? "") === "time"): ?>
                    <input type="time" name="q_<?= $q["id"] ?? "" ?>"
                        <?= !empty($q["is_required"]) ? "required" : "" ?>
                        class="w-full px-4 py-3 rounded-xl <?= $inputBg ?> border <?= $tc[
     "focus"
 ] ?> transition-all text-sm <?= $isDark
     ? "text-white [color-scheme:dark]"
     : "" ?>">

                <?php elseif (($q["type"] ?? "") === "datetime"): ?>
                    <input type="datetime-local" name="q_<?= $q["id"] ?? "" ?>"
                        <?= !empty($q["is_required"]) ? "required" : "" ?>
                        class="w-full px-4 py-3 rounded-xl <?= $inputBg ?> border <?= $tc[
     "focus"
 ] ?> transition-all text-sm <?= $isDark
     ? "text-white [color-scheme:dark]"
     : "" ?>">

                <?php elseif (($q["type"] ?? "") === "color"): ?>
                    <div class="flex items-center gap-4">
                        <input type="color" name="q_<?= $q["id"] ??
                            "" ?>" value="#6366f1"
                            <?= !empty($q["is_required"]) ? "required" : "" ?>
                            class="w-16 h-16 rounded-xl border-2 cursor-pointer transition-all"
                            style="border-color:<?= $tc[
                                "hex"
                            ] ?>;background:<?= $tc["hex"] ?>"
                            onchange="this.style.background=this.value;this.nextElementSibling.textContent=this.value;this.nextElementSibling.style.color=this.value">
                        <span class="text-sm font-mono <?= $textMuted ?>">#6366f1</span>
                    </div>

                <?php elseif (($q["type"] ?? "") === "percentage"): ?>
                    <div class="flex items-center gap-4 py-2">
                        <span class="text-sm font-medium <?= $textMuted ?>">0%</span>
                        <div class="flex-1">
                            <input type="range" name="q_<?= $q["id"] ?? "" ?>"
                                min="0" max="100" step="1" value="50"
                                class="w-full" style="accent-color:<?= $tc[
                                    "hex"
                                ] ?>"
                                oninput="this.nextElementSibling.textContent = this.value + '%'">
                            <div class="flex justify-between text-[9px] <?= $textMuted ?> mt-1 px-1">
                                <span>0%</span>
                                <span>50%</span>
                                <span>100%</span>
                            </div>
                        </div>
                        <span class="text-xl font-bold tabular-nums w-16 text-center" style="color:<?= $tc[
                            "hex"
                        ] ?>">50%</span>
                    </div>

                <?php elseif (($q["type"] ?? "") === "signature"): ?>
                    <div class="border-2 border-dashed rounded-xl p-1 transition-all" style="border-color:rgba(<?= $tc[
                        "hex"
                    ] ?>,0.2)">
                        <canvas class="signature-pad w-full h-36 rounded-lg cursor-crosshair" data-qid="<?= $q[
                            "id"
                        ] ?? "" ?>"
                            style="touch-action:none"></canvas>
                        <input type="hidden" name="q_<?= $q["id"] ??
                            "" ?>" class="signature-input">
                        <div class="flex justify-between items-center mt-2 px-1">
                            <button type="button" onclick="clearSignature(this.closest('.border-dashed').querySelector('canvas'))"
                                class="text-xs px-2 py-1 rounded-lg bg-gray-100 text-gray-600 hover:bg-gray-200 transition-colors">
                                <i class="fas fa-eraser mr-1"></i>Clear
                            </button>
                            <span class="text-[10px] <?= $textMuted ?>">Sign above</span>
                        </div>
                    </div>

                <?php elseif (($q["type"] ?? "") === "image_choice"):
                    $imgOpts = $q["options"] ?? []; ?>
                    <div class="grid grid-cols-2 sm:grid-cols-3 gap-3">
                        <?php foreach ($imgOpts as $io):

                            $ioUrl = $io["image_url"] ?? "";
                            $ioLabel = $io["label"] ?? "";
                            ?>
                        <label class="image-choice-option relative cursor-pointer group">
                            <input type="radio" name="q_<?= $q["id"] ??
                                "" ?>" value="<?= htmlspecialchars(
    $ioLabel,
) ?>" class="hidden peer" <?= !empty($q["is_required"]) ? "required" : "" ?>>
                            <div class="aspect-[4/3] rounded-xl overflow-hidden border-2 border-transparent peer-checked:border-<?= $themeColor ?>-500 peer-checked:shadow-lg transition-all group-hover:scale-[1.02]">
                                <img src="<?= htmlspecialchars(
                                    $ioUrl,
                                ) ?>" alt="<?= htmlspecialchars(
    $ioLabel,
) ?>" class="w-full h-full object-cover" loading="lazy" onerror="this.parentElement.innerHTML='<div class=\'flex items-center justify-center w-full h-full bg-gray-100 text-gray-400 text-xs\'>No image</div>'">
                            </div>
                            <?php if (
                                $ioLabel
                            ): ?><p class="text-xs text-center mt-1 <?= $textMuted ?> truncate"><?= htmlspecialchars(
     $ioLabel,
 ) ?></p><?php endif; ?>
                        </label>
                        <?php
                        endforeach; ?>
                    </div>

                <?php
                elseif (($q["type"] ?? "") === "drag_drop_rank"):
                    $rankOpts = $q["options"] ?? []; ?>
                    <div class="rank-list space-y-2" data-qid="<?= $q["id"] ??
                        "" ?>">
                        <?php
                        shuffle($rankOpts);
                        foreach ($rankOpts as $ri => $ro): ?>
                        <div class="rank-item flex items-center gap-3 px-4 py-3 rounded-xl cursor-grab active:cursor-grabbing select-none transition-all border" style="border-color:rgba(<?= $tc[
                            "hex"
                        ] ?>,0.15);background:rgba(<?= $tc[
    "hex"
] ?>,0.03)" draggable="true" data-value="<?= htmlspecialchars($ro) ?>">
                            <span class="rank-handle flex items-center justify-center w-7 h-7 rounded-lg text-xs font-bold" style="background:<?= $tc[
                                "hex"
                            ] ?>15;color:<?= $tc[
    "hex"
] ?>"><i class="fas fa-grip-vertical text-[10px]"></i></span>
                            <span class="flex-1 text-sm <?= $textColor ?>"><?= htmlspecialchars(
    $ro,
) ?></span>
                            <input type="hidden" name="q_<?= $q["id"] ??
                                "" ?>[]" value="<?= htmlspecialchars($ro) ?>">
                        </div>
                        <?php endforeach;
                        ?>
                    </div>

                <?php
                elseif (($q["type"] ?? "") === "slider_labels"):

                    $slOpts = $q["options"] ?? [];
                    $slCount = count($slOpts);
                    ?>
                    <div class="py-4">
                        <input type="range" name="q_<?= $q["id"] ??
                            "" ?>" min="0" max="<?= max(
    0,
    $slCount - 1,
) ?>" step="1" value="0" class="w-full" style="accent-color:<?= $tc[
    "hex"
] ?>" oninput="var t=this.closest('.py-4').querySelector('.slider-value');if(t){var idx=parseInt(this.value);var labels=JSON.parse(this.getAttribute('data-labels'));t.textContent=labels[idx]||''}">
                        <div class="flex justify-between mt-1 px-0.5">
                            <?php foreach ($slOpts as $si => $sl): ?>
                            <span class="text-[10px] <?= $textMuted ?> text-center" style="width:<?= $slCount >
 0
     ? 100 / $slCount
     : 100 ?>%"><?= htmlspecialchars($sl) ?></span>
                            <?php endforeach; ?>
                        </div>
                        <div class="text-center mt-2"><span class="slider-value text-sm font-medium" style="color:<?= $tc[
                            "hex"
                        ] ?>"><?= htmlspecialchars(
    $slOpts[0] ?? "",
) ?></span></div>
                        <input type="hidden" class="slider-labels-store" value="<?= htmlspecialchars(
                            json_encode($slOpts),
                        ) ?>">
                    </div>

                <?php
                elseif (($q["type"] ?? "") === "star_rating"):
                    $srCount = (int) ($q["options"][0] ?? 5); ?>
                    <div class="star-rating flex flex-row-reverse justify-end gap-1 py-2" data-qid="<?= $q[
                        "id"
                    ] ?? "" ?>">
                        <?php for ($s = $srCount; $s >= 1; $s--): ?>
                        <input type="radio" name="q_<?= $q["id"] ??
                            "" ?>" value="<?= $s ?>" id="star_<?= $q["id"] ??
    "" ?>_<?= $s ?>" class="hidden peer" <?= !empty($q["is_required"])
    ? "required"
    : "" ?>>
                        <label for="star_<?= $q["id"] ??
                            "" ?>_<?= $s ?>" class="cursor-pointer text-3xl transition-all peer-checked:text-yellow-400 peer-checked:scale-110 hover:text-yellow-400 hover:scale-110 text-gray-300" style="color:rgba(<?= $tc[
    "rgb"
] ?>,0.25)">★</label>
                        <?php endfor; ?>
                    </div>

                <?php
                elseif (($q["type"] ?? "") === "emoji_rating"):
                    $emojiList = $q["options"] ?? [
                        "😡",
                        "😟",
                        "😐",
                        "🙂",
                        "😍",
                    ]; ?>
                    <div class="flex justify-center gap-3 py-2">
                        <?php foreach ($emojiList as $ei => $em): ?>
                        <label class="emoji-option cursor-pointer text-center transition-all hover:scale-125 peer-checked:scale-125">
                            <input type="radio" name="q_<?= $q["id"] ??
                                "" ?>" value="<?= $ei ?>" class="hidden peer" <?= !empty(
    $q["is_required"]
)
    ? "required"
    : "" ?>>
                            <span class="text-3xl block transition-transform peer-checked:scale-125 peer-checked:drop-shadow-lg"><?= $em ?></span>
                            <span class="text-[10px] <?= $textMuted ?> mt-1 block opacity-0 peer-checked:opacity-100 transition-opacity"><?= $ei +
     1 ?></span>
                        </label>
                        <?php endforeach; ?>
                    </div>

                <?php
                elseif (($q["type"] ?? "") === "constant_sum"):

                    $csOpts = $q["options"] ?? [];
                    $csTotal = (int) ($q["max_value"] ?? 100);
                    ?>
                    <div class="constant-sum space-y-3 py-2" data-total="<?= $csTotal ?>" data-qid="<?= $q[
    "id"
] ?? "" ?>">
                        <div class="flex justify-between text-xs <?= $textMuted ?> mb-1"><span>Allocate <?= $csTotal ?> points</span><span>Remaining: <strong class="cs-remaining font-bold" style="color:<?= $tc[
     "hex"
 ] ?>"><?= $csTotal ?></strong></span></div>
                        <?php foreach ($csOpts as $ci => $co): ?>
                        <div class="flex items-center gap-3">
                            <span class="text-sm <?= $textColor ?> flex-1"><?= htmlspecialchars(
     $co,
 ) ?></span>
                            <input type="number" name="q_<?= $q["id"] ??
                                "" ?>[<?= $ci ?>]" min="0" max="<?= $csTotal ?>" value="0" class="cs-input w-20 px-3 py-2 rounded-xl text-center text-sm font-bold border transition-all" style="border-color:rgba(<?= $tc[
    "hex"
] ?>,0.2);color:<?= $tc["hex"] ?>" data-label="<?= htmlspecialchars($co) ?>">
                        </div>
                        <?php endforeach; ?>
                    </div>

                <?php
                elseif (($q["type"] ?? "") === "heatmap"):

                    $hmRows = $q["rows"] ?? [];
                    $hmCols = $q["options"] ?? [];
                    ?>
                    <div class="overflow-x-auto py-2">
                        <table class="w-full text-xs">
                            <thead><tr><th class="p-2 <?= $textMuted ?> font-medium text-left"></th><?php foreach (
     $hmCols
     as $hc
 ): ?><th class="p-2 text-center <?= $textMuted ?> font-medium"><?= htmlspecialchars(
     $hc,
 ) ?></th><?php endforeach; ?></tr></thead>
                            <tbody><?php foreach (
                                $hmRows
                                as $hr => $hmRow
                            ): ?><tr><td class="p-2 <?= $textColor ?> font-medium whitespace-nowrap"><?= htmlspecialchars(
     $hmRow,
 ) ?></td><?php foreach (
    $hmCols
    as $hc => $hmCol
): ?><td class="p-1"><label class="heatmap-cell block aspect-square rounded-lg cursor-pointer transition-all hover:scale-110" style="background:rgba(<?= $tc[
    "rgb"
] ?>,0.08)" onmouseenter="this.style.background='rgba(<?= $tc[
    "rgb"
] ?>,0.3)'" onmouseleave="if(!this.querySelector('input').checked)this.style.background='rgba(<?= $tc[
    "rgb"
] ?>,0.08)'"><input type="radio" name="q_<?= $q["id"] ??
    "" ?>_<?= $hr ?>" value="<?= htmlspecialchars(
    $hmCol,
) ?>" class="hidden peer"><span class="flex items-center justify-center w-full h-full peer-checked:opacity-100 opacity-0 transition-opacity" style="background:<?= $tc[
    "hex"
] ?>;border-radius:inherit"><i class="fas fa-check text-white text-[8px]"></i></span></label></td><?php endforeach; ?></tr><?php endforeach; ?></tbody>
                        </table>
                    </div>

                <?php
                elseif (($q["type"] ?? "") === "click_map"):

                    $cmImage = $q["image_url"] ?? "";
                    $cmAreas = $q["options"] ?? [];
                    ?>
                    <div class="click-map-container relative inline-block w-full py-2">
                        <?php if ($cmImage): ?>
                        <div class="relative mx-auto" style="max-width:500px">
                            <img src="<?= htmlspecialchars(
                                $cmImage,
                            ) ?>" alt="Click map" class="w-full rounded-xl" usemap="#clickmap_<?= $q[
    "id"
] ?? "" ?>" style="pointer-events:none" loading="lazy">
                            <?php foreach ($cmAreas as $ci => $ca):
                                $caCoords = $ca["coords"] ?? "0,0,0,0"; ?>
                            <input type="radio" name="q_<?= $q["id"] ??
                                "" ?>" value="<?= htmlspecialchars(
    $ca["label"] ?? $caCoords,
) ?>" id="cm_<?= $q["id"] ?? "" ?>_<?= $ci ?>" class="hidden peer">
                            <label for="cm_<?= $q["id"] ??
                                "" ?>_<?= $ci ?>" class="click-area absolute cursor-pointer rounded-full border-2 border-transparent hover:border-<?= $themeColor ?>-400 hover:bg-<?= $themeColor ?>-200/30 transition-all peer-checked:border-<?= $themeColor ?>-500 peer-checked:bg-<?= $themeColor ?>-300/40" style="left:<?= explode(
    ",",
    $caCoords,
)[0] ?? 0 ?>px;top:<?= explode(",", $caCoords)[1] ?? 0 ?>px;width:<?= explode(
    ",",
    $caCoords,
)[2] ?? 20 ?>px;height:<?= explode(",", $caCoords)[3] ??
    20 ?>px" title="<?= htmlspecialchars($ca["label"] ?? "") ?>"></label>
                            <?php
                            endforeach; ?>
                            <input type="hidden" name="q_<?= $q["id"] ??
                                "" ?>" id="cm_hidden_<?= $q["id"] ??
    "" ?>" value="">
                        </div>
                        <?php else: ?>
                        <p class="text-sm <?= $textMuted ?>">No click map image configured.</p>
                        <?php endif; ?>
                    </div>

                <?php
                elseif (($q["type"] ?? "") === "audio_response"): ?>
                    <div class="audio-recorder py-2">
                        <div class="flex items-center gap-4 p-4 rounded-xl border" style="border-color:rgba(<?= $tc[
                            "hex"
                        ] ?>,0.15)">
                            <button type="button" onclick="toggleAudioRecording(this, '<?= $q[
                                "id"
                            ] ??
                                "" ?>')" class="rec-btn w-12 h-12 rounded-full flex items-center justify-center text-white transition-all active:scale-90" style="background:<?= $tc[
    "hex"
] ?>"><i class="fas fa-microphone"></i></button>
                            <div class="flex-1">
                                <div class="h-2 rounded-full bg-gray-200 overflow-hidden"><div class="h-full rounded-full audio-level transition-all" style="width:0%;background:<?= $tc[
                                    "hex"
                                ] ?>"></div></div>
                                <p class="text-xs <?= $textMuted ?> mt-1 audio-status">Click to start recording</p>
                            </div>
                            <audio class="audio-preview hidden" controls></audio>
                            <input type="hidden" name="q_<?= $q["id"] ??
                                "" ?>" class="audio-data" value="">
                        </div>
                    </div>

                <?php elseif (($q["type"] ?? "") === "video_response"): ?>
                    <div class="video-recorder py-2">
                        <div class="flex items-center gap-4 p-4 rounded-xl border" style="border-color:rgba(<?= $tc[
                            "hex"
                        ] ?>,0.15)">
                            <button type="button" onclick="toggleVideoRecording(this, '<?= $q[
                                "id"
                            ] ??
                                "" ?>')" class="rec-btn w-12 h-12 rounded-full flex items-center justify-center text-white transition-all active:scale-90" style="background:<?= $tc[
    "hex"
] ?>"><i class="fas fa-video"></i></button>
                            <div class="flex-1">
                                <p class="text-sm <?= $textColor ?> video-status">Click to start recording</p>
                                <p class="text-xs <?= $textMuted ?> mt-0.5">Camera access required</p>
                            </div>
                            <video class="video-preview hidden w-24 h-18 rounded-lg object-cover" muted playsinline></video>
                            <input type="hidden" name="q_<?= $q["id"] ??
                                "" ?>" class="video-data" value="">
                        </div>
                    </div>

                <?php elseif (($q["type"] ?? "") === "drawing"):
                    $dwColor = $q["accent_color"] ?? $tc["hex"]; ?>
                    <div class="drawing-pad-wrapper border-2 border-dashed rounded-xl p-1 transition-all" style="border-color:rgba(<?= $tc[
                        "hex"
                    ] ?>,0.2)">
                        <canvas class="drawing-pad w-full h-48 rounded-lg cursor-crosshair" data-qid="<?= $q[
                            "id"
                        ] ?? "" ?>" style="touch-action:none"></canvas>
                        <input type="hidden" name="q_<?= $q["id"] ??
                            "" ?>" class="drawing-input">
                        <div class="flex justify-between items-center mt-2 px-1">
                            <div class="flex items-center gap-2">
                                <button type="button" onclick="clearDrawing(this.closest('.drawing-pad-wrapper').querySelector('canvas'))" class="text-xs px-2 py-1 rounded-lg bg-gray-100 text-gray-600 hover:bg-gray-200 transition-colors"><i class="fas fa-eraser mr-1"></i>Clear</button>
                                <input type="color" class="drawing-color w-6 h-6 rounded cursor-pointer border-0 p-0" value="<?= $dwColor ?>" onchange="setDrawingColor(this.closest('.drawing-pad-wrapper').querySelector('canvas'), this.value)">
                            </div>
                            <span class="text-[10px] <?= $textMuted ?>">Draw your response</span>
                        </div>
                    </div>

                <?php
                elseif (($q["type"] ?? "") === "card_sort"):

                    $csGroups = $q["rows"] ?? ["Group A", "Group B"];
                    $csCards = $q["options"] ?? [];
                    ?>
                    <div class="card-sort-container py-2" data-qid="<?= $q[
                        "id"
                    ] ?? "" ?>">
                        <div class="flex flex-wrap gap-2 mb-4 min-h-[60px] p-3 rounded-xl border-2 border-dashed" style="border-color:rgba(<?= $tc[
                            "hex"
                        ] ?>,0.15)" id="cs_unsorted_<?= $q["id"] ?? "" ?>">
                            <?php
                            shuffle($csCards);
                            foreach ($csCards as $csCard): ?>
                            <span class="cs-card px-3 py-1.5 rounded-lg text-xs font-medium cursor-grab active:cursor-grabbing select-none border transition-all" style="background:<?= $tc[
                                "hex"
                            ] ?>10;border-color:<?= $tc[
    "hex"
] ?>30;color:<?= $tc[
    "hex"
] ?>" draggable="true" data-value="<?= htmlspecialchars(
    $csCard,
) ?>"><?= htmlspecialchars($csCard) ?></span>
                            <?php endforeach;
                            ?>
                        </div>
                        <div class="grid grid-cols-2 gap-3">
                            <?php foreach ($csGroups as $cg => $csGroup): ?>
                            <div class="cs-group rounded-xl p-3 min-h-[80px] border-2 transition-all" style="border-color:rgba(<?= $tc[
                                "hex"
                            ] ?>,0.15)" data-group="<?= $cg ?>">
                                <p class="text-xs font-semibold <?= $textColor ?> mb-2"><?= htmlspecialchars(
     $csGroup,
 ) ?></p>
                                <div class="cs-dropzone flex flex-wrap gap-1.5 min-h-[40px]"></div>
                                <input type="hidden" name="q_<?= $q["id"] ??
                                    "" ?>[<?= $cg ?>][]" class="cs-group-input" value="">
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                <?php
                elseif (($q["type"] ?? "") === "max_diff"):
                    $mdOpts = $q["options"] ?? []; ?>
                    <div class="max-diff-container space-y-4 py-2">
                        <p class="text-xs font-medium <?= $textMuted ?> mb-2">Select <strong class="<?= $tc[
     "text"
 ] ?>">Most</strong> and <strong class="<?= $tc[
    "text"
] ?>">Least</strong> applicable:</p>
                        <?php foreach ($mdOpts as $mi => $md): ?>
                        <div class="flex items-center gap-3 p-3 rounded-xl border transition-all" style="border-color:rgba(<?= $tc[
                            "hex"
                        ] ?>,0.12)">
                            <span class="flex-1 text-sm <?= $textColor ?>"><?= htmlspecialchars(
    $md,
) ?></span>
                            <label class="flex items-center gap-1.5 cursor-pointer"><input type="radio" name="q_md_most_<?= $q[
                                "id"
                            ] ??
                                "" ?>" value="<?= $mi ?>" class="peer hidden"><span class="text-xs px-2 py-1 rounded-lg border transition-all peer-checked:bg-green-100 peer-checked:text-green-700 peer-checked:border-green-300 <?= $textMuted ?> border-gray-200">Most</span></label>
                            <label class="flex items-center gap-1.5 cursor-pointer"><input type="radio" name="q_md_least_<?= $q[
                                "id"
                            ] ??
                                "" ?>" value="<?= $mi ?>" class="peer hidden"><span class="text-xs px-2 py-1 rounded-lg border transition-all peer-checked:bg-red-100 peer-checked:text-red-700 peer-checked:border-red-300 <?= $textMuted ?> border-gray-200">Least</span></label>
                        </div>
                        <?php endforeach; ?>
                    </div>

                <?php
                elseif (($q["type"] ?? "") === "conjoint"):

                    $cjProfiles = $q["options"] ?? [];
                    $cjAttrs = $q["rows"] ?? [];
                    ?>
                    <div class="conjoint-container py-2">
                        <?php foreach ($cjProfiles as $pj => $cjProfile):
                            if (!is_array($cjProfile)) {
                                $cjProfile = ["title" => $cjProfile];
                            } ?>
                        <div class="conjoint-profile p-4 rounded-xl border mb-3 transition-all hover:shadow-md cursor-pointer" style="border-color:rgba(<?= $tc[
                            "hex"
                        ] ?>,0.15)" onclick="document.getElementById('cj_<?= $q[
    "id"
] ??
    "" ?>_<?= $pj ?>').checked=true;this.closest('.conjoint-container').querySelectorAll('.conjoint-profile').forEach(function(p){p.style.borderColor='rgba(<?= $tc[
    "hex"
] ?>,0.15)'});this.style.borderColor='<?= $tc["hex"] ?>'">
                            <input type="radio" name="q_<?= $q["id"] ??
                                "" ?>" value="<?= $pj ?>" id="cj_<?= $q["id"] ??
    "" ?>_<?= $pj ?>" class="hidden" <?= !empty($q["is_required"])
    ? "required"
    : "" ?>>
                            <p class="text-sm font-semibold <?= $textColor ?> mb-2"><?= htmlspecialchars(
     $cjProfile["title"] ?? "Profile " . ($pj + 1),
 ) ?></p>
                            <ul class="space-y-1">
                                <?php foreach ($cjAttrs as $aj => $cjAttr):
                                    if (isset($cjProfile[$aj])): ?>
                                <li class="flex justify-between text-xs"><span class="<?= $textMuted ?>"><?= htmlspecialchars(
    $cjAttr,
) ?>:</span><span class="<?= $textColor ?> font-medium"><?= htmlspecialchars(
     $cjProfile[$aj],
 ) ?></span></li>
                                <?php endif;
                                endforeach; ?>
                            </ul>
                        </div>
                        <?php
                        endforeach; ?>
                    </div>

                <?php
                elseif (($q["type"] ?? "") === "image_hotspot"):

                    $hsImage = $q["image_url"] ?? "";
                    $hsRegions = $q["options"] ?? [];
                    ?>
                    <div class="image-hotspot-container relative inline-block w-full py-2">
                        <?php if ($hsImage): ?>
                        <div class="relative mx-auto" style="max-width:500px">
                            <img src="<?= htmlspecialchars(
                                $hsImage,
                            ) ?>" alt="Hotspot image" class="w-full rounded-xl select-none" style="pointer-events:none" usemap="#hotspot_<?= $q[
    "id"
] ?? "" ?>" loading="lazy">
                            <?php foreach ($hsRegions as $hi => $hs):

                                $hsCoords = $hs["coords"] ?? "0,0,20,20";
                                $hsShape = $hs["shape"] ?? "circle";
                                $hsLabel = $hs["label"] ?? "";
                                $hsColor = $hs["color"] ?? $tc["hex"];
                                ?>
                            <input type="radio" name="q_<?= $q["id"] ??
                                "" ?>" value="<?= htmlspecialchars(
    $hsLabel,
) ?>" id="hs_<?= $q["id"] ?? "" ?>_<?= $hi ?>" class="hidden peer">
                            <label for="hs_<?= $q["id"] ??
                                "" ?>_<?= $hi ?>" class="hotspot-area absolute cursor-pointer rounded-full transition-all hover:scale-125 peer-checked:scale-125 peer-checked:ring-2 peer-checked:ring-offset-2" style="left:<?= explode(
    ",",
    $hsCoords,
)[0] ?? 0 ?>px;top:<?= explode(",", $hsCoords)[1] ??
    0 ?>px;width:<?= $hsShape === "circle"
    ? explode(",", $hsCoords)[2] ?? 16
    : explode(",", $hsCoords)[2] ?? 16 ?>px;height:<?= $hsShape === "circle"
    ? explode(",", $hsCoords)[2] ?? 16
    : explode(",", $hsCoords)[3] ??
        16 ?>px;background:<?= $hsColor ?>40;border:2px solid <?= $hsColor ?>" title="<?= htmlspecialchars(
    $hsLabel,
) ?>"><span class="absolute -top-6 left-1/2 -translate-x-1/2 text-[9px] font-medium whitespace-nowrap px-1.5 py-0.5 rounded" style="background:<?= $hsColor ?>;color:white"><?= htmlspecialchars(
    $hsLabel,
) ?></span></label>
                            <?php
                            endforeach; ?>
                        </div>
                        <?php else: ?>
                        <p class="text-sm <?= $textMuted ?>">No hotspot image configured.</p>
                        <?php endif; ?>
                    </div>

                <?php
                elseif (($q["type"] ?? "") === "location_picker"): ?>
                    <div class="location-picker py-2">
                        <div class="flex items-center gap-2 mb-2">
                            <i class="fas fa-search text-gray-400"></i>
                            <input type="text" name="q_<?= $q["id"] ??
                                "" ?>" class="location-input flex-1 px-4 py-2.5 rounded-xl <?= $inputBg ?> border <?= $tc[
     "focus"
 ] ?> transition-all text-sm" placeholder="Search for a location..." autocomplete="off">
                        </div>
                        <div class="location-suggestions hidden mt-1 rounded-xl border overflow-hidden" style="border-color:rgba(<?= $tc[
                            "hex"
                        ] ?>,0.15)"></div>
                        <p class="text-[10px] <?= $textMuted ?> mt-1"><i class="fas fa-info-circle mr-1"></i>Type to search, then select a location</p>
                    </div>

                <?php elseif (($q["type"] ?? "") === "date_range"): ?>
                    <div class="flex items-center gap-3 py-2">
                        <div class="flex-1">
                            <label class="text-[10px] <?= $textMuted ?> mb-1 block">From</label>
                            <input type="date" name="q_<?= $q["id"] ??
                                "" ?>_from" class="w-full px-4 py-2.5 rounded-xl <?= $inputBg ?> border <?= $tc[
     "focus"
 ] ?> transition-all text-sm <?= $isDark
     ? "text-white [color-scheme:dark]"
     : "" ?>" <?= !empty($q["is_required"]) ? "required" : "" ?>>
                        </div>
                        <span class="text-gray-400 mt-5">→</span>
                        <div class="flex-1">
                            <label class="text-[10px] <?= $textMuted ?> mb-1 block">To</label>
                            <input type="date" name="q_<?= $q["id"] ??
                                "" ?>_to" class="w-full px-4 py-2.5 rounded-xl <?= $inputBg ?> border <?= $tc[
     "focus"
 ] ?> transition-all text-sm <?= $isDark
     ? "text-white [color-scheme:dark]"
     : "" ?>" <?= !empty($q["is_required"]) ? "required" : "" ?>>
                        </div>
                    </div>

                <?php elseif (($q["type"] ?? "") === "duration"): ?>
                    <div class="flex items-center gap-3 py-2">
                        <div class="flex-1">
                            <label class="text-[10px] <?= $textMuted ?> mb-1 block">Hours</label>
                            <input type="number" name="q_<?= $q["id"] ??
                                "" ?>_hours" min="0" max="99" value="0" class="w-full px-4 py-2.5 rounded-xl <?= $inputBg ?> border <?= $tc[
     "focus"
 ] ?> transition-all text-sm text-center" <?= !empty($q["is_required"])
     ? "required"
     : "" ?>>
                        </div>
                        <span class="text-gray-400 mt-5 font-medium">:</span>
                        <div class="flex-1">
                            <label class="text-[10px] <?= $textMuted ?> mb-1 block">Minutes</label>
                            <input type="number" name="q_<?= $q["id"] ??
                                "" ?>_minutes" min="0" max="59" value="0" class="w-full px-4 py-2.5 rounded-xl <?= $inputBg ?> border <?= $tc[
     "focus"
 ] ?> transition-all text-sm text-center" <?= !empty($q["is_required"])
     ? "required"
     : "" ?>>
                        </div>
                    </div>

                <?php elseif (($q["type"] ?? "") === "phone_intl"):
                    $piDefault = $q["placeholder"] ?? "+1"; ?>
                    <div class="flex items-center gap-2 py-2">
                        <select name="q_<?= $q["id"] ??
                            "" ?>_code" class="w-24 px-3 py-3 rounded-xl <?= $inputBg ?> border <?= $tc[
     "focus"
 ] ?> transition-all text-sm appearance-none cursor-pointer">
                            <option value="+1">US +1</option>
                            <option value="+44">UK +44</option>
                            <option value="+91">IN +91</option>
                            <option value="+61">AU +61</option>
                            <option value="+86">CN +86</option>
                            <option value="+49">DE +49</option>
                            <option value="+33">FR +33</option>
                            <option value="+81">JP +81</option>
                            <option value="+55">BR +55</option>
                            <option value="+7">RU +7</option>
                        </select>
                        <input type="tel" name="q_<?= $q["id"] ??
                            "" ?>_number" class="flex-1 px-4 py-3 rounded-xl <?= $inputBg ?> border <?= $tc[
     "focus"
 ] ?> transition-all text-sm" placeholder="<?= htmlspecialchars(
     $piDefault,
 ) ?>" <?= !empty($q["is_required"]) ? "required" : "" ?>>
                    </div>

                <?php
                elseif (($q["type"] ?? "") === "currency"):
                    $curSymbol = $q["placeholder"] ?? '$'; ?>
                    <div class="flex items-center gap-2 py-2">
                        <span class="text-lg font-bold" style="color:<?= $tc[
                            "hex"
                        ] ?>"><?= htmlspecialchars($curSymbol) ?></span>
                        <input type="number" name="q_<?= $q["id"] ??
                            "" ?>" min="0" step="0.01" value="" class="flex-1 px-4 py-3 rounded-xl <?= $inputBg ?> border <?= $tc[
     "focus"
 ] ?> transition-all text-sm" placeholder="0.00" <?= !empty($q["is_required"])
     ? "required"
     : "" ?>>
                        <span class="text-xs <?= $textMuted ?>"><?= htmlspecialchars(
    $curSymbol,
) ?>USD</span>
                    </div>

                <?php
                elseif (($q["type"] ?? "") === "rich_text"): ?>
                    <div class="rich-text-editor py-2">
                        <div class="flex items-center gap-1 px-3 py-2 border-b rounded-t-xl flex-wrap" style="border-color:rgba(<?= $tc[
                            "hex"
                        ] ?>,0.15);background:rgba(<?= $tc["hex"] ?>,0.03)">
                            <button type="button" onclick="document.execCommand('bold')" class="w-7 h-7 flex items-center justify-center rounded hover:bg-gray-200 text-xs font-bold transition-colors" title="Bold"><b>B</b></button>
                            <button type="button" onclick="document.execCommand('italic')" class="w-7 h-7 flex items-center justify-center rounded hover:bg-gray-200 text-xs italic transition-colors" title="Italic"><i>I</i></button>
                            <button type="button" onclick="document.execCommand('underline')" class="w-7 h-7 flex items-center justify-center rounded hover:bg-gray-200 text-xs underline transition-colors" title="Underline"><u>U</u></button>
                            <span class="w-px h-5 bg-gray-300 mx-1"></span>
                            <button type="button" onclick="document.execCommand('insertUnorderedList')" class="w-7 h-7 flex items-center justify-center rounded hover:bg-gray-200 text-xs transition-colors" title="Bullet list"><i class="fas fa-list-ul text-[10px]"></i></button>
                            <button type="button" onclick="document.execCommand('insertOrderedList')" class="w-7 h-7 flex items-center justify-center rounded hover:bg-gray-200 text-xs transition-colors" title="Numbered list"><i class="fas fa-list-ol text-[10px]"></i></button>
                        </div>
                        <div contenteditable="true" name="q_<?= $q["id"] ??
                            "" ?>" class="rich-text-content w-full min-h-[120px] px-4 py-3 rounded-b-xl border border-t-0 text-sm transition-all focus:outline-none" style="border-color:rgba(<?= $tc[
    "hex"
] ?>,0.15);background:<?= $isDark
    ? "rgba(255,255,255,0.05)"
    : "white" ?>;color:<?= $isDark ? "white" : "#1f2937" ?>" <?= !empty(
    $q["is_required"]
)
    ? 'data-required="1"'
    : "" ?>></div>
                        <input type="hidden" name="q_<?= $q["id"] ??
                            "" ?>" class="rich-text-input">
                    </div>

                <?php elseif (($q["type"] ?? "") === "code_editor"):
                    $ceLang = $q["placeholder"] ?? "javascript"; ?>
                    <div class="code-editor py-2">
                        <div class="flex items-center justify-between px-3 py-1.5 rounded-t-xl text-[10px] font-mono" style="background:#1e293b;color:#94a3b8">
                            <span><i class="fas fa-code mr-1"></i><?= htmlspecialchars(
                                $ceLang,
                            ) ?></span>
                            <span class="opacity-50">Tab → 2 spaces</span>
                        </div>
                        <textarea name="q_<?= $q["id"] ??
                            "" ?>" class="code-textarea w-full min-h-[120px] px-4 py-3 rounded-b-xl border border-t-0 text-sm font-mono leading-relaxed transition-all focus:outline-none resize-y" style="background:#0f172a;color:#e2e8f0;border-color:#334155;caret-color:#facc15" placeholder="// Write your code here..." spellcheck="false" <?= !empty(
    $q["is_required"]
)
    ? "required"
    : "" ?>></textarea>
                    </div>

                <?php
                elseif (($q["type"] ?? "") === "formula"):
                    $fmExpr = $q["question_text"] ?? ""; ?>
                    <div class="formula-display py-2">
                        <div class="p-4 rounded-xl text-center" style="background:rgba(<?= $tc[
                            "rgb"
                        ] ?>,0.06);border:1px solid rgba(<?= $tc[
    "rgb"
] ?>,0.15)">
                            <span class="text-2xl font-mono font-bold" style="color:<?= $tc[
                                "hex"
                            ] ?>"><?= htmlspecialchars($fmExpr) ?></span>
                            <p class="text-[10px] <?= $textMuted ?> mt-1">Auto-calculated</p>
                        </div>
                        <input type="hidden" name="q_<?= $q["id"] ??
                            "" ?>" value="">
                    </div>

                <?php
                else:
                     ?>
                    <input type="text" name="q_<?= $q["id"] ??
                        "" ?>" class="answer-input w-full px-4 py-2.5 rounded-xl border transition-all text-sm focus:outline-none focus:ring-2 bg-white/70 backdrop-blur-xl" style="border-color:rgba(<?= $tc[
    "hex"
] ?>,0.2);--tw-ring-color:<?= $tc[
    "hex"
] ?>e0" placeholder="Type your answer..." autocomplete="off" <?= !empty($isDark)
    ? "data-dark"
    : "" ?>>
                <?php
                endif; ?>

                <!-- Paste detection -->
                <input type="hidden" name="_pasted_<?= $q["id"] ??
                    "" ?>" id="pasted_<?= $q["id"] ?? "" ?>" value="0">

                <!-- Frozen overlay -->
                <div class="frozen-overlay hidden absolute inset-0 <?= $isDark
                    ? "bg-gray-900/80"
                    : "bg-white/80" ?> backdrop-blur-sm rounded-xl flex items-center justify-center z-10" data-qid="<?= $q[
     "id"
 ] ?? "" ?>">
                    <div class="text-center">
                        <div class="w-12 h-12 <?= $isDark
                            ? "bg-gray-700"
                            : "bg-gray-100" ?> rounded-full flex items-center justify-center mx-auto mb-2">
                            <i class="fas fa-lock text-xl text-gray-400"></i>
                        </div>
                        <p class="text-sm font-medium <?= $isDark
                            ? "text-gray-300"
                            : "text-gray-500" ?>">Complete the timed question first</p>
                    </div>
                </div>
            </div>
            <?php
            endforeach; ?>
        </div>

        <!-- Hidden tracking fields -->
        <input type="hidden" name="_timed_question_ids" id="timed-question-ids" value="">
        <input type="hidden" name="_timed_times[_timed_placeholder]" id="timed-times-placeholder" value="0">
        <input type="hidden" name="_inactive_seconds" id="inactive-seconds" value="0">

        <!-- Honeypot -->
        <?php if (!empty($qualityConfig["honeypot"])): ?>
        <div style="position:absolute;left:-9999px" aria-hidden="true">
            <label for="honeypot">Leave this empty</label>
            <input type="text" name="honeypot" id="honeypot" tabindex="-1" autocomplete="off">
        </div>
        <?php endif; ?>

        <!-- CAPTCHA -->
        <?php if (!empty($qualityConfig["captcha"])): ?>
        <?php
        $a = rand(1, 20);
        $b = rand(1, 20);
        $captchaAnswer = $a + $b;
        ?>
        <div class="<?= $cardBg ?> rounded-xl p-4 mt-4 border animate-scale-in">
            <div class="flex items-center gap-3 flex-wrap">
                <div class="w-10 h-10 bg-gradient-to-br <?= $tc[
                    "gradient"
                ] ?> rounded-xl flex items-center justify-center text-white shadow-sm">
                    <i class="fas fa-shield-alt text-sm"></i>
                </div>
                <span class="font-medium <?= $textColor ?> text-sm">What is <strong class="<?= $tc[
     "text"
 ] ?>"><?= $a ?> + <?= $b ?></strong>?</span>
                <input type="number" name="captcha_answer" required
                    class="w-24 px-3 py-2 rounded-xl <?= $inputBg ?> border <?= $tc[
     "focus"
 ] ?> text-center text-sm transition-all"
                    placeholder="?">
                <input type="hidden" name="captcha_expected" value="<?= $captchaAnswer ?>">
                <span class="text-xs <?= $textMuted ?> flex items-center gap-1"><i class="fas fa-robot"></i> Anti-bot verification</span>
            </div>
        </div>
        <?php endif; ?>

        <input type="hidden" name="device_fingerprint" id="device-fingerprint" value="">

        <!-- Power-ups (quiz mode) -->
        <?php if ($isQuiz): ?>
        <div class="flex items-center justify-center gap-2 mt-6 flex-wrap animate-slide-up-fade" id="powerups-bar">
            <button type="button" class="powerup-btn px-3 py-2 rounded-xl text-xs font-medium border-2 transition-all duration-300 flex items-center gap-1.5 hover:scale-105 active:scale-95" data-powerup="fifty" data-uses="2" onclick="usePowerup('fifty', this)" style="border-color:<?= $tc[
                "hex"
            ] ?>40;color:<?= $tc["hex"] ?>;background:<?= $tc["hex"] ?>08">
                <i class="fas fa-half"></i> 50/50 <span class="uses text-[9px] opacity-60">(2)</span>
            </button>
            <button type="button" class="powerup-btn px-3 py-2 rounded-xl text-xs font-medium border-2 transition-all duration-300 flex items-center gap-1.5 hover:scale-105 active:scale-95" data-powerup="skip" data-uses="3" onclick="usePowerup('skip', this)" style="border-color:<?= $tc[
                "hex"
            ] ?>40;color:<?= $tc["hex"] ?>;background:<?= $tc["hex"] ?>08">
                <i class="fas fa-forward"></i> Skip <span class="uses text-[9px] opacity-60">(3)</span>
            </button>
            <button type="button" class="powerup-btn px-3 py-2 rounded-xl text-xs font-medium border-2 transition-all duration-300 flex items-center gap-1.5 hover:scale-105 active:scale-95" data-powerup="double" data-uses="2" onclick="usePowerup('double', this)" style="border-color:<?= $tc[
                "hex"
            ] ?>40;color:<?= $tc["hex"] ?>;background:<?= $tc["hex"] ?>08">
                <i class="fas fa-bolt"></i> 2x Score <span class="uses text-[9px] opacity-60">(2)</span>
            </button>
            <button type="button" class="powerup-btn px-3 py-2 rounded-xl text-xs font-medium border-2 transition-all duration-300 flex items-center gap-1.5 hover:scale-105 active:scale-95" data-powerup="freeze" data-uses="1" onclick="usePowerup('freeze', this)" style="border-color:<?= $tc[
                "hex"
            ] ?>40;color:<?= $tc["hex"] ?>;background:<?= $tc["hex"] ?>08">
                <i class="fas fa-snowflake"></i> Freeze Time <span class="uses text-[9px] opacity-60">(1)</span>
            </button>
        </div>
        <?php endif; ?>

        <!-- Submit -->
        <div class="mt-6 text-center pb-8" id="survey-footer">
            <button type="submit" id="submit-btn"
                class="bg-gradient-to-r <?= $tc[
                    "btn"
                ] ?> text-white px-12 py-3.5 rounded-xl hover:<?= $tc[
     "btnHover"
 ] ?> transition-all text-base font-medium shadow-lg <?= $tc[
     "shadow"
 ] ?> hover:shadow-xl hover:shadow-<?= $themeColor ?>-300 active:scale-[0.98]">
                <i class="fas fa-paper-plane mr-2"></i><?= $isQuiz
                    ? "Submit Quiz"
                    : "Submit Responses" ?>
            </button>
            <p class="text-xs <?= $isDark
                ? "text-gray-400"
                : "text-gray-400" ?> mt-2 flex items-center justify-center gap-1">
                <i class="fas fa-keyboard"></i> Press <kbd class="px-1.5 py-0.5 bg-gray-100 border border-gray-300 rounded text-[10px] font-mono <?= $isDark
                    ? "bg-gray-700 text-gray-200 border-gray-600"
                    : "" ?>">Ctrl+Enter</kbd> to submit
            </p>
        </div>
    </form>
</div>

<!-- Inactivity warning modal -->
<div id="inactivity-modal" class="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 hidden flex items-center justify-center animate-fade-in">
    <div class="<?= $cardBg ?> rounded-2xl shadow-2xl p-8 max-w-sm mx-4 text-center animate-scale-in">
        <div class="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <i class="fas fa-clock text-2xl text-amber-600"></i>
        </div>
        <h3 class="text-lg font-bold <?= $textColor ?> mb-2">Are you still there?</h3>
        <p class="text-sm <?= $textMuted ?> mb-6" id="inactivity-msg">You've been inactive for a while.</p>
        <button onclick="resetInactivity()" class="bg-gradient-to-r <?= $tc[
            "btn"
        ] ?> text-white px-6 py-2.5 rounded-xl hover:<?= $tc[
     "btnHover"
 ] ?> transition-colors font-medium shadow-lg active:scale-[0.98]">
            <i class="fas fa-check mr-1.5"></i>Yes, I'm here!
        </button>
    </div>
</div>

<script src="<?= url("/public/assets/js/fingerprint.js") ?>"></script>
<script>
(function() {
    'use strict';

    // ========== CONFIG ==========
    const isSequential = <?= $isSequential ? "true" : "false" ?>;
    const isQuiz = <?= $isQuiz ? "true" : "false" ?>;
    const quizLives = <?= $quizLives ?>;
    const quizPassScore = <?= $quizPassScore ?>;
    const quizTimerPerQ = <?= $quizTimerPerQ ?>;
    const showAnswers = <?= $showAnswers ? "true" : "false" ?>;
    const isFullscreen = <?= !empty($qualityConfig["fullscreen_mode"])
        ? "true"
        : "false" ?>;
    const inactivityTimeout = <?= (int) ($qualityConfig["inactivity_timeout"] ??
        300) ?> * 1000;
    const inactivityWarn = <?= (int) ($qualityConfig[
        "inactivity_warn_before"
    ] ?? 30) ?> * 1000;
    const disableRightClick = <?= !empty($qualityConfig["disable_rightclick"])
        ? "true"
        : "false" ?>;
    const allowResume = <?= !empty($resumeCode) ? "true" : "false" ?>;
    const resumeCode = '<?= $resumeCode ?? "" ?>';
    const surveyId = '<?= $survey["id"] ?? "" ?>';
    const preBackNav = <?= !empty($qualityConfig["prevent_back_nav"])
        ? "true"
        : "false" ?>;
    const timePerQ = <?= !empty($qualityConfig["time_per_question"])
        ? "true"
        : "false" ?>;
    const themeHex = '<?= $tc["hex"] ?>';
    const isDark = <?= $isDark ? "true" : "false" ?>;

    const questionCards = document.querySelectorAll('.question-card');
    const totalQs = questionCards.length;
    let currentSeqIndex = 0;
    let timedTimers = {};
    let startTime = Date.now();
    let lastActivity = Date.now();
    let tabSwitches = 0;
    let inactiveSeconds = 0;
    let inactivityInterval = null;
    let inactivityWarned = false;
    let quizScore = 0;
    let quizStreak = 0;
    let lives = quizLives;

    // ========== THEME APPLICATION ==========
    document.documentElement.style.setProperty('--theme-hex', themeHex);
    const app = document.getElementById('survey-app');
    if (app) {
        if (isDark) {
            app.classList.add('text-white');
        }
    }

    // ========== STATUS DOTS ==========
    function buildStatusDots() {
        const container = document.getElementById('status-dots');
        if (!container) return;
        questionCards.forEach(function(_, idx) {
            const dot = document.createElement('span');
            dot.className = 'status-dot w-2.5 h-2.5 rounded-full bg-gray-200 transition-all duration-300 inline-block';
            dot.dataset.index = idx;
            container.appendChild(dot);
        });
    }
    buildStatusDots();

    function updateStatusDots(answeredIndices) {
        document.querySelectorAll('.status-dot').forEach(function(dot) {
            const idx = parseInt(dot.dataset.index);
            if (answeredIndices.includes(idx)) {
                dot.className = 'status-dot w-2.5 h-2.5 rounded-full transition-all duration-300 inline-block';
                dot.style.background = themeHex;
            } else if (idx === currentSeqIndex && isSequential) {
                dot.className = 'status-dot w-3 h-3 rounded-full transition-all duration-300 inline-block';
                dot.style.background = themeHex;
                dot.style.boxShadow = '0 0 0 3px ' + themeHex + '40';
            } else if (idx <= currentSeqIndex || !isSequential) {
                dot.className = 'status-dot w-2.5 h-2.5 rounded-full bg-gray-200 transition-all duration-300 inline-block';
            } else {
                dot.className = 'status-dot w-2.5 h-2.5 rounded-full bg-gray-100 transition-all duration-300 inline-block';
            }
        });
    }

    // ========== FINGERPRINT ==========
    if (typeof getDeviceFingerprint === 'function') {
        document.getElementById('device-fingerprint').value = getDeviceFingerprint().hash;
    }

    // ========== TIMER ==========
    let timerEl = document.getElementById('timer-value');
    let timerBox = document.getElementById('timer-box');
    setInterval(function() {
        let elapsed = Math.floor((Date.now() - startTime) / 1000);
        let mins = Math.floor(elapsed / 60);
        let secs = elapsed % 60;
        timerEl.textContent = mins + ':' + (secs < 10 ? '0' : '') + secs;
    }, 500);

    // ========== RIGHT-CLICK DISABLE ==========
    if (disableRightClick) {
        document.addEventListener('contextmenu', function(e) { e.preventDefault(); return false; });
    }

    // ========== PREVENT BACK NAV ==========
    if (preBackNav) {
        history.pushState(null, null, location.href);
        window.addEventListener('popstate', function(e) {
            history.pushState(null, null, location.href);
            showToast('Navigation back is disabled for this survey', 'warning');
        });
    }

    // ========== TAB SWITCH DETECTION ==========
    document.addEventListener('visibilitychange', function() {
        if (document.hidden) {
            tabSwitches++;
            document.getElementById('tab-switch-count').textContent = tabSwitches;
        }
    });

    // ========== INACTIVITY DETECTION ==========
    function resetInactivity() {
        lastActivity = Date.now();
        inactiveSeconds = 0;
        inactivityWarned = false;
        document.getElementById('inactivity-modal').classList.add('hidden');
        document.body.style.overflow = '';
    }
    document.addEventListener('mousemove', resetInactivity);
    document.addEventListener('keydown', resetInactivity);
    document.addEventListener('click', resetInactivity);
    document.addEventListener('scroll', resetInactivity);
    document.addEventListener('touchstart', resetInactivity);

    if (inactivityTimeout > 0) {
        inactivityInterval = setInterval(function() {
            let now = Date.now();
            let elapsed = now - lastActivity;
            let secs = Math.floor(elapsed / 1000);
            inactiveSeconds = secs;
            if (elapsed >= inactivityTimeout) {
                document.getElementById('inactive-seconds').value = secs;
            } else if (elapsed >= inactivityTimeout - inactivityWarn && !inactivityWarned) {
                inactivityWarned = true;
                let remaining = Math.ceil((inactivityTimeout - elapsed) / 1000);
                document.getElementById('inactivity-msg').textContent =
                    'You\'ve been inactive for ' + secs + ' seconds. Auto-submit in ' + remaining + 's.';
                document.getElementById('inactivity-modal').classList.remove('hidden');
                document.body.style.overflow = 'hidden';
            }
        }, 1000);
    }

    // ========== AUTO-SAVE ==========
    function autoSave() {
        if (!allowResume) return;
        const data = { answers: {}, timestamp: Date.now() };
        questionCards.forEach(function(card) {
            const qid = card.dataset.qid;
            const inputs = card.querySelectorAll('input, select, textarea');
            inputs.forEach(function(input) {
                if (input.type === 'hidden' || input.type === 'submit' || input.type === 'button') return;
                if (input.type === 'radio' || input.type === 'checkbox') {
                    if (input.checked) {
                        data.answers[input.name] = data.answers[input.name] || [];
                        data.answers[input.name].push(input.value);
                    }
                } else {
                    data.answers[input.name] = input.value;
                }
            });
        });
        try { localStorage.setItem('survey_draft_' + surveyId, JSON.stringify(data)); } catch(e) {}
    }
    if (allowResume) {
        setInterval(autoSave, 10000);
        document.querySelectorAll('.question-card input, .question-card select, .question-card textarea').forEach(function(el) {
            el.addEventListener('change', autoSave);
            el.addEventListener('input', autoSave);
        });
    }

    // ========== COPY-PASTE DETECTION ==========
    document.querySelectorAll('.question-card input[type="text"], .question-card input[type="email"], .question-card input[type="tel"]').forEach(function(input) {
        input.addEventListener('paste', function(e) {
            const qcard = this.closest('.question-card');
            if (qcard) {
                const pastedInput = document.getElementById('pasted_' + qcard.dataset.qid);
                if (pastedInput) pastedInput.value = '1';
            }
            // Show toast warning
            showToast('Pasting is not allowed', 'warning');
        });
    });

    // ========== STAR RATING ==========
    document.querySelectorAll('[id^="star-group"]').forEach(function(group) {
        group.addEventListener('click', function(e) {
            const label = e.target.closest('.star-label');
            if (!label) return;
            const clickedStar = parseInt(label.dataset.star);
            label.querySelector('input[type="radio"]').checked = true;
            // Fill all stars up to clicked one
            group.querySelectorAll('.star-label').forEach(function(sl, idx) {
                const starNum = parseInt(sl.dataset.star);
                const icon = sl.querySelector('i');
                if (starNum <= clickedStar) {
                    icon.className = 'fas fa-star transition-all duration-200';
                    icon.style.color = '#facc15';
                } else {
                    icon.className = 'far fa-star transition-all duration-200';
                    icon.style.color = isDark ? '#6b7280' : '#d1d5db';
                }
            });
            let evt = new Event('change', { bubbles: true });
            label.querySelector('input[type="radio"]').dispatchEvent(evt);
        });
    });

    // ========== CUSTOM RADIO / CHECKBOX VISUAL ==========
    document.querySelectorAll('.q-option input[type="radio"]').forEach(function(radio) {
        radio.addEventListener('change', function() {
            const parent = this.closest('.q-option');
            const dot = parent.querySelector('span span');
            if (this.checked) {
                dot.style.opacity = '1';
                parent.style.borderColor = themeHex;
                parent.style.background = themeHex + '15';
            }
            // Uncheck siblings
            const siblings = parent.parentElement.querySelectorAll('.q-option');
            siblings.forEach(function(s) {
                const sRadio = s.querySelector('input[type="radio"]');
                const sDot = s.querySelector('span span');
                if (sRadio !== radio && sRadio) {
                    sDot.style.opacity = '0';
                    s.style.borderColor = themeHex + '30';
                    s.style.background = 'transparent';
                }
            });
        });
    });
    document.querySelectorAll('.q-option input[type="checkbox"]').forEach(function(cb) {
        cb.addEventListener('change', function() {
            const parent = this.closest('.q-option');
            const check = parent.querySelector('span span');
            if (this.checked) {
                check.style.opacity = '1';
                parent.style.borderColor = themeHex;
                parent.style.background = themeHex + '15';
            } else {
                check.style.opacity = '0';
                parent.style.borderColor = themeHex + '30';
                parent.style.background = 'transparent';
            }
        });
    });

    // ========== MATRIX VISUAL ==========
    document.querySelectorAll('.matrix-cell input[type="radio"]').forEach(function(radio) {
        radio.addEventListener('change', function() {
            const cell = this.closest('.matrix-cell');
            const dot = cell.querySelector('span');
            cell.style.borderColor = themeHex;
            cell.style.background = themeHex + '20';
            dot.style.opacity = '1';
            // Reset siblings in same row
            const row = cell.closest('tr');
            if (row) {
                row.querySelectorAll('.matrix-cell').forEach(function(c) {
                    if (c !== cell) {
                        c.style.borderColor = themeHex + '30';
                        c.style.background = 'transparent';
                        c.querySelector('span').style.opacity = '0';
                    }
                });
            }
        });
    });

    // ========== INPUT VALIDATION ==========
    document.querySelectorAll('[data-validate]').forEach(function(input) {
        input.addEventListener('blur', function() {
            let val = this.value.trim();
            let card = this.closest('.question-card');
            if (!card) return;
            let msgEl = card.querySelector('.validation-message');
            if (!val) { msgEl.classList.add('hidden'); return; }
            let type = this.getAttribute('data-validate');
            let valid = true;
            let msg = '';
            if (type === 'email') {
                valid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val);
                msg = 'Please enter a valid email address';
            } else if (type === 'phone') {
                valid = /^[+\-\d\s()]{7,20}$/.test(val);
                msg = 'Please enter a valid phone number';
            }
            let minLen = this.getAttribute('data-minlen');
            if (minLen && val.length > 0 && val.length < parseInt(minLen)) {
                valid = false;
                msg = 'Minimum ' + minLen + ' characters required';
            }
            if (!valid) {
                msgEl.querySelector('span').textContent = msg;
                msgEl.classList.remove('hidden');
                card.classList.add('shake');
                setTimeout(function() { card.classList.remove('shake'); }, 500);
            } else {
                msgEl.classList.add('hidden');
            }
        });
    });

    // ========== SEQUENTIAL UNLOCK ==========
    function initSequential() {
        questionCards.forEach(function(card, idx) {
            if (idx === 0) {
                card.style.display = '';
            } else {
                card.style.display = 'none';
            }
        });
        revealNextSequential();
    }

    function revealNextSequential() {
        if (!isSequential) return;
        for (let i = 0; i <= currentSeqIndex && i < questionCards.length; i++) {
            questionCards[i].style.display = '';
            if (i === currentSeqIndex) {
                requestAnimationFrame(function() {
                    questionCards[i].scrollIntoView({ behavior: 'smooth', block: 'center' });
                });
            }
        }
    }

    // ========== TIMED QUESTIONS ==========
    function findActiveTimedQuestion() {
        for (let i = 0; i < questionCards.length; i++) {
            if (questionCards[i].getAttribute('data-timed') === '1' && questionCards[i].style.display !== 'none') {
                return questionCards[i];
            }
        }
        return null;
    }

    function freezeOthers(activeCard) {
        questionCards.forEach(function(card) {
            if (card === activeCard) return;
            let overlay = card.querySelector('.frozen-overlay');
            if (overlay) overlay.classList.remove('hidden');
            card.querySelectorAll('input, select, textarea, button').forEach(function(el) {
                el.disabled = true;
            });
        });
    }

    function unfreezeAll() {
        questionCards.forEach(function(card) {
            let overlay = card.querySelector('.frozen-overlay');
            if (overlay) overlay.classList.add('hidden');
            card.querySelectorAll('input, select, textarea, button').forEach(function(el) {
                el.disabled = false;
            });
        });
    }

    function startTimedCountdown(card) {
        let qid = card.getAttribute('data-qid');
        let limit = parseInt(card.getAttribute('data-timelimit')) || 0;
        if (limit <= 0) return;
        let countdownEl = document.querySelector('.timed-countdown[data-qid="' + qid + '"]');
        if (!countdownEl) return;
        let remaining = limit;
        let startTimeMs = Date.now();
        if (timedTimers[qid]) clearInterval(timedTimers[qid]);
        timedTimers[qid] = setInterval(function() {
            let elapsed = Math.floor((Date.now() - startTimeMs) / 1000);
            remaining = Math.max(0, limit - elapsed);
            countdownEl.textContent = remaining + 's';
            let badge = countdownEl.closest('.timed-badge');
            if (badge) {
                if (remaining <= 5) {
                    badge.className = 'timed-badge px-2 py-0.5 text-xs bg-red-50 text-red-700 border border-red-200 rounded-full animate-pulse';
                    badge.classList.add('timer-critical');
                } else if (remaining <= 10) {
                    badge.className = 'timed-badge px-2 py-0.5 text-xs bg-amber-50 text-amber-700 border border-amber-200 rounded-full';
                }
            }
            if (remaining <= 0) {
                clearInterval(timedTimers[qid]);
                countdownEl.textContent = '0s';
                let ovfInput = document.getElementById('_elapsed_' + qid);
                if (!ovfInput) {
                    ovfInput = document.createElement('input');
                    ovfInput.type = 'hidden';
                    ovfInput.name = '_elapsed_' + qid;
                    ovfInput.id = '_elapsed_' + qid;
                    document.getElementById('survey-form').appendChild(ovfInput);
                }
                ovfInput.value = limit + 1;
                unfreezeAll();
                if (isSequential) {
                    currentSeqIndex++;
                    revealNextSequential();
                }
                let nextTimed = findActiveTimedQuestion();
                if (nextTimed) {
                    freezeOthers(nextTimed);
                    startTimedCountdown(nextTimed);
                }
            }
        }, 500);
    }

    // ========== ANSWER DETECTION ==========
    function isCardAnswered(card) {
        var inputs = card.querySelectorAll('input, select, textarea');
        for (var i = 0; i < inputs.length; i++) {
            var input = inputs[i];
            if (input.type === 'hidden' || input.type === 'submit' || input.type === 'button') continue;
            if (input.type === 'radio' && input.checked) return true;
            if (input.type === 'checkbox' && input.checked) return true;
            if ((input.type === 'text' || input.type === 'email' || input.type === 'tel' || input.type === 'number' || input.type === 'date' || input.type === 'url' || input.type === 'time' || input.type === 'datetime-local') && input.value.trim()) return true;
            if (input.tagName === 'TEXTAREA' && input.value.trim()) return true;
            if (input.type === 'color') return true;
            if (input.tagName === 'SELECT' && input.value) return true;
            if (input.type === 'range') return true;
            if (input.type === 'file' && input.files && input.files.length > 0) return true;
        }
        // Also check custom option text inputs (they may be inside a flex container without a radio/checkbox checked yet)
        var customTexts = card.querySelectorAll('.custom-cb');
        for (var j = 0; j < customTexts.length; j++) {
            if (customTexts[j].checked) return true;
        }
        return false;
    }

    function getAnsweredIndices() {
        const indices = [];
        questionCards.forEach(function(card, idx) {
            if (isCardAnswered(card)) indices.push(idx);
        });
        return indices;
    }

    function onAnswerChange() {
        updateProgress();
        updateStatusDots(getAnsweredIndices());
        if (!isSequential) return;
        if (currentSeqIndex < questionCards.length - 1 && isCardAnswered(questionCards[currentSeqIndex])) {
            currentSeqIndex++;
            revealNextSequential();
            let revealed = questionCards[currentSeqIndex];
            if (revealed && revealed.getAttribute('data-timed') === '1' && revealed.style.display !== 'none') {
                freezeOthers(revealed);
                startTimedCountdown(revealed);
            }
        }
    }

    // ========== PROGRESS ==========
    function updateProgress() {
        let answered = 0;
        questionCards.forEach(function(card) {
            if (isCardAnswered(card)) answered++;
        });
        let pct = totalQs > 0 ? Math.round((answered / totalQs) * 100) : 0;
        let pb = document.getElementById('progress-bar');
        if (pb) {
            pb.style.width = pct + '%';
        }
        let pt = document.getElementById('progress-text');
        if (pt) pt.textContent = answered + ' / ' + totalQs + ' answered';
    }

    document.querySelectorAll('.question-card input, .question-card select, .question-card textarea').forEach(function(el) {
        el.addEventListener('change', onAnswerChange);
        el.addEventListener('input', onAnswerChange);
    });

    // ========== CUSTOM OPTIONS ==========
    function addCustomOption(qId, mode) {
        var container = document.getElementById('custom-opts-' + qId);
        if (!container) return;
        var count = container.children.length + 1;
        var div = document.createElement('div');
        div.className = 'flex items-center gap-2';
        div.style.animation = 'slideInRight 0.3s ease-out';
        var nameAttr = mode === 'single' ? 'q_' + qId : 'q_' + qId + '[]';
        var inputType = mode === 'single' ? 'radio' : 'checkbox';
        div.innerHTML = '<input type="text" class="flex-1 px-3 py-2 rounded-xl <?= $inputBg ?> border <?= $tc[
     "focus"
 ] ?> transition-all text-sm" placeholder="Type your custom option..." oninput="var me=this;var cb=me.nextElementSibling;cb.value=\'__custom__:\'+me.value;cb.checked=!!me.value.trim()" onfocus="var cb=this.nextElementSibling;if(!cb.checked){cb.checked=true}">'
            + '<input type="' + inputType + '" name="' + nameAttr + '" value="" class="sr-only custom-cb" style="display:none">'
            + '<button type="button" onclick="this.parentElement.remove();updateProgress()" class="text-red-300 hover:text-red-500 transition-all p-1 flex-shrink-0"><i class="fas fa-times text-xs"></i></button>';
        container.appendChild(div);
        div.querySelector('input[type="text"]').focus();
        updateProgress();
    }
    window.addCustomOption = addCustomOption;

    // ========== CONFETTI ==========
    function fireConfetti() {
        const colors = ['<?= $tc["hex"] ?>', '<?= $tc["hex2"] ?>', '<?= $tc[
    "hex3"
] ?>', '#facc15', '#34d399', '#60a5fa', '#f97316', '#f43f5e'];
        for (let i = 0; i < 100; i++) {
            const piece = document.createElement('div');
            piece.className = 'confetti-piece';
            const size = Math.random() * 8 + 4;
            piece.style.width = size + 'px';
            piece.style.height = size * (Math.random() * 2 + 0.5) + 'px';
            piece.style.left = Math.random() * 100 + 'vw';
            piece.style.top = '-10px';
            piece.style.background = colors[Math.floor(Math.random() * colors.length)];
            piece.style.borderRadius = Math.random() > 0.5 ? '50%' : '2px';
            piece.style.animationDuration = (Math.random() * 2 + 2) + 's';
            piece.style.animationDelay = (Math.random() * 0.5) + 's';
            piece.style.transform = 'rotate(' + (Math.random() * 360) + 'deg)';
            document.body.appendChild(piece);
            setTimeout(function() { piece.remove(); }, 4000);
        }
    }

    function fireMinConfetti() {
        const colors = ['#facc15', '#f97316', '#34d399', '<?= $tc["hex"] ?>'];
        for (let i = 0; i < 20; i++) {
            const piece = document.createElement('div');
            piece.className = 'confetti-piece';
            const size = Math.random() * 6 + 3;
            piece.style.width = size + 'px';
            piece.style.height = size * (Math.random() * 2 + 0.5) + 'px';
            piece.style.left = Math.random() * 100 + 'vw';
            piece.style.top = '-10px';
            piece.style.background = colors[Math.floor(Math.random() * colors.length)];
            piece.style.animationDuration = (Math.random() * 1.5 + 1.5) + 's';
            piece.style.borderRadius = '50%';
            document.body.appendChild(piece);
            setTimeout(function() { piece.remove(); }, 3000);
        }
    }

    // ========== QUIZ FEEDBACK SYSTEM ==========
    var quizStreakCount = 0;
    var quizCorrectCount = 0;
    var quizWrongCount = 0;
    var adaptiveLevel = 1;
    var doubleScoreActive = false;
    var freezeActive = false;
    var lastPowerupUse = 0;

    function showQuizFeedback(card, isCorrect, expectedAnswer, explanation, userAnswer) {
        var fb = card.querySelector('.quiz-feedback');
        if (!fb) return;
        fb.classList.remove('hidden');
        var icon = fb.querySelector('.feedback-icon');
        var title = fb.querySelector('.feedback-title');
        var detail = fb.querySelector('.feedback-detail');
        var expl = fb.querySelector('.feedback-explanation');

        if (isCorrect) {
            icon.innerHTML = '<i class="fas fa-check-circle text-2xl"></i>';
            icon.className = 'feedback-icon w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 text-lg bg-emerald-100 text-emerald-600';
            fb.className = 'quiz-feedback mb-3 p-3 rounded-xl text-sm font-medium transition-all duration-500 flex items-start gap-3 animate-slide-down-fade bg-emerald-50 border border-emerald-200 text-emerald-800';
            title.textContent = 'Correct! ' + (quizStreakCount > 2 ? ' Streak x' + quizStreakCount + '!' : '');
            detail.textContent = expectedAnswer ? 'Expected: ' + expectedAnswer : '';
            fireBurst(card);
            if (quizStreakCount >= 5) fireMinConfetti();
            quizCorrectCount++;
            adaptiveLevel = Math.min(5, adaptiveLevel + 0.2);
            quizStreakCount++;
        } else {
            icon.innerHTML = '<i class="fas fa-times-circle text-2xl"></i>';
            icon.className = 'feedback-icon w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 text-lg bg-red-100 text-red-600';
            fb.className = 'quiz-feedback mb-3 p-3 rounded-xl text-sm font-medium transition-all duration-500 flex items-start gap-3 animate-shake bg-red-50 border border-red-200 text-red-800';
            title.textContent = expectedAnswer ? 'Incorrect! Answer: ' + expectedAnswer : 'Incorrect!';
            detail.textContent = userAnswer ? 'Your answer: ' + userAnswer : '';
            if (explanation) expl.textContent = explanation;
            card.classList.add('shake');
            setTimeout(function() { card.classList.remove('shake'); }, 500);
            quizWrongCount++;
            quizStreakCount = 0;
            adaptiveLevel = Math.max(1, adaptiveLevel - 0.3);
        }

        // Auto-hide feedback after 8s
        setTimeout(function() {
            fb.classList.add('opacity-0', 'translate-y-2');
            setTimeout(function() {
                fb.classList.add('hidden');
                fb.classList.remove('opacity-0', 'translate-y-2');
            }, 500);
        }, 8000);

        updateQuizScore();
    }

    function checkQuizAnswer(card) {
        if (!isQuiz) return false;
        var expected = card.getAttribute('data-expected');
        if (!expected) return false;
        var isCorrect = false;
        var userAnswer = '';
        var inputs = card.querySelectorAll('input, select, textarea');
        inputs.forEach(function(inp) {
            if (inp.type === 'hidden' || inp.type === 'submit' || inp.type === 'button') return;
            if (inp.type === 'radio' && inp.checked) { userAnswer = inp.value; if (inp.value === expected) isCorrect = true; }
            else if (inp.type === 'checkbox' && inp.checked) { userAnswer = (userAnswer ? userAnswer + ', ' : '') + inp.value; }
            else if ((inp.type === 'text' || inp.type === 'number') && inp.value.trim()) { userAnswer = inp.value.trim(); if (inp.value.trim().toLowerCase() === expected.toLowerCase()) isCorrect = true; }
            else if (inp.tagName === 'SELECT' && inp.value) { userAnswer = inp.value; if (inp.value === expected) isCorrect = true; }
        });
        // Also check checkboxes/radios that are mcq options
        card.querySelectorAll('.q-option input[type="radio"]:checked, .q-option input[type="checkbox"]:checked').forEach(function(inp) {
            userAnswer = inp.value;
            if (inp.value === expected) isCorrect = true;
        });
        // For text-based fill-in-blank
        var textInput = card.querySelector('input[type="text"]');
        if (textInput && textInput.value.trim()) {
            userAnswer = textInput.value.trim();
            if (userAnswer.toLowerCase() === expected.toLowerCase()) isCorrect = true;
        }

        var explanation = card.getAttribute('data-explanation') || '';
        var scoreIncrement = 0;
        if (isCorrect) {
            scoreIncrement = 10 + (quizStreakCount * 2);
            if (doubleScoreActive) { scoreIncrement *= 2; doubleScoreActive = false; }
            quizScore += scoreIncrement;
        } else {
            quizScore = Math.max(0, quizScore - 5);
        }

        showQuizFeedback(card, isCorrect, expected, explanation, userAnswer);
        setTimeout(function() {
            proceedToNextSequential(card);
        }, isCorrect ? 1200 : 2200);
        return true;
    }

    function proceedToNextSequential(card) {
        if (currentSeqIndex < questionCards.length - 1) {
            currentSeqIndex++;
            revealNextSequential();
            animateQuestionIn(questionCards[currentSeqIndex]);
            var nextTimed = findActiveTimedQuestion();
            if (nextTimed) {
                freezeOthers(nextTimed);
                startTimedCountdown(nextTimed);
            }
        }
        updateStatusDots(getAnsweredIndices());
    }

    function animateQuestionIn(card) {
        if (!card) return;
        card.style.opacity = '0';
        card.style.transform = 'translateY(30px) scale(0.97)';
        requestAnimationFrame(function() {
            card.style.transition = 'all 0.5s cubic-bezier(0.4,0,0.2,1)';
            card.style.opacity = '1';
            card.style.transform = 'translateY(0) scale(1)';
        });
    }

    function updateQuizScore() {
        var scoreEl = document.getElementById('quiz-score');
        if (scoreEl) scoreEl.textContent = quizScore;
        var streakEl = document.getElementById('quiz-streak');
        if (streakEl) streakEl.textContent = quizStreakCount;
        // Pulse score on change
        if (scoreEl) {
            scoreEl.style.transition = 'transform 0.2s cubic-bezier(0.4,0,0.2,1)';
            scoreEl.style.transform = 'scale(1.3)';
            setTimeout(function() { scoreEl.style.transform = 'scale(1)'; }, 200);
        }
    }

    // Override onAnswerChange for quiz feedback
    var origOnAnswerChange = onAnswerChange;
    onAnswerChange = function() {
        origOnAnswerChange();
        if (!isSequential && isQuiz) {
            var lastCard = questionCards[currentSeqIndex];
            if (lastCard && isCardAnswered(lastCard)) {
                checkQuizAnswer(lastCard);
            }
        }
    };

    // Re-register event listeners to pick up the overridden onAnswerChange
    document.querySelectorAll('.question-card input, .question-card select, .question-card textarea').forEach(function(el) {
        el.removeEventListener('change', origOnAnswerChange);
        el.removeEventListener('input', origOnAnswerChange);
        el.addEventListener('change', onAnswerChange);
        el.addEventListener('input', onAnswerChange);
    });

    // Override sequential reveal for quiz feedback
    var origRevealNext = revealNextSequential;
    revealNextSequential = function() {
        origRevealNext();
        if (isQuiz && currentSeqIndex > 0 && currentSeqIndex < questionCards.length) {
            var prevCard = questionCards[currentSeqIndex - 1];
            if (prevCard && isCardAnswered(prevCard) && !prevCard.querySelector('.quiz-feedback:not(.hidden)')) {
                checkQuizAnswer(prevCard);
            }
        }
    };

    // ========== ADAPTIVE DIFFICULTY TRACKING ==========
    function getDifficultyLabel() {
        var labels = ['Easy', 'Medium', 'Moderate', 'Hard', 'Expert'];
        return labels[Math.min(4, Math.max(0, Math.floor(adaptiveLevel) - 1))];
    }

    // ========== POWER-UPS ==========
    function usePowerup(type, btn) {
        var uses = parseInt(btn.getAttribute('data-uses'));
        if (uses <= 0) { showToast('No ' + type + ' power-ups left!', 'warning'); return; }
        var now = Date.now();
        if (now - lastPowerupUse < 1500) { showToast('Power-up on cooldown!', 'warning'); return; }
        lastPowerupUse = now;

        if (type === 'fifty') {
            var currentCard = questionCards[currentSeqIndex];
            if (!currentCard) { showToast('No active question', 'error'); return; }
            var options = currentCard.querySelectorAll('.q-option');
            var correctOption = null;
            var wrongOptions = [];
            options.forEach(function(opt) {
                var checkInput = opt.querySelector('input[type="radio"], input[type="checkbox"]');
                if (checkInput && checkInput.value === currentCard.getAttribute('data-expected')) {
                    correctOption = opt;
                } else {
                    wrongOptions.push(opt);
                }
            });
            if (correctOption && wrongOptions.length > 1) {
                var toRemove = wrongOptions.sort(function() { return 0.5 - Math.random(); }).slice(0, Math.floor(wrongOptions.length / 2));
                toRemove.forEach(function(opt) {
                    opt.style.transition = 'all 0.4s cubic-bezier(0.4,0,0.2,1)';
                    opt.style.opacity = '0';
                    opt.style.transform = 'scale(0.8)';
                    opt.style.pointerEvents = 'none';
                    setTimeout(function() { opt.style.display = 'none'; }, 400);
                });
                showToast('Half the options removed!', 'success');
                fireBurst(currentCard);
            } else {
                showToast('Cannot use 50/50 on this question type', 'warning');
                return;
            }
        } else if (type === 'skip') {
            if (currentSeqIndex < questionCards.length - 1) {
                showToast('Skipped! Moving to next question', 'info');
                currentSeqIndex++;
                revealNextSequential();
                animateQuestionIn(questionCards[currentSeqIndex]);
            } else {
                showToast('Last question — can\'t skip!', 'warning');
                return;
            }
        } else if (type === 'double') {
            doubleScoreActive = true;
            showToast('2x Score activated for next correct answer!', 'success');
            btn.style.background = themeHex + '30';
            btn.style.borderColor = themeHex;
            btn.style.transform = 'scale(1.1)';
            btn.querySelector('i').className = 'fas fa-bolt';
        } else if (type === 'freeze') {
            freezeActive = true;
            // Pause all timed timers
            Object.keys(timedTimers).forEach(function(k) {
                clearInterval(timedTimers[k]);
            });
            showToast('Time frozen! Take your time.', 'success');
            btn.style.opacity = '0.5';
            btn.style.pointerEvents = 'none';
            // Unfreeze after 15s
            setTimeout(function() {
                freezeActive = false;
                var activeTimed = findActiveTimedQuestion();
                if (activeTimed) startTimedCountdown(activeTimed);
                showToast('Time unfrozen!', 'info');
            }, 15000);
        }

        uses--;
        btn.setAttribute('data-uses', uses);
        var usesSpan = btn.querySelector('.uses');
        if (usesSpan) usesSpan.textContent = '(' + uses + ')';
        if (uses <= 0) {
            btn.style.opacity = '0.3';
            btn.style.pointerEvents = 'none';
        }
    }
    window.usePowerup = usePowerup;

    // ========== RIPPLE EFFECT ==========
    function addRipple(e) {
        var btn = e.currentTarget;
        var existing = btn.querySelector('.ripple-effect');
        if (existing) existing.remove();
        var ripple = document.createElement('span');
        ripple.className = 'ripple-effect';
        var rect = btn.getBoundingClientRect();
        var size = Math.max(rect.width, rect.height);
        ripple.style.width = ripple.style.height = size + 'px';
        ripple.style.left = (e.clientX - rect.left - size / 2) + 'px';
        ripple.style.top = (e.clientY - rect.top - size / 2) + 'px';
        btn.appendChild(ripple);
        setTimeout(function() { ripple.remove(); }, 600);
    }
    document.querySelectorAll('.q-option, button, .powerup-btn').forEach(function(el) {
        el.addEventListener('click', addRipple);
    });

    // ========== PARTICLE BURST ==========
    function fireBurst(card) {
        if (!card) return;
        var rect = card.getBoundingClientRect();
        var cx = rect.left + rect.width / 2;
        var cy = rect.top + rect.height / 2;
        var colors = ['<?= $tc["hex"] ?>', '<?= $tc[
    "hex2"
] ?>', '#facc15', '#34d399', '#f43f5e'];
        for (var i = 0; i < 12; i++) {
            var dot = document.createElement('div');
            dot.style.position = 'fixed';
            dot.style.width = '6px';
            dot.style.height = '6px';
            dot.style.borderRadius = '50%';
            dot.style.background = colors[Math.floor(Math.random() * colors.length)];
            dot.style.left = cx + 'px';
            dot.style.top = cy + 'px';
            dot.style.pointerEvents = 'none';
            dot.style.zIndex = '9999';
            var angle = (Math.PI * 2 / 12) * i + (Math.random() - 0.5) * 0.5;
            var dist = 40 + Math.random() * 60;
            document.body.appendChild(dot);
            var tx = Math.cos(angle) * dist;
            var ty = Math.sin(angle) * dist;
            dot.style.transition = 'all 0.6s cubic-bezier(0.4,0,0.2,1)';
            requestAnimationFrame(function() {
                dot.style.transform = 'translate(' + tx + 'px, ' + ty + 'px) scale(0)';
                dot.style.opacity = '0';
            });
            setTimeout(function() { dot.remove(); }, 700);
        }
    }

    // ========== KEYBOARD SHORTCUTS ==========
    document.addEventListener('keydown', function(e) {
        if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
            e.preventDefault();
            const form = document.getElementById('survey-form');
            if (form && form.requestSubmit) {
                form.requestSubmit();
            } else {
                document.getElementById('submit-btn').click();
            }
        }
    });

    // ========== TOAST SYSTEM ==========
    function showToast(msg, type) {
        const existing = document.querySelector('.toast-notif');
        if (existing) existing.remove();
        const t = document.createElement('div');
        t.className = 'toast-notif fixed bottom-6 right-6 z-[9999] px-4 py-3 rounded-xl shadow-2xl text-sm font-medium transition-all duration-300 translate-y-4 opacity-0 flex items-center gap-2';
        const icons = { success:'fa-check-circle text-emerald-400', error:'fa-exclamation-circle text-red-400', info:'fa-info-circle text-blue-400', warning:'fa-exclamation-triangle text-amber-400' };
        t.innerHTML = '<i class="fas ' + (icons[type] || icons.info) + '"></i> ' + msg;
        if (type === 'success') t.className += ' bg-emerald-900/90 text-white backdrop-blur-md border border-emerald-700/50';
        else if (type === 'error') t.className += ' bg-red-900/90 text-white backdrop-blur-md border border-red-700/50';
        else if (type === 'warning') t.className += ' bg-amber-900/90 text-white backdrop-blur-md border border-amber-700/50';
        else t.className += ' bg-gray-900/90 text-white backdrop-blur-md border border-gray-700/50';
        document.body.appendChild(t);
        requestAnimationFrame(() => { t.classList.remove('translate-y-4', 'opacity-0'); });
        setTimeout(() => { t.classList.add('translate-y-4', 'opacity-0'); setTimeout(() => t.remove(), 300); }, 3500);
    }

    // ========== PARTICLE BACKGROUND ==========
    <?php if ($bgStyle === "particles"): ?>
    (function() {
        const canvas = document.getElementById('particles-canvas');
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        let particles = [];
        function resize() { canvas.width = window.innerWidth; canvas.height = window.innerHeight; }
        window.addEventListener('resize', resize);
        resize();
        const count = Math.floor((canvas.width * canvas.height) / 15000);
        for (let i = 0; i < Math.min(count, 80); i++) {
            particles.push({
                x: Math.random() * canvas.width,
                y: Math.random() * canvas.height,
                vx: (Math.random() - 0.5) * 0.5,
                vy: (Math.random() - 0.5) * 0.5,
                r: Math.random() * 2 + 1,
                alpha: Math.random() * 0.5 + 0.2
            });
        }
        function draw() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            particles.forEach(function(p, i) {
                p.x += p.vx;
                p.y += p.vy;
                if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
                if (p.y < 0 || p.y > canvas.height) p.vy *= -1;
                ctx.beginPath();
                ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
                ctx.fillStyle = 'rgba(255,255,255,' + p.alpha + ')';
                ctx.fill();
                // Connect nearby particles
                for (let j = i + 1; j < particles.length; j++) {
                    const dx = p.x - particles[j].x;
                    const dy = p.y - particles[j].y;
                    const dist = Math.sqrt(dx * dx + dy * dy);
                    if (dist < 120) {
                        ctx.beginPath();
                        ctx.moveTo(p.x, p.y);
                        ctx.lineTo(particles[j].x, particles[j].y);
                        ctx.strokeStyle = 'rgba(255,255,255,' + (0.1 * (1 - dist / 120)) + ')';
                        ctx.lineWidth = 0.5;
                        ctx.stroke();
                    }
                }
            });
            requestAnimationFrame(draw);
        }
        draw();
    })();
    <?php endif; ?>

    // ========== INIT ==========
    if (isSequential) initSequential();

    let firstTimed = findActiveTimedQuestion();
    if (firstTimed) {
        freezeOthers(firstTimed);
        startTimedCountdown(firstTimed);
    }

    updateProgress();
    updateStatusDots(getAnsweredIndices());

    // Restore from localStorage
    if (allowResume) {
        try {
            const saved = localStorage.getItem('survey_draft_' + surveyId);
            if (saved) {
                const data = JSON.parse(saved);
                if (data.answers) {
                    Object.keys(data.answers).forEach(function(name) {
                        const vals = data.answers[name];
                        const inputs = document.querySelectorAll('[name="' + CSS.escape(name) + '"]');
                        if (inputs.length === 0) return;
                        if (inputs[0].type === 'radio' || inputs[0].type === 'checkbox') {
                            inputs.forEach(function(input) {
                                if (Array.isArray(vals) && vals.includes(input.value)) {
                                    input.checked = true;
                                }
                            });
                        } else {
                            inputs[0].value = Array.isArray(vals) ? vals[0] : vals;
                        }
                    });
                    updateProgress();
                    updateStatusDots(getAnsweredIndices());
                }
            }
        } catch(e) {}
    }

    // ========== FORM SUBMISSION ==========
    document.getElementById('survey-form').addEventListener('submit', function(e) {
        let elapsed = Math.floor((Date.now() - startTime) / 1000);
        let minTime = <?= (int) ($qualityConfig["min_time_seconds"] ?? 0) ?>;

        // Check required
        let missingRequired = false;
        questionCards.forEach(function(card) {
            if (card.dataset.required === '1' && !isCardAnswered(card)) {
                missingRequired = true;
                card.style.borderLeftColor = '#f87171';
                card.style.borderLeftWidth = '3px';
                setTimeout(function() {
                    card.style.animation = 'shake 0.4s ease-in-out';
                    card.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }, 100);
            }
        });

        if (missingRequired) {
            showToast('Please answer all required questions before submitting.', 'error');
            e.preventDefault();
            return;
        }

        <?php if (!empty($qualityConfig["confirm_answers"])): ?>
        if (!confirm('Please confirm you want to submit your responses. Make sure all answers are correct.')) {
            e.preventDefault();
            return;
        }
        <?php endif; ?>

        if (minTime > 0 && elapsed < minTime) {
            let remaining = minTime - elapsed;
            showToast('Please spend at least ' + minTime + ' seconds. Wait ' + remaining + ' more seconds.', 'warning');
            e.preventDefault();
            return;
        }

        <?php if (!empty($qualityConfig["detect_straightline"])): ?>
        let radioGroups = {};
        this.querySelectorAll('.question-card').forEach(function(card) {
            let radios = card.querySelectorAll('input[type="radio"]');
            radios.forEach(function(r) {
                if (r.name && !radioGroups[r.name]) radioGroups[r.name] = [];
            });
        });
        let values = [];
        for (let name in radioGroups) {
            let checked = this.querySelector('input[name="' + CSS.escape(name) + '"]:checked');
            if (checked) values.push(checked.value);
        }
        if (values.length >= 4) {
            let unique = values.filter(function(v, i, a) { return a.indexOf(v) === i; });
            if (unique.length <= 1) {
                if (!confirm('It looks like you selected the same answer for multiple questions. Are you sure?')) {
                    e.preventDefault();
                    return;
                }
            }
        }
        <?php endif; ?>

        // Tab switches
        let tsInput = document.createElement('input');
        tsInput.type = 'hidden';
        tsInput.name = 'tab_switches';
        tsInput.value = tabSwitches;
        this.appendChild(tsInput);

        // Inactivity
        document.getElementById('inactive-seconds').value = inactiveSeconds;

        // Timed question data
        let timedIds = [];
        questionCards.forEach(function(card) {
            if (card.getAttribute('data-timed') === '1') {
                let qid = card.getAttribute('data-qid');
                timedIds.push(qid);
                let limit = parseInt(card.getAttribute('data-timelimit')) || 0;
                let elapsedInput = document.getElementById('_elapsed_' + qid);
                let elapsedVal = elapsedInput ? parseInt(elapsedInput.value) : 0;
                if (elapsedVal === 0) elapsedVal = Math.floor((Date.now() - startTime) / 1000);
                let elInput = document.createElement('input');
                elInput.type = 'hidden';
                elInput.name = '_elapsed_' + qid;
                elInput.value = elapsedVal > limit ? limit + 1 : Math.min(elapsedVal, limit);
                document.getElementById('survey-form').appendChild(elInput);
            }
        });
        document.getElementById('timed-question-ids').value = timedIds.join(',');
        document.getElementById('timed-times-placeholder').name = '';

        // Clear auto-save
        if (allowResume) {
            try { localStorage.removeItem('survey_draft_' + surveyId); } catch(e) {}
        }

        // Confetti
        fireConfetti();
        showToast('Submitting your responses...', 'info');
    });

    // ========== FULLSCREEN ==========
    if (isFullscreen) {
        document.getElementById('survey-header').addEventListener('click', function() {
            if (!document.fullscreenElement) {
                document.documentElement.requestFullscreen().catch(function() {});
            }
        });
    }

    // Expose resetInactivity globally
    window.resetInactivity = resetInactivity;

    // ========== SIGNATURE PAD ==========
    function initSignaturePad(canvas) {
        const ctx = canvas.getContext('2d');
        let drawing = false;
        let lastX, lastY;
        function resizeCanvas() {
            const rect = canvas.getBoundingClientRect();
            canvas.width = rect.width * 2;
            canvas.height = rect.height * 2;
            ctx.scale(2, 2);
            ctx.strokeStyle = '<?= $tc["hex"] ?>';
            ctx.lineWidth = 2;
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';
        }
        resizeCanvas();
        window.addEventListener('resize', function() {
            const data = canvas.toDataURL();
            resizeCanvas();
            const img = new Image();
            img.onload = function() { ctx.drawImage(img, 0, 0); };
            img.src = data;
        });
        function getPos(e) {
            const rect = canvas.getBoundingClientRect();
            const clientX = e.touches ? e.touches[0].clientX : e.clientX;
            const clientY = e.touches ? e.touches[0].clientY : e.clientY;
            return { x: clientX - rect.left, y: clientY - rect.top };
        }
        function startDrawing(e) {
            e.preventDefault();
            drawing = true;
            const pos = getPos(e);
            lastX = pos.x; lastY = pos.y;
        }
        function draw(e) {
            e.preventDefault();
            if (!drawing) return;
            const pos = getPos(e);
            ctx.beginPath();
            ctx.moveTo(lastX, lastY);
            ctx.lineTo(pos.x, pos.y);
            ctx.stroke();
            lastX = pos.x; lastY = pos.y;
            canvas.closest('.border-dashed').querySelector('.signature-input').value = canvas.toDataURL();
        }
        function stopDrawing() { drawing = false; }
        canvas.addEventListener('mousedown', startDrawing);
        canvas.addEventListener('mousemove', draw);
        canvas.addEventListener('mouseup', stopDrawing);
        canvas.addEventListener('mouseleave', stopDrawing);
        canvas.addEventListener('touchstart', startDrawing, { passive: false });
        canvas.addEventListener('touchmove', draw, { passive: false });
        canvas.addEventListener('touchend', stopDrawing);
    }
    document.querySelectorAll('.signature-pad').forEach(initSignaturePad);

    window.clearSignature = function(canvas) {
        const ctx = canvas.getContext('2d');
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        canvas.closest('.border-dashed').querySelector('.signature-input').value = '';
    };

    // ========== RANKING DRAG & DROP ==========
    window.handleRankingDrop = function(e) {
        const list = e.target.closest('.ranking-list');
        if (!list) return;
        const draggedIdx = parseInt(list.dataset.dragged);
        const targetItem = e.target.closest('.ranking-item');
        if (!targetItem) return;
        const targetIdx = parseInt(targetItem.dataset.idx);
        if (draggedIdx === targetIdx) return;
        const items = Array.from(list.querySelectorAll('.ranking-item'));
        const draggedItem = items.find(function(it) { return parseInt(it.dataset.idx) === draggedIdx; });
        const targetRef = items.find(function(it) { return parseInt(it.dataset.idx) === targetIdx; });
        if (!draggedItem || !targetRef) return;
        if (draggedIdx < targetIdx) {
            targetRef.parentNode.insertBefore(draggedItem, targetRef.nextSibling);
        } else {
            targetRef.parentNode.insertBefore(draggedItem, targetRef);
        }
        list.querySelectorAll('.ranking-item').forEach(function(item, idx) {
            item.dataset.idx = idx;
            item.querySelector('.rank-number').textContent = idx + 1;
            item.querySelector('input[type="hidden"]').value = item.querySelector('.flex-1').textContent.trim();
        });
        var evt = new Event('change', { bubbles: true });
        list.dispatchEvent(evt);
    };

    // ========== NEW TYPES: DRAG & DROP RANK ==========
    document.querySelectorAll('.rank-list').forEach(function(list) {
        var items = list.querySelectorAll('.rank-item');
        items.forEach(function(item) {
            item.addEventListener('dragstart', function(e) {
                e.dataTransfer.setData('text/plain', Array.from(list.children).indexOf(item));
                item.classList.add('opacity-50');
            });
            item.addEventListener('dragend', function() { item.classList.remove('opacity-50'); });
            item.addEventListener('dragover', function(e) { e.preventDefault(); });
            item.addEventListener('drop', function(e) {
                e.preventDefault();
                var fromIdx = parseInt(e.dataTransfer.getData('text/plain'));
                var toIdx = Array.from(list.children).indexOf(item);
                if (fromIdx === toIdx) return;
                var fromItem = list.children[fromIdx];
                if (fromIdx < toIdx) { list.insertBefore(fromItem, item.nextSibling); }
                else { list.insertBefore(fromItem, item); }
                list.querySelectorAll('.rank-item').forEach(function(it, idx) {
                    it.querySelector('input[type="hidden"]').value = it.dataset.value;
                });
                var evt = new Event('change', { bubbles: true });
                list.dispatchEvent(evt);
            });
        });
    });

    // ========== NEW TYPES: CONSTANT SUM VALIDATION ==========
    document.querySelectorAll('.constant-sum').forEach(function(container) {
        var total = parseInt(container.dataset.total);
        var inputs = container.querySelectorAll('.cs-input');
        inputs.forEach(function(inp) {
            inp.addEventListener('input', function() {
                var sum = 0;
                container.querySelectorAll('.cs-input').forEach(function(i) { sum += parseInt(i.value) || 0; });
                var remaining = total - sum;
                container.querySelector('.cs-remaining').textContent = Math.max(0, remaining);
                if (remaining < 0) { inp.value = Math.max(0, parseInt(inp.value) + remaining); }
            });
        });
    });

    // ========== NEW TYPES: AUDIO RECORDER ==========
    window.toggleAudioRecording = function(btn, qid) {
        var statusEl = btn.closest('.audio-recorder').querySelector('.audio-status');
        var levelEl = btn.closest('.audio-recorder').querySelector('.audio-level');
        var previewEl = btn.closest('.audio-recorder').querySelector('.audio-preview');
        var inputEl = btn.closest('.audio-recorder').querySelector('.audio-data');
        if (btn.dataset.recording === '1') {
            if (window._audioRecorder && window._audioRecorder.state !== 'inactive') {
                window._audioRecorder.stop();
            }
            btn.dataset.recording = '0';
            btn.innerHTML = '<i class="fas fa-microphone"></i>';
            btn.style.background = '<?= $tc["hex"] ?>';
            statusEl.textContent = 'Recording stopped';
            return;
        }
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            statusEl.textContent = 'Recording not supported';
            return;
        }
        navigator.mediaDevices.getUserMedia({ audio: true }).then(function(stream) {
            var chunks = [];
            var recorder = new MediaRecorder(stream);
            window._audioRecorder = recorder;
            recorder.ondataavailable = function(e) { if (e.data.size > 0) chunks.push(e.data); };
            recorder.onstop = function() {
                var blob = new Blob(chunks, { type: 'audio/webm' });
                var reader = new FileReader();
                reader.onloadend = function() { inputEl.value = reader.result; };
                reader.readAsDataURL(blob);
                previewEl.src = URL.createObjectURL(blob);
                previewEl.classList.remove('hidden');
                stream.getTracks().forEach(function(t) { t.stop(); });
            };
            recorder.start();
            btn.dataset.recording = '1';
            btn.innerHTML = '<i class="fas fa-stop"></i>';
            btn.style.background = '#ef4444';
            statusEl.textContent = 'Recording...';
            // Simulate audio levels
            var interval = setInterval(function() {
                if (window._audioRecorder && window._audioRecorder.state === 'inactive') {
                    clearInterval(interval);
                    return;
                }
                var level = Math.random() * 60 + 10;
                levelEl.style.width = level + '%';
            }, 200);
        }).catch(function() {
            statusEl.textContent = 'Microphone access denied';
        });
    };

    // ========== NEW TYPES: VIDEO RECORDER ==========
    window.toggleVideoRecording = function(btn, qid) {
        var statusEl = btn.closest('.video-recorder').querySelector('.video-status');
        var previewEl = btn.closest('.video-recorder').querySelector('.video-preview');
        var inputEl = btn.closest('.video-recorder').querySelector('.video-data');
        if (btn.dataset.recording === '1') {
            if (window._videoRecorder && window._videoRecorder.state !== 'inactive') {
                window._videoRecorder.stop();
            }
            btn.dataset.recording = '0';
            btn.innerHTML = '<i class="fas fa-video"></i>';
            btn.style.background = '<?= $tc["hex"] ?>';
            statusEl.textContent = 'Recording stopped';
            return;
        }
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            statusEl.textContent = 'Recording not supported';
            return;
        }
        navigator.mediaDevices.getUserMedia({ video: true, audio: true }).then(function(stream) {
            var chunks = [];
            var recorder = new MediaRecorder(stream);
            window._videoRecorder = recorder;
            previewEl.srcObject = stream;
            previewEl.classList.remove('hidden');
            previewEl.play();
            recorder.ondataavailable = function(e) { if (e.data.size > 0) chunks.push(e.data); };
            recorder.onstop = function() {
                var blob = new Blob(chunks, { type: 'video/webm' });
                var reader = new FileReader();
                reader.onloadend = function() { inputEl.value = reader.result; };
                reader.readAsDataURL(blob);
                stream.getTracks().forEach(function(t) { t.stop(); });
                previewEl.srcObject = null;
            };
            recorder.start();
            btn.dataset.recording = '1';
            btn.innerHTML = '<i class="fas fa-stop"></i>';
            btn.style.background = '#ef4444';
            statusEl.textContent = 'Recording...';
        }).catch(function() {
            statusEl.textContent = 'Camera/Mic access denied';
        });
    };

    // ========== NEW TYPES: DRAWING PAD ==========
    function initDrawingPad(canvas) {
        var ctx = canvas.getContext('2d');
        var drawing = false, lastX, lastY;
        var color = '<?= $tc["hex"] ?>';
        function resize() {
            var rect = canvas.getBoundingClientRect();
            canvas.width = rect.width * 2;
            canvas.height = rect.height * 2;
            ctx.scale(2, 2);
            ctx.strokeStyle = color;
            ctx.lineWidth = 3;
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';
        }
        resize();
        window.addEventListener('resize', function() {
            var data = canvas.toDataURL();
            resize();
            var img = new Image();
            img.onload = function() { ctx.drawImage(img, 0, 0); };
            img.src = data;
        });
        function getPos(e) {
            var rect = canvas.getBoundingClientRect();
            return { x: (e.touches ? e.touches[0].clientX : e.clientX) - rect.left, y: (e.touches ? e.touches[0].clientY : e.clientY) - rect.top };
        }
        function start(e) { e.preventDefault(); drawing = true; var p = getPos(e); lastX = p.x; lastY = p.y; }
        function move(e) {
            e.preventDefault(); if (!drawing) return;
            var p = getPos(e);
            ctx.beginPath(); ctx.moveTo(lastX, lastY); ctx.lineTo(p.x, p.y); ctx.stroke();
            lastX = p.x; lastY = p.y;
            canvas.closest('.drawing-pad-wrapper').querySelector('.drawing-input').value = canvas.toDataURL();
        }
        function stop() { drawing = false; }
        canvas.addEventListener('mousedown', start);
        canvas.addEventListener('mousemove', move);
        canvas.addEventListener('mouseup', stop);
        canvas.addEventListener('mouseleave', stop);
        canvas.addEventListener('touchstart', start, { passive: false });
        canvas.addEventListener('touchmove', move, { passive: false });
        canvas.addEventListener('touchend', stop);
        canvas._drawingCtx = ctx;
        canvas._drawingColor = color;
    }
    document.querySelectorAll('.drawing-pad').forEach(initDrawingPad);

    window.clearDrawing = function(canvas) {
        var ctx = canvas.getContext('2d');
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        canvas.closest('.drawing-pad-wrapper').querySelector('.drawing-input').value = '';
    };
    window.setDrawingColor = function(canvas, color) {
        var ctx = canvas.getContext('2d');
        ctx.strokeStyle = color;
    };

    // ========== NEW TYPES: CARD SORT DRAG & DROP ==========
    document.querySelectorAll('.card-sort-container').forEach(function(container) {
        var qid = container.dataset.qid;
        container.querySelectorAll('.cs-card').forEach(function(card) {
            card.addEventListener('dragstart', function(e) {
                e.dataTransfer.setData('text/plain', card.dataset.value);
                card.classList.add('opacity-30');
            });
            card.addEventListener('dragend', function() { card.classList.remove('opacity-30'); });
        });
        container.querySelectorAll('.cs-dropzone').forEach(function(zone) {
            zone.addEventListener('dragover', function(e) { e.preventDefault(); zone.closest('.cs-group').style.borderColor = '<?= $tc[
                "hex"
            ] ?>'; });
            zone.addEventListener('dragleave', function() { zone.closest('.cs-group').style.borderColor = ''; });
            zone.addEventListener('drop', function(e) {
                e.preventDefault();
                var val = e.dataTransfer.getData('text/plain');
                var card = container.querySelector('.cs-card[data-value="' + val.replace(/"/g, '\\"') + '"]');
                if (!card || card.closest('.cs-dropzone')) return;
                var clone = card.cloneNode(true);
                clone.draggable = true;
                clone.classList.remove('opacity-30');
                clone.addEventListener('dragstart', function(ce) { ce.dataTransfer.setData('text/plain', clone.dataset.value); });
                zone.appendChild(clone);
                card.remove();
                updateCardSortInput(container);
                zone.closest('.cs-group').style.borderColor = '';
            });
        });
        container.querySelectorAll('.cs-group').forEach(function(group) {
            var dz = group.querySelector('.cs-dropzone');
            if (dz) {
                dz.addEventListener('dragover', function(e) { e.preventDefault(); group.style.borderColor = '<?= $tc[
                    "hex"
                ] ?>'; });
                dz.addEventListener('dragleave', function() { if (!dz.contains(e.relatedTarget)) group.style.borderColor = ''; });
                dz.addEventListener('drop', function(e) {
                    e.preventDefault();
                    var val = e.dataTransfer.getData('text/plain');
                    var card = container.querySelector('.cs-card[data-value="' + val.replace(/"/g, '\\"') + '"]');
                    if (!card || card.closest('.cs-dropzone')) return;
                    var clone = card.cloneNode(true);
                    clone.draggable = true;
                    clone.addEventListener('dragstart', function(ce) { ce.dataTransfer.setData('text/plain', clone.dataset.value); });
                    dz.appendChild(clone);
                    card.remove();
                    updateCardSortInput(container);
                    group.style.borderColor = '';
                });
            }
        });
        function updateCardSortInput(container) {
            container.querySelectorAll('.cs-group').forEach(function(group) {
                var values = [];
                group.querySelectorAll('.cs-dropzone .cs-card').forEach(function(c) { values.push(c.dataset.value); });
                group.querySelector('.cs-group-input').value = JSON.stringify(values);
            });
        }
    });

    // ========== NEW TYPES: RICH TEXT SAVE ==========
    document.querySelectorAll('.rich-text-editor').forEach(function(editor) {
        var content = editor.querySelector('.rich-text-content');
        var input = editor.querySelector('.rich-text-input');
        var form = editor.closest('form');
        if (content && input && form) {
            form.addEventListener('submit', function() {
                input.value = content.innerHTML;
            });
        }
    });

    // ========== NEW TYPES: LOCATION PICKER ==========
    document.querySelectorAll('.location-input').forEach(function(inp) {
        var suggestions = inp.closest('.location-picker').querySelector('.location-suggestions');
        var debounceTimer;
        inp.addEventListener('input', function() {
            clearTimeout(debounceTimer);
            var val = inp.value.trim();
            if (val.length < 3) { suggestions.classList.add('hidden'); return; }
            debounceTimer = setTimeout(function() {
                // Use OpenStreetMap Nominatim for free geocoding
                fetch('https://nominatim.openstreetmap.org/search?format=json&q=' + encodeURIComponent(val) + '&limit=5')
                    .then(function(r) { return r.json(); })
                    .then(function(data) {
                        suggestions.innerHTML = '';
                        if (!data || data.length === 0) { suggestions.classList.add('hidden'); return; }
                        suggestions.classList.remove('hidden');
                        data.forEach(function(place) {
                            var div = document.createElement('div');
                            div.className = 'px-4 py-2.5 text-sm cursor-pointer hover:bg-gray-50 transition-colors border-b last:border-b-0';
                            div.style.borderColor = 'rgba(<?= $tc[
                                "rgb"
                            ] ?>,0.1)';
                            div.textContent = place.display_name;
                            div.addEventListener('click', function() {
                                inp.value = place.display_name;
                                inp.dataset.lat = place.lat;
                                inp.dataset.lon = place.lon;
                                suggestions.classList.add('hidden');
                            });
                            suggestions.appendChild(div);
                        });
                    })
                    .catch(function() { suggestions.classList.add('hidden'); });
            }, 400);
        });
        document.addEventListener('click', function(e) {
            if (!inp.closest('.location-picker').contains(e.target)) {
                suggestions.classList.add('hidden');
            }
        });
    });

    // ========== NEW TYPES: CLICK MAP HIDDEN INPUT ==========
    document.querySelectorAll('.click-area').forEach(function(area) {
        area.addEventListener('click', function() {
            var container = area.closest('.click-map-container');
            var hidden = container.querySelector('input[type="hidden"]');
            if (hidden) hidden.value = area.querySelector('input') ? area.querySelector('input').value : area.getAttribute('title') || '';
        });
    });

    // ========== ANTI-CHEAT BEHAVIORAL LOGGING ==========
    var behaviorEvents = [];
    var bcSurveyId = document.querySelector('input[name="survey_id"]') ? document.querySelector('input[name="survey_id"]').value : '';

    function logBehavior(eventType, extra) {
        behaviorEvents.push({
            event_type: eventType,
            event_data: extra || {},
            timestamp_ms: Date.now()
        });
    }

    // Focus loss / tab switch
    document.addEventListener('visibilitychange', function() {
        if (document.hidden) {
            logBehavior('tab_switch', { action: 'switched_away' });
        } else {
            logBehavior('focus_loss', { action: 'returned' });
        }
    });
    window.addEventListener('blur', function() {
        logBehavior('focus_loss', { action: 'window_blur' });
    });
    window.addEventListener('focus', function() {
        logBehavior('focus_loss', { action: 'window_focus' });
    });

    // Copy / Paste
    document.addEventListener('copy', function() { logBehavior('copy', {}); });
    document.addEventListener('paste', function() { logBehavior('paste', {}); });

    // Right click
    document.addEventListener('contextmenu', function() {
        logBehavior('right_click', {});
        return true;
    });

    // Devtools detection (basic)
    var devtoolsOpen = false;
    var checkDevtools = setInterval(function() {
        var threshold = 160;
        var widthThreshold = window.outerWidth - window.innerWidth > threshold;
        var heightThreshold = window.outerHeight - window.innerHeight > threshold;
        if (widthThreshold || heightThreshold) {
            if (!devtoolsOpen) {
                devtoolsOpen = true;
                logBehavior('devtools_open', { detected: true });
            }
        } else {
            devtoolsOpen = false;
        }
    }, 2000);

    // Scroll tracking
    var scrollTimeout;
    window.addEventListener('scroll', function() {
        clearTimeout(scrollTimeout);
        scrollTimeout = setTimeout(function() {
            logBehavior('scroll', { scrollY: window.scrollY, maxScroll: document.documentElement.scrollHeight - window.innerHeight });
        }, 1000);
    });

    // Idle detection
    var idleTimer;
    function resetIdle() {
        clearTimeout(idleTimer);
        idleTimer = setTimeout(function() { logBehavior('idle', { duration_ms: 30000 }); }, 30000);
    }
    document.addEventListener('mousemove', resetIdle);
    document.addEventListener('keydown', resetIdle);
    document.addEventListener('click', resetIdle);
    resetIdle();

    // Submit behavioral data with form
    var surveyForm = document.getElementById('survey-form');
    if (surveyForm) {
        var origSubmit = surveyForm.onsubmit;
        surveyForm.onsubmit = function(e) {
            clearInterval(checkDevtools);
            var input = document.createElement('input');
            input.type = 'hidden';
            input.name = '_behavior_log';
            input.value = JSON.stringify(behaviorEvents);
            surveyForm.appendChild(input);
            if (typeof origSubmit === 'function') return origSubmit.call(this, e);
        };
    }

})();
</script>
