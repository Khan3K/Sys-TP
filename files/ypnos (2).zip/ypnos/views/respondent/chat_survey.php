<?php
$t = \Helpers\ComputeTheme::fromConfig($themeCfg ?? []);
extract($t);
$isSequential = false;
$isQuiz = false;
$nodeCount = count($chatConfig["nodes"] ?? []);
function ai_config_strip(array $cfg): array
{
    unset($cfg["api_key"]);
    return $cfg;
}
?>
<div class="max-w-2xl mx-auto py-4 px-3 min-h-[100dvh] flex flex-col" id="chat-app" style="background:radial-gradient(120% 120% at 50% 0%, <?= $tc[
    "hex"
] ?>10 0%, transparent 55%);">
  <div class="relative <?= $cardBg ?> rounded-2xl shadow-xl border overflow-hidden flex-1 flex flex-col" style="height: calc(100dvh - 96px); min-height: 500px; display: flex; flex-direction: column;">
    <!-- Header -->
    <div class="flex-shrink-0 px-4 py-3 border-b border-white/20 bg-gradient-to-r <?= $tc[
        "gradient"
    ] ?>">
      <div class="flex items-center gap-3">
        <div class="relative w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center backdrop-blur-sm">
          <i class="fas fa-comment-dots text-white text-sm"></i>
          <span class="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-emerald-400 border-2 border-white online-pulse"></span>
        </div>
        <div class="flex-1 min-w-0">
          <h2 class="text-sm font-bold text-white truncate flex items-center gap-1.5">
            <?= htmlspecialchars($survey["title"] ?? "Chat Survey") ?>
            <span class="text-[9px] font-normal text-white/70 inline-flex items-center gap-1"><span class="w-1.5 h-1.5 rounded-full bg-emerald-300 inline-block"></span>Online</span>
          </h2>
          <p class="text-[10px] text-white/70">Question <span id="chat-q-current-header">1</span> of <span id="chat-q-total-header"><?= $nodeCount ?></span></p>
        </div>
<div class="flex items-center gap-1.5 bg-white/10 rounded-lg px-2.5 py-1.5 backdrop-blur-sm">
        <i class="fas fa-comment text-white/60 text-[9px]"></i>
        <span class="text-white font-semibold text-[11px]" id="chat-q-current">1</span>
        <span class="text-white/40 text-[9px]">/ <?= $nodeCount ?></span>
      </div>
    </div>
    <div class="mt-2.5 h-1.5 bg-white/10 rounded-full overflow-hidden">
      <div id="chat-progress-bar" class="h-full rounded-full transition-all duration-700 ease-out" style="width:0%;background:linear-gradient(90deg, rgba(255,255,255,0.9), rgba(255,255,255,0.55))"></div>
    </div>
    <!-- Progress labels -->
    <div class="flex justify-between mt-1.5 px-0.5">
      <span class="text-[9px] text-white/60">0%</span>
      <span class="text-[9px] text-white/60" id="chat-progress-percent">0%</span>
      <span class="text-[9px] text-white/60">100%</span>
    </div>
  </div>

    <!-- Messages -->
    <div class="flex-1 overflow-y-auto px-4 py-4 space-y-3" id="chat-messages" role="log" aria-live="polite" aria-label="Conversation" style="scroll-behavior: smooth;">
      <div class="flex items-start gap-3 chat-msg bot" data-role="bot" data-msg-index="0">
        <div class="w-8 h-8 rounded-xl bg-gradient-to-br <?= $tc[
            "gradient"
        ] ?> flex items-center justify-center text-white text-xs flex-shrink-0 shadow-sm mt-0.5 msg-avatar animate-scale-in">
          <i class="fas fa-robot"></i>
        </div>
        <div class="flex flex-col max-w-[80%] items-start">
          <div class="bot-bubble rounded-2xl px-4 py-3 text-sm leading-relaxed" style="background:<?= $tc[
              "hex"
          ] ?>0a;border:1px solid <?= $tc[
    "hex"
] ?>15;color:<?= $textColor ?>;border-bottom-left-radius:8px;box-shadow:0 2px 8px rgba(0,0,0,0.04)">
            <?= htmlspecialchars(
                $chatConfig["intro_message"] ??
                    'Hello! I\'ll be asking you some questions today. There are no right or wrong answers — just share your thoughts.',
            ) ?>
          </div>
          <span class="msg-time text-[9px] text-gray-400 mt-1 ml-1"><?= date(
              "H:i",
          ) ?></span>
        </div>
      </div>
    </div>

    <!-- Input -->
    <div class="flex-shrink-0 border-t border-white/10 bg-gradient-to-t from-white/70 to-white/40 backdrop-blur-xl">
      <div class="p-3" id="chat-input-area">
        <div id="chat-validating" class="hidden items-center gap-2 mb-2 text-[10px] font-medium" style="color:<?= $tc[
            "hex"
        ] ?>">
          <span class="inline-block w-3 h-3 rounded-full border-2 border-current border-t-transparent spin-slow"></span>
          <span>Validating your answer…</span>
          <span class="typing-dots"><span></span><span></span><span></span></span>
        </div>
        <div class="flex items-end gap-2 bg-white/80 rounded-2xl border border-white/50 px-3 py-2 focus-within:border-primary-300 focus-within:ring-2 focus-within:ring-primary-100 transition-all shadow-lg backdrop-blur-sm">
          <div class="flex-1 relative">
            <textarea id="chat-input" rows="1" autocomplete="off" placeholder="Type your response..." class="w-full text-sm outline-none resize-none bg-transparent max-h-36 leading-relaxed placeholder:text-gray-400 pr-2"></textarea>
            <div class="absolute bottom-0 right-0 hidden" id="chat-char-warning" style="color:<?= $tc[
                "hex"
            ] ?>">Character limit reached</div>
          </div>
          <button type="button" id="chat-send-btn" class="w-10 h-10 rounded-xl bg-gradient-to-br <?= $tc[
              "gradient"
          ] ?> text-white flex items-center justify-center shadow-lg hover:scale-105 active:scale-95 transition-all disabled:opacity-40 disabled:cursor-not-allowed flex-shrink-0" aria-label="Send message">
            <i class="fas fa-paper-plane text-xs send-icon"></i>
            <span class="hidden send-spinner"><i class="fas fa-spinner fa-spin text-xs"></i></span>
          </button>
        </div>
        <div class="flex items-center justify-between mt-2 px-1">
          <span class="text-[9px] text-gray-400"><kbd class="px-1.5 py-0.5 bg-gray-100 rounded text-[8px] font-mono border border-gray-200">Enter</kbd> to send · <kbd class="px-1.5 py-0.5 bg-gray-100 rounded text-[8px] font-mono border border-gray-200">Shift+Enter</kbd> new line</span>
          <span class="text-[9px] text-gray-400" id="chat-chars-remaining"></span>
        </div>
      </div>
      <div class="hidden p-3" id="chat-done-area">
        <div class="bg-white rounded-2xl border border-<?= $tc[
            "hex"
        ] ?>20 p-5 shadow-sm text-center done-pop">
          <div class="w-14 h-14 mx-auto rounded-2xl bg-gradient-to-br <?= $tc[
              "gradient"
          ] ?> flex items-center justify-center text-white shadow-lg mb-3 animate-scale-in"><i class="fas fa-check text-xl"></i></div>
          <div class="text-base font-bold text-gray-800">All done! 🎉</div>
          <div class="text-[11px] text-gray-400 mt-1">You answered <strong id="chat-final-count">0</strong> question(s). Thank you!</div>
          <button type="button" id="chat-restart-btn" class="mt-4 text-[11px] text-gray-400 hover:text-gray-600 font-medium transition-all inline-flex items-center gap-1">
            <i class="fas fa-rotate-left"></i> Start over
          </button>
          <button type="button" id="chat-finish-btn" class="w-full mt-4 py-3 rounded-xl bg-gradient-to-r <?= $tc[
              "gradient"
          ] ?> text-white text-sm font-medium shadow-lg hover:from-<?= $tc[
     "hex"
 ] ?> hover:to-<?= $tc["hex"] ?> transition-all active:scale-[0.98]">
            <i class="fas fa-check mr-1.5"></i>Finish & Submit
          </button>
        </div>
      </div>
<div class="hidden p-2" id="chat-skip-area">
        <div class="flex justify-center">
          <button type="button" id="chat-skip-btn" class="text-[10px] font-medium transition-all flex items-center gap-1" style="color:<?= $tc[
              "hex"
          ] ?>">
            <i class="fas fa-forward"></i> Skip this question
          </button>
        </div>
      </div>
      </div>
    </div>
  </div>
</div>

<!-- Hidden form for submission -->
<form method="POST" action="<?= url(
    "/survey/take/" . ($survey["id"] ?? ""),
) ?>" id="chat-submit-form" class="hidden">
  <?= csrf() ?>
  <input type="hidden" name="survey_id" value="<?= $survey["id"] ?? "" ?>">
  <?php if (
      !empty($responseId)
  ): ?><input type="hidden" name="response_id" value="<?= (int) $responseId ?>"><?php endif; ?>
  <input type="hidden" name="chat_responses" id="chat-responses-input" value="">
  <input type="hidden" name="device_fingerprint" value="">
  <input type="hidden" name="tab_switches" value="0">
  <input type="hidden" name="_inactive_seconds" value="0">
  <input type="hidden" name="_behavior_log" value="">
  <input type="hidden" name="survey_type" value="chat">
</form>

<style>
#chat-messages { scroll-behavior: smooth; }
#chat-messages::-webkit-scrollbar { width: 4px; }
#chat-messages::-webkit-scrollbar-thumb { background: <?= $tc[
    "hex"
] ?>30; border-radius: 2px; }
#chat-messages::-webkit-scrollbar-track { background: transparent; }

.chat-msg { animation: msgIn 0.4s cubic-bezier(0.34,1.56,0.64,1) both; }
@keyframes msgIn { from { opacity: 0; transform: translateY(16px) scale(0.97); } to { opacity: 1; transform: translateY(0) scale(1); } }
.chat-msg.bot .bot-bubble { animation: bubblePop 0.35s cubic-bezier(0.34,1.56,0.64,1) both; transform-origin: bottom left; }
@keyframes bubblePop { from { opacity: 0; transform: scale(0.85) translateX(-8px); } to { opacity: 1; transform: scale(1) translateX(0); } }
.chat-msg.user-msg .user-bubble { animation: bubbleSlide 0.3s cubic-bezier(0.34,1.56,0.64,1) both; transform-origin: bottom right; }
@keyframes bubbleSlide { from { opacity: 0; transform: scale(0.85) translateX(8px); } to { opacity: 1; transform: scale(1) translateX(0); } }
.bot-bubble { border-bottom-left-radius: 4px; box-shadow: 0 1px 3px rgba(0,0,0,0.04); }
.user-bubble { border-bottom-right-radius: 4px; box-shadow: 0 2px 8px <?= $tc[
    "hex"
] ?>25; }
.bot-bubble, .user-bubble { white-space: pre-wrap; word-break: break-word; }
.chat-msg.bot .bot-bubble { display: inline-block; width: max-content; max-width: 100%; align-self: flex-start; }
.chat-msg.bot .msg-time { align-self: flex-start; }

.choice-chip:focus-visible, .rating-btn:focus-visible, #chat-send-btn:focus-visible {
  outline: 2px solid <?= $tc["hex"] ?>80;
  outline-offset: 2px;
}

/* Message merge logic - using data-merge attribute instead of sibling selector */
.chat-msg[data-merge="true"] .msg-avatar { visibility: hidden; }
.chat-msg[data-merge="true"] .msg-time { display: none; }
.chat-msg[data-merge="true"] { margin-top: -6px; }
.chat-msg.bot[data-merge="true"] .bot-bubble { border-top-left-radius: 12px; animation: none; }
.chat-msg.user-msg[data-merge="true"] { margin-top: -4px; }
.chat-msg.user-msg[data-merge="true"] .user-bubble { border-top-right-radius: 12px; animation: none; }

.typing-dots { display: inline-flex; gap: 4px; align-items: center; padding: 6px 0; }
.typing-dots span { width: 7px; height: 7px; border-radius: 50%; animation: dotBounce 1.4s ease-in-out infinite both; }
.typing-dots span:nth-child(1) { animation-delay: 0s; }
.typing-dots span:nth-child(2) { animation-delay: 0.2s; }
.typing-dots span:nth-child(3) { animation-delay: 0.4s; }
@keyframes dotBounce { 0%,80%,100% { transform: translateY(0) scale(0.6); opacity: 0.3; } 40% { transform: translateY(-8px) scale(1); opacity: 1; } }

.choice-chip { transition: all 0.2s cubic-bezier(0.34,1.56,0.64,1); cursor: pointer; position: relative; overflow: hidden; }
.choice-chip::after { content: ''; position: absolute; inset: 0; background: currentColor; opacity: 0; transition: opacity 0.2s; border-radius: inherit; }
.choice-chip:hover { transform: translateY(-2px) scale(1.03); box-shadow: 0 4px 16px rgba(0,0,0,0.08); }
.choice-chip:hover::after { opacity: 0.06; }
.choice-chip:active { transform: translateY(0) scale(0.97); }

.rating-btn { transition: all 0.2s cubic-bezier(0.34,1.56,0.64,1); }
.rating-btn:hover { transform: scale(1.15); box-shadow: 0 4px 12px <?= $tc[
    "hex"
] ?>25; }
.rating-btn:active { transform: scale(0.9); }
.rating-btn.selected { background: <?= $tc[
    "hex"
] ?> !important; color: #fff; border-color: <?= $tc["hex"] ?> !important; }

#chat-send-btn { transition: all 0.2s cubic-bezier(0.34,1.56,0.64,1); }
#chat-send-btn:hover { transform: scale(1.08); filter: brightness(1.1); }
#chat-send-btn:active { transform: scale(0.92); }
#chat-send-btn:disabled { opacity: 0.4; }

#chat-finish-btn { animation: finishPulse 2s ease-in-out infinite; }
@keyframes finishPulse { 0%,100% { box-shadow: 0 4px 16px rgba(16,185,129,0.3); } 40% { box-shadow: 0 4px 24px rgba(16,185,129,0.5); } }

#chat-input { transition: height 0.1s ease; }
#chat-input:focus { outline: none; }

.chat-msg.bot .bot-bubble:has(.fa-brain) { animation: brainGlow 2s ease-in-out infinite; }
@keyframes brainGlow { 0%,100% { border-color: <?= $tc[
    "hex"
] ?>20; } 50% { border-color: <?= $tc["hex"] ?>50; } }

#chat-choices-container { animation: slideUp 0.25s cubic-bezier(0.34,1.56,0.64,1) both; }
@keyframes slideUp { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }

.online-pulse { animation: onlinePulse 2s ease-in-out infinite; }
@keyframes onlinePulse { 0%,100% { box-shadow: 0 0 0 0 rgba(52,211,153,0.6); } 50% { box-shadow: 0 0 0 4px rgba(52,211,153,0); } }

.spin-slow { animation: spin 0.8s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }

.done-pop { animation: donePop 0.5s cubic-bezier(0.34,1.56,0.64,1) both; }
@keyframes donePop { from { opacity: 0; transform: scale(0.92) translateY(10px); } to { opacity: 1; transform: scale(1) translateY(0); } }

#chat-messages { box-shadow: inset 0 -8px 12px -10px rgba(0,0,0,0.06); }

.choice-chip.selected { background: <?= $tc[
    "hex"
] ?> !important; color: #fff !important; border-color: <?= $tc[
     "hex"
 ] ?> !important; transform: translateY(-1px) scale(1.02); }

.animate-scale-in { animation: animateScaleIn 0.3s cubic-bezier(0.4, 0, 0.2, 1) both; }
@keyframes animateScaleIn { from { opacity: 0; transform: scale(0.95) translateY(4px); } to { opacity: 1; transform: scale(1) translateY(0); } }

@keyframes loaderBar { 0% { width: 0%; margin-left: 0; } 50% { width: 70%; margin-left: 15%; } 100% { width: 0%; margin-left: 100%; } }
</style>

<script src="https://js.puter.com/v2/"></script>
<script>
window.onerror = function(m,s,l,c,err) { console.error('[Chat]', m, err); var app=document.getElementById('chat-app'); if(app) app.innerHTML='<div class="p-8 text-center text-red-500">Something went wrong. Please refresh and try again.<br><span class="text-xs text-gray-400">'+escapeHtml(m)+'</span></div>'; return true; };
window.addEventListener('unhandledrejection',function(e){ console.error('[Chat] Unhandled:', e.reason); });
(function() {
  'use strict';
  try {

  // ============================================================
  // CONFIG
  // ============================================================
  const chatConfig = <?= json_encode($chatConfig ?? []) ?>;
  if (typeof chatConfig !== 'object' || chatConfig === null) { console.error('Invalid chatConfig'); return; }
  const nodes = chatConfig.nodes || [];
  const responseId = '<?= $responseId ?? "" ?>';
  const surveyId = '<?= $survey["id"] ?? "" ?>';
  const formAction = '<?= url("/survey/take/" . ($survey["id"] ?? "")) ?>';
  const csrfToken = document.querySelector('#chat-submit-form input[name="_csrf_token"]')?.value || '';
  const aiConfig = <?= json_encode(
      ai_config_strip(
          $aiConfig ?? [
              "provider" => "pollinations",
              "model" => "",
              "capabilities" => [],
              "system_prompt" => "",
              "temperature" => 0.7,
              "max_tokens" => 500,
          ],
      ),
  ) ?>;
  const aiProvider = aiConfig.provider || 'pollinations';
  const baseUrl = '<?= rtrim(url(""), "/") ?>';
  const MAX_RETRIES = 5;
  const themeColor = '<?= $tc["hex"] ?>';

  // ========== DOM ==========
  const messagesEl = document.getElementById('chat-messages');
  const inputEl = document.getElementById('chat-input');
  const sendBtn = document.getElementById('chat-send-btn');
  const inputArea = document.getElementById('chat-input-area');
  const doneArea = document.getElementById('chat-done-area');
  const finishBtn = document.getElementById('chat-finish-btn');
  const progressEl = document.getElementById('chat-q-current');
  const progressBar = document.getElementById('chat-progress-bar');
  const currentHeaderEl = document.getElementById('chat-q-current-header');
  const totalHeaderEl = document.getElementById('chat-q-total-header');
  let choicesContainer = null;
  const skipArea = document.getElementById('chat-skip-area');
  const skipBtn = document.getElementById('chat-skip-btn');
  const finalCountEl = document.getElementById('chat-final-count');
  const charsRemainingEl = document.getElementById('chat-chars-remaining');
  const validatingEl = document.getElementById('chat-validating');
  const sendIcon = document.querySelector('#chat-send-btn .send-icon');
  const sendSpinner = document.querySelector('#chat-send-btn .send-spinner');
  const restartBtn = document.getElementById('chat-restart-btn');
  const progressPercentEl = document.getElementById('chat-progress-percent');
  if (!messagesEl || !inputEl || !sendBtn) { console.error('Chat DOM missing'); return; }

  const introText = chatConfig.intro_message || "Hello! I'll be asking you some questions today. There are no right or wrong answers — just share your thoughts.";
  if (totalHeaderEl) totalHeaderEl.textContent = nodes.length;

  // ========== State ==========
  let currentNodeIndex = -1;
  let currentNode = null;
  let responses = {};
  let conversation = [];
  let isProcessing = false;
  let currentTryCount = 0;
  let currentQuestionMessages = [];
  let pendingCorrection = null;
  let lastRole = 'bot'; // track last message role for merging
  let tabSwitches = 0;
  let behaviorLog = [];
  let lastActivityMs = Date.now();

  function pushBehavior(eventType, eventData) {
    behaviorLog.push({
      event_type: eventType,
      event_data: eventData || {},
      timestamp_ms: Date.now(),
      question_index: Math.max(0, currentNodeIndex)
    });
    if (behaviorLog.length > 200) behaviorLog = behaviorLog.slice(-200);
  }

  function markActivity() {
    lastActivityMs = Date.now();
  }

  document.addEventListener('visibilitychange', function() {
    if (document.hidden) {
      tabSwitches += 1;
      pushBehavior('tab_switch', { action: 'switched_away' });
    } else {
      pushBehavior('tab_switch', { action: 'returned' });
      markActivity();
    }
  });

  window.addEventListener('blur', function() { pushBehavior('focus_loss', { action: 'blur' }); });
  window.addEventListener('focus', function() { pushBehavior('focus_loss', { action: 'focus' }); markActivity(); });
  document.addEventListener('click', markActivity, true);
  document.addEventListener('keydown', markActivity, true);
  document.addEventListener('mousemove', markActivity, true);

  // ========== Auto-resize textarea ==========
  function autoResize() {
    inputEl.style.height = 'auto';
    var h = inputEl.scrollHeight;
    var max = parseInt(inputEl.style.maxHeight) || 128;
    inputEl.style.height = Math.min(h, max) + 'px';
    var remaining = 2000 - inputEl.value.length;
    var warnEl = document.getElementById('chat-char-warning');
    if (charsRemainingEl) {
      if (remaining < 50) {
        charsRemainingEl.textContent = remaining + ' chars left';
        charsRemainingEl.style.color = '<?= $tc["hex"] ?>';
        if (warnEl) warnEl.classList.remove('hidden');
      } else if (remaining < 200) {
        charsRemainingEl.textContent = remaining + ' chars left';
        charsRemainingEl.style.color = '#f59e0b';
        if (warnEl) warnEl.classList.add('hidden');
      } else {
        charsRemainingEl.textContent = '';
        if (warnEl) warnEl.classList.add('hidden');
      }
    }
    sendBtn.disabled = isProcessing || !inputEl.value.trim();
  }
  inputEl.addEventListener('input', autoResize);

  function showProcessing(on) {
    isProcessing = on;
    sendBtn.disabled = on || !inputEl.value.trim();
    inputEl.disabled = on;
    if (sendIcon) sendIcon.classList.toggle('hidden', on);
    if (sendSpinner) sendSpinner.classList.toggle('hidden', !on);
    if (validatingEl) {
      validatingEl.classList.toggle('hidden', !on);
      validatingEl.classList.toggle('flex', on);
    }
  }

  // ============================================================
  // AI RESPONSE PARSING
  // ============================================================
  function parseAIResponse(text) {
    if (!text || !text.trim()) return { action: 'accept', message: '' };
    var t = text.trim();
    var prefixes = [
      { rx: /^ACCEPT:\s*/i, action: 'accept' },
      { rx: /^EXPLAIN:\s*/i, action: 'explain' },
      { rx: /^CLARIFY:\s*/i, action: 'clarify' },
      { rx: /^CONFIRM:\s*/i, action: 'confirm' },
      { rx: /^RETRY:\s*/i, action: 'retry' },
      { rx: /^OFFER_SKIP:\s*/i, action: 'offer_skip' }
    ];
    for (var i = 0; i < prefixes.length; i++) {
      if (prefixes[i].rx.test(t)) {
        return { action: prefixes[i].action, message: t.replace(prefixes[i].rx, '').trim() };
      }
    }
    return { action: 'accept', message: t };
  }

  function buildValidationPrompt(node, answer) {
    var qType = node.type || 'text';
    var typeHint = '';
    if (qType === 'number') typeHint = 'The expected answer is a number.';
    else if (qType === 'text' || qType === 'textarea') typeHint = 'The expected answer is a thoughtful text response.';
    var scope = Array.isArray(node.answer_scope) ? node.answer_scope.filter(Boolean) : [];
    var scopeType = node.scope_type || 'absolute';
    var scopeLabel = node.scope_label || '';
    var scopeRule = '';
    if (scope.length) {
      if (scopeType === 'near') {
        scopeRule = '\nAnswer anchors (lenient): ' + JSON.stringify(scope) + '. These are examples of acceptable answers. Accept any answer that is SEMANTICALLY RELATED or NEARBY in meaning to these anchors. Broader, narrower, or synonymous concepts are all fine.';
      } else if (scopeType === 'set' && scopeLabel) {
        scopeRule = '\nAccepted answer scope (category: ' + scopeLabel + '): ' + JSON.stringify(scope) + '. The answer must be a valid member of this category. If the answer is clearly a misspelling of one item, use CONFIRM with only the corrected item. Reject items that do not belong to this category.';
      } else {
        scopeRule = '\nAccepted answer scope (strict): ' + JSON.stringify(scope) + '. Reject answers outside this scope. If the answer is clearly a misspelling of one item, use CONFIRM with only the corrected item.';
      }
    }
    var context = '';
    var caps = aiConfig.capabilities || [];
    var hasContext = caps.indexOf('context_awareness') !== -1 || caps.indexOf('context') !== -1;
    if (hasContext && conversation.length > 0) {
      context = '\nFull conversation history (previous questions and answers for context):\n';
      for (var ci = 0; ci < conversation.length; ci++) {
        var c = conversation[ci];
        context += (c.role === 'bot' ? 'Assistant: ' : 'Respondent: ') + c.message + '\n';
      }
    }
    return 'You are a strict but helpful survey assistant. Your job is to validate answers and guide the respondent.\n\n' +
      'Current question: "' + (node.question || '') + '" (type: ' + qType + ')' +
      scopeRule + context +
      '\nNew answer from respondent: "' + answer + '"\n\n' +
      'IMPORTANT — Decide what to do. Respond with EXACTLY one prefix line followed by your message:\n\n' +
      'ACCEPT: Use ONLY when the answer genuinely and meaningfully addresses the question. The answer must be RELEVANT to what was asked. Follow with a brief warm acknowledgment (max 1 sentence) that restates key information from the answer and transitions to next topic.\n\n' +
      'RETRY: Use when the answer is gibberish, meaningless, outside the accepted answer scope, just a single random character/letter, keyboard smash (like "asdf", "qqq", "jjjj"), or completely non-responsive. Follow with a gentle prompt asking for a real answer (max 1 sentence).\n\n' +
      'CONFIRM: Use when the answer is relevant but contains a clear likely spelling mistake. After the prefix output ONLY the corrected answer, not a sentence. Never correct names, opinions, or uncertain wording.\n\n' +
      'EXPLAIN: Use when the answer is OFF-TOPIC or shows the respondent clearly misunderstood what was being asked. Follow with a clarifying rephrasing of the question and an example of what kind of answer is expected (1-2 sentences). Help them narrow down.\n\n' +
      'EXAMPLES of what to ACCEPT vs REJECT:\n' +
      '- Question "where are you?" → ACCEPT "at home", "in New York", "outside", "park", "school" | REJECT "good", "fine", "yes", "no", "w", "x", "ok" (these do NOT answer "where")\n' +
      '- Question "how do you feel?" → ACCEPT "happy", "tired", "stressed", "great" | REJECT "red", "chair", "w", "asdf", "yes" (these do NOT answer "how feel")\n' +
      '- Question "who are you?" → ACCEPT "a student", "John", "I am a teacher" | REJECT "good", "fine", "w", "x", "asdf" (these do NOT answer "who")\n\n' +
      'Rules:\n' +
      '- The answer MUST be RELEVANT to the specific question asked. An answer that could work for any question is NOT acceptable (e.g., "good" is not a valid answer for "where are you?").\n' +
      '- Single characters, random letters, or gibberish are ALWAYS rejected with RETRY.\n' +
      '- Off-topic answers that show misunderstanding get EXPLAIN (clarify + guide).\n' +
      '- Never ACCEPT a likely misspelling when a clear correction exists; use CONFIRM.\n' +
      '- Be warm and helpful, but firm about answer quality.';
  }

  // ============================================================
  // NAVIGATION
  // ============================================================
  function getNextNodeIndex() {
    if (nodes.length === 0) return -1;
    var nextIdx = currentNodeIndex + 1;
    while (nextIdx < nodes.length) {
      var node = nodes[nextIdx];
      if (node.condition && node.condition.field && node.condition.value) {
        var prevAnswer = (responses[node.condition.field] || '').toLowerCase();
        var condValue = node.condition.value.toLowerCase();
        if (node.condition.operator === 'contains' && prevAnswer.indexOf(condValue) === -1) { nextIdx++; continue; }
        if (node.condition.operator === 'not_contains' && prevAnswer.indexOf(condValue) !== -1) { nextIdx++; continue; }
        if (node.condition.operator === 'equals' && prevAnswer !== condValue) { nextIdx++; continue; }
      }
      return nextIdx;
    }
    return nodes.length;
  }

  // ============================================================
  // LOCAL VALIDATION
  // ============================================================
  function localValidate(node, answer) {
    var q = (node.question || '').toLowerCase();
    var a = answer.toLowerCase().trim();
    if (a.length <= 1) return { action: 'retry', message: 'Please provide a more complete answer.' };
    if (/(.)\1{2,}/.test(a)) return { action: 'retry', message: 'Please type a real answer.' };
    var qCore = q.replace(/^(what|where|who|when|why|how|do|does|did|is|are|can)\s+/i, '').substring(0, 8);
    if (qCore.length >= 4 && a.indexOf(qCore) >= 0) return { action: 'explain', message: 'Please answer in your own words rather than repeating the question.' };
    var confusionPhrases = ['i dont know', "i don't know", 'i dunno', 'not sure', "i don't understand", 'i dont understand', "i don't get", 'i dont get', "i'm confused", 'im confused', 'i am confused', 'i dont know what', "i don't know what", 'i dont', "i don't"];
    function hasConfusion(val) { for (var ci = 0; ci < confusionPhrases.length; ci++) { if (val.indexOf(confusionPhrases[ci]) >= 0) return true; } return false; }
    var naWhereWho = ['good', 'bad', 'ok', 'okay', 'fine', 'yes', 'no', 'maybe', 'idk', 'dunno', 'sure', 'nice', 'cool', 'great', 'awesome', 'wow', 'lol', 'lmao', 'xd', 'hmm', 'meh', 'whatever', 'nothing', 'nope', 'yeah', 'nah', 'yep', 'perhaps'];
    if (q.indexOf('where') >= 0) { if (naWhereWho.indexOf(a) !== -1 || hasConfusion(a)) return { action: 'explain', message: 'I asked about your location. Could you tell me where you are, like "at home", "in the office", or a city name?' }; }
    if (q.indexOf('who') >= 0) { if (naWhereWho.indexOf(a) !== -1 || hasConfusion(a)) return { action: 'explain', message: 'I asked who someone is. Could you share their name or describe who they are?' }; }
    if (hasConfusion(a)) return { action: 'explain', message: 'No problem! Take your time. The question is: "' + (node.question || '') + '". Just share whatever comes to mind.' };
    return null;
  }

  function normalizeScopeAnswer(value) {
    return String(value || '').toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]/g, '');
  }

  function editDistance(a, b) {
    var row = [];
    for (var j = 0; j <= b.length; j++) row[j] = j;
    for (var i = 1; i <= a.length; i++) {
      var previous = row[0];
      row[0] = i;
      for (var k = 1; k <= b.length; k++) {
        var saved = row[k];
        row[k] = Math.min(row[k] + 1, row[k - 1] + 1, previous + (a[i - 1] === b[k - 1] ? 0 : 1));
        previous = saved;
      }
    }
    return row[b.length];
  }

  function validateAnswerScope(node, answer) {
    var scope = Array.isArray(node.answer_scope) ? node.answer_scope.filter(Boolean) : [];
    if (scope.length === 0) return null;
    var scopeType = node.scope_type || 'absolute';

    if (scopeType === 'near') return null;

    var normalized = normalizeScopeAnswer(answer);
    var closest = null;
    var closestDistance = Infinity;
    for (var i = 0; i < scope.length; i++) {
      var candidate = normalizeScopeAnswer(scope[i]);
      if (normalized === candidate) return { action: 'accept', canonical: scope[i] };
      var distance = editDistance(normalized, candidate);
      if (distance < closestDistance) { closestDistance = distance; closest = scope[i]; }
    }
    var closestNormalized = normalizeScopeAnswer(closest);
    var threshold = Math.max(1, Math.floor(closestNormalized.length * 0.25));
    if (normalized.length >= 3 && closestNormalized.length >= 3 && normalized[0] === closestNormalized[0] && closestDistance <= threshold) {
      return { action: 'confirm', canonical: closest };
    }
    if (scopeType === 'set' && node.scope_label) {
      return { action: 'retry', message: 'Please answer with a valid ' + node.scope_label + ' (e.g. ' + scope.slice(0, 3).join(', ') + ').' };
    }
    return { action: 'retry', message: 'Please answer with one of: ' + scope.join(', ') + '.' };
  }

  // ============================================================
  // ANSWER PROCESSING
  // ============================================================
  function processAnswer(answer) {
    if (isProcessing) return;
    if (!answer || !answer.toString().trim()) { addBotMessage('Please type something to continue.'); return; }
    var a = answer.toString().trim();

    if (pendingCorrection) {
      addUserMessage(a);
      if (/^(yes|y|yeah|yep|correct|confirm)$/i.test(a)) {
        var correctedAnswer = pendingCorrection;
        pendingCorrection = null;
        addBotMessage('Thanks — I’ll record that as "' + correctedAnswer + '".');
        proceedWithAnswer(correctedAnswer);
      } else if (/^(no|n|nope|incorrect)$/i.test(a)) {
        pendingCorrection = null;
        addBotMessage('No problem. Please type your answer again.');
      } else {
        addBotMessage('Please answer Yes or No, or choose No to re-enter your answer.');
      }
      return;
    }

    addUserMessage(a);
    var scopeResult = validateAnswerScope(currentNode, a);
    if (scopeResult) {
      if (scopeResult.action === 'accept') { proceedWithAnswer(scopeResult.canonical); return; }
      if (scopeResult.action === 'confirm') {
        pendingCorrection = scopeResult.canonical;
        addBotMessage('Did you mean "' + scopeResult.canonical + '"? Please answer Yes or No.');
        return;
      }
      addBotMessage(scopeResult.message);
      currentTryCount++;
      if (currentTryCount >= MAX_RETRIES) { addBotMessage('Would you like to skip this question?'); showSkipButton(); }
      return;
    }

    if (['file_upload', 'file', 'image'].indexOf(currentNode.type) !== -1) { proceedWithAnswer(a); return; }
    if (['choice', 'rating', 'yes_no', 'mcq_single', 'mcq_multiple', 'likert5', 'nps'].indexOf(currentNode.type) !== -1) { proceedWithAnswer(a); return; }
    if (currentNode.type === 'number' && /^-?\d*\.?\d+$/.test(a)) { proceedWithAnswer(a); return; }

    var localResult = localValidate(currentNode, a);
    if (localResult) {
      if (localResult.action === 'retry') {
        addBotMessage(localResult.message);
        currentTryCount++;
        if (currentTryCount >= MAX_RETRIES) { addBotMessage('Would you like to skip this question?'); showSkipButton(); }
      } else if (localResult.action === 'explain') { addBotMessage(localResult.message); }
      return;
    }
    validateWithAI(a);
  }

  // ============================================================
  // AI VALIDATION
  // ============================================================
  var AI_PROVIDERS = [
    function(prompt) {
      return fetch('https://text.pollinations.ai/openai', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [{role: 'system', content: 'You are a smart survey response validator. Respond ONLY with a prefix (ACCEPT, CONFIRM, RETRY, or EXPLAIN) followed by the required content.'}, {role: 'user', content: prompt}],
          model: 'openai', temperature: 0.3, max_tokens: 200
        })
      }).then(function(r) { return r.json(); }).then(function(data) { return data && data.choices && data.choices[0] ? data.choices[0].message.content : null; });
    },
    function(prompt) {
      return new Promise(function(resolve) {
        if (typeof puter === 'undefined' || !puter.ai) { resolve(null); return; }
        puter.ai.chat(prompt, { model: 'gemini-3.5-flash', max_tokens: 200, temperature: 0.3 })
          .then(function(r) { if (r && r.message && r.message.content) { resolve(r.message.content); return; } if (typeof r === 'string') { resolve(r); return; } resolve(null); })
          .catch(function() { resolve(null); });
      });
    },
    function(prompt) {
      var paidProviders = ['openai', 'claude', 'gemini', 'deepseek'];
      if (paidProviders.indexOf(aiConfig.provider) === -1) return Promise.resolve(null);
      return fetch(baseUrl + '/api/ai/chat', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          provider: aiConfig.provider, response_id: responseId, model: aiConfig.model || '',
          messages: [{role: 'user', content: prompt}],
          system_prompt: 'You are a smart survey response validator. Respond ONLY with a prefix (ACCEPT, CONFIRM, RETRY, or EXPLAIN) followed by the required content.',
          temperature: 0.3, max_tokens: 200
        })
      }).then(function(r) { return r.json(); }).then(function(data) { if (data && data.success && data.text) return data.text; return null; });
    }
  ];

  function validateWithAI(answer) { showProcessing(true); showTyping(); tryNextProvider(buildValidationPrompt(currentNode, answer), answer, 0); }

  function isAIError(text) {
    if (!text) return false;
    // Normalize: replace smart quotes, normalize whitespace, lowercase
    var tl = text.replace(/[\u2018\u2019\u201c\u201d]/g, '"').replace(/\s+/g, ' ').toLowerCase().trim();

    // Quick length heuristic: very long messages with technical content are likely errors
    if (text.length > 300) {
      var techKeywords = ['error', 'exception', 'stack trace', 'undefined', 'null reference', 'at line', 'function', 'module', 'provider', 'api', 'endpoint', 'timeout', 'rate limit', 'quota', 'invalid', 'malformed', 'parsing', 'syntax'];
      var techCount = 0;
      for (var k = 0; k < techKeywords.length; k++) {
        if (tl.indexOf(techKeywords[k]) !== -1) techCount++;
      }
      if (techCount >= 3) return true;
    }

    // Keyword matching (expanded)
    var keywords = [
      'cannot read', 'can\'t read', 'does not support', 'doesn\'t support', 'not supported',
      'error:', 'api error', 'model error', 'i can\'t', 'i cannot', 'i am unable', 'unable to',
      'not able to', 'cannot process', 'inform the user', 'as an ai', 'only text', 'image input',
      'vision', 'file input', 'sorry, but i', 'i\'m sorry', 'i am sorry', 'please provide a valid',
      'failed to', 'failure', 'unavailable', 'temporarily', 'rate limit', 'quota exceeded',
      'bad request', 'internal server', 'service unavailable', 'gateway timeout',
      'provider error', 'upstream', 'downstream', 'malformed', 'invalid input',
      'unsupported format', 'unsupported media', 'content type', 'multipart'
    ];
    for (var ei = 0; ei < keywords.length; ei++) {
      if (tl.indexOf(keywords[ei]) !== -1) return true;
    }

    // Regex patterns for common error formats
    var errorPatterns = [
      /cannot read\s+["']?[\w\-.]+\.(png|jpg|jpeg|gif|webp|pdf|doc|mp4|mov)["']?/i,
      /does not support\s+image\s+input/i,
      /model does not support/i,
      /unsupported.*(image|file|media)/i,
      /inform the user/i,
      /error\s*[:\(]/i,
      /exception\s*[:\(]/i,
      /stack\s+trace/i,
      /at\s+\w+\.\w+\s*\(/i,  // stack trace line
      /provider.*(error|fail|unavailable)/i
    ];
    for (var pi = 0; pi < errorPatterns.length; pi++) {
      if (errorPatterns[pi].test(text)) return true;
    }

    return false;
  }

  function tryNextProvider(prompt, answer, idx) {
    if (idx >= AI_PROVIDERS.length) { handleAIValidation(null, answer); return; }
    AI_PROVIDERS[idx](prompt).then(function(text) {
      if (text && !isAIError(text)) handleAIValidation(text, answer);
      else tryNextProvider(prompt, answer, idx + 1);
    }).catch(function() { tryNextProvider(prompt, answer, idx + 1); });
  }

  function handleAIValidation(response, answer) {
    hideTyping(); showProcessing(false);
    if (!response) { addBotMessage('Got it, thanks!'); currentQuestionMessages.push(answer); proceedWithAnswer(currentQuestionMessages.length === 1 ? currentQuestionMessages[0] : currentQuestionMessages); return; }
    var parsed = parseAIResponse(response);
    // Never surface raw model/provider error text to the respondent.
    if (isAIError(parsed.message)) {
      parsed.message = '';
      if (parsed.action === 'retry' || parsed.action === 'explain' || parsed.action === 'clarify') parsed.action = 'accept';
    }
    switch (parsed.action) {
      case 'accept': currentQuestionMessages.push(answer); if (parsed.message && parsed.message.length > 2) addBotMessage(parsed.message); proceedWithAnswer(currentQuestionMessages.length === 1 ? currentQuestionMessages[0] : currentQuestionMessages); break;
      case 'retry': currentQuestionMessages = []; if (parsed.message) addBotMessage(parsed.message); currentTryCount++; if (currentTryCount >= MAX_RETRIES) { addBotMessage('Would you like to skip this question?'); showSkipButton(); } break;
      case 'confirm':
        var correction = (parsed.message || '').replace(/^did you mean\s*/i, '').replace(/^["']|["'?.]$/g, '').trim();
        if (correction) { pendingCorrection = correction; addBotMessage('Did you mean "' + correction + '"? Please answer Yes or No.'); }
        else { addBotMessage('Please check the spelling and type your answer again.'); }
        break;
      case 'explain': currentQuestionMessages.push(answer); if (parsed.message) addBotMessage(parsed.message); break;
      case 'clarify': if (parsed.message) addBotMessage(parsed.message); break;
      case 'offer_skip': if (parsed.message) addBotMessage(parsed.message); showSkipButton(); break;
      default: currentQuestionMessages.push(answer); proceedWithAnswer(currentQuestionMessages.length === 1 ? currentQuestionMessages[0] : currentQuestionMessages);
    }
  }

  function proceedWithAnswer(answer) {
    var key = currentNode.key || ('q_' + currentNodeIndex);
    responses[key] = answer;
    currentNodeIndex = getNextNodeIndex();
    updateProgress();
    if (currentNodeIndex >= nodes.length) {
      showTyping();
      setTimeout(function() {
        hideTyping();
        addBotMessage('Thank you for completing the survey! Click "Finish & Submit" to save your responses.');
        showDoneButton();
      }, 800);
    } else {
      showTyping();
      setTimeout(function() {
        hideTyping();
        renderNode(nodes[currentNodeIndex]);
      }, 600 + Math.random() * 400);
    }
  }

  function handleSkip() {
    if (isProcessing) return;
    hideSkipButton();
    addUserMessage('[Skipped]');
    proceedWithAnswer('[SKIPPED]');
  }

  // ============================================================
  // RENDER
  // ============================================================
  function renderNode(node) {
    currentNode = node;
    currentTryCount = 0;
    currentQuestionMessages = [];
    pendingCorrection = null;
    hideSkipButton();
    hideChoices();
    var question = (node.question || '').trim();
    var duplicatesIntro = currentNodeIndex === 0 && question.toLowerCase() === introText.trim().toLowerCase();
    if (question && !duplicatesIntro) addBotMessage(question);
    renderNodeInput(node);
  }

  function renderNodeInput(node) {
    inputArea.classList.add('hidden');
    if (node.type === 'choice' && node.options && node.options.length > 0) showChoiceInput(node.options);
    else if (node.type === 'rating' || node.type === 'likert5' || node.type === 'nps') {
      var ratingOpts = node.options;
      if (!ratingOpts || ratingOpts.length === 0) {
        if (node.type === 'nps') ratingOpts = ['0','1','2','3','4','5','6','7','8','9','10'];
        else if (node.type === 'likert5') ratingOpts = ['Strongly Disagree','Disagree','Neutral','Agree','Strongly Agree'];
        else ratingOpts = ['1','2','3','4','5'];
      }
      showRatingInput(ratingOpts);
    } else if (node.type === 'yes_no') showChoiceInput(['Yes', 'No']);
    else if (node.type === 'mcq_single' || node.type === 'mcq_multiple') {
      if (node.options && node.options.length > 0) showChoiceInput(node.options);
      else showTextInput(true, 'text');
    } else if (['file_upload', 'file', 'image'].indexOf(node.type) !== -1) {
      showTextInput(true, 'text');
      inputEl.placeholder = 'Describe the file or paste a link (e.g. "report.pdf" or a URL)…';
      addBotMessage('Since I can\'t receive files directly, just describe the file or paste a link and I\'ll record your answer.');
    } else showTextInput(true, node.type === 'number' ? 'number' : 'text');
  }

  // ============================================================
  // UI HELPERS
  // ============================================================
  function addBotMessage(text) {
    conversation.push({ role: 'bot', message: text });
    var ts = new Date();
    var timeStr = ts.getHours().toString().padStart(2,'0') + ':' + ts.getMinutes().toString().padStart(2,'0');
    var typingEl = document.getElementById('typing-indicator');
    var lastMsg = typingEl ? typingEl.previousElementSibling : messagesEl.lastElementChild;
    var merge = lastRole === 'bot' && lastMsg && lastMsg.dataset.role === 'bot';

    var div = typingEl || document.createElement('div');
    if (typingEl) typingEl.removeAttribute('id');
    div.className = 'flex items-start gap-3 chat-msg bot';
    div.dataset.role = 'bot';
    div.dataset.merge = merge ? 'true' : 'false';
    div.innerHTML = '<div class="w-8 h-8 rounded-xl bg-gradient-to-br <?= $tc[
        "gradient"
    ] ?> flex items-center justify-center text-white text-xs flex-shrink-0 shadow-sm mt-0.5 msg-avatar' + (merge ? ' invisible' : '') + '"><i class="fas fa-robot"></i></div><div class="flex flex-col max-w-[80%] items-start"><div class="bot-bubble rounded-2xl px-4 py-3 text-sm leading-relaxed" style="background:<?= $tc[
     "hex"
 ] ?>0a;border:1px solid <?= $tc[
    "hex"
] ?>15;color:<?= $textColor ?>;border-bottom-left-radius:8px;box-shadow:0 2px 8px rgba(0,0,0,0.04)">' + escapeHtml(text) + '</div><span class="msg-time text-[9px] text-gray-400 mt-1 ml-1' + (merge ? ' hidden' : '') + '">' + timeStr + '</span></div>';
    if (merge) div.style.marginTop = '-6px';
    if (!typingEl) messagesEl.appendChild(div);
    scrollToBottom();
    lastRole = 'bot';
  }

  function addUserMessage(text) {
    conversation.push({ role: 'user', message: text });
    var ts = new Date();
    var timeStr = ts.getHours().toString().padStart(2,'0') + ':' + ts.getMinutes().toString().padStart(2,'0');

    hideChoices();

    var lastMsg = messagesEl.lastElementChild;
    var merge = lastRole === 'user' && lastMsg && lastMsg.dataset.role === 'user';

    var div = document.createElement('div');
    div.className = 'flex items-start gap-3 chat-msg justify-end user-msg';
    div.dataset.role = 'user';
    div.dataset.merge = merge ? 'true' : 'false';
    div.innerHTML = '<div class="flex flex-col items-end max-w-[80%]"><div class="user-bubble rounded-2xl px-4 py-3 text-sm leading-relaxed bg-gradient-to-br <?= $tc[
        "gradient"
    ] ?> text-white shadow-sm" style="border-bottom-right-radius:8px">' + escapeHtml(text) + '</div><span class="msg-time text-[9px] text-gray-400 mt-1 mr-1' + (merge ? ' hidden' : '') + '">' + timeStr + '</span></div>';
    if (merge) div.style.marginTop = '-4px';
    messagesEl.appendChild(div);
    scrollToBottom();
    lastRole = 'user';
  }

  function showTyping() {
    var existing = document.getElementById('typing-indicator');
    if (existing) existing.remove();
    var div = document.createElement('div');
    div.className = 'flex items-start gap-3 chat-msg bot';
    div.id = 'typing-indicator';
    div.dataset.role = 'bot';
    div.dataset.merge = 'false';
    div.innerHTML = '<div class="w-8 h-8 rounded-xl bg-gradient-to-br <?= $tc[
        "gradient"
    ] ?> flex items-center justify-center text-white text-xs flex-shrink-0 shadow-sm mt-0.5 msg-avatar animate-pulse-soft"><i class="fas fa-robot"></i></div><div class="flex flex-col max-w-[80%] items-start"><div class="bot-bubble px-4 py-3" style="background:<?= $tc[
     "hex"
 ] ?>0a;border:1px solid <?= $tc[
    "hex"
] ?>15;border-bottom-left-radius:4px"><div class="typing-dots"><span style="background:<?= $tc[
    "hex"
] ?>"></span><span style="background:<?= $tc[
    "hex"
] ?>"></span><span style="background:<?= $tc["hex"] ?>"></span></div></div></div>';
    messagesEl.appendChild(div);
    scrollToBottom();
  }

  function hideTyping() {
    var el = document.getElementById('typing-indicator');
    if (el) el.remove();
  }

  function showChoiceInput(options) {
    hideChoices();
    var container = document.createElement('div');
    container.id = 'chat-choices-container';
    container.className = 'flex flex-wrap gap-2 mb-2 ml-11 animate-fade-in-up';
    options.forEach(function(opt) {
      var chip = document.createElement('button');
      chip.type = 'button';
      chip.className = 'choice-chip px-3.5 py-2 rounded-xl text-xs font-medium border transition-all';
      chip.style.cssText = 'border-color:' + themeColor + '30;color:' + themeColor + ';background:' + themeColor + '06';
      chip.textContent = opt;
      chip.onclick = function() { chip.classList.add('selected'); setTimeout(function() { processAnswer(opt); }, 180); };
      container.appendChild(chip);
    });
    choicesContainer = container;
    messagesEl.appendChild(container);
    scrollToBottom();
  }

  function showRatingInput(options) {
    hideChoices();
    var container = document.createElement('div');
    container.id = 'chat-choices-container';
    container.className = 'flex flex-wrap gap-2 mb-2 ml-11 animate-fade-in-up';
    options.forEach(function(opt) {
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'rating-btn w-9 h-9 rounded-xl text-sm font-bold border transition-all flex items-center justify-center';
      btn.style.cssText = 'border-color:' + themeColor + '30;color:' + themeColor + ';background:' + themeColor + '06';
      btn.textContent = opt;
      btn.onclick = function() {
        document.querySelectorAll('#chat-choices-container .rating-btn').forEach(function(b) { b.classList.remove('selected'); b.style.background = themeColor + '06'; b.style.color = themeColor; b.style.borderColor = themeColor + '30'; });
        btn.classList.add('selected');
        btn.style.background = themeColor;
        btn.style.color = '#fff';
        btn.style.borderColor = themeColor;
        setTimeout(function() { processAnswer(opt); }, 200);
      };
      container.appendChild(btn);
    });
    choicesContainer = container;
    messagesEl.appendChild(container);
    scrollToBottom();
  }

  function hideChoices() {
    if (choicesContainer && choicesContainer.parentNode) {
      choicesContainer.parentNode.removeChild(choicesContainer);
    }
    choicesContainer = null;
  }

  function showTextInput(show, type) {
    inputArea.classList.remove('hidden');
    inputEl.type = type || 'text';
    var placeholder = (currentNode && currentNode.placeholder) ? currentNode.placeholder : 'Type your response...';
    // Add contextual hint for file/image questions
    if (currentNode && ['file_upload', 'file', 'image'].indexOf(currentNode.type) !== -1) {
      placeholder = 'Describe the file or paste a link (e.g. "report.pdf" or a URL)…';
    }
    inputEl.placeholder = placeholder;
    inputEl.disabled = false;
    autoResize();
    setTimeout(function() { inputEl.focus(); }, 100);
  }

  function showDoneButton() {
    inputArea.classList.add('hidden');
    if (finalCountEl) finalCountEl.textContent = Object.keys(responses).length;
    doneArea.classList.remove('hidden');
  }

  function showSkipButton() { if (skipArea) skipArea.classList.remove('hidden'); }
  function hideSkipButton() { if (skipArea) skipArea.classList.add('hidden'); }

  function scrollToBottom() {
    var target = messagesEl.lastElementChild;
    if (target) {
      setTimeout(function() { target.scrollIntoView({ behavior: 'smooth', block: 'end' }); }, 30);
    } else {
      setTimeout(function() { messagesEl.scrollTop = messagesEl.scrollHeight; }, 30);
    }
  }

  function updateProgress() {
    var answered = Object.keys(responses).length;
    var current = Math.min(answered + 1, nodes.length);
    if (progressEl) progressEl.textContent = current;
    if (currentHeaderEl) currentHeaderEl.textContent = current;
    if (progressBar) progressBar.style.width = (nodes.length > 0 ? (answered / nodes.length * 100) : 0) + '%';
    if (progressPercentEl) progressPercentEl.textContent = Math.round(nodes.length > 0 ? (answered / nodes.length * 100) : 0) + '%';
  }

  function escapeHtml(text) {
    var d = document.createElement('div');
    d.textContent = text;
    return d.innerHTML;
  }

  // ============================================================
  // EVENTS
  // ============================================================
  function handleSend() {
    if (isProcessing) return;
    var val = inputEl.value.trim();
    if (!val) return;
    inputEl.value = '';
    autoResize();
    processAnswer(val);
  }

  sendBtn.addEventListener('click', handleSend);
  inputEl.addEventListener('keydown', function(e) {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); }
  });

  if (skipBtn) skipBtn.addEventListener('click', handleSkip);

  function restartSurvey() {
    if (isProcessing) return;
    responses = {};
    conversation = [];
    currentNodeIndex = -1;
    currentTryCount = 0;
    currentQuestionMessages = [];
    pendingCorrection = null;
    lastRole = 'bot';
    messagesEl.querySelectorAll('.chat-msg').forEach(function(n) { n.remove(); });
    addBotMessage(introText);
    hideSkipButton();
    hideChoices();
    doneArea.classList.add('hidden');
    updateProgress();
    startSurvey();
  }
  if (restartBtn) restartBtn.addEventListener('click', restartSurvey);

  finishBtn.addEventListener('click', function() {
    finishBtn.disabled = true;
    finishBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-1.5"></i>Submitting...';
    var payload = JSON.stringify({ responses: responses, conversation: conversation, config: { survey_id: surveyId, response_id: responseId } });
    var fd = new FormData();
    fd.append('_csrf_token', csrfToken);
    fd.append('survey_id', surveyId);
    fd.append('response_id', responseId);
    fd.append('chat_responses', payload);
    const inactiveSeconds = Math.max(0, Math.floor((Date.now() - lastActivityMs) / 1000));
    const fp = [navigator.userAgent || '', navigator.language || '', navigator.platform || '', String(screen.width || ''), String(screen.height || '')].join('|').slice(0, 250);
    fd.append('survey_type', 'chat');
    fd.append('tab_switches', String(tabSwitches));
    fd.append('_inactive_seconds', String(inactiveSeconds));
    fd.append('_behavior_log', JSON.stringify(behaviorLog));
    fd.append('device_fingerprint', fp);
    fetch(formAction, { method: 'POST', body: fd })
      .then(function(r) {
        if (r.redirected) { window.location.href = r.url; return; }
        window.location.href = baseUrl + '/dashboard';
      })
      .catch(function(err) {
        console.error('Submit failed:', err);
        finishBtn.disabled = false;
        finishBtn.innerHTML = '<i class="fas fa-check mr-1.5"></i>Finish & Submit';
        addBotMessage('Failed to submit. Please try again.');
      });
  });

  // ============================================================
  // START
  // ============================================================
  function startSurvey() {
    if (nodes.length > 0) {
      showTyping();
      setTimeout(function() {
        hideTyping();
        currentNodeIndex = getNextNodeIndex();
        if (currentNodeIndex >= 0 && currentNodeIndex < nodes.length) {
          renderNode(nodes[currentNodeIndex]);
          updateProgress();
        }
      }, 1000);
    } else { showDoneButton(); }
  }

  startSurvey();

  } catch(e) { console.error('[Chat] Fatal:', e); var app = document.getElementById('chat-app'); if (app) app.innerHTML = '<div class="p-8 text-center text-red-500">Something went wrong loading this survey. Please refresh the page.</div>'; }
})();
</script>
