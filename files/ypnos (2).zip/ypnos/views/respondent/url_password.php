<div class="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 flex items-center justify-center p-4">
  <div class="max-w-sm w-full bg-white rounded-2xl shadow-xl border border-gray-100 p-6 text-center">
    <div class="w-14 h-14 mx-auto bg-amber-100 rounded-2xl flex items-center justify-center mb-4">
      <i class="fas fa-lock text-amber-600 text-xl"></i>
    </div>
    <h2 class="text-lg font-bold text-gray-800 mb-1">Password Required</h2>
    <p class="text-xs text-gray-500 mb-4">This survey link is password-protected. Enter the password to continue.</p>
    <form method="POST" action="<?= url('/s/' . rawurlencode($code ?? '')) ?>" class="space-y-3">
      <?= csrf() ?>
      <input type="password" name="survey_url_pass" placeholder="Enter link password" class="w-full px-3 py-2.5 rounded-xl border border-gray-200 text-sm focus:border-indigo-300 focus:ring-2 focus:ring-indigo-100 outline-none" required autofocus>
      <button type="submit" class="w-full py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-indigo-700 text-white text-sm font-semibold hover:from-indigo-700 hover:to-indigo-800 transition-all shadow-lg shadow-indigo-200"><i class="fas fa-unlock mr-1.5"></i>Unlock Link</button>
    </form>
    <p class="mt-3 text-[10px] text-gray-400">Contact the survey owner for the password.</p>
  </div>
</div>
