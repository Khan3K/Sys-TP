<div class="max-w-3xl mx-auto">
    <div class="flex items-center gap-4 mb-6">
        <div class="w-14 h-14 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-2xl flex items-center justify-center text-white text-xl shadow-lg">
            <i class="fas fa-magic"></i>
        </div>
        <div>
            <h1 class="text-2xl font-bold text-gray-900">Form Filler Bookmarklet</h1>
            <p class="text-sm text-gray-500">Auto-fill forms with realistic data</p>
        </div>
    </div>

    <div class="bg-amber-50 border border-amber-200 rounded-2xl p-5 mb-6">
        <div class="flex items-start gap-3">
            <div class="w-8 h-8 rounded-full bg-amber-100 flex items-center justify-center text-amber-600 flex-shrink-0 mt-0.5">
                <i class="fas fa-info-circle text-sm"></i>
            </div>
            <p class="text-amber-800 text-sm">Drag the button below to your bookmarks bar. When you're on any form page, click the bookmark to auto-fill fields with realistic data.</p>
        </div>
    </div>

    <div class="bg-white rounded-2xl shadow-sm border border-gray-200 p-8 text-center mb-6 hover:shadow-md transition-shadow">
        <a href="<?= htmlspecialchars($bookmarkletCode) ?>"
           class="inline-flex items-center gap-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-10 py-5 rounded-2xl text-lg font-bold hover:from-indigo-700 hover:to-purple-700 shadow-lg hover:shadow-xl transition-all active:scale-[0.98]">
            <i class="fas fa-magic"></i>Resrch Fill
        </a>
        <p class="mt-3 text-sm text-gray-400"><i class="fas fa-arrows-alt mr-1"></i>Drag this to your bookmarks bar</p>
    </div>

    <div class="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
        <div class="flex items-center gap-2 mb-4">
            <div class="w-8 h-8 rounded-lg bg-indigo-50 flex items-center justify-center text-indigo-600">
                <i class="fas fa-book"></i>
            </div>
            <h2 class="font-semibold text-gray-900">How to Use</h2>
        </div>
        <ol class="space-y-3 text-sm text-gray-700">
            <?php $steps = ['Drag the <strong>Resrch Fill</strong> button above to your browser bookmarks bar', 'Navigate to any page with a form (survey, registration, etc.)', 'Click the <strong>Resrch Fill</strong> bookmark', 'A popup will appear showing detected fields', 'Map each field to a data type (or click <strong>Auto-Fill All</strong>)', 'Click <strong>Fill Selected Fields</strong> to populate the form']; ?>
            <?php foreach ($steps as $si => $step): ?>
            <li class="flex items-start gap-3">
                <span class="flex-shrink-0 w-6 h-6 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center text-xs font-bold"><?= $si + 1 ?></span>
                <span class="pt-0.5"><?= $step ?></span>
            </li>
            <?php endforeach; ?>
        </ol>
    </div>

    <div class="mt-6 text-center">
        <a href="<?= url('/dashboard') ?>" class="inline-flex items-center gap-2 text-sm text-indigo-600 hover:text-indigo-800 font-medium">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
    </div>
</div>
