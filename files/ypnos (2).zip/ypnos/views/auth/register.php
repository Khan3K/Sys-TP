<div class="min-h-[80vh] flex items-center justify-center">
    <div class="w-full max-w-md">
        <div class="text-center mb-8">
            <div class="w-16 h-16 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-2xl flex items-center justify-center text-white text-2xl font-bold mx-auto shadow-lg mb-4 animate-float">
                <i class="fas fa-flask"></i>
            </div>
            <h1 class="text-3xl font-bold text-gray-900">Create account</h1>
            <p class="text-gray-500 mt-2">Join Resrch as a researcher or respondent</p>
        </div>

        <div class="bg-white rounded-2xl shadow-sm border border-gray-200 p-8">
            <form method="POST" action="<?= url('/register') ?>">
                <?= csrf() ?>
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Full Name</label>
                    <div class="relative">
                        <i class="fas fa-user absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 text-sm"></i>
                        <input type="text" name="full_name" value="<?= old('full_name') ?>" required
                            class="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-sm"
                            placeholder="Dr. Smith">
                    </div>
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Email Address</label>
                    <div class="relative">
                        <i class="fas fa-envelope absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 text-sm"></i>
                        <input type="email" name="email" value="<?= old('email') ?>" required
                            class="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-sm"
                            placeholder="you@example.com">
                    </div>
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">I want to...</label>
                    <div class="grid grid-cols-2 gap-3">
                        <label class="relative flex items-center justify-center p-3 border-2 rounded-xl cursor-pointer transition-all <?= old('role', 'respondent') === 'respondent' ? 'border-indigo-500 bg-indigo-50' : 'border-gray-200 hover:border-gray-300' ?>">
                            <input type="radio" name="role" value="respondent" class="sr-only" <?= old('role', 'respondent') === 'respondent' ? 'checked' : '' ?> onchange="this.closest('label').parentElement.querySelectorAll('label').forEach(l=>l.className=l.className.replace(/border-indigo-500 bg-indigo-50/,'border-gray-200'));this.closest('label').className='relative flex items-center justify-center p-3 border-2 rounded-xl cursor-pointer transition-all border-indigo-500 bg-indigo-50'">
                            <div class="text-center">
                                <i class="fas fa-pen-fancy text-xl text-indigo-600 mb-1"></i>
                                <div class="text-sm font-medium text-gray-900">Respondent</div>
                                <div class="text-xs text-gray-500">Take surveys</div>
                            </div>
                        </label>
                        <label class="relative flex items-center justify-center p-3 border-2 rounded-xl cursor-pointer transition-all <?= old('role') === 'researcher' ? 'border-indigo-500 bg-indigo-50' : 'border-gray-200 hover:border-gray-300' ?>">
                            <input type="radio" name="role" value="researcher" class="sr-only" <?= old('role') === 'researcher' ? 'checked' : '' ?> onchange="this.closest('label').parentElement.querySelectorAll('label').forEach(l=>l.className=l.className.replace(/border-indigo-500 bg-indigo-50/,'border-gray-200'));this.closest('label').className='relative flex items-center justify-center p-3 border-2 rounded-xl cursor-pointer transition-all border-indigo-500 bg-indigo-50'">
                            <div class="text-center">
                                <i class="fas fa-flask text-xl text-purple-600 mb-1"></i>
                                <div class="text-sm font-medium text-gray-900">Researcher</div>
                                <div class="text-xs text-gray-500">Create surveys</div>
                            </div>
                        </label>
                    </div>
                </div>

                <div class="mb-6">
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Password</label>
                    <div class="relative">
                        <i class="fas fa-lock absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 text-sm"></i>
                        <input type="password" name="password" required minlength="6"
                            class="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-sm"
                            placeholder="Min. 6 characters">
                    </div>
                    <p class="text-xs text-gray-400 mt-1">Must be at least 6 characters</p>
                </div>

                <button type="submit" class="w-full bg-gradient-to-r from-indigo-600 to-indigo-700 text-white py-2.5 rounded-xl hover:from-indigo-700 hover:to-indigo-800 transition-all font-medium shadow-sm">
                    <i class="fas fa-user-plus mr-2"></i>Create Account
                </button>

                <div class="relative my-5">
                    <div class="absolute inset-0 flex items-center"><div class="w-full border-t border-gray-200"></div></div>
                    <div class="relative flex justify-center"><span class="bg-white px-3 text-[11px] text-gray-400">or</span></div>
                </div>

                <a href="<?= url('/auth/google') ?>" class="w-full inline-flex items-center justify-center gap-2 bg-white text-gray-700 px-4 py-2.5 rounded-xl hover:bg-gray-50 transition-all text-sm font-medium border border-gray-200 shadow-sm">
                    <i class="fab fa-google text-red-500"></i> Sign up with Google
                </a>
            </form>

            <div class="mt-6 text-center">
                <p class="text-sm text-gray-500">
                    Already have an account?
                    <a href="<?= url('/login') ?>" class="text-indigo-600 hover:text-indigo-800 font-medium">Sign in</a>
                </p>
            </div>
        </div>
    </div>
</div>
