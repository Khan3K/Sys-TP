<div class="min-h-[80vh] flex items-center justify-center">
    <div class="w-full max-w-md">
        <div class="text-center mb-8">
            <div class="w-16 h-16 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-2xl flex items-center justify-center text-white text-2xl font-bold mx-auto shadow-lg mb-4 animate-float">
                <i class="fas fa-flask"></i>
            </div>
            <h1 class="text-3xl font-bold text-gray-900">Welcome back</h1>
            <p class="text-gray-500 mt-2">Sign in to your Resrch account</p>
        </div>

        <div class="bg-white rounded-2xl shadow-sm border border-gray-200 p-8">
            <form method="POST" action="<?= url('/login') ?>">
                <?= csrf() ?>
                <div class="mb-5">
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Email Address</label>
                    <div class="relative">
                        <i class="fas fa-envelope absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 text-sm"></i>
                        <input type="email" name="email" value="<?= old('email') ?>" required
                            class="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-sm"
                            placeholder="you@example.com">
                    </div>
                </div>

                <div class="mb-6">
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">Password</label>
                    <div class="relative">
                        <i class="fas fa-lock absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 text-sm"></i>
                        <input type="password" name="password" required
                            class="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-sm"
                            placeholder="Enter your password">
                    </div>
                </div>

                <div class="flex items-center justify-between mb-6">
                    <div class="flex items-center gap-2">
                        <input type="checkbox" id="remember" class="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500">
                        <label for="remember" class="text-sm text-gray-600">Remember me</label>
                    </div>
                    <a href="<?= url('/forgot-password') ?>" class="text-sm text-indigo-600 hover:text-indigo-800 font-medium">Forgot password?</a>
                </div>

                <button type="submit" class="w-full bg-gradient-to-r from-indigo-600 to-indigo-700 text-white py-2.5 rounded-xl hover:from-indigo-700 hover:to-indigo-800 transition-all font-medium shadow-sm">
                    <i class="fas fa-arrow-right mr-2"></i>Sign In
                </button>

                <div class="relative my-5">
                    <div class="absolute inset-0 flex items-center"><div class="w-full border-t border-gray-200"></div></div>
                    <div class="relative flex justify-center"><span class="bg-white px-3 text-[11px] text-gray-400">or</span></div>
                </div>

                <a href="<?= url('/auth/google') ?>" class="w-full inline-flex items-center justify-center gap-2 bg-white text-gray-700 px-4 py-2.5 rounded-xl hover:bg-gray-50 transition-all text-sm font-medium border border-gray-200 shadow-sm">
                    <i class="fab fa-google text-red-500"></i> Sign in with Google
                </a>
            </form>

            <div class="mt-6 text-center">
                <p class="text-sm text-gray-500">
                    Don't have an account?
                    <a href="<?= url('/register') ?>" class="text-indigo-600 hover:text-indigo-800 font-medium">Create one</a>
                </p>
            </div>
        </div>
    </div>
</div>
