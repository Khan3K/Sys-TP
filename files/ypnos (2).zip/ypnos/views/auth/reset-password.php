<div class="min-h-[70vh] flex items-center justify-center">
    <div class="w-full max-w-md">
        <div class="text-center mb-8">
            <div class="w-16 h-16 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-2xl flex items-center justify-center text-white text-2xl font-bold mx-auto shadow-lg mb-4 animate-float">
                <i class="fas fa-lock-open"></i>
            </div>
            <h1 class="text-3xl font-bold text-gray-900">New password</h1>
            <p class="text-gray-500 mt-2">Choose a strong password for your account</p>
        </div>

        <div class="bg-white rounded-2xl shadow-sm border border-gray-200 p-8">
            <form method="POST" action="<?= url('/reset-password/' . htmlspecialchars($token)) ?>">
                <?= csrf() ?>
                <div class="mb-6">
                    <label class="block text-sm font-medium text-gray-700 mb-1.5">New Password</label>
                    <div class="relative">
                        <i class="fas fa-lock absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 text-sm"></i>
                        <input type="password" name="password" required minlength="6"
                            class="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-sm"
                            placeholder="Min. 6 characters">
                    </div>
                </div>

                <button type="submit" class="w-full bg-gradient-to-r from-indigo-600 to-indigo-700 text-white py-2.5 rounded-xl hover:from-indigo-700 hover:to-indigo-800 transition-all font-medium shadow-sm">
                    <i class="fas fa-check mr-2"></i>Reset Password
                </button>
            </form>
        </div>
    </div>
</div>
