(function() {
    'use strict';

    function getFingerprint() {
        var fp = {};

        fp.screen = screen.width + 'x' + screen.height + 'x' + screen.colorDepth;
        fp.timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
        fp.language = navigator.language;
        fp.platform = navigator.platform;
        fp.cookies = navigator.cookieEnabled;
        fp.doNotTrack = navigator.doNotTrack;

        var canvas = document.createElement('canvas');
        canvas.width = 200;
        canvas.height = 50;
        var ctx = canvas.getContext('2d');
        ctx.textBaseline = 'top';
        ctx.font = '14px Arial';
        ctx.fillStyle = '#f60';
        ctx.fillRect(125, 1, 62, 20);
        ctx.fillStyle = '#069';
        ctx.fillText('fp', 2, 15);
        ctx.fillStyle = 'rgba(102, 204, 0, 0.7)';
        ctx.fillText('test', 4, 17);
        fp.canvas = canvas.toDataURL();

        var fonts = ['Arial', 'Courier New', 'Georgia', 'Times New Roman', 'Verdana', 'Trebuchet MS', 'Comic Sans MS'];
        var available = [];
        for (var i = 0; i < fonts.length; i++) {
            if (document.fonts && document.fonts.check('12px ' + fonts[i])) {
                available.push(fonts[i]);
            }
        }
        fp.fonts = available;

        fp.userAgent = navigator.userAgent;

        var hash = 0;
        var str = JSON.stringify(fp);
        for (var i = 0; i < str.length; i++) {
            var char = str.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash |= 0;
        }
        fp.hash = hash.toString(36);

        return fp;
    }

    window.Resrch = window.Resrch || {};
    window.Resrch.fingerprint = getFingerprint();

    var honeypot = document.querySelector('input[name="honeypot"]');
    if (honeypot) {
        honeypot.value = '';
    }

    if (document.getElementById('survey-form')) {
        var fpInput = document.createElement('input');
        fpInput.type = 'hidden';
        fpInput.name = 'device_fingerprint';
        fpInput.value = window.Resrch.fingerprint.hash;
        document.getElementById('survey-form').appendChild(fpInput);
    }
})();
