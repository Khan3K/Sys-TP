(function() {
    'use strict';

    const DATA_SOURCE = 'http://localhost/dashboard/ypnos';
    const fields = document.querySelectorAll('input, select, textarea');
    const detected = [];

    fields.forEach(function(field) {
        if (field.type === 'hidden' || field.type === 'submit' || field.type === 'button') return;
        if (field.name === 'honeypot') return;

        const labels = [];
        const labelEl = document.querySelector('label[for="' + field.id + '"]');
        if (labelEl) labels.push(labelEl.textContent.trim());

        const parentLabel = field.closest('label');
        if (parentLabel) labels.push(parentLabel.textContent.trim());

        const placeholder = field.placeholder || '';
        const name = field.name || field.id || '';
        const type = field.type || 'text';

        detected.push({
            name: name,
            id: field.id,
            type: type,
            placeholder: placeholder,
            labels: labels,
            field: field
        });
    });

    if (detected.length === 0) {
        alert('No form fields detected on this page.');
        return;
    }

    var iframe = document.createElement('iframe');
    iframe.src = DATA_SOURCE + '/bookmarklet-popup?fields=' + encodeURIComponent(JSON.stringify(detected.map(function(f) {
        return { name: f.name, id: f.id, type: f.type, placeholder: f.placeholder, labels: f.labels };
    })));
    iframe.style.cssText = 'position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);width:600px;height:500px;border:2px solid #4f46e5;border-radius:12px;z-index:999999;background:white;box-shadow:0 25px 50px rgba(0,0,0,0.3);';
    iframe.id = 'resrch-bookmarklet';

    var closeBtn = document.createElement('button');
    closeBtn.textContent = '×';
    closeBtn.style.cssText = 'position:fixed;top:calc(50% - 250px);left:calc(50% + 280px);z-index:1000000;background:#ef4444;color:white;border:none;border-radius:50%;width:30px;height:30px;font-size:20px;cursor:pointer;line-height:30px;text-align:center;';
    closeBtn.onclick = function() {
        document.body.removeChild(iframe);
        document.body.removeChild(closeBtn);
    };

    document.body.appendChild(iframe);
    document.body.appendChild(closeBtn);

    window.addEventListener('message', function(event) {
        if (event.data.type === 'RESRCH_FILL') {
            var map = event.data.mapping;
            detected.forEach(function(item) {
                if (map[item.name] || map[item.id]) {
                    var value = map[item.name] || map[item.id];
                    var field = item.field;
                    var tag = field.tagName.toLowerCase();
                    if (tag === 'select') {
                        var opts = field.querySelectorAll('option');
                        for (var i = 0; i < opts.length; i++) {
                            if (opts[i].value === value || opts[i].textContent === value) {
                                field.value = opts[i].value;
                                break;
                            }
                        }
                    } else if (field.type === 'checkbox' || field.type === 'radio') {
                        field.checked = field.value === value || value === 'true' || value === 'Yes';
                    } else {
                        field.value = value;
                    }
                    field.dispatchEvent(new Event('input', { bubbles: true }));
                    field.dispatchEvent(new Event('change', { bubbles: true }));
                }
            });
            document.body.removeChild(iframe);
            document.body.removeChild(closeBtn);
            alert('Form fields filled!');
        }
    });
})();
