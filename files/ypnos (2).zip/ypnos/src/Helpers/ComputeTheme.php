<?php

namespace Helpers;

class ComputeTheme
{
    /**
     * Compute all theme variables from theme config array.
     * Returns an associative array with 42+ keys for use in templates.
     */
    public static function fromConfig(array $themeCfg = array()): array
    {
        $result = array();

        // === RAW CONFIG VALUES ===
        $result['themeColor'] = $themeCfg['theme'] ?? 'indigo';
        $result['bgStyle'] = $themeCfg['background'] ?? 'glass';
        $result['logoUrl'] = $themeCfg['logo_url'] ?? '';
        $result['cardStyle'] = $themeCfg['card_style'] ?? 'glass';
        $result['questionAnim'] = $themeCfg['question_animation'] ?? 'slide-up';
        $result['questionAnimDuration'] = $themeCfg['question_animation_duration'] ?? 400;
        $result['frozenAnim'] = $themeCfg['frozen_animation'] ?? 'pulse';
        $result['customCSS'] = $themeCfg['custom_css'] ?? '';
        $result['confettiOnComplete'] = !empty($themeCfg['confetti_on_complete']);
        $result['particleCount'] = (int)($themeCfg['particle_count'] ?? 0);
        $result['fontFamily'] = $themeCfg['font_family'] ?? 'inherit';
        $result['fontSize'] = $themeCfg['font_size'] ?? '';
        $result['borderRadius'] = $themeCfg['question_border_radius'] ?? 'xl';
        $result['shadowStyle'] = $themeCfg['question_shadow'] ?? 'lg';
        $result['accentStyle'] = $themeCfg['accent_style'] ?? 'normal';
        $result['bgType'] = $themeCfg['bg_type'] ?? 'gradient';
        $result['bgValue'] = $themeCfg['bg_value'] ?? '';
        $result['bgImage'] = $themeCfg['bg_image'] ?? '';
        $result['bgVideo'] = $themeCfg['bg_video'] ?? '';
        $result['secondsPerQuestion'] = max(5, min(120, (int)($themeCfg['seconds_per_question'] ?? 20)));
        $result['questionSpacing'] = $themeCfg['question_spacing'] ?? 'normal';
        $result['showProgressBar'] = isset($themeCfg['show_progress_bar']) ? !empty($themeCfg['show_progress_bar']) : true;
        $result['showQuestionNumbers'] = isset($themeCfg['show_question_numbers']) ? !empty($themeCfg['show_question_numbers']) : true;
        $result['stickyHeader'] = !empty($themeCfg['sticky_header']);

        // === 12 COLOR THEMES ===
        $themeMap = array(
            'indigo' => array('hex'=>'#6366f1','hex2'=>'#a855f7','hex3'=>'#818cf8','light'=>'#eef2ff','medium'=>'#c7d2fe','dark'=>'#4338ca','rgb'=>'99,102,241','gradient'=>'from-indigo-500 to-purple-600','text'=>'text-indigo-600','bg'=>'bg-indigo-50','btn'=>'from-indigo-600 to-purple-600','btnHover'=>'from-indigo-700 to-purple-700','focus'=>'focus:ring-indigo-300','shadow'=>'shadow-indigo-500/20'),
            'emerald' => array('hex'=>'#10b981','hex2'=>'#34d399','hex3'=>'#6ee7b7','light'=>'#ecfdf5','medium'=>'#a7f3d0','dark'=>'#047857','rgb'=>'16,185,129','gradient'=>'from-emerald-500 to-teal-500','text'=>'text-emerald-600','bg'=>'bg-emerald-50','btn'=>'from-emerald-600 to-teal-600','btnHover'=>'from-emerald-700 to-teal-700','focus'=>'focus:ring-emerald-300','shadow'=>'shadow-emerald-500/20'),
            'amber' => array('hex'=>'#f59e0b','hex2'=>'#fbbf24','hex3'=>'#fcd34d','light'=>'#fffbeb','medium'=>'#fde68a','dark'=>'#b45309','rgb'=>'245,158,11','gradient'=>'from-amber-500 to-orange-500','text'=>'text-amber-600','bg'=>'bg-amber-50','btn'=>'from-amber-600 to-orange-600','btnHover'=>'from-amber-700 to-orange-700','focus'=>'focus:ring-amber-300','shadow'=>'shadow-amber-500/20'),
            'rose' => array('hex'=>'#f43f5e','hex2'=>'#fb7185','hex3'=>'#fda4af','light'=>'#ffe4e6','medium'=>'#fecdd3','dark'=>'#be123c','rgb'=>'244,63,94','gradient'=>'from-rose-500 to-pink-500','text'=>'text-rose-600','bg'=>'bg-rose-50','btn'=>'from-rose-600 to-pink-600','btnHover'=>'from-rose-700 to-pink-700','focus'=>'focus:ring-rose-300','shadow'=>'shadow-rose-500/20'),
            'cyan' => array('hex'=>'#06b6d4','hex2'=>'#22d3ee','hex3'=>'#67e8f9','light'=>'#ecfeff','medium'=>'#a5f3fc','dark'=>'#0891b2','rgb'=>'6,182,212','gradient'=>'from-cyan-500 to-blue-500','text'=>'text-cyan-600','bg'=>'bg-cyan-50','btn'=>'from-cyan-600 to-blue-600','btnHover'=>'from-cyan-700 to-blue-700','focus'=>'focus:ring-cyan-300','shadow'=>'shadow-cyan-500/20'),
            'violet' => array('hex'=>'#8b5cf6','hex2'=>'#a78bfa','hex3'=>'#c4b5fd','light'=>'#f5f3ff','medium'=>'#ddd6fe','dark'=>'#6d28d9','rgb'=>'139,92,246','gradient'=>'from-violet-500 to-purple-500','text'=>'text-violet-600','bg'=>'bg-violet-50','btn'=>'from-violet-600 to-purple-600','btnHover'=>'from-violet-700 to-purple-700','focus'=>'focus:ring-violet-300','shadow'=>'shadow-violet-500/20'),
            'teal' => array('hex'=>'#14b8a6','hex2'=>'#2dd4bf','hex3'=>'#5eead4','light'=>'#f0fdfa','medium'=>'#99f6e4','dark'=>'#0d9488','rgb'=>'20,184,166','gradient'=>'from-teal-500 to-emerald-500','text'=>'text-teal-600','bg'=>'bg-teal-50','btn'=>'from-teal-600 to-emerald-600','btnHover'=>'from-teal-700 to-emerald-700','focus'=>'focus:ring-teal-300','shadow'=>'shadow-teal-500/20'),
            'red' => array('hex'=>'#ef4444','hex2'=>'#f87171','hex3'=>'#fca5a5','light'=>'#fef2f2','medium'=>'#fecaca','dark'=>'#b91c1c','rgb'=>'239,68,68','gradient'=>'from-red-500 to-rose-500','text'=>'text-red-600','bg'=>'bg-red-50','btn'=>'from-red-600 to-rose-600','btnHover'=>'from-red-700 to-rose-700','focus'=>'focus:ring-red-300','shadow'=>'shadow-red-500/20'),
            'orange' => array('hex'=>'#f97316','hex2'=>'#fb923c','hex3'=>'#fdba74','light'=>'#fff7ed','medium'=>'#fed7aa','dark'=>'#c2410c','rgb'=>'249,115,22','gradient'=>'from-orange-500 to-amber-500','text'=>'text-orange-600','bg'=>'bg-orange-50','btn'=>'from-orange-600 to-amber-600','btnHover'=>'from-orange-700 to-amber-700','focus'=>'focus:ring-orange-300','shadow'=>'shadow-orange-500/20'),
            'pink' => array('hex'=>'#ec4899','hex2'=>'#f472b6','hex3'=>'#f9a8d4','light'=>'#fdf2f8','medium'=>'#fbcfe8','dark'=>'#be185d','rgb'=>'236,72,153','gradient'=>'from-pink-500 to-rose-500','text'=>'text-pink-600','bg'=>'bg-pink-50','btn'=>'from-pink-600 to-rose-600','btnHover'=>'from-pink-700 to-rose-700','focus'=>'focus:ring-pink-300','shadow'=>'shadow-pink-500/20'),
            'blue' => array('hex'=>'#3b82f6','hex2'=>'#60a5fa','hex3'=>'#93c5fd','light'=>'#eff6ff','medium'=>'#bfdbfe','dark'=>'#1d4ed8','rgb'=>'59,130,246','gradient'=>'from-blue-500 to-indigo-500','text'=>'text-blue-600','bg'=>'bg-blue-50','btn'=>'from-blue-600 to-indigo-600','btnHover'=>'from-blue-700 to-indigo-700','focus'=>'focus:ring-blue-300','shadow'=>'shadow-blue-500/20'),
            'slate' => array('hex'=>'#64748b','hex2'=>'#94a3b8','hex3'=>'#cbd5e1','light'=>'#f8fafc','medium'=>'#e2e8f0','dark'=>'#334155','rgb'=>'100,116,139','gradient'=>'from-slate-500 to-gray-500','text'=>'text-slate-600','bg'=>'bg-slate-50','btn'=>'from-slate-600 to-gray-600','btnHover'=>'from-slate-700 to-gray-700','focus'=>'focus:ring-slate-300','shadow'=>'shadow-slate-500/20'),
        );
        $result['tc'] = $themeMap[$result['themeColor']] ?? $themeMap['indigo'];

        // === DYNAMIC BACKGROUND SYSTEM ===
        $bgMap = array(
            'glass' => "from-gray-50 via-{$result['themeColor']}-50/30 to-{$result['themeColor']}-50/30",
            'warm' => "from-amber-50 via-orange-50/30 to-rose-50/30",
            'cool' => "from-sky-50 via-blue-50/30 to-cyan-50/30",
            'dark' => "from-gray-900 via-gray-800 to-gray-900",
            'mountain' => "from-indigo-900 via-purple-900 to-pink-900",
            'sunset' => "from-orange-500 via-rose-500 to-purple-800",
            'ocean' => "from-cyan-600 via-blue-700 to-indigo-900",
            'forest' => "from-emerald-800 via-green-700 to-teal-800",
            'midnight' => "from-slate-900 via-gray-900 to-zinc-900",
            'lavender' => "from-violet-300 via-fuchsia-200 to-pink-300",
            'peach' => "from-amber-200 via-orange-200 to-rose-300",
            'gradient-1' => "from-{$result['themeColor']}-500 via-purple-500 to-pink-500",
            'gradient-2' => "from-{$result['themeColor']}-400 via-cyan-400 to-{$result['themeColor']}-400",
            'gradient-3' => "from-indigo-500 via-{$result['themeColor']}-500 to-amber-500",
            'particles' => "from-gray-900 via-{$result['themeColor']}-900 to-gray-900",
        );

        $result['bgClass'] = '';
        $result['bgImageStyle'] = '';
        $result['useBgVideo'] = false;

        if ($result['bgType'] === 'solid') {
            $result['bgClass'] = $result['bgValue'] ? "bg-[{$result['bgValue']}]" : $result['tc']['light'];
        } elseif ($result['bgType'] === 'image' && $result['bgImage']) {
            $result['bgClass'] = '';
            $result['bgImageStyle'] = "background-image:url('{$result['bgImage']}');background-size:cover;background-position:center;background-attachment:fixed;";
        } elseif ($result['bgType'] === 'video' && $result['bgVideo']) {
            $result['bgClass'] = '';
            $result['useBgVideo'] = true;
        } else {
            $result['bgClass'] = $bgMap[$result['bgStyle']] ?? $bgMap['glass'];
            if (!empty($result['bgValue']) && $result['bgType'] === 'gradient') {
                $result['bgClass'] = $result['bgValue'];
            }
        }

        // === DARK MODE DETECTION ===
        $result['isDark'] = in_array($result['bgStyle'], array('dark','particles','midnight','mountain','ocean','forest'))
            || ($result['bgType'] === 'solid' && preg_match('/#[0-3]/', $result['bgValue'] ?? ''));
        $result['textColor'] = $result['isDark'] ? 'text-white' : 'text-gray-900';
        $result['textMuted'] = $result['isDark'] ? 'text-gray-300' : 'text-gray-500';
        $result['cardBg'] = $result['isDark'] ? 'bg-white/10 backdrop-blur-xl border-white/10' : 'bg-white/70 backdrop-blur-xl border-white/50';
        $result['inputBg'] = $result['isDark'] ? 'bg-white/10 border-white/20 text-white placeholder:text-gray-400' : 'bg-white/50 border-gray-200 text-gray-900';

        // === CARD STYLE PRESETS ===
        $cardStyles = array(
            'glass' => 'bg-white/70 backdrop-blur-xl border-white/50',
            'solid' => 'bg-white border-gray-200',
            'bordered' => 'bg-white border-2 border-gray-200',
            'ghost' => 'bg-transparent border-gray-200/30',
            'dark-glass' => 'bg-white/10 backdrop-blur-xl border-white/10',
            'neumorphic' => 'shadow-[inset_0_-2px_6px_rgba(0,0,0,0.05),0_2px_6px_rgba(0,0,0,0.05)] bg-white border-transparent',
            'gradient' => 'bg-gradient-to-br border-transparent',
        );
        $result['cardBgClass'] = $cardStyles[$result['cardStyle']] ?? $cardStyles['glass'];
        if ($result['cardStyle'] === 'gradient') {
            $result['cardBgClass'] = "bg-gradient-to-br from-{$result['themeColor']}-50/80 to-{$result['themeColor']}-100/30 backdrop-blur-xl border-transparent";
        }

        // === BORDER RADIUS PRESETS ===
        $radiusMap = array('none'=>'','sm'=>'rounded-sm','md'=>'rounded-md','lg'=>'rounded-lg','xl'=>'rounded-xl','2xl'=>'rounded-2xl','3xl'=>'rounded-3xl','full'=>'rounded-full');
        $result['radiusClass'] = $radiusMap[$result['borderRadius']] ?? $radiusMap['xl'];

        // === SHADOW PRESETS ===
        $shadowMap = array('none'=>'','sm'=>'shadow-sm','md'=>'shadow-md','lg'=>'shadow-lg','xl'=>'shadow-xl','2xl'=>'shadow-2xl','inner'=>'shadow-inner');
        $result['shadowClass'] = $shadowMap[$result['shadowStyle']] ?? $shadowMap['lg'];

        // === FONT ===
        $result['fontFamilyStyle'] = ($result['fontFamily'] && $result['fontFamily'] !== 'inherit')
            ? "font-family:'{$result['fontFamily']}',sans-serif;"
            : '';

        // === DURATION/FORMATTING HELPERS ===
        $totalSeconds = $result['secondsPerQuestion'];
        $result['durationLabel'] = $totalSeconds < 60 ? "{$totalSeconds} sec" : (ceil($totalSeconds / 60) . " min");

        return $result;
    }
}
