<?php

namespace Helpers;

class SurveyTemplates
{
    /**
     * All templates with categories, difficulty, accuracy metadata
     */
    public static function all(): array
    {
        return [
            'customer-satisfaction' => [
                'name'             => 'Customer Satisfaction',
                'icon'             => 'fa-smile',
                'color'            => 'emerald',
                'description'      => 'Measure customer happiness with your product or service. Includes NPS-style questions with attention checks.',
                'category'         => 'feedback',
                'difficulty'       => 'easy',
                'accuracy_score'   => 92,
                'estimated_minutes'=> 3,
                'popularity'       => 'high',
                'tags'             => ['customer', 'satisfaction', 'nps', 'feedback', 'service'],
                'theme'            => ['bg' => 'glass', 'card_style' => 'glass', 'animation' => 'slide-up', 'font' => 'Inter'],
                'quality'     => [
                    'honeypot' => true, 'captcha' => true, 'prevent_duplicates' => true,
                    'detect_straightline' => true, 'validate_input' => true, 'min_time_seconds' => 45,
                    'min_text_length' => 10, 'confirm_answers' => true, 'sequential_unlock' => false,
                    'track_tab_switches' => false, 'prevent_copy_paste' => false, 'require_attention' => true,
                ],
                'questions' => [
                    ['type' => 'text', 'question_text' => 'What is your full name?', 'is_required' => true],
                    ['type' => 'email', 'question_text' => 'What is your email address?', 'is_required' => true],
                    ['type' => 'likert5', 'question_text' => 'How satisfied are you with our service?', 'is_required' => true, 'options' => ["Very Dissatisfied","Dissatisfied","Neutral","Satisfied","Very Satisfied"]],
                    ['type' => 'likert5', 'question_text' => 'How likely are you to recommend us?', 'is_required' => true, 'options' => ["Very Unlikely","Unlikely","Neutral","Likely","Very Likely"]],
                    ['type' => 'mcq_single', 'question_text' => 'How did you hear about us?', 'is_required' => true, 'options' => ["Social Media","Friend Referral","Search Engine","Advertisement","Other"]],
                    ['type' => 'likert5', 'question_text' => 'Please select "Agree" for verification', 'is_required' => true, 'is_attention_check' => true, 'options' => ["Strongly Disagree","Disagree","Neutral","Agree","Strongly Agree"]],
                    ['type' => 'yes_no', 'question_text' => 'Would you recommend us to others?', 'is_required' => true],
                    ['type' => 'text', 'question_text' => 'What can we improve?', 'is_required' => false, 'min_length' => 20],
                ],
            ],
            'market-research' => [
                'name'             => 'Market Research',
                'icon'             => 'fa-chart-bar',
                'color'            => 'blue',
                'description'      => 'Gather deep insights about market trends, demographics, and consumer preferences with advanced attention checks.',
                'category'         => 'research',
                'difficulty'       => 'medium',
                'accuracy_score'   => 95,
                'estimated_minutes'=> 5,
                'popularity'       => 'high',
                'tags'             => ['market', 'demographics', 'research', 'trends', 'consumer'],
                'theme'            => ['bg' => 'grid', 'card_style' => 'outlined', 'animation' => 'fade', 'font' => 'Inter'],
                'quality'     => [
                    'honeypot' => true, 'captcha' => true, 'prevent_duplicates' => true,
                    'detect_straightline' => true, 'validate_input' => false, 'min_time_seconds' => 60,
                    'min_text_length' => 15, 'confirm_answers' => false, 'sequential_unlock' => true,
                    'track_tab_switches' => true, 'prevent_copy_paste' => false, 'require_attention' => true,
                ],
                'questions' => [
                    ['type' => 'mcq_single', 'question_text' => 'What age group are you in?', 'is_required' => true, 'options' => ["Under 18","18-24","25-34","35-44","45-54","55+"]],
                    ['type' => 'mcq_single', 'question_text' => 'What is your gender?', 'is_required' => true, 'options' => ["Male","Female","Non-binary","Prefer not to say"]],
                    ['type' => 'text', 'question_text' => 'What industry do you work in?', 'is_required' => true],
                    ['type' => 'likert5', 'question_text' => 'How important is price when making purchase decisions?', 'is_required' => true, 'options' => ["Not Important","Slightly","Moderately","Very","Extremely"]],
                    ['type' => 'mcq_multiple', 'question_text' => 'Which social platforms do you use?', 'is_required' => true, 'options' => ["Facebook","Instagram","Twitter","LinkedIn","TikTok","YouTube"]],
                    ['type' => 'likert5', 'question_text' => 'Please select "Agree" for verification', 'is_required' => true, 'is_attention_check' => true, 'options' => ["Strongly Disagree","Disagree","Neutral","Agree","Strongly Agree"]],
                    ['type' => 'text', 'question_text' => 'Describe your ideal product in one sentence', 'is_required' => true, 'min_length' => 30],
                    ['type' => 'rating', 'question_text' => 'Rate your current satisfaction with available options', 'is_required' => true],
                ],
            ],
            'employee-engagement' => [
                'name'             => 'Employee Engagement',
                'icon'             => 'fa-users',
                'color'            => 'purple',
                'description'      => 'Understand employee satisfaction, company culture, and growth opportunities with high-accuracy protections.',
                'category'         => 'hr',
                'difficulty'       => 'medium',
                'accuracy_score'   => 96,
                'estimated_minutes'=> 6,
                'popularity'       => 'medium',
                'tags'             => ['employee', 'hr', 'engagement', 'culture', 'workplace'],
                'theme'            => ['bg' => 'dots', 'card_style' => 'rounded', 'animation' => 'fade', 'font' => 'Inter'],
                'quality'     => [
                    'honeypot' => true, 'captcha' => true, 'prevent_duplicates' => true,
                    'detect_straightline' => true, 'validate_input' => false, 'min_time_seconds' => 90,
                    'min_text_length' => 20, 'confirm_answers' => false, 'sequential_unlock' => false,
                    'track_tab_switches' => true, 'prevent_copy_paste' => true, 'require_attention' => true,
                ],
                'questions' => [
                    ['type' => 'number', 'question_text' => 'How many years have you worked here?', 'is_required' => true],
                    ['type' => 'likert5', 'question_text' => 'I feel valued at my workplace.', 'is_required' => true, 'options' => ["Strongly Disagree","Disagree","Neutral","Agree","Strongly Agree"]],
                    ['type' => 'likert5', 'question_text' => 'I have opportunities for growth.', 'is_required' => true, 'options' => ["Strongly Disagree","Disagree","Neutral","Agree","Strongly Agree"]],
                    ['type' => 'yes_no', 'question_text' => 'Would you recommend this company as a workplace?', 'is_required' => true],
                    ['type' => 'text', 'question_text' => 'What would make your work experience better?', 'is_required' => false, 'min_length' => 20],
                    ['type' => 'rating', 'question_text' => 'Rate your overall job satisfaction.', 'is_required' => true],
                    ['type' => 'likert5', 'question_text' => 'I trust leadership decisions', 'is_required' => true, 'options' => ["Strongly Disagree","Disagree","Neutral","Agree","Strongly Agree"]],
                ],
            ],
            'event-feedback' => [
                'name'             => 'Event Feedback',
                'icon'             => 'fa-calendar-check',
                'color'            => 'rose',
                'description'      => 'Collect post-event feedback quickly. Optimized for high completion rates with minimal friction.',
                'category'         => 'feedback',
                'difficulty'       => 'easy',
                'accuracy_score'   => 88,
                'estimated_minutes'=> 2,
                'popularity'       => 'high',
                'tags'             => ['event', 'feedback', 'webinar', 'conference', 'post-event'],
                'theme'            => ['bg' => 'glass', 'card_style' => 'glass', 'animation' => 'slide-up', 'font' => 'Inter'],
                'quality'     => [
                    'honeypot' => true, 'captcha' => true, 'prevent_duplicates' => true,
                    'detect_straightline' => true, 'validate_input' => false, 'min_time_seconds' => 30,
                    'min_text_length' => 10, 'confirm_answers' => false, 'sequential_unlock' => false,
                    'track_tab_switches' => false, 'prevent_copy_paste' => false, 'require_attention' => false,
                ],
                'questions' => [
                    ['type' => 'text', 'question_text' => 'Your name (optional)', 'is_required' => false],
                    ['type' => 'email', 'question_text' => 'Your email', 'is_required' => false],
                    ['type' => 'likert5', 'question_text' => 'How would you rate the event overall?', 'is_required' => true, 'options' => ["Poor","Fair","Good","Very Good","Excellent"]],
                    ['type' => 'likert5', 'question_text' => 'How relevant was the content?', 'is_required' => true, 'options' => ["Not Relevant","Slightly","Moderately","Relevant","Very Relevant"]],
                    ['type' => 'mcq_single', 'question_text' => 'How did you attend?', 'is_required' => true, 'options' => ["In-person","Live Online","Watched Recording","Other"]],
                    ['type' => 'text', 'question_text' => 'What topics would you like covered next time?', 'is_required' => false],
                ],
            ],
            'academic-research' => [
                'name'             => 'Academic Research',
                'icon'             => 'fa-graduation-cap',
                'color'            => 'amber',
                'description'      => 'Rigorous academic survey with multiple attention checks, trap questions, and speed bumps for maximum data quality.',
                'category'         => 'research',
                'difficulty'       => 'hard',
                'accuracy_score'   => 98,
                'estimated_minutes'=> 8,
                'popularity'       => 'medium',
                'tags'             => ['academic', 'research', 'scientific', 'rigorous', 'phd'],
                'theme'            => ['bg' => 'grid', 'card_style' => 'shadow', 'animation' => 'fade', 'font' => 'Inter'],
                'quality'     => [
                    'honeypot' => true, 'captcha' => true, 'prevent_duplicates' => true,
                    'detect_straightline' => true, 'validate_input' => true, 'min_time_seconds' => 120,
                    'min_text_length' => 20, 'confirm_answers' => true, 'sequential_unlock' => true,
                    'track_tab_switches' => true, 'prevent_copy_paste' => true, 'require_attention' => true,
                ],
                'questions' => [
                    ['type' => 'mcq_single', 'question_text' => 'What is your field of study?', 'is_required' => true, 'options' => ["Natural Sciences","Social Sciences","Engineering","Humanities","Medical","Business","Other"]],
                    ['type' => 'likert5', 'question_text' => 'How frequently do you read academic papers?', 'is_required' => true, 'options' => ["Never","Rarely","Monthly","Weekly","Daily"]],
                    ['type' => 'text', 'question_text' => 'What is 7 + 12? (speed bump)', 'is_required' => true, 'is_speed_bump' => true],
                    ['type' => 'likert5', 'question_text' => 'Please select "Strongly Agree" to confirm you are paying attention', 'is_required' => true, 'is_attention_check' => true, 'options' => ["Strongly Disagree","Disagree","Neutral","Agree","Strongly Agree"]],
                    ['type' => 'rating', 'question_text' => 'Rate the importance of peer review', 'is_required' => true],
                    ['type' => 'yes_no', 'question_text' => 'Have you ever published research?', 'is_required' => true, 'is_trap' => true],
                    ['type' => 'text', 'question_text' => 'Describe your research methodology in detail', 'is_required' => true, 'min_length' => 50],
                ],
            ],
            'product-feedback' => [
                'name'             => 'Product Feedback',
                'icon'             => 'fa-cube',
                'color'            => 'cyan',
                'description'      => 'Detailed product feedback with feature comparison, usability ratings, and copy-paste prevention.',
                'category'         => 'feedback',
                'difficulty'       => 'easy',
                'accuracy_score'   => 91,
                'estimated_minutes'=> 4,
                'popularity'       => 'high',
                'tags'             => ['product', 'ux', 'usability', 'feature', 'feedback'],
                'theme'            => ['bg' => 'glass', 'card_style' => 'outlined', 'animation' => 'slide-left', 'font' => 'Inter'],
                'quality'     => [
                    'honeypot' => true, 'captcha' => true, 'prevent_duplicates' => true,
                    'detect_straightline' => true, 'validate_input' => false, 'min_time_seconds' => 60,
                    'min_text_length' => 10, 'confirm_answers' => false, 'sequential_unlock' => false,
                    'track_tab_switches' => false, 'prevent_copy_paste' => false, 'require_attention' => true,
                ],
                'questions' => [
                    ['type' => 'text', 'question_text' => 'Which product did you use?', 'is_required' => true],
                    ['type' => 'likert5', 'question_text' => 'How easy was it to use?', 'is_required' => true, 'options' => ["Very Difficult","Difficult","Neutral","Easy","Very Easy"]],
                    ['type' => 'likert5', 'question_text' => 'How would you rate the design?', 'is_required' => true, 'options' => ["Poor","Fair","Good","Very Good","Excellent"]],
                    ['type' => 'mcq_multiple', 'question_text' => 'Which features did you use?', 'is_required' => true, 'options' => ["Feature A","Feature B","Feature C","Feature D","Feature E"]],
                    ['type' => 'likert5', 'question_text' => 'Select "Neutral" to confirm attention', 'is_required' => true, 'is_attention_check' => true, 'options' => ["Strongly Disagree","Disagree","Neutral","Agree","Strongly Agree"]],
                    ['type' => 'text', 'question_text' => 'What one thing would you improve?', 'is_required' => true, 'min_length' => 10],
                ],
            ],
            'health-wellness' => [
                'name'             => 'Health & Wellness',
                'icon'             => 'fa-heartbeat',
                'color'            => 'red',
                'description'      => 'Sensitive health data collection with privacy-first design, trap detection, and consistency scoring.',
                'category'         => 'research',
                'difficulty'       => 'medium',
                'accuracy_score'   => 94,
                'estimated_minutes'=> 5,
                'popularity'       => 'medium',
                'tags'             => ['health', 'wellness', 'medical', 'privacy', 'sensitive'],
                'theme'            => ['bg' => 'dots', 'card_style' => 'rounded', 'animation' => 'fade', 'font' => 'Inter'],
                'quality'     => [
                    'honeypot' => true, 'captcha' => true, 'prevent_duplicates' => true,
                    'detect_straightline' => true, 'validate_input' => true, 'min_time_seconds' => 90,
                    'min_text_length' => 15, 'confirm_answers' => true, 'sequential_unlock' => true,
                    'track_tab_switches' => true, 'prevent_copy_paste' => false, 'require_attention' => true,
                ],
                'questions' => [
                    ['type' => 'mcq_single', 'question_text' => 'How would you describe your overall health?', 'is_required' => true, 'options' => ["Poor","Fair","Good","Very Good","Excellent"]],
                    ['type' => 'number', 'question_text' => 'How many hours do you sleep per night?', 'is_required' => true],
                    ['type' => 'likert5', 'question_text' => 'How often do you exercise?', 'is_required' => true, 'options' => ["Never","Rarely","1-2 times/week","3-4 times/week","Daily"]],
                    ['type' => 'likert5', 'question_text' => 'How would you rate your stress level?', 'is_required' => true, 'options' => ["Very Low","Low","Moderate","High","Very High"]],
                    ['type' => 'likert5', 'question_text' => 'Select "Agree" to confirm', 'is_required' => true, 'is_attention_check' => true, 'options' => ["Strongly Disagree","Disagree","Neutral","Agree","Strongly Agree"]],
                    ['type' => 'text', 'question_text' => 'Any health tips you would like to share?', 'is_required' => false],
                ],
            ],
            'training-evaluation' => [
                'name'             => 'Training Evaluation',
                'icon'             => 'fa-chalkboard-teacher',
                'color'            => 'orange',
                'description'      => 'Evaluate training programs with knowledge checks, reaction metrics, and long-text analysis.',
                'category'         => 'feedback',
                'difficulty'       => 'easy',
                'accuracy_score'   => 89,
                'estimated_minutes'=> 3,
                'popularity'       => 'medium',
                'tags'             => ['training', 'learning', 'evaluation', 'education', 'course'],
                'theme'            => ['bg' => 'glass', 'card_style' => 'shadow', 'animation' => 'slide-up', 'font' => 'Inter'],
                'quality'     => [
                    'honeypot' => true, 'captcha' => true, 'prevent_duplicates' => true,
                    'detect_straightline' => true, 'validate_input' => false, 'min_time_seconds' => 45,
                    'min_text_length' => 10, 'confirm_answers' => false, 'sequential_unlock' => false,
                    'track_tab_switches' => false, 'prevent_copy_paste' => false, 'require_attention' => false,
                ],
                'questions' => [
                    ['type' => 'text', 'question_text' => 'What training did you attend?', 'is_required' => true],
                    ['type' => 'likert5', 'question_text' => 'How relevant was the training?', 'is_required' => true, 'options' => ["Not Relevant","Slightly","Moderately","Relevant","Very Relevant"]],
                    ['type' => 'rating', 'question_text' => 'Rate the instructor quality', 'is_required' => true],
                    ['type' => 'likert5', 'question_text' => 'Will you apply what you learned?', 'is_required' => true, 'options' => ["Definitely Not","Probably Not","Maybe","Probably Yes","Definitely Yes"]],
                    ['type' => 'text', 'question_text' => 'What was the most valuable thing you learned?', 'is_required' => true, 'min_length' => 15],
                    ['type' => 'text', 'question_text' => 'Suggestions for improvement', 'is_required' => false],
                ],
            ],
            'website-usability' => [
                'name'             => 'Website Usability',
                'icon'             => 'fa-globe',
                'color'            => 'teal',
                'description'      => 'Test website usability with task completion metrics, time tracking, and session recording simulation.',
                'category'         => 'research',
                'difficulty'       => 'medium',
                'accuracy_score'   => 93,
                'estimated_minutes'=> 4,
                'popularity'       => 'medium',
                'tags'             => ['usability', 'ux', 'website', 'testing', 'experience'],
                'theme'            => ['bg' => 'grid', 'card_style' => 'outlined', 'animation' => 'fade', 'font' => 'Inter'],
                'quality'     => [
                    'honeypot' => true, 'captcha' => true, 'prevent_duplicates' => true,
                    'detect_straightline' => true, 'validate_input' => false, 'min_time_seconds' => 60,
                    'min_text_length' => 10, 'confirm_answers' => true, 'sequential_unlock' => true,
                    'track_tab_switches' => true, 'prevent_copy_paste' => false, 'require_attention' => true,
                ],
                'questions' => [
                    ['type' => 'mcq_single', 'question_text' => 'How often do you visit our website?', 'is_required' => true, 'options' => ["First Time","Rarely","Monthly","Weekly","Daily"]],
                    ['type' => 'likert5', 'question_text' => 'How easy is it to find what you need?', 'is_required' => true, 'options' => ["Very Difficult","Difficult","Neutral","Easy","Very Easy"]],
                    ['type' => 'likert5', 'question_text' => 'How would you rate the page load speed?', 'is_required' => true, 'options' => ["Very Slow","Slow","Okay","Fast","Very Fast"]],
                    ['type' => 'likert5', 'question_text' => 'Select "Strongly Disagree" for attention', 'is_required' => true, 'is_attention_check' => true, 'options' => ["Strongly Disagree","Disagree","Neutral","Agree","Strongly Agree"]],
                    ['type' => 'text', 'question_text' => 'What feature would you add?', 'is_required' => false],
                    ['type' => 'rating', 'question_text' => 'Overall satisfaction with the website', 'is_required' => true],
                ],
            ],
            'mint-quiz' => [
                'name'             => 'Mint Quiz',
                'icon'             => 'fa-trophy',
                'color'            => 'emerald',
                'description'      => 'Fully gamified knowledge quiz with scoring, lives, timers, and sequential unlock. Perfect for learning assessments.',
                'category'         => 'quiz',
                'difficulty'       => 'medium',
                'accuracy_score'   => 97,
                'estimated_minutes'=> 5,
                'popularity'       => 'high',
                'tags'             => ['quiz', 'gamification', 'scoring', 'lives', 'learning', 'education', 'assessment'],
                'theme'            => ['bg' => 'glass', 'card_style' => 'glass', 'animation' => 'bounce', 'font' => 'Inter'],
                'quality'     => [
                    'honeypot' => true, 'captcha' => false, 'prevent_duplicates' => true,
                    'detect_straightline' => true, 'validate_input' => false, 'min_time_seconds' => 30,
                    'min_text_length' => 10, 'confirm_answers' => false, 'sequential_unlock' => true,
                    'quiz_mode' => true, 'quiz_pass_score' => 70, 'quiz_lives' => 3, 'quiz_timer_per_q' => 30, 'quiz_show_answers' => true,
                    'track_tab_switches' => true, 'prevent_copy_paste' => true, 'require_attention' => true,
                    'time_per_question' => true, 'prevent_back_nav' => true, 'fullscreen_mode' => true,
                ],
                'questions' => [
                    ['type' => 'mcq_single', 'question_text' => 'What is the capital of France?', 'is_required' => true, 'options' => ['London', 'Paris', 'Berlin', 'Madrid'], 'animation' => 'bounce'],
                    ['type' => 'mcq_single', 'question_text' => 'Which planet is known as the Red Planet?', 'is_required' => true, 'options' => ['Venus', 'Mars', 'Jupiter', 'Saturn'], 'animation' => 'fade'],
                    ['type' => 'number', 'question_text' => 'What is 15 × 12?', 'is_required' => true, 'min_value' => 0, 'max_value' => 999, 'animation' => 'slide-up'],
                    ['type' => 'mcq_single', 'question_text' => 'Who wrote "Romeo and Juliet"?', 'is_required' => true, 'options' => ['Charles Dickens', 'William Shakespeare', 'Jane Austen', 'Mark Twain'], 'animation' => 'scale'],
                    ['type' => 'yes_no', 'question_text' => 'Is water H₂O?', 'is_required' => true, 'animation' => 'glow'],
                    ['type' => 'mcq_single', 'question_text' => 'What is the largest ocean on Earth?', 'is_required' => true, 'options' => ['Atlantic', 'Indian', 'Pacific', 'Arctic'], 'animation' => 'drop'],
                    ['type' => 'text', 'question_text' => 'Name one programming language (speed bump)', 'is_required' => true, 'is_speed_bump' => true, 'min_length' => 2, 'animation' => 'bounce'],
                    ['type' => 'rating', 'question_text' => 'How confident do you feel about your answers?', 'is_required' => true, 'options' => ['1','2','3','4','5'], 'animation' => 'fade'],
                ],
            ],
            'flow-state' => [
                'name'             => 'Flow State',
                'icon'             => 'fa-water',
                'color'            => 'cyan',
                'description'      => 'Immersive, gamified experience with progressive difficulty, streak bonuses, and real-time feedback for deep engagement.',
                'category'         => 'quiz',
                'difficulty'       => 'medium',
                'accuracy_score'   => 95,
                'estimated_minutes'=> 6,
                'popularity'       => 'medium',
                'tags'             => ['flow', 'gamification', 'progressive', 'streak', 'immersive', 'engagement'],
                'theme'            => ['bg' => 'dots', 'card_style' => 'rounded', 'animation' => 'slide-up', 'font' => 'Inter'],
                'quality'     => [
                    'honeypot' => true, 'captcha' => false, 'prevent_duplicates' => true,
                    'detect_straightline' => true, 'validate_input' => false, 'min_time_seconds' => 45,
                    'min_text_length' => 10, 'confirm_answers' => false, 'sequential_unlock' => true,
                    'quiz_mode' => true, 'quiz_pass_score' => 60, 'quiz_lives' => 5, 'quiz_timer_per_q' => 45, 'quiz_show_answers' => true,
                    'track_tab_switches' => true, 'prevent_copy_paste' => false, 'require_attention' => true,
                    'time_per_question' => true, 'prevent_back_nav' => true, 'shuffle_questions' => true,
                ],
                'questions' => [
                    ['type' => 'likert5', 'question_text' => 'I enjoy challenges that test my knowledge', 'is_required' => true, 'options' => ['Strongly Disagree','Disagree','Neutral','Agree','Strongly Agree'], 'animation' => 'fade'],
                    ['type' => 'mcq_single', 'question_text' => 'Which of these is a programming language?', 'is_required' => true, 'options' => ['HTML', 'Python', 'CSS', 'HTTP'], 'animation' => 'slide-up'],
                    ['type' => 'mcq_single', 'question_text' => 'What does AI stand for?', 'is_required' => true, 'options' => ['Automated Intelligence', 'Artificial Intelligence', 'Advanced Integration', 'Algorithmic Input'], 'animation' => 'bounce'],
                    ['type' => 'text', 'question_text' => 'Define "machine learning" in one sentence', 'is_required' => true, 'min_length' => 10, 'animation' => 'slide-left'],
                    ['type' => 'likert5', 'question_text' => 'Select "Agree" to verify attention', 'is_required' => true, 'is_attention_check' => true, 'options' => ['Strongly Disagree','Disagree','Neutral','Agree','Strongly Agree'], 'animation' => 'scale'],
                    ['type' => 'rating', 'question_text' => 'Rate this survey experience', 'is_required' => true, 'options' => ['1','2','3','4','5'], 'animation' => 'glow'],
                ],
            ],
            'pulse-check' => [
                'name'             => 'Pulse Check',
                'icon'             => 'fa-heart-pulse',
                'color'            => 'rose',
                'description'      => 'Quick 30-second engagement pulse with gamified scoring. Capture immediate sentiment with minimal friction.',
                'category'         => 'feedback',
                'difficulty'       => 'easy',
                'accuracy_score'   => 90,
                'estimated_minutes'=> 1,
                'popularity'       => 'high',
                'tags'             => ['pulse', 'quick', 'sentiment', 'engagement', 'fast', 'gamified'],
                'theme'            => ['bg' => 'glass', 'card_style' => 'glass', 'animation' => 'scale', 'font' => 'Inter'],
                'quality'     => [
                    'honeypot' => true, 'captcha' => false, 'prevent_duplicates' => true,
                    'detect_straightline' => true, 'validate_input' => false, 'min_time_seconds' => 15,
                    'min_text_length' => 5, 'confirm_answers' => false, 'sequential_unlock' => false,
                    'quiz_mode' => false, 'track_tab_switches' => false, 'prevent_copy_paste' => false, 'require_attention' => false,
                ],
                'questions' => [
                    ['type' => 'rating', 'question_text' => 'How are you feeling right now?', 'is_required' => true, 'options' => ['1','2','3','4','5'], 'animation' => 'bounce'],
                    ['type' => 'yes_no', 'question_text' => 'Did you find value today?', 'is_required' => true, 'animation' => 'fade'],
                    ['type' => 'text', 'question_text' => 'One word to describe your experience', 'is_required' => false, 'max_length' => 20, 'animation' => 'scale'],
                ],
            ],
            'rapid-fire' => [
                'name'             => 'Rapid Fire',
                'icon'             => 'fa-bolt',
                'color'            => 'amber',
                'description'      => 'Fast-paced timed quiz with countdown per question. Tests knowledge under pressure with lives system.',
                'category'         => 'quiz',
                'difficulty'       => 'hard',
                'accuracy_score'   => 96,
                'estimated_minutes'=> 3,
                'popularity'       => 'medium',
                'tags'             => ['rapid', 'timed', 'speed', 'pressure', 'knowledge', 'quiz', 'challenge'],
                'theme'            => ['bg' => 'dots', 'card_style' => 'shadow', 'animation' => 'flip', 'font' => 'Inter'],
                'quality'     => [
                    'honeypot' => true, 'captcha' => false, 'prevent_duplicates' => true,
                    'detect_straightline' => true, 'validate_input' => false, 'min_time_seconds' => 20,
                    'min_text_length' => 5, 'confirm_answers' => false, 'sequential_unlock' => true,
                    'quiz_mode' => true, 'quiz_pass_score' => 80, 'quiz_lives' => 2, 'quiz_timer_per_q' => 15, 'quiz_show_answers' => true,
                    'track_tab_switches' => true, 'prevent_copy_paste' => true, 'require_attention' => true,
                    'time_per_question' => true, 'prevent_back_nav' => true, 'fullscreen_mode' => true,
                    'disable_rightclick' => true, 'shuffle_questions' => true, 'shuffle_options' => true,
                ],
                'questions' => [
                    ['type' => 'mcq_single', 'question_text' => 'What is the speed of light approx?', 'is_required' => true, 'options' => ['300 km/s', '300,000 km/s', '30,000 km/s', '3,000 km/s'], 'animation' => 'flip'],
                    ['type' => 'mcq_single', 'question_text' => 'Which element has symbol Fe?', 'is_required' => true, 'options' => ['Iron', 'Silver', 'Gold', 'Copper'], 'animation' => 'bounce'],
                    ['type' => 'number', 'question_text' => 'How many bits in a byte?', 'is_required' => true, 'min_value' => 0, 'max_value' => 64, 'animation' => 'slide-up'],
                    ['type' => 'mcq_single', 'question_text' => 'Who painted the Mona Lisa?', 'is_required' => true, 'options' => ['Michelangelo', 'Leonardo da Vinci', 'Raphael', 'Donatello'], 'animation' => 'swing'],
                    ['type' => 'yes_no', 'question_text' => 'Is the Earth round?', 'is_required' => true, 'animation' => 'shake'],
                    ['type' => 'text', 'question_text' => 'Type "speed" to confirm', 'is_required' => true, 'is_speed_bump' => true, 'animation' => 'zoom'],
                ],
            ],
            'deep-dive' => [
                'name'             => 'Deep Dive',
                'icon'             => 'fa-fish',
                'color'            => 'violet',
                'description'      => 'Comprehensive research survey with gamified breaks, trap questions, and detailed open-ended exploration.',
                'category'         => 'research',
                'difficulty'       => 'hard',
                'accuracy_score'   => 98,
                'estimated_minutes'=> 10,
                'popularity'       => 'high',
                'tags'             => ['comprehensive', 'research', 'deep', 'exploration', 'qualitative', 'in-depth'],
                'theme'            => ['bg' => 'grid', 'card_style' => 'outlined', 'animation' => 'fade', 'font' => 'Inter'],
                'quality'     => [
                    'honeypot' => true, 'captcha' => true, 'prevent_duplicates' => true,
                    'detect_straightline' => true, 'validate_input' => true, 'min_time_seconds' => 180,
                    'min_text_length' => 30, 'confirm_answers' => true, 'sequential_unlock' => false,
                    'quiz_mode' => false, 'track_tab_switches' => true, 'prevent_copy_paste' => false, 'require_attention' => true,
                    'shuffle_questions' => true, 'shuffle_options' => true,
                ],
                'questions' => [
                    ['type' => 'mcq_single', 'question_text' => 'What is your primary area of expertise?', 'is_required' => true, 'options' => ['Technology', 'Healthcare', 'Education', 'Finance', 'Manufacturing', 'Services', 'Other']],
                    ['type' => 'text', 'question_text' => 'What is 7 + 12? (speed bump)', 'is_required' => true, 'is_speed_bump' => true],
                    ['type' => 'likert5', 'question_text' => 'I enjoy deep analytical thinking', 'is_required' => true, 'options' => ['Strongly Disagree','Disagree','Neutral','Agree','Strongly Agree']],
                    ['type' => 'likert5', 'question_text' => 'Select "Strongly Agree" for attention', 'is_required' => true, 'is_attention_check' => true, 'options' => ['Strongly Disagree','Disagree','Neutral','Agree','Strongly Agree']],
                    ['type' => 'text', 'question_text' => 'Describe a complex problem you solved recently', 'is_required' => true, 'min_length' => 50, 'animation' => 'slide-up'],
                    ['type' => 'rating', 'question_text' => 'Rate your expertise level in your field', 'is_required' => true, 'options' => ['1','2','3','4','5','6','7','8','9','10']],
                    ['type' => 'mcq_multiple', 'question_text' => 'Which tools do you use regularly?', 'is_required' => true, 'options' => ['Analytics', 'CRM', 'ERP', 'Project Management', 'Communication', 'Automation']],
                    ['type' => 'likert5', 'question_text' => 'I would participate in future research', 'is_required' => true, 'options' => ['Strongly Disagree','Disagree','Neutral','Agree','Strongly Agree']],
                    ['type' => 'text', 'question_text' => 'Any additional thoughts?', 'is_required' => false],
                ],
            ],
        ];
    }

    public static function get(string $key): ?array
    {
        $all = self::all();
        return $all[$key] ?? null;
    }

    public static function categories(): array
    {
        return [
            'feedback' => ['label' => 'Feedback & Satisfaction', 'icon' => 'fa-comments', 'color' => 'emerald'],
            'research' => ['label' => 'Research & Academia',    'icon' => 'fa-flask',    'color' => 'blue'],
            'hr'       => ['label' => 'HR & Workplace',         'icon' => 'fa-building', 'color' => 'purple'],
            'quiz'     => ['label' => 'Quiz & Gamification',    'icon' => 'fa-gamepad',  'color' => 'amber'],
        ];
    }

    public static function difficultyLevels(): array
    {
        return [
            'easy'   => ['label' => 'Easy',   'icon' => 'fa-thermometer-quarter', 'color' => 'text-emerald-600', 'bg' => 'bg-emerald-100'],
            'medium' => ['label' => 'Medium',  'icon' => 'fa-thermometer-half',    'color' => 'text-amber-600',   'bg' => 'bg-amber-100'],
            'hard'   => ['label' => 'Rigorous','icon' => 'fa-thermometer-full',    'color' => 'text-red-600',     'bg' => 'bg-red-100'],
        ];
    }

    public static function accuracyColor(int $score): string
    {
        return $score >= 95 ? 'text-emerald-600' : ($score >= 90 ? 'text-blue-600' : ($score >= 85 ? 'text-amber-600' : 'text-gray-600'));
    }

    public static function accuracyBg(int $score): string
    {
        return $score >= 95 ? 'bg-emerald-100' : ($score >= 90 ? 'bg-blue-100' : ($score >= 85 ? 'bg-amber-100' : 'bg-gray-100'));
    }

    public static function accuracyBar(int $score): string
    {
        return $score >= 95 ? 'bg-emerald-500' : ($score >= 90 ? 'bg-blue-500' : ($score >= 85 ? 'bg-amber-500' : 'bg-gray-400'));
    }
}
