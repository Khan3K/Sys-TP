<?php

namespace Helpers;

class QuestionGenerator
{
    public static function fromText(string $text, int $count = 5): array
    {
        $sentences = self::splitSentences($text);
        if (count($sentences) < 2) return [];

        shuffle($sentences);
        $questions = [];
        $usedEntities = [];

        foreach ($sentences as $sentence) {
            if (count($questions) >= $count) break;
            $sentence = trim($sentence);
            if (strlen($sentence) < 20) continue;

            $entities = self::extractEntities($sentence);
            if (empty($entities)) continue;

            $entity = $entities[0];
            $key = strtolower($entity);
            if (in_array($key, $usedEntities)) continue;
            $usedEntities[] = $key;

            $type = self::pickType();
            $question = self::generateQuestion($sentence, $entity, $type, $sentences);
            if ($question) $questions[] = $question;
        }

        return $questions;
    }

    private static function splitSentences(string $text): array
    {
        $text = preg_replace('/\s+/', ' ', $text);
        $text = strip_tags($text);
        $raw = preg_split('/(?<=[.!?])\s+/', $text, -1, PREG_SPLIT_NO_EMPTY);
        $result = [];
        foreach ($raw as $s) {
            $s = trim($s);
            if (strlen($s) > 15) $result[] = $s;
        }
        return $result;
    }

    private static function extractEntities(string $sentence): array
    {
        $entities = [];

        if (preg_match_all('/\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\b/', $sentence, $m)) {
            foreach ($m[0] as $e) {
                $e = trim($e);
                if (strlen($e) > 2 && !in_array(strtolower($e), ['The', 'This', 'That', 'These', 'Those', 'What', 'When', 'Where', 'Why', 'How', 'Which', 'Who', 'Whom', 'Whose'])) {
                    $entities[] = $e;
                }
            }
        }

        if (preg_match_all('/\b\d+(?:[,.]\d+)*(?:\s*[%°CF])?\b/', $sentence, $m)) {
            foreach ($m[0] as $n) {
                $entities[] = trim($n);
            }
        }

        if (preg_match_all('/\b(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},?\s+\d{4}\b/', $sentence, $m)) {
            foreach ($m[0] as $d) {
                $entities[] = $d;
            }
        }

        if (empty($entities) && preg_match('/\b(is|was|are|were|has|have|had|will|shall|can|could|may|might)\s+(\w+)/i', $sentence, $m)) {
            if (strlen($m[2]) > 3) $entities[] = $m[2];
        }

        $entities = array_unique($entities);
        shuffle($entities);
        return $entities;
    }

    private static function pickType(): string
    {
        $types = ['multiple_choice', 'true_false', 'fill_blank'];
        return $types[array_rand($types)];
    }

    private static function generateQuestion(string $sentence, string $entity, string $type, array $allSentences): ?array
    {
        $cleanSentence = preg_replace('/[.!?]$/', '', $sentence);

        if ($type === 'true_false') {
            $isTrue = mt_rand(0, 1) === 1;
            if ($isTrue) {
                $statement = $cleanSentence . '.';
                $correct = 'True';
                $explanation = "The text states: \"$cleanSentence.\"";
            } else {
                $words = str_word_count($cleanSentence, 1);
                if (count($words) < 4) return null;
                $idx = array_rand($words);
                $original = $words[$idx];
                $replacements = self::getReplacements($original);
                if (!$replacements) return null;
                $wrongWord = $replacements[array_rand($replacements)];
                $falseStmt = preg_replace('/\b' . preg_quote($original, '/') . '\b/', $wrongWord, $cleanSentence, 1);
                if ($falseStmt === $cleanSentence) return null;
                $statement = $falseStmt . '.';
                $correct = 'False';
                $explanation = "The correct text says: \"$cleanSentence.\" The word \"$original\" was changed to \"$wrongWord.\"";
            }

            return [
                'type' => 'multiple_choice',
                'question_text' => $statement,
                'options' => ['True', 'False'],
                'expected_answer' => $correct,
                'explanation' => $explanation,
            ];
        }

        if ($type === 'fill_blank') {
            $blanked = preg_replace('/\b' . preg_quote($entity, '/') . '\b/', '__________', $cleanSentence, 1);
            if ($blanked === $cleanSentence) return null;

            return [
                'type' => 'text',
                'question_text' => $blanked . '.',
                'options' => [],
                'expected_answer' => $entity,
                'explanation' => "The text states: \"$cleanSentence.\" The answer is \"$entity.\"",
            ];
        }

        $distractors = self::getDistractors($entity, $allSentences);
        if (count($distractors) < 2) return null;

        $blanked = preg_replace('/\b' . preg_quote($entity, '/') . '\b/', '__________', $cleanSentence, 1);
        if ($blanked === $cleanSentence) return null;

        $options = array_merge([$entity], array_slice($distractors, 0, 3));
        shuffle($options);

        return [
            'type' => 'multiple_choice',
            'question_text' => $blanked . '?',
            'options' => $options,
            'expected_answer' => $entity,
            'explanation' => "The text states: \"$cleanSentence.\"",
        ];
    }

    private static function getDistractors(string $entity, array $allSentences): array
    {
        $entities = [];
        foreach ($allSentences as $s) {
            $extracted = self::extractEntities($s);
            foreach ($extracted as $e) {
                if (strtolower($e) !== strtolower($entity)) {
                    $entities[] = $e;
                }
            }
        }
        $entities = array_unique($entities);
        shuffle($entities);
        return $entities;
    }

    private static function getReplacements(string $word): ?array
    {
        $pairs = [
            'always' => ['never', 'sometimes', 'rarely', 'usually'],
            'never' => ['always', 'sometimes', 'often', 'rarely'],
            'all' => ['some', 'many', 'most', 'few'],
            'none' => ['some', 'many', 'all', 'several'],
            'every' => ['some', 'many', 'most', 'a few'],
            'best' => ['worst', 'average', 'poorest', 'least'],
            'worst' => ['best', 'average', 'finest', 'greatest'],
            'first' => ['last', 'second', 'final', 'initial'],
            'last' => ['first', 'initial', 'opening', 'earliest'],
            'increase' => ['decrease', 'reduce', 'lower', 'diminish'],
            'decrease' => ['increase', 'raise', 'grow', 'expand'],
            'largest' => ['smallest', 'tiniest', 'least', 'minimum'],
            'smallest' => ['largest', 'biggest', 'greatest', 'maximum'],
            'most' => ['least', 'fewest', 'minimum', 'lowest'],
            'least' => ['most', 'greatest', 'maximum', 'highest'],
            'before' => ['after', 'following', 'later', 'subsequent'],
            'after' => ['before', 'prior', 'earlier', 'preceding'],
            'above' => ['below', 'beneath', 'under', 'underneath'],
            'below' => ['above', 'over', 'higher', 'superior'],
        ];
        $lower = strtolower($word);
        return $pairs[$lower] ?? null;
    }
}
