<?php

namespace Services;

class QuestionNLP
{
    private static array $typeMap = [
        'rating' => [
            'rate', 'rating', 'stars', 'star', 'how would you rate', 'on a scale',
            'satisfaction', 'satisfied', 'how satisfied', 'score', 'score out of',
            'how much', 'how likely', 'level of', 'overall',
        ],
        'nps' => [
            'net promoter', 'recommend', 'how likely to recommend', 'promoter',
            'nps', '0-10', 'would you recommend',
        ],
        'yes_no' => [
            'do you', 'have you', 'are you', 'would you', 'did you',
            'is there', 'are there', 'do they', 'yes or no', 'yes/no',
            'agree or disagree', 'true or false', 'did they',
        ],
        'mcq_single' => [
            'which', 'what is your favorite', 'choose one', 'pick one',
            'what is your preferred', 'select one', 'single choice',
            'what type of', 'best describes', 'which of the following',
        ],
        'mcq_multiple' => [
            'select all', 'choose all', 'which of these', 'check all',
            'multiple choice', 'select any', 'choose any', 'pick all',
        ],
        'dropdown' => [
            'dropdown', 'select from', 'choose from list', 'country',
            'state', 'province', 'city', 'industry', 'department',
        ],
        'ranking' => [
            'rank', 'order', 'prioritize', 'most important', 'least important',
            'sort', 'arrange', 'top 3', 'top 5', 'rank the following',
        ],
        'likert5' => [
            'strongly disagree', 'agree disagree', 'satisfaction scale',
            'to what extent', 'how much do you agree', '5-point',
            'agree neutral disagree', 'level of agreement',
        ],
        'likert7' => [
            '7-point', 'very strongly', '7 scale', '7 likert',
            'extremely satisfied', 'detailed agreement',
        ],
        'slider' => [
            'slider', 'continuous scale', 'range slider', 'drag',
            'slide to rate', 'from 0 to', '0 to 10', '0 to 100',
        ],
        'matrix' => [
            'matrix', 'grid', 'rate the following', 'for each of the following',
            'please rate each', 'evaluate each', 'table',
        ],
        'text' => [
            'describe', 'tell us about', 'what do you think', 'feedback',
            'comments', 'opinion', 'suggestions', 'thoughts',
            'open ended', 'explain', 'elaborate', 'any other',
            'in your own words', 'how would you describe', 'please share',
        ],
        'textarea' => [
            'long answer', 'detailed', 'paragraph', 'essay', 'long text',
            'write about', 'describe in detail',
        ],
        'email' => [
            'email', 'email address', 'e-mail', 'contact email',
        ],
        'phone' => [
            'phone', 'phone number', 'mobile', 'telephone', 'cell phone',
            'contact number', 'whatsapp',
        ],
        'number' => [
            'how many', 'what is your age', 'how old', 'years of experience',
            'amount', 'count', 'quantity', 'how much', 'number of',
            'what age', 'how long',
        ],
        'date' => [
            'date', 'what date', 'when did', 'birthday', 'birth date',
            'date of', 'what day', 'which date',
        ],
        'time' => [
            'what time', 'time of day', 'what hour', 'which time',
            'time slot', 'arrival time',
        ],
        'datetime' => [
            'date and time', 'date time', 'when exactly', 'datetime',
            'appointment', 'schedule',
        ],
        'address' => [
            'address', 'where do you live', 'location', 'residence',
            'shipping address', 'mailing address', 'postal code',
            'zip code', 'country', 'city you live',
        ],
        'url' => [
            'website', 'url', 'link', 'web page', 'site url',
            'linkedin', 'portfolio', 'social media link',
        ],
        'file_upload' => [
            'upload', 'file', 'document', 'attach', 'attachment',
            'resume', 'cv', 'photo', 'image upload', 'pdf',
        ],
        'signature' => [
            'signature', 'sign here', 'digital signature', 'sign below',
            'e-signature', 'authorize',
        ],
        'color' => [
            'color', 'favorite color', 'preferred color', 'colour',
            'what color', 'which color',
        ],
        'percentage' => [
            'percentage', 'percent', '%', 'proportion', 'allocation',
            'what percent', 'how much percent',
        ],
        'multi_text' => [
            'multiple text', 'multi text', 'list of items', 'multiple fields',
            'several questions', 'multiple short answers',
        ],
    ];

    private static array $categories = [
        'rating' => 'Rating & Scale',
        'nps' => 'Loyalty Measurement',
        'yes_no' => 'Binary / Yes-No',
        'mcq_single' => 'Multiple Choice',
        'mcq_multiple' => 'Multiple Choice',
        'dropdown' => 'Selection',
        'ranking' => 'Ranking & Prioritization',
        'likert5' => 'Likert Scale',
        'likert7' => 'Likert Scale',
        'slider' => 'Continuous Scale',
        'matrix' => 'Matrix / Grid',
        'text' => 'Open-ended',
        'textarea' => 'Open-ended',
        'email' => 'Contact Info',
        'phone' => 'Contact Info',
        'number' => 'Numeric Input',
        'date' => 'Date & Time',
        'time' => 'Date & Time',
        'datetime' => 'Date & Time',
        'address' => 'Location',
        'url' => 'Contact Info',
        'file_upload' => 'File Upload',
        'signature' => 'Verification',
        'color' => 'Preference',
        'percentage' => 'Numeric Input',
        'multi_text' => 'Structured Input',
    ];

    private static array $defaultOptions = [
        'rating' => ['1', '2', '3', '4', '5'],
        'nps' => ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10'],
        'yes_no' => ['Yes', 'No'],
        'likert5' => ['Strongly Disagree', 'Disagree', 'Neutral', 'Agree', 'Strongly Agree'],
        'likert7' => ['Strongly Disagree', 'Disagree', 'Slightly Disagree', 'Neutral', 'Slightly Agree', 'Agree', 'Strongly Agree'],
        'slider' => null,
        'ranking' => null,
        'dropdown' => null,
        'matrix' => null,
    ];

    public static function analyze(string $prompt): array
    {
        $prompt = trim($prompt);
        if (empty($prompt)) {
            return self::error('Please describe what you want to ask.');
        }

        $lower = mb_strtolower($prompt);
        $scores = [];

        foreach (self::$typeMap as $type => $keywords) {
            $score = 0;
            foreach ($keywords as $kw) {
                if (mb_strpos($lower, $kw) !== false) {
                    $score += strlen($kw) / 10;
                }
            }
            if ($score > 0) {
                $scores[$type] = round($score, 2);
            }
        }

        if (empty($scores)) {
            return self::analyzeFallback($prompt, $lower);
        }

        arsort($scores);
        $types = array_keys($scores);
        $primaryType = $types[0];
        $bestScore = $scores[$primaryType];

        $results = [];
        foreach (array_slice($types, 0, 3) as $type) {
            $confidence = min(100, round(($scores[$type] / max($scores)) * 100));
            if ($confidence < 30) break;
            $results[] = self::buildSuggestion($type, $prompt, $confidence, $lower);
        }

        return [
            'success' => true,
            'prompt' => $prompt,
            'primary' => $results[0] ?? null,
            'suggestions' => $results,
            'count' => count($results),
        ];
    }

    private static function analyzeFallback(string $prompt, string $lower): array
    {
        preg_match_all('/\b(\w+)\b/', $lower, $words);
        $words = array_unique($words[1]);
        $wordCount = count($words);

        if ($wordCount < 4) {
            return self::error('Please provide more detail. For example: "Ask users to rate their satisfaction from 1 to 5"');
        }

        $questionWords = ['what', 'how', 'why', 'when', 'where', 'who', 'which', 'do', 'does', 'did', 'are', 'is', 'have', 'has'];
        $isQuestion = false;
        foreach ($questionWords as $qw) {
            if (mb_strpos($lower, $qw) === 0 || preg_match('/\b' . $qw . '\b/', $lower)) {
                $isQuestion = true;
                break;
            }
        }

        if ($isQuestion && preg_match('/\b(you|your|they|he|she|it)\b/', $lower)) {
            $result = self::buildSuggestion('text', "Please share your thoughts on: $prompt", 65, $lower);
        } elseif (preg_match('/\b(rate|score|scale)\b/', $lower)) {
            $result = self::buildSuggestion('rating', "How would you rate the following: $prompt", 60, $lower);
        } elseif (preg_match('/\b(select|choose|pick|option)\b/', $lower)) {
            $result = self::buildSuggestion('mcq_single', $prompt, 55, $lower);
        } else {
            $result = self::buildSuggestion('text', $prompt, 50, $lower);
        }

        return [
            'success' => true,
            'prompt' => $prompt,
            'primary' => $result,
            'suggestions' => [$result],
            'count' => 1,
        ];
    }

    private static function buildSuggestion(string $type, string $prompt, int $confidence, string $lower): array
    {
        $questionText = self::generateQuestionText($type, $prompt, $lower);
        $options = self::generateOptions($type, $prompt, $lower);

        return [
            'type' => $type,
            'question_text' => $questionText,
            'options' => $options,
            'category' => self::$categories[$type] ?? 'General',
            'confidence' => $confidence,
            'explanation' => self::generateExplanation($type, $prompt),
            'icon' => self::getTypeIcon($type),
            'color' => self::getTypeColor($type),
        ];
    }

    private static function generateQuestionText(string $type, string $prompt, string $lower): string
    {
        $hasQuestionMark = mb_strpos($prompt, '?') !== false;

        if ($hasQuestionMark) {
            return $prompt;
        }

        $prefixes = [
            'rating' => 'How would you rate ',
            'nps' => 'How likely are you to recommend ',
            'yes_no' => 'Do you ',
            'mcq_single' => 'Which of the following best describes ',
            'mcq_multiple' => 'Which of the following apply to ',
            'dropdown' => 'Please select ',
            'likert5' => 'To what extent do you agree: ',
            'likert7' => 'Please indicate your level of agreement: ',
            'slider' => 'On a scale of 0 to 10, how would you rate ',
            'text' => 'Please share your thoughts on ',
            'textarea' => 'Please describe in detail ',
            'email' => 'What is your email address?',
            'phone' => 'What is your phone number?',
            'number' => 'How many ',
            'date' => 'What date did ',
            'time' => 'What time will ',
            'address' => 'What is your address?',
            'signature' => 'Please sign below to confirm ',
            'color' => 'What is your preferred color for ',
            'file_upload' => 'Please upload ',
            'ranking' => 'Please rank the following in order of ',
        ];

        if (isset($prefixes[$type])) {
            $prefix = $prefixes[$type];

            if (in_array($type, ['email', 'phone', 'address'])) {
                return $prefix;
            }

            $cleaned = preg_replace('/^(please|can you|could you|would you|i want to|i need to|ask|tell)\s+/i', '', $prompt);
            $cleaned = preg_replace('/^(\w+)\s+(them|users|respondents|people|everyone)\s+/i', '', $cleaned);

            $article = in_array($type, ['rating', 'slider']) ? '' : '';

            if (preg_match('/^(' . implode('|', array_map('preg_quote', array_keys($prefixes))) . ')/', lcfirst($cleaned))) {
                return ucfirst($cleaned) . ($hasQuestionMark ? '' : '?');
            }

            return rtrim($prefix . lcfirst($cleaned), ' .') . '?';
        }

        $questionFormers = ['what', 'how', 'why', 'when', 'where', 'who', 'which', 'do', 'does', 'did', 'are', 'is', 'have', 'has', 'would', 'could', 'should', 'can'];

        $firstWord = strtok($lower, ' ');
        if ($firstWord && in_array($firstWord, $questionFormers)) {
            return ucfirst($prompt) . ($hasQuestionMark ? '' : '?');
        }

        return 'How would you describe ' . lcfirst($prompt) . '?';
    }

    private static function generateOptions(?string $type, string $prompt, string $lower): ?array
    {
        if (in_array($type, ['text', 'textarea', 'email', 'phone', 'number', 'date', 'time', 'datetime', 'url', 'signature', 'color', 'file_upload', 'multi_text', 'address', 'percentage'])) {
            return null;
        }

        if (isset(self::$defaultOptions[$type])) {
            if (in_array($type, ['dropdown', 'ranking']) || ($type === 'slider')) {
                return self::extractListOptions($prompt);
            }
            return self::$defaultOptions[$type];
        }

        if (in_array($type, ['mcq_single', 'mcq_multiple', 'dropdown'])) {
            return self::extractListOptions($prompt) ?: ['Option 1', 'Option 2', 'Option 3', 'Other'];
        }

        return null;
    }

    private static function extractListOptions(string $prompt): ?array
    {
        $patterns = [
            '/\b(?:like|such as|including|for example|e\.g\.|examples?|options?|choices?)\s*:\s*(.+?)(?:\.|$)/i',
            '/\b(?:like|such as|including|for example|e\.g\.|examples?|options?|choices?)\s+(.+?)(?:\.|$)/i',
            '/[:,;]\s*(.+?)(?:\.|$)/',
        ];

        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $prompt, $m)) {
                $items = preg_split('/[,;\/]|(?:\s+and\s+)|\s+or\s+/', $m[1]);
                $items = array_map('trim', $items);
                $items = array_filter($items, fn($i) => !empty($i) && strlen($i) > 2);
                if (count($items) >= 2) {
                    return array_slice(array_values($items), 0, 15);
                }
            }
        }

        $lines = explode("\n", $prompt);
        if (count($lines) >= 3) {
            $items = array_map('trim', $lines);
            $items = array_filter($items, fn($i) => !empty($i) && strlen($i) > 1);
            $items = array_values($items);
            $nonQuestion = array_filter($items, fn($i) => !preg_match('/[?]$/', $i));
            if (count($nonQuestion) >= 2) {
                return array_slice(array_values($nonQuestion), 0, 15);
            }
        }

        return null;
    }

    private static function generateExplanation(string $type, string $prompt): string
    {
        $explanations = [
            'rating' => 'Perfect for measuring satisfaction, quality, or experience level on a numeric scale.',
            'nps' => 'Industry-standard Net Promoter Score question for measuring customer loyalty.',
            'yes_no' => 'Simple binary choice — great for quick yes/no or agree/disagree questions.',
            'mcq_single' => 'Single-select multiple choice — ideal when respondents should pick one best option.',
            'mcq_multiple' => 'Multi-select question — let respondents choose all options that apply.',
            'dropdown' => 'Compact selection from a list — saves space when you have many options.',
            'ranking' => 'Ranking question — ask respondents to order items by preference or priority.',
            'likert5' => '5-point Likert scale — classic agreement measurement with neutral midpoint.',
            'likert7' => '7-point Likert scale — finer granularity for detailed attitude measurement.',
            'slider' => 'Visual continuous scale — intuitive rating with drag interaction.',
            'matrix' => 'Matrix/grid question — rate multiple items against the same scale efficiently.',
            'text' => 'Open-ended text — let respondents share their thoughts freely.',
            'textarea' => 'Long-form text — for detailed responses, stories, or comprehensive feedback.',
            'email' => 'Email input with validation — collects properly formatted email addresses.',
            'phone' => 'Phone number input — for contact information collection.',
            'number' => 'Numeric input — precise numbers for age, quantity, or measurements.',
            'date' => 'Date picker — for dates, birthdays, or event scheduling.',
            'time' => 'Time input — for time slots, schedules, or duration preferences.',
            'datetime' => 'Date and time combined — for appointments and exact scheduling.',
            'address' => 'Address input — collect location details for shipping or demographics.',
            'url' => 'Website URL input — for collecting links, portfolios, or social profiles.',
            'file_upload' => 'File upload — let respondents attach documents, images, or files.',
            'signature' => 'Digital signature — collect consent or authorization.',
            'color' => 'Color picker — for design preferences or visual choices.',
            'percentage' => 'Percentage input — for proportional allocation or distribution questions.',
            'multi_text' => 'Multiple text fields — for structured data like name, company, role.',
        ];

        return $explanations[$type] ?? 'A question to gather respondent input on this topic.';
    }

    public static function getTypeIcon(string $type): string
    {
        $icons = [
            'text' => 'fa-font', 'number' => 'fa-hashtag', 'email' => 'fa-at',
            'phone' => 'fa-phone', 'date' => 'fa-calendar', 'yes_no' => 'fa-check-circle',
            'rating' => 'fa-star', 'mcq_single' => 'fa-circle-dot', 'mcq_multiple' => 'fa-list-check',
            'dropdown' => 'fa-chevron-down', 'likert5' => 'fa-grip-lines', 'likert7' => 'fa-grip-lines',
            'slider' => 'fa-sliders', 'matrix' => 'fa-table', 'file_upload' => 'fa-upload',
            'textarea' => 'fa-paragraph', 'url' => 'fa-link', 'nps' => 'fa-chart-bar',
            'ranking' => 'fa-list-ol', 'multi_text' => 'fa-list', 'address' => 'fa-map-marker-alt',
            'time' => 'fa-clock', 'datetime' => 'fa-calendar-alt', 'color' => 'fa-palette',
            'percentage' => 'fa-percent', 'signature' => 'fa-pen-fancy',
        ];
        return $icons[$type] ?? 'fa-circle';
    }

    public static function getTypeColor(string $type): string
    {
        $colors = [
            'text' => '#10b981', 'number' => '#3b82f6', 'email' => '#06b6d4',
            'phone' => '#14b8a6', 'date' => '#f43f5e', 'yes_no' => '#3b82f6',
            'rating' => '#f59e0b', 'mcq_single' => '#a855f7', 'mcq_multiple' => '#d946ef',
            'dropdown' => '#f97316', 'likert5' => '#8b5cf6', 'likert7' => '#8b5cf6',
            'slider' => '#ec4899', 'matrix' => '#6b7280', 'file_upload' => '#0ea5e9',
            'textarea' => '#78716c', 'url' => '#0ea5e9', 'nps' => '#ef4444',
            'ranking' => '#f59e0b', 'multi_text' => '#84cc16', 'address' => '#eab308',
            'time' => '#f43f5e', 'datetime' => '#d946ef', 'color' => '#ec4899',
            'percentage' => '#06b6d4', 'signature' => '#6366f1',
        ];
        return $colors[$type] ?? '#6366f1';
    }

    private static function error(string $message): array
    {
        return [
            'success' => false,
            'error' => $message,
            'prompt' => '',
            'primary' => null,
            'suggestions' => [],
            'count' => 0,
        ];
    }
}
