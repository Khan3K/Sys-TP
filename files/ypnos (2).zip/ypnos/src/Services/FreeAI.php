<?php

namespace Services;

class FreeAI
{
    private const POLLINATIONS_URL = "https://text.pollinations.ai/";

    public static function suggestQuestion(string $prompt): array
    {
        $prompt = trim($prompt);
        if (empty($prompt)) {
            return [
                "success" => false,
                "error" => "Please describe what you want to ask.",
                "suggestions" => [],
                "count" => 0,
            ];
        }

        $response = self::callPollinations($prompt);

        if ($response !== null) {
            $parsed = self::parseResponse($response);
            if (!empty($parsed)) {
                return [
                    "success" => true,
                    "source" => "ai",
                    "prompt" => $prompt,
                    "primary" => $parsed[0],
                    "suggestions" => $parsed,
                    "count" => count($parsed),
                ];
            }
        }

        $fallback = QuestionNLP::analyze($prompt);
        if ($fallback["success"]) {
            $fallback["source"] = "rule";
        }
        return $fallback;
    }

    public static function generateQuestions(
        string $text,
        int $count = 5,
        string $mode = "form",
    ): array {
        $text = trim($text);
        $count = max(1, min(20, $count));
        $mode = $mode === "chat" ? "chat" : "form";

        if ($text === "") {
            return ["success" => false, "source" => "none", "questions" => []];
        }

        $systemPrompt =
            $mode === "chat"
                ? "You are an expert conversational survey designer. Generate natural chat-style interview questions. Output ONLY JSON array."
                : "You are an expert form survey designer. Generate clear and unbiased survey questions. Output ONLY JSON array.";

        $schemaPrompt =
            "Return ONLY a valid JSON array with exactly " .
            $count .
            " items. " .
            'Each item shape: {"type":"...","question_text":"...","options":[],"explanation":"..."}. ' .
            "Allowed types: text,textarea,email,phone,number,date,time,datetime,url,yes_no,rating,nps,likert5,likert7,mcq_single,mcq_multiple,dropdown,ranking,slider,address,matrix,multi_text,percentage,file_upload,signature,color. " .
            "Use options only when appropriate (mcq, dropdown, ranking, likert, rating, nps, yes_no). " .
            "Question text must be specific, answerable, and non-ambiguous. " .
            "For complex topics, decompose into concrete sub-questions. " .
            "User request: " .
            $text;

        $response = self::callPollinationsCustom($schemaPrompt, $systemPrompt);
        if ($response === null) {
            return ["success" => false, "source" => "none", "questions" => []];
        }

        $parsed = self::parseResponse($response);
        if (empty($parsed)) {
            return ["success" => false, "source" => "none", "questions" => []];
        }

        $questions = [];
        foreach ($parsed as $item) {
            $qText = trim((string) ($item["question_text"] ?? ""));
            if ($qText === "") {
                continue;
            }
            $options = null;
            if (isset($item["options"]) && is_array($item["options"])) {
                $options = array_values(
                    array_filter(
                        array_map("strval", $item["options"]),
                        fn($v) => trim($v) !== "",
                    ),
                );
                if (empty($options)) {
                    $options = null;
                }
            }

            $questions[] = [
                "type" => (string) ($item["type"] ?? "text"),
                "question_text" => $qText,
                "options" => $options,
                "explanation" => trim((string) ($item["explanation"] ?? "")),
            ];

            if (count($questions) >= $count) {
                break;
            }
        }

        return [
            "success" => !empty($questions),
            "source" => "ai",
            "questions" => $questions,
        ];
    }

    private static function callPollinations(string $prompt): ?string
    {
        $systemPrompt =
            'You are a survey question generator. Given a user\'s request, generate 1-3 survey questions. ' .
            'Respond ONLY with a JSON array. Each item: {"type":"question_type","question_text":"...","options":["..."],' .
            '"category":"...","explanation":"..."}. ' .
            "Types: rating,nps,yes_no,mcq_single,mcq_multiple,dropdown,ranking,likert5,slider,text,email,phone,number,date,file_upload,signature,color. " .
            "Use options only for: rating,nps,yes_no,mcq_single,mcq_multiple,dropdown,likert5. " .
            "For mcq_single/mcq_multiple/dropdown, generate relevant options from context. " .
            'Be concise. Example: [{"type":"rating","question_text":"How satisfied are you?","options":["1","2","3","4","5"],"category":"Rating & Scale","explanation":"5-point satisfaction scale"}]';

        return self::callPollinationsCustom($prompt, $systemPrompt);
    }

    private static function callPollinationsCustom(
        string $prompt,
        string $systemPrompt,
    ): ?string {
        $payload = json_encode([
            "messages" => [
                ["role" => "system", "content" => $systemPrompt],
                ["role" => "user", "content" => $prompt],
            ],
            "model" => "mistral",
            "json" => true,
            "seed" => rand(1, 99999),
        ]);

        $ctx = stream_context_create([
            "http" => [
                "method" => "POST",
                "header" =>
                    "Content-Type: application/json\r\nAccept: application/json\r\n",
                "content" => $payload,
                "timeout" => 20,
                "ignore_errors" => true,
            ],
            "ssl" => [
                "verify_peer" => false,
                "verify_peer_name" => false,
            ],
        ]);

        $result = @file_get_contents(self::POLLINATIONS_URL, false, $ctx);

        if ($result === false) {
            return null;
        }

        return $result;
    }

    private static function parseResponse(string $response): array
    {
        $data = json_decode($response, true);
        if ($data === null) {
            $cleaned = trim($response);
            if (preg_match("/\[[\s\S]*\]/", $cleaned, $m)) {
                $data = json_decode($m[0], true);
            }
        }

        if (!is_array($data)) {
            return [];
        }

        $results = [];
        $validTypes = [
            "text",
            "number",
            "email",
            "phone",
            "date",
            "likert5",
            "likert7",
            "mcq_single",
            "mcq_multiple",
            "dropdown",
            "rating",
            "slider",
            "yes_no",
            "nps",
            "ranking",
            "textarea",
            "url",
            "file_upload",
            "signature",
            "color",
            "percentage",
            "address",
            "time",
            "datetime",
            "multi_text",
            "matrix",
        ];

        foreach ($data as $item) {
            if (!isset($item["type"], $item["question_text"])) {
                continue;
            }

            $type = $item["type"];
            if (!in_array($type, $validTypes)) {
                $type = "text";
            }

            $results[] = [
                "type" => $type,
                "question_text" => $item["question_text"],
                "options" =>
                    isset($item["options"]) && is_array($item["options"])
                        ? $item["options"]
                        : null,
                "category" =>
                    $item["category"] ??
                    (QuestionNLP::analyze($item["question_text"])["primary"][
                        "category"
                    ] ??
                        "General"),
                "explanation" => $item["explanation"] ?? "",
                "confidence" => 85,
                "icon" => QuestionNLP::getTypeIcon($type),
                "color" => QuestionNLP::getTypeColor($type),
            ];

            if (count($results) >= 3) {
                break;
            }
        }

        return $results;
    }
}
