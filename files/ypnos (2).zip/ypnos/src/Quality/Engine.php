<?php

namespace Quality;

use Core\Database;

class Engine
{
    private $checks = [];
    private $results = [];
    private $threshold;

    public function __construct(float $threshold = 70.0)
    {
        $this->threshold = $threshold;
        $this->registerDefaultChecks();
    }

    private function registerDefaultChecks(): void
    {
        $this->checks = [
            new Checks\AttentionCheck(),
            new Checks\TimeCheck(),
            new Checks\PatternCheck(),
            new Checks\ConsistencyCheck(),
            new Checks\TrapCheck(),
            new Checks\BotCheck(),
            new Checks\GibberishCheck(),
            new Checks\OutlierCheck(),
            new Checks\LongstringCheck(),
            new Checks\EmojiCheck(),
            new Checks\ProfanityCheck(),
            new Checks\SpeedBumpCheck(),
        ];
    }

    public function setThreshold(float $threshold): void
    {
        $this->threshold = $threshold;
    }

    public function evaluate(int $responseId, array $answers, array $questions, array $survey): array
    {
        $this->results = [];
        $db = Database::getInstance();

        $response = $db->fetchOne("SELECT * FROM responses WHERE id = ?", [$responseId]);

        $context = [
            'response' => $response,
            'survey'   => $survey,
            'answers'  => $answers,
            'questions' => $questions,
        ];

        $totalScore = 0;
        $maxScore = 0;

        foreach ($this->checks as $check) {
            $result = $check->run($context);
            $this->results[] = $result;

            $db->insert('quality_logs', [
                'response_id'  => $responseId,
                'check_type'   => $result['check_type'],
                'passed'       => $result['passed'] ? 1 : 0,
                'score'        => $result['score'],
                'details_json' => json_encode($result['details'] ?? []),
            ]);

            $totalScore += $result['score'];
            $maxScore += 100;
        }

        $overallScore = $maxScore > 0 ? round(($totalScore / $maxScore) * 100, 2) : 0;
        $autoRejected = $overallScore < $this->threshold;

        $scoreMap = [];
        foreach ($this->results as $r) {
            $scoreMap[$r['check_type'] . '_score'] = $r['score'];
        }

        $db->insert('quality_scores', [
            'response_id'       => $responseId,
            'overall_score'     => $overallScore,
            'attention_score'   => $scoreMap['attention_score'] ?? 0,
            'time_score'        => $scoreMap['time_score'] ?? 0,
            'pattern_score'     => $scoreMap['pattern_score'] ?? 0,
            'consistency_score' => $scoreMap['consistency_score'] ?? 0,
            'trap_score'        => $scoreMap['trap_score'] ?? 0,
            'bot_score'         => $scoreMap['bot_score'] ?? 0,
            'gibberish_score'   => $scoreMap['gibberish_score'] ?? 0,
            'longstring_score'  => $scoreMap['longstring_score'] ?? 0,
            'outlier_score'     => $scoreMap['outlier_score'] ?? 0,
            'emoji_score'       => $scoreMap['emoji_score'] ?? 0,
            'profanity_score'   => $scoreMap['profanity_score'] ?? 0,
            'speed_bump_score'  => $scoreMap['speed_bump_score'] ?? 0,
            'is_auto_rejected'  => $autoRejected ? 1 : 0,
        ]);

        $status = $autoRejected ? 'flagged' : 'accepted';
        $db->update('responses', [
            'status'        => $status,
            'quality_score' => $overallScore,
        ], 'id = ?', [$responseId]);

        return [
            'overall_score' => $overallScore,
            'auto_rejected' => $autoRejected,
            'threshold'     => $this->threshold,
            'checks'        => $this->results,
        ];
    }

    public function getResults(): array
    {
        return $this->results;
    }
}
