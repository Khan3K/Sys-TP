<?php

namespace Quality\Checks;

abstract class BaseCheck
{
    protected $name;
    protected $weight = 1;

    abstract public function run(array $context): array;

    protected function result(bool $passed, float $score, array $details = []): array
    {
        return [
            'check_type' => $this->name,
            'passed'     => $passed,
            'score'      => $score,
            'weight'     => $this->weight,
            'details'    => $details,
        ];
    }
}
