<?php

namespace Quality\Checks;

class GibberishCheck extends BaseCheck
{
    protected $name = 'gibberish';

    public function run(array $context): array
    {
        $answers = $context['answers'];
        $questions = $context['questions'];
        $flags = [];
        $textAnswers = [];

        foreach ($answers as $a) {
            $val = trim($a['answer_value'] ?? '');
            if (empty($val)) continue;

            $q = $this->findQuestion($a['question_id'], $questions);
            if (!$q) continue;
            if (!in_array($q['type'], ['text', 'email', 'phone'])) continue;

            if ($this->isGibberish($val)) {
                $flags[] = "Gibberish detected in question #{$a['question_id']}";
            }
            if ($this->isRepeatedChars($val)) {
                $flags[] = "Repeated characters in question #{$a['question_id']}";
            }
            if ($this->isKeyboardSmash($val)) {
                $flags[] = "Keyboard smash in question #{$a['question_id']}";
            }

            $textAnswers[] = [
                'qid' => $a['question_id'],
                'text' => $val,
                'qtext' => $q['question_text'] ?? '',
            ];
        }

        // Cross-answer repetition check
        $repFlags = $this->detectRepetition($textAnswers);
        $flags = array_merge($flags, $repFlags);

        if (!empty($flags)) {
            $severity = max(0, 100 - (count($flags) * 20));
            return $this->result(false, $severity, ['flags' => $flags]);
        }

        return $this->result(true, 100, ['note' => 'No gibberish detected']);
    }

    private function detectRepetition(array $textAnswers): array
    {
        $flags = [];
        $count = count($textAnswers);
        if ($count < 2) return $flags;

        // Check for verbatim repeated text across different questions
        $seen = [];
        foreach ($textAnswers as $ta) {
            $normalized = preg_replace('/\s+/', ' ', strtolower(trim($ta['text'])));
            $normalized = preg_replace('/[^\w\s]/', '', $normalized);
            $words = explode(' ', $normalized);
            $wordCount = count($words);

            if ($wordCount < 5) continue;

            // Skip answers shorter than 5 words for repetition check
            $signature = implode(' ', array_slice($words, 0, min(10, $wordCount)));

            if (isset($seen[$signature])) {
                $flags[] = "Repetitive text: answer matches question #{$seen[$signature]}";
            } else {
                $seen[$signature] = $ta['qid'];
            }
        }

        // Check for question rephrasing (AI pattern: starts answer by rephrasing question)
        foreach ($textAnswers as $ta) {
            if (empty($ta['qtext'])) continue;
            $answerLower = strtolower($ta['text']);
            $questionWords = preg_split('/\s+/', strtolower(trim($ta['qtext'])));
            $significant = array_filter($questionWords, function($w) { return strlen($w) > 3; });
            $significant = array_slice(array_values($significant), 0, 5);

            $rephraseCount = 0;
            foreach ($significant as $word) {
                if (strpos($answerLower, $word) !== false) $rephraseCount++;
            }

            if (count($significant) >= 3 && $rephraseCount >= count($significant) - 1) {
                $flags[] = "Answer rephrases question #{$ta['qid']} (AI pattern)";
            }
        }

        // Check for disproportionate verbosity
        foreach ($textAnswers as $ta) {
            if (empty($ta['qtext'])) continue;
            $qLen = strlen(trim($ta['qtext']));
            $aLen = strlen($ta['text']);
            if ($qLen > 0 && $aLen > $qLen * 5 && $aLen > 200) {
                $flags[] = "Disproportionately long answer for question #{$ta['qid']}";
            }
        }

        return $flags;
    }

    private function isGibberish(string $text): bool
    {
        $text = preg_replace('/[^a-z]/i', '', $text);
        if (strlen($text) < 5) return false;

        $vowelCount = preg_match_all('/[aeiou]/i', $text);
        $ratio = $vowelCount / strlen($text);
        if ($ratio < 0.1 || $ratio > 0.7) return true;

        $consecutiveConsonants = max(array_map('strlen', preg_split('/[aeiou]+/i', $text)));
        if ($consecutiveConsonants > 8) return true;

        return false;
    }

    private function isRepeatedChars(string $text): bool
    {
        return (bool)preg_match('/(.)\1{4,}/', $text);
    }

    private function isKeyboardSmash(string $text): bool
    {
        $smashPatterns = ['asdf', 'qwerty', 'zxcvb', 'sdfgh', 'xcvbn'];
        $lower = strtolower($text);
        foreach ($smashPatterns as $pattern) {
            if (strpos($lower, $pattern) !== false) return true;
        }
        return false;
    }

    private function findQuestion(int $questionId, array $questions): ?array
    {
        foreach ($questions as $q) {
            if ((int)$q['id'] === $questionId) return $q;
        }
        return null;
    }
}
