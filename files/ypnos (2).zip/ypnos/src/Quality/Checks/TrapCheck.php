<?php

namespace Quality\Checks;

class TrapCheck extends BaseCheck
{
    protected $name = 'trap';

    public function run(array $context): array
    {
        $questions = $context['questions'];
        $answers = $context['answers'];

        $trapQuestions = array_filter($questions, function($q) { return !empty($q['is_trap']); });

        if (empty($trapQuestions)) {
            return $this->result(true, 100, ['note' => 'No trap questions configured']);
        }

        $passed = 0;
        $effectiveTotal = 0;

        foreach ($trapQuestions as $q) {
            $expected = trim($q['expected_answer'] ?? '');
            if (empty($expected)) {
                $passed++;
                continue;
            }
            $effectiveTotal++;

            $answer = null;
            foreach ($answers as $a) {
                if ((int)$a['question_id'] === (int)$q['id']) {
                    $answer = trim($a['answer_value'] ?? '');
                    break;
                }
            }

            if ($answer !== null && strtolower($answer) === strtolower($expected)) {
                $passed++;
            }
        }

        $total = count($trapQuestions);
        $score = $effectiveTotal > 0 ? round(($passed / $total) * 100, 2) : 100;
        return $this->result($effectiveTotal === 0 || $passed === $total, $score, [
            'passed' => $passed,
            'total'  => $total,
        ]);
    }
}
