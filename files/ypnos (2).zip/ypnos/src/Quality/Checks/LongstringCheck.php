<?php

namespace Quality\Checks;

class LongstringCheck extends BaseCheck
{
    protected $name = 'longstring';

    public function run(array $context): array
    {
        $answers = $context['answers'];
        $questions = $context['questions'];
        $flags = [];

        foreach ($answers as $a) {
            $val = trim($a['answer_value'] ?? '');
            if (empty($val)) continue;

            $q = $this->findQuestion($a['question_id'], $questions);
            if (!$q) continue;
            if (!in_array($q['type'], ['text', 'textarea', 'email', 'phone'])) continue;

            if ($this->hasLongRepeat($val)) {
                $flags[] = "Long string of repeated pattern in question #{$a['question_id']}";
            }

            if ($this->isNonsensicalRepeat($val)) {
                $flags[] = "Nonsensical repeated text in question #{$a['question_id']}";
            }

            if ($this->isCopiedText($val)) {
                $flags[] = "Suspicious copied/pasted text in question #{$a['question_id']}";
            }
        }

        if (!empty($flags)) {
            $score = max(0, 100 - (count($flags) * 30));
            return $this->result(false, $score, ['flags' => $flags]);
        }

        return $this->result(true, 100, ['note' => 'No longstring issues']);
    }

    private function hasLongRepeat(string $text): bool
    {
        if (strlen($text) < 20) return false;
        return (bool)preg_match('/(.{1,5})\1{5,}/', $text);
    }

    private function isNonsensicalRepeat(string $text): bool
    {
        if (strlen($text) < 15) return false;
        $chars = function_exists('mb_str_split') ? mb_str_split($text) : str_split($text);
        $unique = count(array_unique($chars));
        $total = count($chars);
        return ($unique / $total) < 0.1;
    }

    private function isCopiedText(string $text): bool
    {
        if (strlen($text) < 50) return false;
        $lower = strtolower($text);
        $loremIndicators = ['lorem ipsum', 'sample text', 'test test', 'asdf', 'qwerty', 'click here', 'submit form'];
        foreach ($loremIndicators as $indicator) {
            if (strpos($lower, $indicator) !== false) return true;
        }
        return false;
    }

    private function findQuestion(int $questionId, array $questions): ?array
    {
        foreach ($questions as $q) {
            if ((int)$q['id'] === $questionId) return $q;
        }
        return null;
    }
}
