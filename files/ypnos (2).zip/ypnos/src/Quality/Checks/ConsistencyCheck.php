<?php

namespace Quality\Checks;

class ConsistencyCheck extends BaseCheck
{
    protected $name = 'consistency';

    public function run(array $context): array
    {
        $answers = $context['answers'];
        $questions = $context['questions'];
        $response = $context['response'] ?? [];
        $inconsistencies = [];

        // Use response completion year for accurate age calculation
        $completionYear = (int)date('Y');
        if (!empty($response['completed_at'])) {
            $compYear = (int)date('Y', strtotime($response['completed_at']));
            if ($compYear > 1970) $completionYear = $compYear;
        }

        $questionTexts = [];
        foreach ($questions as $q) {
            $questionTexts[$q['id']] = strtolower($q['question_text']);
        }

        $answerMap = [];
        foreach ($answers as $a) {
            $answerMap[$a['question_id']] = trim($a['answer_value'] ?? '');
        }

        $age = null;
        $yearOfBirth = null;

        foreach ($answerMap as $qId => $val) {
            $text = $questionTexts[$qId] ?? '';
            if (preg_match('/\bage\b/', $text) && is_numeric($val)) {
                $age = (int)$val;
            }
            if (preg_match('/year of birth|birth year|born in/', $text) && is_numeric($val)) {
                $yearOfBirth = (int)$val;
            }
        }

        if ($age !== null && $yearOfBirth !== null) {
            $calculatedAge = $completionYear - $yearOfBirth;
            if (abs($calculatedAge - $age) > 2) {
                $inconsistencies[] = "Age ({$age}) doesn't match birth year ({$yearOfBirth} -> ~{$calculatedAge})";
            }
        }

        if (!empty($inconsistencies)) {
            $score = max(0, 100 - (count($inconsistencies) * 50));
            return $this->result(false, $score, ['inconsistencies' => $inconsistencies]);
        }

        return $this->result(true, 100, ['note' => 'No consistency issues']);
    }
}
