<?php

namespace Quality\Checks;

class TimeCheck extends BaseCheck
{
    protected $name = 'time';

    public function run(array $context): array
    {
        $response = $context['response'];
        $questions = $context['questions'];
        $totalTime = (int)($response['time_spent_seconds'] ?? 0);
        $totalQuestions = count($questions);

        if ($totalQuestions === 0 || $totalTime === 0) {
            return $this->result(true, 100, ['note' => 'No timing data']);
        }

        $avgTimePerQuestion = $totalTime / $totalQuestions;
        $flags = [];

        if ($avgTimePerQuestion < 2) {
            $flags[] = 'Extremely fast responses (avg < 2s/question)';
        } elseif ($avgTimePerQuestion < 3) {
            $flags[] = 'Very fast responses (avg < 3s/question)';
        }

        if ($totalTime < 30 && $totalQuestions > 5) {
            $flags[] = 'Completed unrealistically fast';
        }

        if (!empty($flags)) {
            $severity = $avgTimePerQuestion < 2 ? 20 : 50;
            return $this->result(false, $severity, ['flags' => $flags, 'avg_time' => round($avgTimePerQuestion, 1)]);
        }

        return $this->result(true, 100, ['avg_time' => round($avgTimePerQuestion, 1)]);
    }
}
