<?php

namespace Quality\Checks;

class OutlierCheck extends BaseCheck
{
    protected $name = 'outlier';

    public function run(array $context): array
    {
        $answers = $context['answers'];
        $questions = $context['questions'];
        $flags = [];

        $textLengths = [];

        foreach ($answers as $a) {
            $q = $this->findQuestion($a['question_id'], $questions);
            if (!$q) continue;

            $val = trim($a['answer_value'] ?? '');

            if (in_array($q['type'], ['number', 'rating', 'slider', 'likert5', 'likert7']) && is_numeric($val)) {
                $min = $q['min_value'] ?? null;
                $max = $q['max_value'] ?? null;
                if ($min !== null && (int)$val < $min) {
                    $flags[] = "Value {$val} below minimum ({$min}) for question #{$a['question_id']}";
                }
                if ($max !== null && (int)$val > $max) {
                    $flags[] = "Value {$val} above maximum ({$max}) for question #{$a['question_id']}";
                }
            }

            if ($q['type'] === 'text' && !empty($val)) {
                $textLengths[] = strlen($val);
            }
        }

        foreach ($textLengths as $len) {
            if ($len > 2000) {
                $flags[] = "Extremely long text response ({$len} chars)";
            }
            if ($len === 1) {
                $flags[] = "Single character text response";
            }
        }

        $totalTime = (int)($context['response']['time_spent_seconds'] ?? 0);
        if ($totalTime > 3600 && count($questions) < 20) {
            $flags[] = "Took over an hour for a short survey";
        }

        if (!empty($flags)) {
            $score = max(0, 100 - (count($flags) * 25));
            return $this->result(false, $score, ['flags' => $flags]);
        }

        return $this->result(true, 100, ['note' => 'No outliers detected']);
    }

    private function findQuestion(int $questionId, array $questions): ?array
    {
        foreach ($questions as $q) {
            if ((int)$q['id'] === $questionId) return $q;
        }
        return null;
    }
}
