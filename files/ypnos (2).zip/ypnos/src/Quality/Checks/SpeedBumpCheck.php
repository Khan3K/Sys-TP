<?php

namespace Quality\Checks;

class SpeedBumpCheck extends BaseCheck
{
    protected $name = 'speed_bump';

    public function run(array $context): array
    {
        $questions = $context['questions'];
        $answers = $context['answers'];

        $speedBumps = array_filter($questions, function($q) { return !empty($q['is_speed_bump']); });

        if (empty($speedBumps)) {
            return $this->result(true, 100, ['note' => 'No speed bump questions']);
        }

        $passed = 0;
        $total = count($speedBumps);

        foreach ($speedBumps as $q) {
            $expected = trim($q['expected_answer'] ?? '');
            $answer = null;

            foreach ($answers as $a) {
                if ((int)$a['question_id'] === (int)$q['id']) {
                    $answer = trim($a['answer_value'] ?? '');
                    break;
                }
            }

            if (empty($expected)) {
                $passed++;
                continue;
            }

            if ($answer !== null && strtolower($answer) === strtolower($expected)) {
                $passed++;
            }
        }

        $score = $total > 0 ? round(($passed / $total) * 100, 2) : 100;
        return $this->result($passed === $total, $score, [
            'passed' => $passed,
            'total'  => $total,
        ]);
    }
}
