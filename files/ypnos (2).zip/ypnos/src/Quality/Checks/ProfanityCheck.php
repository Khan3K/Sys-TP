<?php

namespace Quality\Checks;

class ProfanityCheck extends BaseCheck
{
    protected $name = 'profanity';

    private $profanityList = [
        'fuck', 'shit', 'ass', 'bitch', 'damn', 'crap', 'dick', 'piss',
        'slut', 'whore', 'bastard', 'douche', 'cock', 'cunt', 'motherfucker',
        'asshole', 'dumbass', 'jackass', 'prick', 'twat', 'wanker',
    ];

    public function run(array $context): array
    {
        $answers = $context['answers'];
        $questions = $context['questions'];
        $flags = [];
        $totalChecks = 0;
        $flagged = 0;

        foreach ($answers as $a) {
            $val = trim($a['answer_value'] ?? '');
            if (empty($val)) continue;

            $q = $this->findQuestion((int)$a['question_id'], $questions);
            if (!$q) continue;
            if (!in_array($q['type'], ['text', 'email', 'phone', 'textarea'])) continue;

            $totalChecks++;
            $lower = strtolower($val);
            $words = preg_split('/\W+/', $lower);
            $found = [];

            foreach ($words as $word) {
                $cleanWord = preg_replace('/[^a-z]/', '', $word);
                if (in_array($cleanWord, $this->profanityList)) {
                    $found[] = $cleanWord;
                }
            }

            if (!empty($found)) {
                $flags[] = "Profanity in question #{$a['question_id']}: " . implode(',', array_unique($found));
                $flagged++;
            }
        }

        if ($totalChecks === 0) {
            return $this->result(true, 100, ['note' => 'No text answers to check']);
        }

        $passRate = $totalChecks > 0 ? (($totalChecks - $flagged) / $totalChecks) * 100 : 100;
        $score = max(0, round($passRate, 2));

        if (!empty($flags)) {
            return $this->result(false, $score, ['flags' => $flags, 'checked' => $totalChecks, 'flagged' => $flagged]);
        }

        return $this->result(true, 100, ['note' => 'No profanity detected']);
    }

    private function findQuestion(int $questionId, array $questions): ?array
    {
        foreach ($questions as $q) {
            if ((int)$q['id'] === $questionId) return $q;
        }
        return null;
    }
}
