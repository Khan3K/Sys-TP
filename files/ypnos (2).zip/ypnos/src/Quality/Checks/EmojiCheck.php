<?php

namespace Quality\Checks;

class EmojiCheck extends BaseCheck
{
    protected $name = 'emoji';

    public function run(array $context): array
    {
        $answers = $context['answers'];
        $questions = $context['questions'];
        $flags = [];
        $maxEmojiAllowed = 5;
        $totalChecks = 0;
        $flagged = 0;

        foreach ($answers as $a) {
            $val = trim($a['answer_value'] ?? '');
            if (empty($val)) continue;

            $q = $this->findQuestion((int)$a['question_id'], $questions);
            if (!$q) continue;
            if (!in_array($q['type'], ['text', 'email', 'phone', 'textarea'])) continue;

            $totalChecks++;
            $emojiCount = $this->countEmojis($val);
            if ($emojiCount > $maxEmojiAllowed) {
                $flags[] = "{$emojiCount} emojis in question #{$a['question_id']} (max {$maxEmojiAllowed})";
                $flagged++;
            }
        }

        if ($totalChecks === 0) {
            return $this->result(true, 100, ['note' => 'No text answers to check']);
        }

        $passRate = $totalChecks > 0 ? (($totalChecks - $flagged) / $totalChecks) * 100 : 100;
        $score = max(0, round($passRate, 2));

        if (!empty($flags)) {
            return $this->result(false, $score, ['flags' => $flags, 'checked' => $totalChecks, 'flagged' => $flagged]);
        }

        return $this->result(true, 100, ['note' => 'No excessive emoji detected']);
    }

    private function countEmojis(string $text): int
    {
        $emojiPattern = '/
            [\x{1F600}-\x{1F64F}]|
            [\x{1F300}-\x{1F5FF}]|
            [\x{1F680}-\x{1F6FF}]|
            [\x{1F1E0}-\x{1F1FF}]|
            [\x{2600}-\x{26FF}]|
            [\x{2700}-\x{27BF}]|
            [\x{FE00}-\x{FE0F}]|
            [\x{1F900}-\x{1F9FF}]|
            [\x{1FA00}-\x{1FA6F}]|
            [\x{1FA70}-\x{1FAFF}]|
            [\x{23F0}-\x{23FF}]|
            [\x{2934}-\x{2935}]|
            [\x{2B05}-\x{2B07}]|
            [\x{2B1B}-\x{2B1C}]|
            [\x{3030}]|
            [\x{303D}]|
            [\x{3297}]|
            [\x{3299}]
        /ux';

        preg_match_all($emojiPattern, $text, $matches);
        return count($matches[0] ?? []);
    }

    private function findQuestion(int $questionId, array $questions): ?array
    {
        foreach ($questions as $q) {
            if ((int)$q['id'] === $questionId) return $q;
        }
        return null;
    }
}
