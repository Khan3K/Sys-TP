<?php

namespace Quality\Checks;

class PatternCheck extends BaseCheck
{
    protected $name = 'pattern';

    public function run(array $context): array
    {
        $answers = $context['answers'];
        $questions = $context['questions'];

        $numericalAnswers = [];

        foreach ($answers as $a) {
            $q = $this->findQuestion($a['question_id'], $questions);
            if (!$q) continue;

            $val = trim($a['answer_value'] ?? '');

            if (in_array($q['type'], ['likert5', 'likert7', 'rating', 'slider']) && is_numeric($val)) {
                $numericalAnswers[] = (int)$val;
            }
        }

        $flags = [];

        if (count($numericalAnswers) >= 5) {
            if (count(array_unique($numericalAnswers)) === 1) {
                $flags[] = 'Straight-lining (all same value)';
            }

            $zigzag = $this->detectZigzag($numericalAnswers);
            if ($zigzag) {
                $flags[] = 'Zigzag pattern detected';
            }

            $alternating = $this->detectAlternating($numericalAnswers);
            if ($alternating) {
                $flags[] = 'Alternating pattern detected';
            }
        }

        if (!empty($flags)) {
            $score = max(0, 100 - (count($flags) * 30));
            return $this->result(false, $score, ['flags' => $flags]);
        }

        return $this->result(true, 100, ['note' => 'No suspicious patterns']);
    }

    private function detectZigzag(array $values): bool
    {
        if (count($values) < 4) return false;
        $up = $down = 0;
        for ($i = 1; $i < count($values); $i++) {
            if ($values[$i] > $values[$i - 1]) $up++;
            elseif ($values[$i] < $values[$i - 1]) $down++;
        }
        return abs($up - $down) <= 1 && ($up + $down) >= count($values) - 2;
    }

    private function detectAlternating(array $values): bool
    {
        if (count($values) < 4) return false;
        for ($i = 2; $i < count($values); $i++) {
            if ($values[$i] !== $values[$i - 2]) return false;
        }
        return $values[0] !== $values[1] ?? true;
    }

    private function findQuestion(int $questionId, array $questions): ?array
    {
        foreach ($questions as $q) {
            if ((int)$q['id'] === $questionId) return $q;
        }
        return null;
    }
}
