<?php

namespace Quality\Checks;

class AttentionCheck extends BaseCheck
{
    protected $name = 'attention';

    public function run(array $context): array
    {
        $questions = $context['questions'];
        $answers = $context['answers'];
        $attentionQuestions = array_filter($questions, function($q) { return !empty($q['is_attention_check']); });

        if (empty($attentionQuestions)) {
            return $this->result(true, 100, ['note' => 'No attention checks configured']);
        }

        $passed = 0;
        $effectiveTotal = 0;

        foreach ($attentionQuestions as $q) {
            $expected = trim($q['expected_answer'] ?? '');
            if (empty($expected)) {
                $passed++;
                continue;
            }
            $effectiveTotal++;

            $answer = $this->findAnswer($q['id'], $answers);
            if ($answer !== null && strtolower(trim($answer)) === strtolower($expected)) {
                $passed++;
            }
        }

        $total = count($attentionQuestions);
        $score = $effectiveTotal > 0 ? round(($passed / $total) * 100, 2) : 100;
        return $this->result($effectiveTotal === 0 || $passed === $total, $score, [
            'passed' => $passed,
            'total'  => $total,
        ]);
    }

    private function findAnswer(int $questionId, array $answers): ?string
    {
        foreach ($answers as $a) {
            if ((int)$a['question_id'] === $questionId) {
                return $a['answer_value'];
            }
        }
        return null;
    }
}
