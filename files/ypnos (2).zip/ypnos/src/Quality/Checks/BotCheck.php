<?php

namespace Quality\Checks;

class BotCheck extends BaseCheck
{
    protected $name = 'bot';

    public function run(array $context): array
    {
        $response = $context['response'];
        $flags = [];

        if (!empty($response['ip_address'])) {
            $ip = $response['ip_address'];
            if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false) {
                $flags[] = 'Private/reserved IP range';
            }
        }

        if (!empty($response['user_agent'])) {
            $ua = strtolower($response['user_agent']);
            if (preg_match('/curl|wget|python-requests|java|phantomjs|headless/i', $ua)) {
                $flags[] = 'Suspicious user-agent';
            }
            if (empty($ua) || strlen($ua) < 10) {
                $flags[] = 'Missing or minimal user-agent';
            }
        }

        if (empty($response['device_fingerprint'])) {
            $flags[] = 'No device fingerprint';
        }

        if (!empty($flags)) {
            $score = max(0, 100 - (count($flags) * 25));
            return $this->result(false, $score, ['flags' => $flags]);
        }

        return $this->result(true, 100, ['note' => 'No bot indicators']);
    }
}
