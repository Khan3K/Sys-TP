<?php

namespace Controllers;

use Core\Auth;
use Core\Response;
use Core\Session;

class BookmarkletController
{
    public function popup(): void
    {
        $fieldsJson = $_GET['fields'] ?? '[]';
        $fields = json_decode($fieldsJson, true) ?: [];

        if (empty($fields)) {
            echo '<p class="p-4 text-gray-500">No fields detected on this page.</p>';
            return;
        }

        $dataTypes = [
            'text'           => 'Text',
            'name'           => 'Full Name',
            'first_name'     => 'First Name',
            'last_name'      => 'Last Name',
            'email'          => 'Email',
            'phone'          => 'Phone',
            'number'         => 'Number',
            'date'           => 'Date',
            'address'        => 'Address',
            'city'           => 'City',
            'state'          => 'State',
            'zip'            => 'ZIP Code',
            'country'        => 'Country',
            'company'        => 'Company',
            'job_title'      => 'Job Title',
            'website'        => 'Website',
            'yes_no'         => 'Yes/No',
            'rating'         => 'Rating',
            'age'            => 'Age',
            'gender'         => 'Gender',
        ];

        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>Resrch Bookmarklet</title>
            <script src="https://cdn.tailwindcss.com"></script>
        </head>
        <body class="bg-gray-50 p-4">
            <div class="flex items-center justify-between mb-4">
                <h1 class="text-lg font-bold text-indigo-600">Resrch</h1>
                <button onclick="fillAll()" class="bg-indigo-600 text-white px-3 py-1.5 rounded text-sm hover:bg-indigo-700 transition-colors">
                    Auto-Fill All
                </button>
            </div>

            <p class="text-xs text-gray-500 mb-3"><?= count($fields) ?> field(s) detected:</p>

            <div class="space-y-2 mb-4 max-h-80 overflow-y-auto">
                <?php foreach ($fields as $f): ?>
                    <div class="bg-white rounded-lg border p-2.5 flex items-center gap-2 shadow-sm">
                        <span class="text-xs font-mono text-gray-500 w-36 truncate" title="<?= htmlspecialchars($f['name'] ?: $f['id']) ?>">
                            <?= htmlspecialchars(mb_substr($f['name'] ?: $f['id'] ?: 'unnamed', 0, 25)) ?>
                        </span>
                        <span class="text-xs text-gray-400 w-16"><?= htmlspecialchars($f['type'] ?? '') ?></span>
                        <select class="data-type text-xs border rounded px-2 py-1 flex-1 bg-white" data-field="<?= htmlspecialchars($f['name'] ?: $f['id']) ?>">
                            <option value="">-- Select type --</option>
                            <?php foreach ($dataTypes as $val => $label): ?>
                                <option value="<?= htmlspecialchars($val) ?>"><?= htmlspecialchars($label) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                <?php endforeach; ?>
            </div>

            <button onclick="fillSelected()" class="w-full bg-green-600 text-white py-2.5 rounded-lg hover:bg-green-700 transition-colors text-sm font-medium">
                Fill Selected Fields
            </button>

            <script>
            function getMapping() {
                var map = {};
                document.querySelectorAll('.data-type').forEach(function(sel) {
                    if (sel.value) {
                        map[sel.dataset.field] = generateValue(sel.value);
                    }
                });
                return map;
            }

            function generateValue(type) {
                var values = {
                    'text': 'Sample response',
                    'name': 'John Doe',
                    'first_name': ['James','Mary','Robert','Patricia','John','Jennifer'][Math.floor(Math.random()*6)],
                    'last_name': ['Smith','Johnson','Williams','Brown','Jones','Garcia'][Math.floor(Math.random()*6)],
                    'email': 'user'+Math.floor(Math.random()*10000)+'@example.com',
                    'phone': '('+(Math.floor(Math.random()*900)+100)+') '+(Math.floor(Math.random()*900)+100)+'-'+String(Math.floor(Math.random()*9000)+1000).padStart(4,'0'),
                    'number': String(Math.floor(Math.random()*100)+1),
                    'date': '2024-0'+(Math.floor(Math.random()*9)+1)+'-'+String(Math.floor(Math.random()*28)+1).padStart(2,'0'),
                    'address': Math.floor(Math.random()*9999)+' Main Street',
                    'city': ['New York','Los Angeles','Chicago','Houston','Phoenix'][Math.floor(Math.random()*5)],
                    'state': ['CA','NY','TX','FL','IL'][Math.floor(Math.random()*5)],
                    'zip': String(Math.floor(Math.random()*90000)+10000),
                    'country': 'United States',
                    'company': ['Acme Corp','Tech Solutions','Global Inc','DataCo'][Math.floor(Math.random()*4)],
                    'job_title': ['Manager','Engineer','Analyst','Director'][Math.floor(Math.random()*4)],
                    'website': 'https://example.com',
                    'yes_no': Math.random()>0.5?'Yes':'No',
                    'rating': String(Math.floor(Math.random()*5)+1),
                    'age': String(Math.floor(Math.random()*50)+18),
                    'gender': Math.random()>0.5?'Male':'Female',
                };
                return values[type] || 'Data';
            }

            function fillAll() {
                var sels = document.querySelectorAll('.data-type');
                sels.forEach(function(sel) {
                    if (!sel.value) {
                        var name = sel.dataset.field.toLowerCase();
                        if (name.includes('name')||name.includes('first')) sel.value='first_name';
                        else if (name.includes('last')) sel.value='last_name';
                        else if (name.includes('email')) sel.value='email';
                        else if (name.includes('phone')||name.includes('tel')) sel.value='phone';
                        else if (name.includes('address')||name.includes('street')) sel.value='address';
                        else if (name.includes('city')) sel.value='city';
                        else if (name.includes('state')) sel.value='state';
                        else if (name.includes('zip')||name.includes('postal')) sel.value='zip';
                        else if (name.includes('company')||name.includes('employ')) sel.value='company';
                        else if (name.includes('age')) sel.value='age';
                        else if (name.includes('gender')) sel.value='gender';
                        else if (name.includes('date')||name.includes('dob')||name.includes('birth')) sel.value='date';
                        else if (name.includes('website')||name.includes('url')) sel.value='website';
                        else if (name.includes('number')||name.includes('count')) sel.value='number';
                        else sel.value='text';
                    }
                });
                fillSelected();
            }

            function fillSelected() {
                var mapping = getMapping();
                window.parent.postMessage({type:'RESRCH_FILL',mapping:mapping},'*');
            }
            </script>
        </body>
        </html>
        <?php
    }

    public function fill(): void
    {
        $mapping = $_POST['mapping'] ?? [];
        Response::json(['success' => true, 'data' => $mapping]);
    }

    public function setup(): void
    {
        Auth::requireAuth();

        $jsCode = file_get_contents(__DIR__ . '/../../public/assets/js/bookmarklet.js');
        $bookmarkletCode = "javascript:" . rawurlencode($jsCode);

        Response::layout('main', 'bookmarklet-setup', [
            'pageTitle'       => 'Bookmarklet Setup',
            'bookmarkletCode' => $bookmarkletCode,
        ]);
    }
}
