<?php

namespace Controllers;

use Core\Auth;
use Core\Response;
use Core\Session;
use Core\Database;
use Core\Validator;

class SurveyController
{
    public function createType(): void
    {
        Auth::requireRole("researcher");
        Response::layout("main", "researcher/survey/create", [
            "pageTitle" => "Create a New Survey",
        ]);
    }

    public function createForm(): void
    {
        Auth::requireRole("researcher");
        Response::layout("main", "researcher/survey/create-form", [
            "pageTitle" => "Create Form Survey",
            "qualityConfig" => self::defaultQualityConfig(),
            "surveyType" => "form",
        ]);
    }

    public function createChat(): void
    {
        Auth::requireRole("researcher");
        Response::layout("main", "researcher/survey/create-chat", [
            "pageTitle" => "Create Chat Survey",
            "qualityConfig" => self::defaultQualityConfig(),
            "surveyType" => "chat",
            "chatConfigJson" => json_encode([
                "nodes" => [],
                "intro_message" => "",
                "tone" => "neutral",
            ]),
            "aiConfigJson" => json_encode([
                "provider" => "gemini",
                "api_key" => "",
                "model" => "gemini-1.5-pro",
                "capabilities" => [
                    "sentiment",
                    "adaptive_followup",
                    "summarize",
                    "context_awareness",
                    "gibberish_detection",
                    "injection_protection",
                ],
                "system_prompt" => "",
                "temperature" => 0.7,
                "max_tokens" => 200,
            ]),
        ]);
    }

    private static function defaultQualityConfig(): array
    {
        return [
            "auth_type" => "anyone",
            "honeypot" => false,
            "min_time_seconds" => 0,
            "captcha" => false,
            "min_text_length" => 0,
            "prevent_duplicates" => false,
            "detect_straightline" => false,
            "confirm_answers" => false,
            "validate_input" => false,
            "prevent_copy_paste" => false,
            "track_tab_switches" => false,
            "require_attention" => false,
            "max_idle_seconds" => 600,
            "sequential_unlock" => false,
            "fullscreen_mode" => false,
            "inactivity_timeout" => 600,
            "shuffle_questions" => false,
            "shuffle_options" => false,
            "allow_resume" => false,
            "disable_rightclick" => false,
            "inactivity_warn_before" => 60,
            "vpn_detection" => false,
            "ai_detection" => false,
            "email_domain_verify" => false,
            "geo_timezone_check" => false,
            "language_consistency" => false,
        ];
    }

    public function create(): void
    {
        Auth::requireRole("researcher");

        $v = new Validator($_POST);
        if (!$v->required("title", "Survey title")->passes()) {
            Session::setFlash("danger", $v->firstError());
            Response::redirect("/survey/create");
        }

        $qc = $_POST["qc"] ?? [];
        $allowedAuth = ["anyone", "password", "email", "google", "any_account"];
        $qualityConfig = [
            "auth_type" => in_array($qc["auth_type"] ?? "anyone", $allowedAuth)
                ? $qc["auth_type"]
                : "anyone",
            "honeypot" => !empty($qc["honeypot"]),
            "min_time_seconds" => max(0, (int) ($qc["min_time_seconds"] ?? 30)),
            "captcha" => !empty($qc["captcha"]),
            "min_text_length" => max(0, (int) ($qc["min_text_length"] ?? 10)),
            "prevent_duplicates" => !empty($qc["prevent_duplicates"]),
            "detect_straightline" => !empty($qc["detect_straightline"]),
            "confirm_answers" => !empty($qc["confirm_answers"]),
            "validate_input" => !empty($qc["validate_input"]),
            "prevent_copy_paste" => !empty($qc["prevent_copy_paste"]),
            "track_tab_switches" => !empty($qc["track_tab_switches"]),
            "require_attention" => !empty($qc["require_attention"]),
            "max_idle_seconds" => max(
                0,
                (int) ($qc["max_idle_seconds"] ?? 300),
            ),
            "sequential_unlock" => !empty($qc["sequential_unlock"]),
            "fullscreen_mode" => !empty($qc["fullscreen_mode"]),
            "inactivity_timeout" => max(
                0,
                (int) ($qc["inactivity_timeout"] ?? 300),
            ),
            "shuffle_questions" => !empty($qc["shuffle_questions"]),
            "shuffle_options" => !empty($qc["shuffle_options"]),
            "allow_resume" => !empty($qc["allow_resume"]),
            "disable_rightclick" => !empty($qc["disable_rightclick"]),
            "inactivity_warn_before" => max(
                5,
                (int) ($qc["inactivity_warn_before"] ?? 30),
            ),
            "vpn_detection" => !empty($qc["vpn_detection"]),
            "ai_detection" => !empty($qc["ai_detection"]),
            "email_domain_verify" => !empty($qc["email_domain_verify"]),
            "geo_timezone_check" => !empty($qc["geo_timezone_check"]),
            "language_consistency" => !empty($qc["language_consistency"]),
        ];

        $themeConfig = [];
        if (!empty($_POST["theme_config"])) {
            $decoded = json_decode($_POST["theme_config"], true);
            if (is_array($decoded)) {
                $themeConfig = $decoded;
            }
        }

        $db = Database::getInstance();
        $minRep = max(0, min(100, (float) ($_POST["min_reputation"] ?? 0)));
        $threshold = max(
            0,
            min(100, (float) ($_POST["quality_threshold"] ?? 70)),
        );
        $maxResponses = !empty($_POST["max_responses"])
            ? (int) $_POST["max_responses"]
            : null;
        $password = !empty($_POST["access_password"])
            ? password_hash($_POST["access_password"], PASSWORD_BCRYPT)
            : null;

        $startsInput = trim((string) ($_POST["starts_at"] ?? ""));
        $endsInput = trim((string) ($_POST["ends_at"] ?? ""));
        $startsAt = self::normalizeDateTime($startsInput);
        $endsAt = self::normalizeDateTime($endsInput);

        if ($startsInput !== "" && $startsAt === null) {
            Session::setFlash("danger", "Invalid survey start date/time.");
            Response::redirect("/survey/create");
        }
        if ($endsInput !== "" && $endsAt === null) {
            Session::setFlash("danger", "Invalid survey end date/time.");
            Response::redirect("/survey/create");
        }
        if (
            $startsAt !== null &&
            $endsAt !== null &&
            strtotime($endsAt) < strtotime($startsAt)
        ) {
            Session::setFlash(
                "danger",
                "Survey end date/time must be after start date/time.",
            );
            Response::redirect("/survey/create");
        }

        $surveyType =
            ($_POST["survey_type"] ?? "form") === "chat" ? "chat" : "form";
        $chatConfig = [];
        if ($surveyType === "chat" && !empty($_POST["chat_config"])) {
            $decoded = json_decode($_POST["chat_config"], true);
            if (is_array($decoded)) {
                $chatConfig = $decoded;
            }
        }
        $aiConfig = [];
        if (!empty($_POST["ai_config"])) {
            $decoded = json_decode($_POST["ai_config"], true);
            if (is_array($decoded)) {
                // Normalize capabilities from object to array if needed
                if (
                    isset($decoded["capabilities"]) &&
                    is_array($decoded["capabilities"])
                ) {
                    $caps = $decoded["capabilities"];
                    $normalized = [];
                    $isObject = false;
                    foreach ($caps as $k => $v) {
                        if (is_bool($v) && $v === true) {
                            $normalized[] = $k;
                            $isObject = true;
                        } elseif (is_string($v) && !is_numeric($k)) {
                            $normalized[] = $k;
                            $isObject = true;
                        } elseif (is_string($v) && is_numeric($k)) {
                            $normalized[] = $v;
                        }
                    }
                    $decoded["capabilities"] = $isObject
                        ? $normalized
                        : ($normalized ?:
                        []);
                }
                $aiConfig = $decoded;
            }
        }

        $surveyId = $db->insert("surveys", [
            "researcher_id" => Auth::id(),
            "title" => trim($_POST["title"]),
            "description" => trim($_POST["description"] ?? ""),
            "status" => "draft",
            "quality_threshold" => $threshold,
            "min_reputation" => $minRep,
            "max_responses" => $maxResponses,
            "quality_config" => json_encode($qualityConfig),
            "theme_config" => json_encode($themeConfig),
            "type" => $surveyType,
            "chat_config" => json_encode($chatConfig),
            "ai_config" => json_encode($aiConfig),
            "access_password" => $password,
            "starts_at" => $startsAt,
            "ends_at" => $endsAt,
        ]);

        // Inline questions from JSON (skip for chat surveys — they use chat_config.nodes)
        $questions = [];
        if ($surveyType !== "chat" && !empty($_POST["questions_json"])) {
            $decoded = json_decode($_POST["questions_json"], true);
            if (is_array($decoded)) {
                $questions = $decoded;
            }
        }

        foreach ($questions as $index => $q) {
            $options = null;
            if (!empty($q["options"]) && is_array($q["options"])) {
                $options = json_encode($q["options"]);
            }
            $rows = null;
            if (!empty($q["rows"]) && is_array($q["rows"])) {
                $rows = json_encode($q["rows"]);
            }
            $db->insert("questions", [
                "survey_id" => $surveyId,
                "type" => !empty($q["type"]) ? $q["type"] : "text",
                "question_text" => $q["question_text"] ?? "",
                "options_json" => $options,
                "order_index" => $index,
                "is_required" => !empty($q["is_required"]),
                "is_attention_check" => !empty($q["is_attention_check"]),
                "expected_answer" => $q["expected_answer"] ?? null,
                "is_trap" => !empty($q["is_trap"]),
                "is_timed" => !empty($q["is_timed"]),
                "time_limit_seconds" => !empty($q["time_limit_seconds"])
                    ? (int) $q["time_limit_seconds"]
                    : null,
                "min_value" =>
                    isset($q["min_value"]) && $q["min_value"] !== ""
                        ? (float) $q["min_value"]
                        : null,
                "max_value" =>
                    isset($q["max_value"]) && $q["max_value"] !== ""
                        ? (float) $q["max_value"]
                        : null,
                "char_limit" => !empty($q["char_limit"])
                    ? (int) $q["char_limit"]
                    : null,
                "min_length" => !empty($q["min_length"])
                    ? (int) $q["min_length"]
                    : null,
                "max_length" => !empty($q["max_length"])
                    ? (int) $q["max_length"]
                    : null,
                "allow_paste" =>
                    !isset($q["allow_paste"]) || !empty($q["allow_paste"])
                        ? 1
                        : 0,
                "is_speed_bump" => !empty($q["is_speed_bump"]),
                "rows_json" => $rows,
                "placeholder" => $q["placeholder"] ?? null,
                "hint" => $q["hint"] ?? null,
                "image_url" => $q["image_url"] ?? null,
                "shuffle_options" => !empty($q["shuffle_options"]),
                "include_other" => !isset($q["include_other"])
                    ? 1
                    : (!empty($q["include_other"])
                        ? 1
                        : 0),
                "animation" => $q["animation"] ?? null,
                "accent_color" => $q["accent_color"] ?? null,
                "explanation" => $q["explanation"] ?? null,
            ]);
        }

        $msg = "Survey created!";
        if ($surveyType === "chat") {
            $chatNodeCount = count($chatConfig["nodes"] ?? []);
            if ($chatNodeCount > 0) {
                $msg .=
                    " Added " .
                    $chatNodeCount .
                    " conversation node" .
                    ($chatNodeCount > 1 ? "s" : "") .
                    ".";
            } else {
                $msg .=
                    " Configure your AI provider in the Conversation Flow section.";
            }
        } else {
            if (count($questions) > 0) {
                $msg .=
                    " Added " .
                    count($questions) .
                    " question" .
                    (count($questions) > 1 ? "s" : "") .
                    ".";
            } else {
                $msg .= " Now add questions.";
            }
        }

        self::ensureShortUrl($db, $surveyId);
        $db->clearTableCache("survey");

        Session::setFlash("success", $msg);
        Response::redirect("/survey/edit/{$surveyId}?created=1");
    }

    public function editForm(string $id): void
    {
        Auth::requireRole("researcher");

        $db = Database::getInstance();
        $survey = $db->cacheFetchOne(
            "survey.{$id}.{$_SESSION["user_id"]}",
            "SELECT * FROM surveys WHERE id = ? AND researcher_id = ?",
            [$id, Auth::id()],
            30,
        );

        if (!$survey) {
            Response::notFound();
        }

        $survey["quality_config"] =
            json_decode($survey["quality_config"] ?? "null", true) ??
            self::defaultQualityConfig();
        $survey["theme_config"] =
            json_decode($survey["theme_config"] ?? "null", true) ?? [];
        $rawChatConfig = $survey["chat_config"] ?? null;
        $rawAiConfig = $survey["ai_config"] ?? null;
        $survey["chat_config"] = json_decode(
            $rawChatConfig ?? "null",
            true,
        ) ?? ["nodes" => [], "intro_message" => "", "tone" => "neutral"];
        $survey["ai_config"] = json_decode($rawAiConfig ?? "null", true) ?? [
            "provider" => "gemini",
            "api_key" => "",
            "model" => "gemini-1.5-pro",
            "capabilities" => [
                "sentiment",
                "adaptive_followup",
                "summarize",
                "context_awareness",
            ],
            "system_prompt" => "",
            "temperature" => 0.7,
            "max_tokens" => 200,
        ];



        // Chat surveys use chat_config.nodes, not the questions table
        if (($survey["type"] ?? "form") === "chat") {
            $questions = [];
        } else {
            $questions = $db->cacheFetchAll(
                "survey.{$id}.questions",
                "SELECT * FROM questions WHERE survey_id = ? ORDER BY order_index ASC",
                [$id],
                30,
            );
        }

        // Generate share URL
        $shareUrl = "";
        $showShareModal = false;
        $urlRecord = $db->cacheFetchOne(
            "survey.{$id}.url",
            "SELECT short_code FROM survey_urls WHERE survey_id = ? AND is_active = 1 LIMIT 1",
            [$id],
            60,
        );
        if ($urlRecord) {
            $shareUrl = url("/s/" . $urlRecord["short_code"]);
        }
        if (isset($_GET["created"]) || isset($_GET["published"])) {
            $showShareModal = true;
        }

        Response::layout("main", "researcher/survey/edit", [
            "pageTitle" => "Edit Survey",
            "survey" => $survey,
            "questions" => $questions,
            "questionsJson" => json_encode(
                $questions,
                JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT,
            ),
            "themeConfigJson" => json_encode(
                $survey["theme_config"],
                JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT,
            ),
            "surveyType" => $survey["type"] ?? "form",
            "chatConfigJson" => json_encode(
                $survey["chat_config"],
                JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT,
            ),
            "aiConfigJson" => json_encode(
                $survey["ai_config"],
                JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT,
            ),
            "shareUrl" => $shareUrl,
            "showShareModal" => $showShareModal,
        ]);
    }

    public function update(string $id): void
    {
        Auth::requireRole("researcher");

        $db = Database::getInstance();
        $survey = $db->fetchOne(
            "SELECT * FROM surveys WHERE id = ? AND researcher_id = ?",
            [$id, Auth::id()],
        );

        if (!$survey) {
            Response::notFound();
        }

        $qc = $_POST["qc"] ?? [];
        $allowedAuth = ["anyone", "password", "email", "google", "any_account"];
        $qualityConfig = [
            "auth_type" => in_array($qc["auth_type"] ?? "anyone", $allowedAuth)
                ? $qc["auth_type"]
                : "anyone",
            "honeypot" => !empty($qc["honeypot"]),
            "min_time_seconds" => max(0, (int) ($qc["min_time_seconds"] ?? 30)),
            "captcha" => !empty($qc["captcha"]),
            "min_text_length" => max(0, (int) ($qc["min_text_length"] ?? 10)),
            "prevent_duplicates" => !empty($qc["prevent_duplicates"]),
            "detect_straightline" => !empty($qc["detect_straightline"]),
            "confirm_answers" => !empty($qc["confirm_answers"]),
            "validate_input" => !empty($qc["validate_input"]),
            "prevent_copy_paste" => !empty($qc["prevent_copy_paste"]),
            "track_tab_switches" => !empty($qc["track_tab_switches"]),
            "require_attention" => !empty($qc["require_attention"]),
            "max_idle_seconds" => max(
                0,
                (int) ($qc["max_idle_seconds"] ?? 300),
            ),
            "sequential_unlock" => !empty($qc["sequential_unlock"]),
            "fullscreen_mode" => !empty($qc["fullscreen_mode"]),
            "inactivity_timeout" => max(
                0,
                (int) ($qc["inactivity_timeout"] ?? 300),
            ),
            "shuffle_questions" => !empty($qc["shuffle_questions"]),
            "shuffle_options" => !empty($qc["shuffle_options"]),
            "allow_resume" => !empty($qc["allow_resume"]),
            "disable_rightclick" => !empty($qc["disable_rightclick"]),
            "inactivity_warn_before" => max(
                5,
                (int) ($qc["inactivity_warn_before"] ?? 30),
            ),
            "vpn_detection" => !empty($qc["vpn_detection"]),
            "ai_detection" => !empty($qc["ai_detection"]),
            "email_domain_verify" => !empty($qc["email_domain_verify"]),
            "geo_timezone_check" => !empty($qc["geo_timezone_check"]),
            "language_consistency" => !empty($qc["language_consistency"]),
        ];

        $password = $survey["access_password"];
        if (!empty($_POST["access_password"])) {
            $password = password_hash(
                $_POST["access_password"],
                PASSWORD_BCRYPT,
            );
        } elseif (isset($_POST["access_password_clear"])) {
            $password = null;
        }

        $surveyType =
            ($_POST["survey_type"] ?? $survey["type"]) === "chat"
                ? "chat"
                : "form";
        $chatConfig = $survey["chat_config"];
        if (!empty($_POST["chat_config"])) {
            $decoded = json_decode($_POST["chat_config"], true);
            if (is_array($decoded)) {
                $chatConfig = $decoded;
            }
        }
        $formQuestions = null;
        if ($surveyType !== "chat") {
            $formQuestions = json_decode(
                (string) ($_POST["questions_json"] ?? ""),
                true,
            );
            if (!is_array($formQuestions)) {
                $formQuestions = [];
            }

            $chatConfigArray = is_array($chatConfig)
                ? $chatConfig
                : json_decode((string) $chatConfig, true);
            if (empty($formQuestions) && !empty($chatConfigArray["nodes"])) {
                foreach ($chatConfigArray["nodes"] as $node) {
                    if (empty(trim((string) ($node["question"] ?? "")))) {
                        continue;
                    }
                    $nodeType = $node["type"] ?? "text";
                    $formQuestions[] = [
                        "type" => $nodeType === "choice" ? "mcq_single" : $nodeType,
                        "question_text" => trim((string) $node["question"]),
                        "options" => is_array($node["options"] ?? null)
                            ? $node["options"]
                            : [],
                        "is_required" => ($node["is_required"] ?? true) !== false,
                        "placeholder" => $node["placeholder"] ?? null,
                    ];
                }
            }

            if (empty($formQuestions)) {
                Session::setFlash(
                    "danger",
                    "A form survey must contain at least one question.",
                );
                Response::redirect("/survey/edit/{$id}");
            }
        }

        $aiConfig = $survey["ai_config"];
        if (!empty($_POST["ai_config"])) {
            $decoded = json_decode($_POST["ai_config"], true);
            if (is_array($decoded)) {
                // Normalize capabilities from object to array
                if (
                    isset($decoded["capabilities"]) &&
                    is_array($decoded["capabilities"])
                ) {
                    $caps = $decoded["capabilities"];
                    $normalized = [];
                    $isObject = false;
                    foreach ($caps as $k => $v) {
                        if (is_bool($v) && $v === true) {
                            $normalized[] = $k;
                            $isObject = true;
                        } elseif (is_string($v) && !is_numeric($k)) {
                            $normalized[] = $k;
                            $isObject = true;
                        } elseif (is_string($v) && is_numeric($k)) {
                            $normalized[] = $v;
                        }
                    }
                    $decoded["capabilities"] = $isObject
                        ? $normalized
                        : ($normalized ?:
                        []);
                }
                $aiConfig = $decoded;
            }
        }

        $allowedStatuses = ["draft", "active", "closed", "archived"];
        $newStatus = $_POST["status"] ?? $survey["status"];
        if (!in_array($newStatus, $allowedStatuses, true)) {
            $newStatus = $survey["status"];
        }

        $startsInput = trim((string) ($_POST["starts_at"] ?? ""));
        $endsInput = trim((string) ($_POST["ends_at"] ?? ""));
        $startsAt = self::normalizeDateTime($startsInput);
        $endsAt = self::normalizeDateTime($endsInput);

        if ($startsInput !== "" && $startsAt === null) {
            Session::setFlash("danger", "Invalid survey start date/time.");
            Response::redirect("/survey/edit/{$id}");
        }
        if ($endsInput !== "" && $endsAt === null) {
            Session::setFlash("danger", "Invalid survey end date/time.");
            Response::redirect("/survey/edit/{$id}");
        }
        if (
            $startsAt !== null &&
            $endsAt !== null &&
            strtotime($endsAt) < strtotime($startsAt)
        ) {
            Session::setFlash(
                "danger",
                "Survey end date/time must be after start date/time.",
            );
            Response::redirect("/survey/edit/{$id}");
        }

        $data = [
            "title" => trim($_POST["title"] ?? $survey["title"]),
            "description" => trim(
                $_POST["description"] ?? $survey["description"],
            ),
            "quality_threshold" => max(
                0,
                min(
                    100,
                    (float) ($_POST["quality_threshold"] ??
                        $survey["quality_threshold"]),
                ),
            ),
            "min_reputation" => max(
                0,
                min(
                    100,
                    (float) ($_POST["min_reputation"] ??
                        $survey["min_reputation"]),
                ),
            ),
            "max_responses" => !empty($_POST["max_responses"])
                ? (int) $_POST["max_responses"]
                : null,
            "status" => $newStatus,
            "quality_config" => json_encode($qualityConfig),
            "type" => $surveyType,
            "chat_config" => is_string($chatConfig)
                ? $chatConfig
                : json_encode($chatConfig),
            "ai_config" => is_string($aiConfig)
                ? $aiConfig
                : json_encode($aiConfig),
            "access_password" => $password,
            "starts_at" => $startsAt,
            "ends_at" => $endsAt,
        ];

        // Handle theme_config
        if (!empty($_POST["theme_config"])) {
            $decoded = json_decode($_POST["theme_config"], true);
            if (is_array($decoded)) {
                $data["theme_config"] = json_encode($decoded);
            }
        } elseif (isset($survey["theme_config"])) {
            $data["theme_config"] = is_string($survey["theme_config"])
                ? $survey["theme_config"]
                : json_encode($survey["theme_config"]);
        }

        $db->update("surveys", $data, "id = ?", [$id]);
        $db->clearTableCache("survey");

        $wasPublished =
            $newStatus === "active" && $survey["status"] !== "active";
        if ($wasPublished) {
            self::ensureShortUrl($db, $id);
        }

        // Replace form questions with the validated submitted or converted set.
        if ($surveyType !== "chat" && is_array($formQuestions)) {
            $db->delete("questions", "survey_id = ?", [$id]);
            foreach ($formQuestions as $index => $q) {
                    $options =
                        !empty($q["options"]) && is_array($q["options"])
                            ? json_encode($q["options"])
                            : null;
                    $rows =
                        !empty($q["rows"]) && is_array($q["rows"])
                            ? json_encode($q["rows"])
                            : null;
                    $db->insert("questions", [
                        "survey_id" => $id,
                        "type" => !empty($q["type"]) ? $q["type"] : "text",
                        "question_text" => $q["question_text"] ?? "",
                        "options_json" => $options,
                        "order_index" => $index,
                        "is_required" => !empty($q["is_required"]),
                        "is_attention_check" => !empty(
                            $q["is_attention_check"]
                        ),
                        "expected_answer" => $q["expected_answer"] ?? null,
                        "is_trap" => !empty($q["is_trap"]),
                        "is_timed" => !empty($q["is_timed"]),
                        "time_limit_seconds" => !empty($q["time_limit_seconds"])
                            ? (int) $q["time_limit_seconds"]
                            : null,
                        "min_value" =>
                            isset($q["min_value"]) && $q["min_value"] !== ""
                                ? (float) $q["min_value"]
                                : null,
                        "max_value" =>
                            isset($q["max_value"]) && $q["max_value"] !== ""
                                ? (float) $q["max_value"]
                                : null,
                        "char_limit" => !empty($q["char_limit"])
                            ? (int) $q["char_limit"]
                            : null,
                        "min_length" => !empty($q["min_length"])
                            ? (int) $q["min_length"]
                            : null,
                        "max_length" => !empty($q["max_length"])
                            ? (int) $q["max_length"]
                            : null,
                        "allow_paste" =>
                            !isset($q["allow_paste"]) ||
                            !empty($q["allow_paste"])
                                ? 1
                                : 0,
                        "is_speed_bump" => !empty($q["is_speed_bump"]),
                        "rows_json" => $rows,
                        "placeholder" => $q["placeholder"] ?? null,
                        "hint" => $q["hint"] ?? null,
                        "image_url" => $q["image_url"] ?? null,
                        "shuffle_options" => !empty($q["shuffle_options"]),
                        "include_other" => !isset($q["include_other"])
                            ? 1
                            : (!empty($q["include_other"])
                                ? 1
                                : 0),
                        "animation" => $q["animation"] ?? null,
                        "accent_color" => $q["accent_color"] ?? null,
                        "explanation" => $q["explanation"] ?? null,
                    ]);
            }
        }

        Session::setFlash("success", "Survey updated successfully");

        if ($wasPublished) {
            Response::redirect("/dashboard");
        } else {
            Response::redirect("/survey/edit/{$id}");
        }
    }

    public function view(string $id): void
    {
        $db = Database::getInstance();
        $survey = $db->fetchOne("SELECT * FROM surveys WHERE id = ?", [$id]);

        if (!$survey) {
            Response::notFound();
        }

        $surveyType = $survey["type"] ?? "form";
        $chatConfig = [];
        $questions = [];

        if ($surveyType === "chat") {
            $chatConfig = json_decode(
                $survey["chat_config"] ?? "null",
                true,
            ) ?? ["nodes" => [], "intro_message" => "", "tone" => "neutral"];
            // Convert chat nodes into question-like array for display
            if (!empty($chatConfig["nodes"])) {
                foreach ($chatConfig["nodes"] as $i => $node) {
                    $questions[] = [
                        "id" => 0,
                        "survey_id" => $id,
                        "question_text" => $node["question"] ?? "",
                        "type" => $node["type"] ?? "text",
                        "options_json" => !empty($node["options"])
                            ? json_encode($node["options"])
                            : null,
                        "order_index" => $i,
                        "is_required" => false,
                        "animation" => null,
                    ];
                }
            }
        } else {
            $questions = $db->fetchAll(
                "SELECT * FROM questions WHERE survey_id = ? ORDER BY order_index ASC",
                [$id],
            );
        }

        Response::layout("main", "researcher/survey/view", [
            "pageTitle" => $survey["title"],
            "survey" => $survey,
            "surveyType" => $surveyType,
            "chatConfig" => $chatConfig,
            "questions" => $questions,
        ]);
    }

    public function delete(string $id): void
    {
        Auth::requireRole("researcher");

        $db = Database::getInstance();
        $survey = $db->fetchOne(
            "SELECT * FROM surveys WHERE id = ? AND researcher_id = ?",
            [$id, Auth::id()],
        );

        if ($survey) {
            $db->delete("surveys", "id = ?", [$id]);
            Session::setFlash("success", "Survey deleted");
        }

        Response::redirect("/dashboard");
    }

    public function takeForm(string $id): void
    {
        $db = Database::getInstance();
        $survey = $db->fetchOne("SELECT * FROM surveys WHERE id = ?", [$id]);

        if (!$survey) {
            Session::setFlash("danger", "Survey not found");
            Response::redirect("/dashboard");
        }

        // Allow the survey owner (researcher) to preview regardless of status
        // For respondents, only allow if status is 'active'
        if ($survey["status"] !== "active") {
            $isOwner = Auth::check() && Auth::id() === $survey["researcher_id"];
            if (!$isOwner) {
                Session::setFlash("danger", "Survey not found or not active");
                Response::redirect("/dashboard");
            }
        }

        if (
            $survey["max_responses"] &&
            $survey["current_responses"] >= $survey["max_responses"]
        ) {
            Session::setFlash(
                "warning",
                "This survey has reached its response limit",
            );
            Response::redirect("/dashboard");
        }

        $now = date("Y-m-d H:i:s");
        if ($survey["starts_at"] && $now < $survey["starts_at"]) {
            Session::setFlash(
                "warning",
                "This survey has not opened yet. Please check back later.",
            );
            Response::redirect("/dashboard");
        }
        if ($survey["ends_at"] && $now > $survey["ends_at"]) {
            Session::setFlash("warning", "This survey has closed.");
            Response::redirect("/dashboard");
        }

        $minRep = (float) $survey["min_reputation"];
        if ($minRep > 0 && Auth::check()) {
            $userRep = (float) (Auth::user()["reputation_score"] ?? 0);
            if ($userRep < $minRep) {
                Session::setFlash(
                    "danger",
                    "This survey requires a reputation of " .
                        $minRep .
                        " or higher.",
                );
                Response::redirect("/dashboard");
            }
        }

        $qc =
            json_decode($survey["quality_config"] ?? "null", true) ??
            self::defaultQualityConfig();

        // Chat survey mode — skip question rendering, render chat view
        $surveyType = $survey["type"] ?? "form";
        if ($surveyType === "chat") {
            $chatConfig = json_decode(
                $survey["chat_config"] ?? "null",
                true,
            ) ?? ["nodes" => [], "intro_message" => "", "tone" => "neutral"];
        }

        $themeCfg = json_decode($survey["theme_config"] ?? "null", true) ?? [];
        $aiConfig = json_decode($survey["ai_config"] ?? "null", true) ?? [
            "provider" => "gemini",
            "api_key" => "",
            "model" => "gemini-1.5-pro",
            "capabilities" => ["context_awareness"],
            "system_prompt" => "",
            "temperature" => 0.7,
            "max_tokens" => 200,
        ];

        // Auth type handling
        $authType = $qc["auth_type"] ?? "anyone";

        // Google auth
        if ($authType === "google" && !Auth::check()) {
            Session::set("google_survey_redirect", $id);
            Response::layout("main", "respondent/take", [
                "pageTitle" => $survey["title"],
                "survey" => $survey,
                "questions" => [],
                "responseId" => null,
                "qualityConfig" => $qc,
                "requireGoogle" => true,
            ]);
            return;
        }

        // Email auth
        if ($authType === "email" && !Auth::check()) {
            $emailStep = Session::get("survey_email_step_" . $id);
            $verifiedEmail = Session::get("survey_email_" . $id);
            if (!$verifiedEmail) {
                Response::layout("main", "respondent/take", [
                    "pageTitle" => $survey["title"],
                    "survey" => $survey,
                    "questions" => [],
                    "responseId" => null,
                    "qualityConfig" => $qc,
                    "requireEmail" => true,
                    "emailStep" => $emailStep,
                ]);
                return;
            }
        }

        // Any account auth
        if ($authType === "any_account" && !Auth::check()) {
            Session::set("login_redirect", "/survey/take/" . $id);
            Response::redirect("/login");
            return;
        }

        // Password protection
        $sessionPass = Session::get("survey_pass_" . $id);
        if (!empty($survey["access_password"]) && !$sessionPass) {
            $submittedPass = $_POST["survey_password"] ?? "";
            if (empty($submittedPass)) {
                Response::layout("main", "respondent/take", [
                    "pageTitle" => $survey["title"],
                    "survey" => $survey,
                    "questions" => [],
                    "responseId" => null,
                    "qualityConfig" => $qc,
                    "requirePassword" => true,
                ]);
                return;
            }
            if (!password_verify($submittedPass, $survey["access_password"])) {
                Session::setFlash("danger", "Incorrect survey password.");
                Response::redirect("/survey/take/{$id}");
            }
            Session::set("survey_pass_" . $id, true);
        }

        if (!empty($qc["prevent_duplicates"])) {
            if (Auth::check()) {
                $existing = $db->fetchOne(
                    "SELECT id FROM responses WHERE survey_id = ? AND respondent_id = ? AND status != 'in_progress'",
                    [$id, Auth::id()],
                );
                if ($existing) {
                    Session::setFlash(
                        "warning",
                        "You have already completed this survey",
                    );
                    Response::redirect("/dashboard");
                }
            } else {
                $emailSession = Session::get("survey_email_" . $id);
                if ($emailSession) {
                    $emailKey =
                        "survey_completed_email_" .
                        $id .
                        "_" .
                        sha1(strtolower(trim((string) $emailSession)));
                    if (Session::get($emailKey)) {
                        Session::setFlash(
                            "warning",
                            "You have already completed this survey",
                        );
                        Response::redirect("/dashboard");
                    }
                }

                if (Session::get("survey_completed_" . $id)) {
                    Session::setFlash(
                        "warning",
                        "You have already completed this survey",
                    );
                    Response::redirect("/dashboard");
                }

                $ip = $_SERVER["REMOTE_ADDR"] ?? null;
                if ($ip) {
                    $existingAnon = $db->fetchOne(
                        "SELECT id FROM responses WHERE survey_id = ? AND respondent_id IS NULL AND ip_address = ? AND status != 'in_progress' LIMIT 1",
                        [$id, $ip],
                    );
                    if ($existingAnon) {
                        Session::setFlash(
                            "warning",
                            "You have already completed this survey",
                        );
                        Response::redirect("/dashboard");
                    }
                }
            }
        }

        $questions = $db->fetchAll(
            "SELECT * FROM questions WHERE survey_id = ? ORDER BY order_index ASC",
            [$id],
        );

        $resumeCode = null;
        if (!empty($qc["allow_resume"])) {
            $resumeCode = substr(bin2hex(random_bytes(8)), 0, 16);
        }

        $randomSeed = null;
        if (
            !empty($qc["shuffle_questions"]) ||
            !empty($qc["shuffle_options"])
        ) {
            $randomSeed = mt_rand(1, 999999);
        }

        $responseId = null;
        $existingResponseId = (int) Session::get("current_response_id", 0);
        if ($existingResponseId > 0) {
            $existingInProgress = $db->fetchOne(
                "SELECT id, survey_id, respondent_id, status FROM responses WHERE id = ?",
                [$existingResponseId],
            );
            if (
                $existingInProgress &&
                (int) $existingInProgress["survey_id"] === (int) $id &&
                $existingInProgress["status"] === "in_progress" &&
                (!Auth::check() ||
                    !$existingInProgress["respondent_id"] ||
                    (int) $existingInProgress["respondent_id"] === Auth::id())
            ) {
                $responseId = (int) $existingInProgress["id"];
            }
        }

        if (!$responseId) {
            $responseId = $db->insert("responses", [
                "survey_id" => $id,
                "respondent_id" => Auth::check() ? Auth::id() : null,
                "ip_address" => $_SERVER["REMOTE_ADDR"] ?? null,
                "user_agent" => $_SERVER["HTTP_USER_AGENT"] ?? null,
                "question_random_seed" => $randomSeed,
                "resume_code" => $resumeCode,
                "status" => "in_progress",
            ]);
        }

        Session::set("current_response_id", $responseId);
        Session::set(
            "survey_start_time",
            Session::get("survey_start_time", time()),
        );
        Session::set("tab_switches", Session::get("tab_switches", 0));

        // Chat survey — render chat interface instead of form
        if ($surveyType === "chat") {
            Response::layout("main", "respondent/chat_survey", [
                "pageTitle" => $survey["title"],
                "survey" => $survey,
                "responseId" => $responseId,
                "qualityConfig" => $qc,
                "chatConfig" => $chatConfig,
                "themeCfg" => $themeCfg,
                "aiConfig" => $aiConfig,
            ]);
            return;
        }

        Response::layout("main", "respondent/take", [
            "pageTitle" => $survey["title"],
            "survey" => $survey,
            "questions" => $questions,
            "responseId" => $responseId,
            "qualityConfig" => $qc,
            "themeCfg" => $themeCfg,
            "aiConfig" => $aiConfig,
            "resumeCode" => $resumeCode,
            "randomSeed" => $randomSeed,
        ]);
    }

    public function takeAuth(string $id): void
    {
        $db = Database::getInstance();
        $survey = $db->fetchOne("SELECT * FROM surveys WHERE id = ?", [$id]);
        if (!$survey) {
            Response::redirect("/dashboard");
        }

        // Survey password
        if (
            !empty($survey["access_password"]) &&
            isset($_POST["survey_password"])
        ) {
            if (
                password_verify(
                    $_POST["survey_password"],
                    $survey["access_password"],
                )
            ) {
                Session::set("survey_pass_" . $id, true);
                Session::setFlash("success", "Survey unlocked.");
            } else {
                Session::setFlash("danger", "Incorrect survey password.");
            }
            Response::redirect("/survey/take/{$id}");
        }

        // Email verification — send code
        if (($_POST["email_action"] ?? "") === "send_code") {
            $email = trim($_POST["survey_email"] ?? "");
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                Session::setFlash(
                    "danger",
                    "Please enter a valid email address.",
                );
                Response::redirect("/survey/take/{$id}");
            }
            $code = strval(mt_rand(100000, 999999));
            Session::set("survey_email_code_" . $id, $code);
            Session::set("survey_email_addr_" . $id, $email);
            Session::set("survey_email_step_" . $id, "verify");
            Session::set("survey_email_code_created_" . $id, time());
            Session::set("survey_email_attempts_" . $id, 0);
            Session::setFlash(
                "success",
                "Verification code sent to {$email}. (Dev: {$code})",
            );
            Response::redirect("/survey/take/{$id}");
        }

        // Email verification — verify code
        if (($_POST["email_action"] ?? "") === "verify_code") {
            $submitted = trim($_POST["verify_code"] ?? "");
            $expected = Session::get("survey_email_code_" . $id);
            $createdAt = (int) Session::get(
                "survey_email_code_created_" . $id,
                0,
            );
            $attempts = (int) Session::get("survey_email_attempts_" . $id, 0);

            if ($attempts >= 5) {
                Session::remove("survey_email_code_" . $id);
                Session::remove("survey_email_addr_" . $id);
                Session::remove("survey_email_step_" . $id);
                Session::remove("survey_email_code_created_" . $id);
                Session::remove("survey_email_attempts_" . $id);
                Session::setFlash(
                    "danger",
                    "Too many invalid attempts. Please request a new verification code.",
                );
                Response::redirect("/survey/take/{$id}");
            }

            if ($createdAt <= 0 || time() - $createdAt > 600) {
                Session::remove("survey_email_code_" . $id);
                Session::remove("survey_email_addr_" . $id);
                Session::remove("survey_email_step_" . $id);
                Session::remove("survey_email_code_created_" . $id);
                Session::remove("survey_email_attempts_" . $id);
                Session::setFlash(
                    "danger",
                    "Verification code expired. Please request a new one.",
                );
                Response::redirect("/survey/take/{$id}");
            }

            if (
                $submitted !== "" &&
                $expected !== null &&
                hash_equals((string) $expected, $submitted)
            ) {
                $email = Session::get("survey_email_addr_" . $id);
                Session::set("survey_email_" . $id, $email);
                Session::remove("survey_email_code_" . $id);
                Session::remove("survey_email_addr_" . $id);
                Session::remove("survey_email_step_" . $id);
                Session::remove("survey_email_code_created_" . $id);
                Session::remove("survey_email_attempts_" . $id);
                Session::setFlash("success", "Email verified.");
            } else {
                $attempts++;
                Session::set("survey_email_attempts_" . $id, $attempts);
                $remaining = max(0, 5 - $attempts);
                Session::setFlash(
                    "danger",
                    "Invalid verification code. {$remaining} attempt(s) remaining.",
                );
            }
            Response::redirect("/survey/take/{$id}");
        }

        Response::redirect("/survey/take/{$id}");
    }

    public function submit(string $id): void
    {
        $db = Database::getInstance();
        $survey = $db->fetchOne("SELECT * FROM surveys WHERE id = ?", [$id]);

        if (!$survey) {
            Session::setFlash("danger", "Survey not available");
            Response::redirect("/dashboard");
        }

        // Allow the survey owner to submit preview; deny others if not active
        if ($survey["status"] !== "active") {
            $isOwner = Auth::check() && Auth::id() === $survey["researcher_id"];
            if (!$isOwner) {
                Session::setFlash("danger", "Survey not available");
                Response::redirect("/dashboard");
            }
        }

        // Password check
        if (!empty($survey["access_password"])) {
            $sessionPass = Session::get("survey_pass_" . $id);
            if (!$sessionPass) {
                Session::setFlash("danger", "Survey password required.");
                Response::redirect("/survey/take/{$id}");
            }
        }

        $qc =
            json_decode($survey["quality_config"] ?? "null", true) ??
            self::defaultQualityConfig();

        $responseId = Session::get("current_response_id");
        if (!$responseId) {
            Session::setFlash("danger", "Session expired");
            Response::redirect("/survey/take/{$id}");
        }

        $response = $db->fetchOne(
            "SELECT id, survey_id, respondent_id, status FROM responses WHERE id = ?",
            [$responseId],
        );
        if (!$response || (int) $response["survey_id"] !== (int) $id) {
            Session::setFlash("danger", "Invalid session. Please start over.");
            $this->cleanupSession($id);
            Response::redirect("/survey/take/{$id}");
        }
        if (
            Auth::check() &&
            $response["respondent_id"] &&
            (int) $response["respondent_id"] !== Auth::id()
        ) {
            Session::setFlash("danger", "Invalid session.");
            $this->cleanupSession($id);
            Response::redirect("/survey/take/{$id}");
        }

        $questions = $db->fetchAll(
            "SELECT * FROM questions WHERE survey_id = ? ORDER BY order_index ASC",
            [$id],
        );

        $startTime = Session::get("survey_start_time", time());
        $totalTime = time() - $startTime;
        $tabSwitches = (int) ($_POST["tab_switches"] ?? 0);

        // Active Quality Checks
        $honeypotFilled = !empty($_POST["honeypot"]);
        $minTime = (int) $qc["min_time_seconds"];
        $tooFast = $minTime > 0 && $totalTime < $minTime;
        $tooManyTabSwitches =
            !empty($qc["track_tab_switches"]) && $tabSwitches > 3;

        // Inactivity timeout check
        $maxInactivity = (int) $qc["inactivity_timeout"];
        $inactiveTooLong = false;
        if ($maxInactivity > 0) {
            $inactiveSeconds = (int) ($_POST["_inactive_seconds"] ?? 0);
            if ($inactiveSeconds > $maxInactivity) {
                $inactiveTooLong = true;
            }
        }

        // CAPTCHA
        if (!empty($qc["captcha"])) {
            $captchaAnswer = (int) ($_POST["captcha_answer"] ?? -1);
            $captchaExpected = (int) ($_POST["captcha_expected"] ?? -2);
            if ($captchaAnswer !== $captchaExpected) {
                Session::setFlash(
                    "danger",
                    "Math verification failed. Please try again.",
                );
                $db->update("responses", ["status" => "flagged"], "id = ?", [
                    $responseId,
                ]);
                $this->cleanupSession($id);
                Response::redirect("/survey/take/{$id}");
            }
        }

        // Chat survey — handle structured JSON responses
        $chatData = null;
        $chatResponses = [];
        if (
            ($survey["type"] ?? "form") === "chat" &&
            !empty($_POST["chat_responses"])
        ) {
            $chatData = json_decode($_POST["chat_responses"], true);
            if (is_array($chatData) && isset($chatData["responses"])) {
                $chatResponses = $chatData["responses"];
            }
        }

        $flagged =
            $honeypotFilled ||
            $tooFast ||
            $tooManyTabSwitches ||
            $inactiveTooLong;

        // Behavioral log anti-cheat checks
        if (!empty($_POST["_behavior_log"])) {
            $behaviorData = json_decode($_POST["_behavior_log"], true);
            if (is_array($behaviorData)) {
                foreach ($behaviorData as $be) {
                    if (($be["event_type"] ?? "") === "devtools_open") {
                        $flagged = true;
                        break;
                    }
                }
                // Flag if more than 10 tab switches
                $tabSwitchCount = 0;
                foreach ($behaviorData as $be) {
                    if (
                        ($be["event_type"] ?? "") === "tab_switch" &&
                        ($be["event_data"]["action"] ?? "") === "switched_away"
                    ) {
                        $tabSwitchCount++;
                    }
                }
                if ($tabSwitchCount > 5) {
                    $flagged = true;
                }
            }
        }

        // Timed question validation
        $timedQuestionIds = $_POST["_timed_question_ids"] ?? "";
        if (!empty($timedQuestionIds)) {
            $timedIds = array_filter(
                explode(",", $timedQuestionIds),
                "is_numeric",
            );
            $timedTimes = $_POST["_timed_times"] ?? [];
            foreach ($timedIds as $tqId) {
                $timeKey = "_timed_" . $tqId;
                $allowedSeconds = (int) ($timedTimes[$timeKey] ?? 0);
                $actualSeconds = (int) ($_POST["_elapsed_" . $tqId] ?? 0);
                if ($allowedSeconds > 0 && $actualSeconds > $allowedSeconds) {
                    $flagged = true;
                }
            }
        }

        // Chat survey: save all responses + full conversation as a single JSON blob
        if (!empty($chatData)) {
            $db->update(
                "responses",
                ["chat_data" => json_encode($chatData)],
                "id = ?",
                [$responseId],
            );
        } elseif (!empty($chatResponses)) {
            $db->update(
                "responses",
                ["chat_data" => json_encode($chatResponses)],
                "id = ?",
                [$responseId],
            );
        }

        // Atomic: wrap entire submission in a transaction for data integrity
        $db->beginTransaction();
        try {
            // Re-check max_responses within transaction with row lock
            $currentSurvey = $db->fetchOne(
                "SELECT current_responses, max_responses FROM surveys WHERE id = ? FOR UPDATE",
                [$id],
            );
            if (
                $currentSurvey &&
                $currentSurvey["max_responses"] !== null &&
                (int) $currentSurvey["current_responses"] >=
                    (int) $currentSurvey["max_responses"]
            ) {
                $db->rollback();
                Session::setFlash(
                    "danger",
                    "Survey has reached maximum responses.",
                );
                $this->cleanupSession($id);
                Response::redirect("/dashboard");
                return;
            }

            foreach ($questions as $question) {
                $answerKey = "q_{$question["id"]}";
                $answerValue = "";

                if ($question["type"] === "file_upload") {
                    if (
                        !empty($_FILES[$answerKey]) &&
                        $_FILES[$answerKey]["error"] === UPLOAD_ERR_OK
                    ) {
                        $allowedExts = [
                            "jpg",
                            "jpeg",
                            "png",
                            "gif",
                            "pdf",
                            "doc",
                            "docx",
                            "xls",
                            "xlsx",
                            "csv",
                            "txt",
                            "zip",
                            "mp3",
                            "mp4",
                            "webm",
                            "svg",
                            "json",
                        ];
                        $fileName = $_FILES[$answerKey]["name"];
                        // Sanitize filename to prevent path traversal
                        $fileName = basename($fileName);
                        $ext = strtolower(
                            pathinfo($fileName, PATHINFO_EXTENSION),
                        );
                        if (!in_array($ext, $allowedExts)) {
                            $flagged = true;
                        } else {
                            // Validate MIME type
                            $finfo = finfo_open(FILEINFO_MIME_TYPE);
                            $mimeType = finfo_file(
                                $finfo,
                                $_FILES[$answerKey]["tmp_name"],
                            );
                            finfo_close($finfo);
                            $allowedMimes = [
                                "image/jpeg",
                                "image/png",
                                "image/gif",
                                "image/webp",
                                "image/svg+xml",
                                "application/pdf",
                                "application/msword",
                                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                                "application/vnd.ms-excel",
                                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                "text/csv",
                                "text/plain",
                                "application/zip",
                                "audio/mpeg",
                                "video/mp4",
                                "video/webm",
                                "application/json",
                            ];
                            if (!in_array($mimeType, $allowedMimes, true)) {
                                $flagged = true;
                            } else {
                                $uploadDir = __DIR__ . "/../../uploads/";
                                if (!is_dir($uploadDir)) {
                                    mkdir($uploadDir, 0755, true);
                                }
                                // Ensure upload directory is within project root
                                $uploadDir = realpath($uploadDir);
                                if (
                                    $uploadDir === false ||
                                    strpos(
                                        $uploadDir,
                                        realpath(__DIR__ . "/../../"),
                                    ) !== 0
                                ) {
                                    $flagged = true;
                                } else {
                                    $safeName =
                                        $responseId .
                                        "_" .
                                        $question["id"] .
                                        "_" .
                                        bin2hex(random_bytes(4)) .
                                        "." .
                                        $ext;
                                    $dest =
                                        $uploadDir .
                                        DIRECTORY_SEPARATOR .
                                        $safeName;
                                    if (
                                        move_uploaded_file(
                                            $_FILES[$answerKey]["tmp_name"],
                                            $dest,
                                        )
                                    ) {
                                        $answerValue = "uploads/" . $safeName;
                                    }
                                }
                            }
                        }
                    }
                } elseif ($question["type"] === "mcq_multiple") {
                    $answerValue = isset($_POST[$answerKey])
                        ? json_encode($_POST[$answerKey])
                        : "";
                } elseif ($question["type"] === "matrix") {
                    $rows = json_decode($question["rows_json"] ?? "[]", true);
                    $matrixData = [];
                    foreach ($rows as $row) {
                        $matrixData[$row] =
                            $_POST[$answerKey . "_" . $row] ?? "";
                    }
                    $answerValue = json_encode($matrixData);
                } elseif ($question["type"] === "multi_text") {
                    $options = json_decode(
                        $question["options_json"] ?? "[]",
                        true,
                    );
                    $multiData = [];
                    foreach ($options as $field) {
                        $fieldKey = $answerKey . "_" . $field;
                        $multiData[$field] = trim($_POST[$fieldKey] ?? "");
                    }
                    $answerValue = json_encode($multiData);
                } elseif ($question["type"] === "address") {
                    $addressData = [
                        "street" => trim($_POST[$answerKey . "_street"] ?? ""),
                        "city" => trim($_POST[$answerKey . "_city"] ?? ""),
                        "state" => trim($_POST[$answerKey . "_state"] ?? ""),
                        "zip" => trim($_POST[$answerKey . "_zip"] ?? ""),
                        "country" => trim(
                            $_POST[$answerKey . "_country"] ?? "",
                        ),
                    ];
                    $answerValue = json_encode($addressData);
                } elseif ($question["type"] === "ranking") {
                    $answerValue = isset($_POST[$answerKey])
                        ? json_encode($_POST[$answerKey])
                        : "";
                } else {
                    $answerValue = trim($_POST[$answerKey] ?? "");
                }

                // Handle special types for required check
                if (
                    $question["type"] === "signature" &&
                    $question["is_required"]
                ) {
                    $sigKey = $answerKey;
                    $sigVal = trim($_POST[$sigKey] ?? "");
                    if (empty($sigVal) || $sigVal === "data:,") {
                        $flagged = true;
                    }
                }

                // Required question check
                if (
                    $question["is_required"] &&
                    self::isAnswerEffectivelyEmpty(
                        (string) ($question["type"] ?? "text"),
                        $answerValue,
                    )
                ) {
                    $flagged = true;
                }

                // Min/Max text length checks (question-level, text-like inputs only)
                if (
                    self::isTextLikeType((string) ($question["type"] ?? "text"))
                ) {
                    if (
                        $question["min_length"] &&
                        strlen($answerValue) > 0 &&
                        strlen($answerValue) < (int) $question["min_length"]
                    ) {
                        $flagged = true;
                    }

                    if (
                        $question["max_length"] &&
                        strlen($answerValue) > (int) $question["max_length"]
                    ) {
                        $flagged = true;
                    }
                }

                // Min text length check (survey-level QC)
                if (
                    !empty($qc["min_text_length"]) &&
                    in_array($question["type"], ["text", "email", "phone"])
                ) {
                    $minLen = (int) $qc["min_text_length"];
                    if (
                        $question["is_required"] &&
                        strlen($answerValue) > 0 &&
                        strlen($answerValue) < $minLen
                    ) {
                        $flagged = true;
                    }
                }

                // Paste flag check
                $wasPasted = (int) ($_POST["_pasted_" . $question["id"]] ?? 0);
                if (!empty($qc["prevent_copy_paste"]) && $wasPasted) {
                    $flagged = true;
                }

                // Input validation
                if (!empty($qc["validate_input"]) && !empty($answerValue)) {
                    $isValid = self::validateAnswer(
                        $question["type"],
                        $answerValue,
                    );
                    if (!$isValid) {
                        $flagged = true;
                    }
                }

                $db->insert("answers", [
                    "response_id" => $responseId,
                    "question_id" => $question["id"],
                    "answer_value" => $answerValue,
                    "time_spent_seconds" => null,
                    "is_flagged" => 0,
                ]);
            }

            // Straight-line detection
            if (!empty($qc["detect_straightline"])) {
                $allValues = [];
                foreach ($questions as $q) {
                    $key = "q_{$q["id"]}";
                    if (isset($_POST[$key])) {
                        $allValues[] = is_array($_POST[$key])
                            ? json_encode($_POST[$key])
                            : $_POST[$key];
                    }
                }
                $unique = array_unique(array_filter($allValues));
                if (count($allValues) >= 4 && count($unique) <= 1) {
                    $flagged = true;
                }
            }

            $deviceFingerprint = trim($_POST["device_fingerprint"] ?? "");

            $db->update(
                "responses",
                [
                    "completed_at" => date("Y-m-d H:i:s"),
                    "time_spent_seconds" => $totalTime,
                    "device_fingerprint" => $deviceFingerprint ?: null,
                    "tab_switch_count" => $tabSwitches,
                    "status" => $flagged ? "flagged" : "completed",
                ],
                "id = ?",
                [$responseId],
            );

            // Save behavioral logs
            if (!empty($_POST["_behavior_log"])) {
                $behaviorData = json_decode($_POST["_behavior_log"], true);
                if (is_array($behaviorData)) {
                    foreach ($behaviorData as $be) {
                        $db->insert("behavioral_logs", [
                            "response_id" => $responseId,
                            "event_type" => $be["event_type"] ?? "unknown",
                            "event_data" => isset($be["event_data"])
                                ? json_encode($be["event_data"])
                                : null,
                            "timestamp_ms" =>
                                (int) ($be["timestamp_ms"] ??
                                    round(microtime(true) * 1000)),
                            "question_index" => $be["question_index"] ?? null,
                        ]);
                    }
                }
            }

            $db->query(
                "UPDATE surveys SET current_responses = current_responses + 1 WHERE id = ? AND (max_responses IS NULL OR current_responses < max_responses)",
                [$id],
            );

            $db->commit();
        } catch (\Exception $e) {
            $db->rollback();
            error_log(
                "Response finalization transaction failed: " . $e->getMessage(),
            );
            Session::setFlash(
                "danger",
                "An error occurred while submitting your response.",
            );
            $this->cleanupSession($id);
            Response::redirect("/dashboard");
            return;
        }

        $this->cleanupSession($id);

        if (!empty($qc["prevent_duplicates"]) && !Auth::check()) {
            Session::set("survey_completed_" . $id, true);
            $emailSession = Session::get("survey_email_" . $id);
            if ($emailSession) {
                $emailKey =
                    "survey_completed_email_" .
                    $id .
                    "_" .
                    sha1(strtolower(trim((string) $emailSession)));
                Session::set($emailKey, true);
            }
        }

        // Run quality engine
        $finalScore = null;
        if ($survey["require_quality_check"]) {
            try {
                $answers = $db->fetchAll(
                    "SELECT * FROM answers WHERE response_id = ?",
                    [$responseId],
                );
                $engine = new \Quality\Engine($survey["quality_threshold"]);
                $result = $engine->evaluate(
                    $responseId,
                    $answers,
                    $questions,
                    $survey,
                );
                $finalScore = $result["overall_score"] ?? null;
            } catch (\Exception $e) {
                error_log("Quality engine error: " . $e->getMessage());
            }
        }

        // Update respondent reputation
        if (Auth::check() && Auth::user()["role"] === "respondent") {
            $userId = Auth::id();
            $oldRep =
                (float) ($db->fetchOne(
                    "SELECT reputation_score FROM users WHERE id = ?",
                    [$userId],
                )["reputation_score"] ?? 50);
            $newRep = $oldRep;

            $config = require __DIR__ . "/../../config/app.php";
            $repConfig = $config["reputation"];

            if ($flagged || $honeypotFilled) {
                $newRep = max(
                    0,
                    $oldRep + ($repConfig["flagged_penalty"] ?? -10),
                );
                $reason = "Response flagged by active checks";
            } elseif ($finalScore !== null) {
                $threshold = (float) $survey["quality_threshold"];
                if ($finalScore >= $threshold) {
                    $newRep = min(
                        100,
                        $oldRep + ($repConfig["good_response_bonus"] ?? 2),
                    );
                    $reason =
                        "Quality score " .
                        number_format($finalScore, 1) .
                        " above threshold";
                } else {
                    $newRep = max(
                        0,
                        $oldRep + ($repConfig["poor_response_penalty"] ?? -5),
                    );
                    $reason =
                        "Quality score " .
                        number_format($finalScore, 1) .
                        " below threshold";
                }
            } else {
                $newRep = max(0, $oldRep - 3);
                $reason = "Response submitted with incomplete quality check";
            }

            if ($newRep !== $oldRep) {
                $db->update(
                    "users",
                    [
                        "reputation_score" => $newRep,
                        "last_activity_at" => date("Y-m-d H:i:s"),
                    ],
                    "id = ?",
                    [$userId],
                );
                $db->insert("reputation_history", [
                    "user_id" => $userId,
                    "response_id" => $responseId,
                    "survey_id" => $id,
                    "old_score" => $oldRep,
                    "new_score" => $newRep,
                    "change_reason" => $reason,
                ]);
            }
        }

        // Update last activity
        if (Auth::check()) {
            $db->update(
                "users",
                ["last_activity_at" => date("Y-m-d H:i:s")],
                "id = ?",
                [Auth::id()],
            );
        }

        if ($flagged) {
            Session::setFlash(
                "warning",
                "Your response has been flagged for quality review.",
            );
        } else {
            Session::setFlash(
                "success",
                "Survey submitted! Thank you for your participation.",
            );
        }
        Response::redirect("/dashboard");
    }

    private function cleanupSession(string $surveyId = null): void
    {
        Session::remove("current_response_id");
        Session::remove("survey_start_time");
        Session::remove("tab_switches");
        if ($surveyId) {
            Session::remove("survey_pass_" . $surveyId);
        }
    }

    private static function normalizeDateTime(?string $value): ?string
    {
        $value = trim((string) $value);
        if ($value === "") {
            return null;
        }

        $ts = strtotime($value);
        if ($ts === false) {
            return null;
        }

        return date("Y-m-d H:i:s", $ts);
    }

    private static function isTextLikeType(string $type): bool
    {
        return in_array(
            $type,
            [
                "text",
                "textarea",
                "email",
                "phone",
                "url",
                "number",
                "date",
                "time",
                "datetime",
                "percentage",
                "signature",
                "color",
            ],
            true,
        );
    }

    private static function isAnswerEffectivelyEmpty(
        string $type,
        mixed $answerValue,
    ): bool {
        if ($answerValue === null) {
            return true;
        }

        $value = is_string($answerValue)
            ? trim($answerValue)
            : (string) $answerValue;
        if ($value === "") {
            return true;
        }

        if (in_array($type, ["matrix", "multi_text", "address"], true)) {
            $decoded = json_decode($value, true);
            if (!is_array($decoded) || empty($decoded)) {
                return true;
            }
            foreach ($decoded as $item) {
                if (is_array($item)) {
                    foreach ($item as $nested) {
                        if (trim((string) $nested) !== "") {
                            return false;
                        }
                    }
                } elseif (trim((string) $item) !== "") {
                    return false;
                }
            }
            return true;
        }

        if (in_array($type, ["mcq_multiple", "ranking"], true)) {
            $decoded = json_decode($value, true);
            return !is_array($decoded) ||
                count(
                    array_filter($decoded, fn($v) => trim((string) $v) !== ""),
                ) === 0;
        }

        return $value === "";
    }

    private static function validateAnswer(string $type, string $value): bool
    {
        if (empty($value)) {
            return true;
        }
        return match ($type) {
            "email" => filter_var($value, FILTER_VALIDATE_EMAIL) !== false,
            "number" => is_numeric($value),
            "phone" => preg_match('/^[+\-\d\s()]{7,20}$/', $value) === 1,
            "date" => strtotime($value) !== false,
            "url" => (bool) filter_var($value, FILTER_VALIDATE_URL),
            default => true,
        };
    }

    public function results(string $id): void
    {
        Auth::requireRole("researcher");

        $db = Database::getInstance();
        $survey = $db->fetchOne(
            "SELECT * FROM surveys WHERE id = ? AND researcher_id = ?",
            [$id, Auth::id()],
        );

        if (!$survey) {
            Response::notFound();
        }

        $page = max(1, (int) ($_GET["page"] ?? 1));
        $perPage = 50;
        $offset = ($page - 1) * $perPage;
        $statusFilter = $_GET["status"] ?? "";

        $where = "r.survey_id = ?";
        $params = [$id];

        if (
            !empty($statusFilter) &&
            in_array($statusFilter, [
                "accepted",
                "rejected",
                "flagged",
                "completed",
                "in_progress",
            ])
        ) {
            $where .= " AND r.status = ?";
            $params[] = $statusFilter;
        }

        $total = $db->fetchOne(
            "SELECT COUNT(*) as c FROM responses r WHERE {$where}",
            $params,
        )["c"];

        $responses = $db->fetchAll(
            "SELECT r.*, qs.overall_score, qs.researcher_verdict
             FROM responses r
             LEFT JOIN quality_scores qs ON qs.response_id = r.id
             WHERE {$where}
             ORDER BY r.created_at DESC LIMIT ? OFFSET ?",
            array_merge($params, [$perPage, $offset]),
        );

        $surveyType = $survey["type"] ?? "form";
        $chatNodes = [];
        if ($surveyType === "chat") {
            $chatConfig =
                json_decode($survey["chat_config"] ?? "{}", true) ?? [];
            $chatNodes = $chatConfig["nodes"] ?? [];
            // Parse chat_data for each response (stored as flat {key: value} or wrapped {responses:{...}})
            foreach ($responses as &$r) {
                $r["chat_data_parsed"] = [];
                if (!empty($r["chat_data"])) {
                    $cd = json_decode($r["chat_data"], true);
                    if (is_array($cd)) {
                        if (isset($cd["responses"])) {
                            $r["chat_data_parsed"] = $cd["responses"];
                        } else {
                            $r["chat_data_parsed"] = $cd;
                        }
                    }
                }
            }
            unset($r);
        }

        $questions = $db->fetchAll(
            "SELECT * FROM questions WHERE survey_id = ? ORDER BY order_index ASC",
            [$id],
        );

        // Bulk-fetch answers for visible responses to avoid N+1 in view
        $answersByResponse = [];
        $responseIds = array_column($responses, "id");
        if (!empty($responseIds)) {
            $placeholders = implode(
                ",",
                array_fill(0, count($responseIds), "?"),
            );
            $answerRows = $db->fetchAll(
                "SELECT response_id, question_id, answer_value FROM answers WHERE response_id IN ({$placeholders})",
                $responseIds,
            );
            foreach ($answerRows as $a) {
                $answersByResponse[$a["response_id"]][$a["question_id"]] =
                    $a["answer_value"];
            }
        }

        $totalPages = ceil($total / $perPage);

        Response::layout("main", "researcher/survey/results", [
            "pageTitle" => "Results: {$survey["title"]}",
            "survey" => $survey,
            "responses" => $responses,
            "questions" => $questions,
            "answersByResponse" => $answersByResponse,
            "surveyType" => $surveyType,
            "chatNodes" => $chatNodes,
            "page" => $page,
            "totalPages" => $totalPages,
            "total" => $total,
            "statusFilter" => $statusFilter,
        ]);
    }

    public function templates(): void
    {
        Auth::requireRole("researcher");

        $templates = \Helpers\SurveyTemplates::all();

        Response::layout("main", "researcher/templates", [
            "pageTitle" => "Survey Templates",
            "templates" => $templates,
        ]);
    }

    // ============================================================
    // SURVEY URL SHORTENER
    // ============================================================

    public function createUrl(string $id): void
    {
        if (!$this->requireAjaxAuth()) {
            return;
        }

        $db = Database::getInstance();
        $survey = $db->fetchOne(
            "SELECT * FROM surveys WHERE id = ? AND researcher_id = ?",
            [$id, Auth::id()],
        );
        if (!$survey) {
            Response::json(["error" => "Survey not found"], 404);
        }

        // Generate unique short code
        $shortCode = self::generateShortCode($db);

        $customSlug = trim($_POST["custom_slug"] ?? "");
        if (!empty($customSlug)) {
            if (!preg_match('/^[a-zA-Z0-9\-_]{2,50}$/', $customSlug)) {
                Response::json([
                    "error" =>
                        "Custom slug must be 2-50 chars: letters, numbers, hyphens, underscores.",
                ]);
                return;
            }
            $existing = $db->fetchOne(
                "SELECT id FROM survey_urls WHERE custom_slug = ?",
                [$customSlug],
            );
            if ($existing) {
                Response::json(["error" => "Custom slug already taken."]);
                return;
            }
            $shortCode = $customSlug;
        }

        $db->insert("survey_urls", [
            "survey_id" => $id,
            "short_code" => $shortCode,
            "custom_slug" => $customSlug ?: null,
            "utm_source" => trim($_POST["utm_source"] ?? "") ?: null,
            "utm_medium" => trim($_POST["utm_medium"] ?? "") ?: null,
            "utm_campaign" => trim($_POST["utm_campaign"] ?? "") ?: null,
            "utm_content" => trim($_POST["utm_content"] ?? "") ?: null,
            "utm_term" => trim($_POST["utm_term"] ?? "") ?: null,
            "password" => !empty($_POST["url_password"])
                ? password_hash($_POST["url_password"], PASSWORD_BCRYPT)
                : null,
            "expires_at" => !empty($_POST["expires_at"])
                ? $_POST["expires_at"]
                : null,
            "max_uses" => !empty($_POST["max_uses"])
                ? (int) $_POST["max_uses"]
                : null,
            "is_active" => 1,
        ]);

        Response::json(["success" => true, "short_code" => $shortCode]);
    }

    private function requireAjaxAuth(): bool
    {
        if (!Auth::check() || Auth::role() !== "researcher") {
            Response::json(["error" => "Authentication required"], 401);
            return false;
        }
        return true;
    }

    public function listUrls(string $id): void
    {
        if (!$this->requireAjaxAuth()) {
            return;
        }

        $db = Database::getInstance();
        $survey = $db->fetchOne(
            "SELECT * FROM surveys WHERE id = ? AND researcher_id = ?",
            [$id, Auth::id()],
        );
        if (!$survey) {
            Response::json(["error" => "Survey not found"], 404);
        }

        $urls = $db->fetchAll(
            "SELECT * FROM survey_urls WHERE survey_id = ? ORDER BY created_at DESC",
            [$id],
        );

        Response::json($urls);
    }

    public function toggleUrl(string $urlId): void
    {
        if (!$this->requireAjaxAuth()) {
            return;
        }

        $db = Database::getInstance();
        $url = $db->fetchOne(
            "SELECT su.* FROM survey_urls su JOIN surveys s ON s.id = su.survey_id WHERE su.id = ? AND s.researcher_id = ?",
            [$urlId, Auth::id()],
        );
        if (!$url) {
            Response::json(["error" => "URL not found"], 404);
        }

        $newStatus = $url["is_active"] ? 0 : 1;
        $db->update("survey_urls", ["is_active" => $newStatus], "id = ?", [
            $urlId,
        ]);

        Response::json(["success" => true, "is_active" => $newStatus]);
    }

    public function deleteUrl(string $urlId): void
    {
        if (!$this->requireAjaxAuth()) {
            return;
        }

        $db = Database::getInstance();
        $url = $db->fetchOne(
            "SELECT su.* FROM survey_urls su JOIN surveys s ON s.id = su.survey_id WHERE su.id = ? AND s.researcher_id = ?",
            [$urlId, Auth::id()],
        );
        if (!$url) {
            Response::json(["error" => "URL not found"], 404);
        }

        $db->delete("survey_urls", "id = ?", [$urlId]);

        Response::json(["success" => true]);
    }

    public function redirectByShortCode(string $code): void
    {
        $db = Database::getInstance();

        // Try exact short_code match first, then custom_slug
        $url = $db->fetchOne(
            "SELECT * FROM survey_urls WHERE (short_code = ? OR custom_slug = ?) AND is_active = 1",
            [$code, $code],
        );

        if (!$url) {
            Session::setFlash("danger", "Survey link not found or inactive.");
            Response::redirect("/");
            return;
        }

        // Expiry check
        if ($url["expires_at"] && date("Y-m-d H:i:s") > $url["expires_at"]) {
            Session::setFlash("danger", "This survey link has expired.");
            Response::redirect("/");
            return;
        }

        // Max uses check
        if ($url["max_uses"] && $url["use_count"] >= $url["max_uses"]) {
            Session::setFlash(
                "danger",
                "This survey link has reached its maximum uses.",
            );
            Response::redirect("/");
            return;
        }

        // Password check
        if (!empty($url["password"])) {
            $submittedPass = $_POST["survey_url_pass"] ?? "";
            if (empty($submittedPass)) {
                Session::setFlash(
                    "warning",
                    "This survey link requires a password.",
                );
                // Render password entry page
                Response::layout("main", "respondent/url_password", [
                    "pageTitle" => "Survey Link Password",
                    "code" => $code,
                ]);
                return;
            }
            if (!password_verify($submittedPass, $url["password"])) {
                Session::setFlash(
                    "danger",
                    "Incorrect password for this survey link.",
                );
                Response::redirect("/s/" . rawurlencode($code));
                return;
            }
        }

        // Increment use count
        $db->update(
            "survey_urls",
            ["use_count" => $url["use_count"] + 1],
            "id = ?",
            [$url["id"]],
        );

        // Build target URL with UTM params
        $target = "/survey/take/" . $url["survey_id"];
        $params = [];
        if ($url["utm_source"]) {
            $params["utm_source"] = $url["utm_source"];
        }
        if ($url["utm_medium"]) {
            $params["utm_medium"] = $url["utm_medium"];
        }
        if ($url["utm_campaign"]) {
            $params["utm_campaign"] = $url["utm_campaign"];
        }
        if ($url["utm_content"]) {
            $params["utm_content"] = $url["utm_content"];
        }
        if ($url["utm_term"]) {
            $params["utm_term"] = $url["utm_term"];
        }
        if (!empty($params)) {
            $target .= "?" . http_build_query($params);
        }

        Response::redirect($target);
    }

    private static function generateShortCode(Database $db): string
    {
        $chars =
            "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        $maxAttempts = 20;
        do {
            $code = "";
            for ($i = 0; $i < 6; $i++) {
                $code .= $chars[random_int(0, strlen($chars) - 1)];
            }
            $exists = $db->fetchOne(
                "SELECT id FROM survey_urls WHERE short_code = ?",
                [$code],
            );
            $maxAttempts--;
        } while ($exists && $maxAttempts > 0);

        return $code;
    }

    private static function ensureShortUrl(Database $db, int $surveyId): string
    {
        $existing = $db->fetchOne(
            "SELECT short_code FROM survey_urls WHERE survey_id = ? LIMIT 1",
            [$surveyId],
        );
        if ($existing) {
            return $existing["short_code"];
        }
        $shortCode = self::generateShortCode($db);
        $db->insert("survey_urls", [
            "survey_id" => $surveyId,
            "short_code" => $shortCode,
            "is_active" => 1,
        ]);
        return $shortCode;
    }
}
