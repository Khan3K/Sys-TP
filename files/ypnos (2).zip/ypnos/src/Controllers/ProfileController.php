<?php

namespace Controllers;

use Core\Auth;
use Core\Response;
use Core\Session;
use Core\Database;
use Core\Validator;

class ProfileController
{
    public function index(): void
    {
        Auth::requireAuth();

        $db = Database::getInstance();
        $user = Auth::user();

        if (!$user) {
            Session::setFlash('danger', 'User not found');
            Response::redirect('/login');
        }

        $reputationHistory = [];
        if ($user['role'] === 'respondent') {
            $reputationHistory = $db->fetchAll(
                "SELECT * FROM reputation_history WHERE user_id = ? ORDER BY created_at DESC LIMIT 20",
                [Auth::id()]
            );
        }

        Response::layout('main', 'profile', [
            'pageTitle'         => 'My Profile',
            'user'              => $user,
            'reputationHistory' => $reputationHistory,
        ]);
    }

    public function update(): void
    {
        Auth::requireAuth();

        $name = trim($_POST['full_name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        $v = new Validator($_POST);
        if (!$v->required('full_name', 'Name')->required('email')->email('email')->passes()) {
            Session::setFlash('danger', $v->firstError());
            Response::redirect('/profile');
        }

        $db = Database::getInstance();
        $userId = Auth::id();

        $data = ['full_name' => $name, 'email' => $email];

        if (!empty($password)) {
            if (strlen($password) < 6) {
                Session::setFlash('danger', 'Password must be at least 6 characters');
                Response::redirect('/profile');
            }
            $data['password_hash'] = password_hash($password, PASSWORD_BCRYPT);
        }

        $db->update('users', $data, 'id = ?', [$userId]);
        Session::setFlash('success', 'Profile updated');
        Response::redirect('/profile');
    }
}
