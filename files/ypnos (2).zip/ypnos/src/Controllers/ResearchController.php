<?php

namespace Controllers;

use Core\Auth;
use Core\Response;
use Core\Database;
use Core\Session;

class ResearchController
{
    public function dashboard(): void
    {
        Auth::requireRole('researcher');
        $db = Database::getInstance();

        $projects = $db->fetchAll(
            "SELECT p.*,
             (SELECT COUNT(*) FROM research_project_surveys rps WHERE rps.project_id = p.id) as survey_count,
             (SELECT COUNT(*) FROM research_visualizations rv WHERE rv.project_id = p.id) as viz_count
             FROM research_projects p WHERE p.researcher_id = ? ORDER BY p.updated_at DESC",
            [Auth::id()]
        );

        $surveys = $db->fetchAll(
            "SELECT s.id, s.title, s.status FROM surveys s WHERE s.researcher_id = ? ORDER BY s.title ASC",
            [Auth::id()]
        );

        Response::layout('main', 'researcher/research/dashboard', [
            'pageTitle' => 'Research Ground',
            'projects'  => $projects,
            'surveys'   => $surveys,
        ]);
    }

    public function create(): void
    {
        Auth::requireRole('researcher');

        $name = trim($_POST['name'] ?? '');
        if (empty($name)) {
            Session::setFlash('danger', 'Project name is required.');
            Response::redirect('/research');
        }

        $db = Database::getInstance();
        $projectId = $db->insert('research_projects', [
            'researcher_id' => Auth::id(),
            'name'          => $name,
            'description'   => trim($_POST['description'] ?? ''),
        ]);

        Session::setFlash('success', 'Research project created!');
        Response::redirect("/research/{$projectId}");
    }

    public function delete(string $id): void
    {
        Auth::requireRole('researcher');
        $db = Database::getInstance();

        $project = $db->fetchOne("SELECT * FROM research_projects WHERE id = ? AND researcher_id = ?", [$id, Auth::id()]);
        if (!$project) {
            Response::notFound();
        }

        $db->delete('research_projects', 'id = ?', [$id]);
        Session::setFlash('success', 'Research project deleted.');
        Response::redirect('/research');
    }

    public function view(string $id): void
    {
        Auth::requireRole('researcher');
        $db = Database::getInstance();

        $project = $db->fetchOne("SELECT * FROM research_projects WHERE id = ? AND researcher_id = ?", [$id, Auth::id()]);
        if (!$project) {
            Response::notFound();
        }

        $sources = $db->fetchAll(
            "SELECT rps.*, s.title as survey_title, s.status as survey_status,
             (SELECT COUNT(*) FROM questions q WHERE q.survey_id = s.id) as question_count,
             (SELECT COUNT(*) FROM responses r WHERE r.survey_id = s.id) as response_count
             FROM research_project_surveys rps
             JOIN surveys s ON rps.survey_id = s.id
             WHERE rps.project_id = ? ORDER BY rps.imported_at DESC",
            [$id]
        );

        $visualizations = $db->fetchAll(
            "SELECT * FROM research_visualizations WHERE project_id = ? ORDER BY created_at ASC",
            [$id]
        );

        $allSurveys = $db->fetchAll(
            "SELECT s.id, s.title, s.status FROM surveys s WHERE s.researcher_id = ? AND s.status != 'draft' ORDER BY s.title ASC",
            [Auth::id()]
        );

        // Collect imported question structures for the data view
        $allQuestions = [];
        $allResponses = [];
        $questionMap = [];
        $allAnswers = [];
        $allAnswersByResponse = [];
        $sourceSurveyIds = array_column($sources, 'survey_id');

        if (!empty($sourceSurveyIds)) {
            $sPlaceholders = implode(',', array_fill(0, count($sourceSurveyIds), '?'));
            $questionRows = $db->fetchAll(
                "SELECT * FROM questions WHERE survey_id IN ({$sPlaceholders}) ORDER BY survey_id, order_index ASC",
                $sourceSurveyIds
            );
            $responseRows = $db->fetchAll(
                "SELECT r.*, qs.overall_score FROM responses r 
                 LEFT JOIN quality_scores qs ON qs.response_id = r.id 
                 WHERE r.survey_id IN ({$sPlaceholders}) AND r.status IN ('completed','accepted','flagged') 
                 ORDER BY r.created_at DESC LIMIT 500",
                $sourceSurveyIds
            );

            foreach ($sourceSurveyIds as $sid) {
                $allQuestions[$sid] = [];
                $allResponses[$sid] = [];
            }
            foreach ($questionRows as $q) {
                $allQuestions[$q['survey_id']][] = $q;
                $questionMap[$q['id']] = $q;
            }
            foreach ($responseRows as $r) {
                $allResponses[$r['survey_id']][] = $r;
            }
        }

        // Fetch all answers for all collected responses
        $allResponseIds = [];
        foreach ($allResponses as $sid => $rs) {
            foreach ($rs as $r) {
                $allResponseIds[] = (int)$r['id'];
            }
        }
        if (!empty($allResponseIds)) {
            $allResponseIds = array_unique($allResponseIds);
            $rPlaceholders = implode(',', array_fill(0, count($allResponseIds), '?'));
            $answerRows = $db->fetchAll(
                "SELECT a.*, q.type as q_type, q.question_text as q_text
                 FROM answers a
                 JOIN questions q ON a.question_id = q.id
                 WHERE a.response_id IN ($rPlaceholders)
                 ORDER BY a.response_id, a.question_id",
                $allResponseIds
            );
            $allAnswers = $answerRows;
            foreach ($answerRows as $a) {
                $allAnswersByResponse[$a['response_id']][] = $a;
            }
        }

        Response::layout('main', 'researcher/research/view', [
            'pageTitle'           => $project['name'] . ' — Research Ground',
            'project'             => $project,
            'sources'             => $sources,
            'visualizations'      => $visualizations,
            'allSurveys'          => $allSurveys,
            'allQuestions'        => $allQuestions,
            'allResponses'        => $allResponses,
            'questionMap'         => $questionMap,
            'allAnswers'          => $allAnswers,
            'allAnswersByResponse' => $allAnswersByResponse,
        ]);
    }

    public function importSurvey(string $id): void
    {
        Auth::requireRole('researcher');
        $db = Database::getInstance();

        $project = $db->fetchOne("SELECT * FROM research_projects WHERE id = ? AND researcher_id = ?", [$id, Auth::id()]);
        if (!$project) {
            Response::notFound();
        }

        $surveyId = (int)($_POST['survey_id'] ?? 0);
        $survey = $db->fetchOne("SELECT * FROM surveys WHERE id = ? AND researcher_id = ?", [$surveyId, Auth::id()]);
        if (!$survey) {
            Session::setFlash('danger', 'Survey not found.');
            Response::redirect("/research/{$id}");
        }

        $existing = $db->fetchOne("SELECT id FROM research_project_surveys WHERE project_id = ? AND survey_id = ?", [$id, $surveyId]);
        if ($existing) {
            Session::setFlash('warning', 'Survey already imported to this project.');
        } else {
            $config = json_encode([
                'imported_questions' => count($db->fetchAll("SELECT id FROM questions WHERE survey_id = ?", [$surveyId])),
                'imported_responses' => count($db->fetchAll("SELECT id FROM responses WHERE survey_id = ? AND status IN ('completed','accepted')", [$surveyId])),
                'imported_at'        => date('Y-m-d H:i:s'),
            ]);
            $db->insert('research_project_surveys', [
                'project_id'   => $id,
                'survey_id'    => $surveyId,
                'import_config' => $config,
            ]);
            Session::setFlash('success', 'Survey data imported to research project!');
        }

        Response::redirect("/research/{$id}");
    }

    public function removeSource(string $projectId, string $sourceId): void
    {
        Auth::requireRole('researcher');
        $db = Database::getInstance();

        $project = $db->fetchOne("SELECT * FROM research_projects WHERE id = ? AND researcher_id = ?", [$projectId, Auth::id()]);
        if (!$project) {
            Response::notFound();
        }

        $db->delete('research_project_surveys', 'id = ? AND project_id = ?', [$sourceId, $projectId]);
        Session::setFlash('success', 'Survey removed from project.');
        Response::redirect("/research/{$projectId}");
    }

    public function apiResponses(string $id): void
    {
        Auth::requireRole('researcher');
        $db = Database::getInstance();

        $project = $db->fetchOne("SELECT * FROM research_projects WHERE id = ? AND researcher_id = ?", [$id, Auth::id()]);
        if (!$project) {
            Response::json(['error' => 'Not found'], 404);
        }

        $sources = $db->fetchAll("SELECT survey_id FROM research_project_surveys WHERE project_id = ?", [$id]);
        if (empty($sources)) {
            Response::json(['responses' => [], 'questions' => []]);
        }

        $surveyIds = array_column($sources, 'survey_id');
        $placeholders = implode(',', array_fill(0, count($surveyIds), '?'));

        $questions = $db->fetchAll("SELECT * FROM questions WHERE survey_id IN ($placeholders) ORDER BY survey_id, order_index ASC", $surveyIds);
        $responses = $db->fetchAll("SELECT r.*, qs.overall_score FROM responses r LEFT JOIN quality_scores qs ON qs.response_id = r.id WHERE r.survey_id IN ($placeholders) AND r.status IN ('completed','accepted','flagged') ORDER BY r.created_at DESC LIMIT 2000", $surveyIds);

        $answers = [];
        if (!empty($responses)) {
            $respIds = array_column($responses, 'id');
            $rPlaceholders = implode(',', array_fill(0, count($respIds), '?'));
            $answers = $db->fetchAll("SELECT a.*, q.type as q_type, q.question_text as q_text FROM answers a JOIN questions q ON a.question_id = q.id WHERE a.response_id IN ($rPlaceholders) ORDER BY a.response_id, a.question_id", $respIds);
        }

        // Build response_answers map
        $answersByResponse = [];
        foreach ($answers as $a) {
            $answersByResponse[$a['response_id']][] = $a;
        }

        Response::json([
            'questions' => $questions,
            'responses' => $responses,
            'answers'   => $answers,
            'answersByResponse' => $answersByResponse,
        ]);
    }

    public function apiAnswers(string $id): void
    {
        Auth::requireRole('researcher');
        $db = Database::getInstance();

        $project = $db->fetchOne("SELECT * FROM research_projects WHERE id = ? AND researcher_id = ?", [$id, Auth::id()]);
        if (!$project) {
            Response::json(['error' => 'Not found'], 404);
        }

        $surveyId = (int)($_GET['survey_id'] ?? 0);
        $questionId = (int)($_GET['question_id'] ?? 0);

        $answers = $db->fetchAll(
            "SELECT a.* FROM answers a
             JOIN responses r ON a.response_id = r.id
             JOIN research_project_surveys rps ON rps.survey_id = r.survey_id
             WHERE rps.project_id = ? AND r.survey_id = ? AND a.question_id = ?
             AND r.status IN ('completed','accepted')
             ORDER BY r.created_at ASC",
            [$id, $surveyId, $questionId]
        );

        Response::json(['answers' => $answers]);
    }

    // --- Visualizations ---

    public function saveViz(string $id): void
    {
        Auth::requireRole('researcher');
        $db = Database::getInstance();

        $project = $db->fetchOne("SELECT * FROM research_projects WHERE id = ? AND researcher_id = ?", [$id, Auth::id()]);
        if (!$project) {
            Response::notFound();
        }

        $name = trim($_POST['name'] ?? '');
        $chartType = trim($_POST['chart_type'] ?? '');
        $chartConfig = $_POST['chart_config'] ?? '{}';

        if (empty($name) || empty($chartType)) {
            Session::setFlash('danger', 'Name and chart type are required.');
            Response::redirect("/research/{$id}#viz");
        }

        $db->insert('research_visualizations', [
            'project_id'  => $id,
            'name'        => $name,
            'chart_type'  => $chartType,
            'chart_config' => is_string($chartConfig) ? $chartConfig : json_encode($chartConfig),
        ]);

        Session::setFlash('success', 'Visualization saved!');
        Response::redirect("/research/{$id}#viz");
    }

    public function deleteViz(string $projectId, string $vizId): void
    {
        Auth::requireRole('researcher');
        $db = Database::getInstance();

        $project = $db->fetchOne("SELECT * FROM research_projects WHERE id = ? AND researcher_id = ?", [$projectId, Auth::id()]);
        if (!$project) {
            Response::notFound();
        }

        $db->delete('research_visualizations', 'id = ? AND project_id = ?', [$vizId, $projectId]);
        Session::setFlash('success', 'Visualization deleted.');
        Response::redirect("/research/{$projectId}#viz");
    }
}
