<?php

namespace Controllers;

use Core\Auth;
use Core\Response;
use Core\Session;
use Core\Database;

class QualityController
{
    public function dashboard(string $surveyId): void
    {
        Auth::requireRole('researcher');

        $db = Database::getInstance();
        $survey = $db->fetchOne("SELECT * FROM surveys WHERE id = ? AND researcher_id = ?", [$surveyId, Auth::id()]);

        if (!$survey) {
            Response::notFound();
        }

        $page = max(1, (int)($_GET['page'] ?? 1));
        $perPage = 30;
        $offset = ($page - 1) * $perPage;
        $statusFilter = $_GET['status'] ?? '';
        $minScore = $_GET['min_score'] ?? '';

        $where = 'r.survey_id = ?';
        $params = [$surveyId];

        if (!empty($statusFilter) && in_array($statusFilter, ['accepted', 'rejected', 'flagged', 'completed', 'pending'])) {
            if ($statusFilter === 'pending') {
                $where .= ' AND (qs.researcher_verdict IS NULL OR qs.researcher_verdict = ?)';
                $params[] = 'pending';
            } else {
                $where .= ' AND r.status = ?';
                $params[] = $statusFilter;
            }
        }

        if ($minScore !== '' && is_numeric($minScore)) {
            $where .= ' AND (qs.overall_score IS NULL OR qs.overall_score < ?)';
            $params[] = (float)$minScore;
        }

        $total = $db->fetchOne(
            "SELECT COUNT(*) as c FROM responses r LEFT JOIN quality_scores qs ON qs.response_id = r.id WHERE {$where}",
            $params
        )['c'];

        $responses = $db->fetchAll(
            "SELECT r.*, qs.overall_score, qs.researcher_verdict
             FROM responses r
             LEFT JOIN quality_scores qs ON qs.response_id = r.id
             WHERE {$where}
             ORDER BY COALESCE(qs.overall_score, 0) ASC LIMIT ? OFFSET ?",
            array_merge($params, [$perPage, $offset])
        );

        $qualityLogs = $db->fetchAll(
            "SELECT ql.* FROM quality_logs ql
             JOIN responses r ON ql.response_id = r.id
             WHERE r.survey_id = ?
             ORDER BY ql.created_at DESC LIMIT 200",
            [$surveyId]
        );

        $totalResponses = $db->fetchOne("SELECT COUNT(*) as c FROM responses WHERE survey_id = ?", [$surveyId])['c'];
        $avgQuality = $db->fetchOne(
            "SELECT ROUND(AVG(qs.overall_score), 1) as avg FROM quality_scores qs
             JOIN responses r ON r.id = qs.response_id WHERE r.survey_id = ?",
            [$surveyId]
        )['avg'] ?? 0;

        $checkBreakdown = [];
        foreach ($qualityLogs as $log) {
            $type = $log['check_type'];
            if (!isset($checkBreakdown[$type])) {
                $checkBreakdown[$type] = ['passed' => 0, 'failed' => 0, 'total' => 0];
            }
            $checkBreakdown[$type]['total']++;
            if ($log['passed']) {
                $checkBreakdown[$type]['passed']++;
            } else {
                $checkBreakdown[$type]['failed']++;
            }
        }

        $totalPages = ceil($total / $perPage);

        Response::layout('main', 'researcher/quality/dashboard', [
            'pageTitle'      => "Quality: {$survey['title']}",
            'survey'         => $survey,
            'responses'      => $responses,
            'qualityLogs'    => $qualityLogs,
            'stats'          => [
                'total'      => $totalResponses,
                'avgQuality' => $avgQuality,
                'passed'     => $db->fetchOne(
                    "SELECT COUNT(*) as c FROM responses r JOIN quality_scores qs ON qs.response_id = r.id WHERE r.survey_id = ? AND qs.overall_score >= ?",
                    [$surveyId, $survey['quality_threshold']]
                )['c'],
                'flagged'    => $db->fetchOne(
                    "SELECT COUNT(*) as c FROM responses r JOIN quality_scores qs ON qs.response_id = r.id WHERE r.survey_id = ? AND qs.overall_score < ?",
                    [$surveyId, $survey['quality_threshold']]
                )['c'],
            ],
            'checkBreakdown' => $checkBreakdown,
            'page'           => $page,
            'totalPages'     => $totalPages,
            'total'          => $total,
            'statusFilter'   => $statusFilter,
            'minScore'       => $minScore,
        ]);
    }

    public function viewResponse(string $surveyId, string $responseId): void
    {
        Auth::requireRole('researcher');

        $db = Database::getInstance();
        $survey = $db->fetchOne("SELECT * FROM surveys WHERE id = ? AND researcher_id = ?", [$surveyId, Auth::id()]);

        if (!$survey) {
            Response::notFound();
        }

        $response = $db->fetchOne("SELECT * FROM responses WHERE id = ? AND survey_id = ?", [$responseId, $surveyId]);
        if (!$response) {
            Response::notFound();
        }

        $answers = $db->fetchAll(
            "SELECT a.*, q.question_text, q.type, q.options_json
             FROM answers a JOIN questions q ON a.question_id = q.id
             WHERE a.response_id = ? ORDER BY q.order_index ASC",
            [$responseId]
        );

        // Parse chat data for chat surveys (handles both flat and wrapped formats)
        $chatAnswers = [];
        $chatNodes = [];
        if (($survey['type'] ?? 'form') === 'chat') {
            $chatConfig = json_decode($survey['chat_config'] ?? '{}', true) ?? [];
            $chatNodes = $chatConfig['nodes'] ?? [];
            if (!empty($response['chat_data'])) {
                $cd = json_decode($response['chat_data'], true);
                if (is_array($cd)) {
                    if (isset($cd['responses'])) {
                        $chatAnswers = $cd['responses'];
                    } else {
                        $chatAnswers = $cd;
                    }
                }
            }
        }

        $qualityScore = $db->fetchOne("SELECT * FROM quality_scores WHERE response_id = ?", [$responseId]);
        $qualityLogs = $db->fetchAll("SELECT * FROM quality_logs WHERE response_id = ?", [$responseId]);

        Response::layout('main', 'researcher/quality/response-detail', [
            'pageTitle'    => 'Response Detail',
            'survey'       => $survey,
            'response'     => $response,
            'answers'      => $answers,
            'chatAnswers'  => $chatAnswers,
            'chatNodes'    => $chatNodes,
            'qualityScore' => $qualityScore,
            'qualityLogs'  => $qualityLogs,
        ]);
    }

    public function verdict(string $surveyId, string $responseId): void
    {
        Auth::requireRole('researcher');

        $db = Database::getInstance();
        $survey = $db->fetchOne("SELECT * FROM surveys WHERE id = ? AND researcher_id = ?", [$surveyId, Auth::id()]);

        if (!$survey) {
            Response::notFound();
        }

        $response = $db->fetchOne("SELECT id, respondent_id FROM responses WHERE id = ? AND survey_id = ?", [$responseId, $surveyId]);
        if (!$response) {
            Response::notFound();
        }

        $verdict = $_POST['verdict'] ?? 'pending';
        $notes = trim($_POST['notes'] ?? '');

        $existing = $db->fetchOne("SELECT id FROM quality_scores WHERE response_id = ?", [$responseId]);

        if ($existing) {
            $db->update('quality_scores', [
                'researcher_verdict' => $verdict,
                'notes'              => $notes ?: null,
            ], 'id = ?', [$existing['id']]);
        } else {
            $db->insert('quality_scores', [
                'response_id'        => $responseId,
                'overall_score'      => null,
                'researcher_verdict' => $verdict,
                'notes'              => $notes ?: null,
            ]);
        }

        $responseStatus = $verdict === 'accepted' ? 'accepted' : ($verdict === 'rejected' ? 'rejected' : 'flagged');
        $db->update('responses', ['status' => $responseStatus], 'id = ?', [$responseId]);

        if ($verdict === 'rejected') {
            if ($response['respondent_id']) {
                $userId = $response['respondent_id'];
                $oldRep = (float)$db->fetchOne("SELECT reputation_score FROM users WHERE id = ?", [$userId])['reputation_score'];
                $newRep = max(0, $oldRep - 5);
                $db->update('users', ['reputation_score' => $newRep], 'id = ?', [$userId]);
                $db->insert('reputation_history', [
                    'user_id'       => $userId,
                    'response_id'   => (int)$responseId,
                    'survey_id'     => (int)$surveyId,
                    'old_score'     => $oldRep,
                    'new_score'     => $newRep,
                    'change_reason' => 'Researcher rejected response',
                ]);
            }
        }

        Session::setFlash('success', "Response {$verdict}");
        Response::redirect("/quality/{$surveyId}");
    }

    public function bulkVerdict(string $surveyId): void
    {
        Auth::requireRole('researcher');

        $db = Database::getInstance();
        $survey = $db->fetchOne("SELECT * FROM surveys WHERE id = ? AND researcher_id = ?", [$surveyId, Auth::id()]);

        if (!$survey) {
            Response::notFound();
        }

        $verdict = $_POST['bulk_verdict'] ?? '';
        $responseIds = $_POST['response_ids'] ?? [];

        if (empty($responseIds) || !in_array($verdict, ['accepted', 'rejected'])) {
            Session::setFlash('danger', 'Select responses and a verdict');
            Response::redirect("/quality/{$surveyId}");
        }

        // Verify ownership in bulk
        $placeholders = implode(',', array_fill(0, count($responseIds), '?'));
        $ownedIds = $db->fetchAll(
            "SELECT id FROM responses WHERE id IN ({$placeholders}) AND survey_id = ?",
            array_merge($responseIds, [$surveyId])
        );
        $ownedIds = array_column($ownedIds, 'id');

        if (empty($ownedIds)) {
            Session::setFlash('danger', 'No valid responses selected');
            Response::redirect("/quality/{$surveyId}");
        }

        $responseStatus = $verdict === 'accepted' ? 'accepted' : 'rejected';

        // Bulk upsert quality_scores (response_id has UNIQUE constraint)
        foreach ($ownedIds as $rid) {
            $db->query(
                "INSERT INTO quality_scores (response_id, overall_score, researcher_verdict) 
                 VALUES (?, NULL, ?) 
                 ON DUPLICATE KEY UPDATE researcher_verdict = VALUES(researcher_verdict)",
                [$rid, $verdict]
            );
        }

        // Bulk update response status
        $ownedPlaceholders = implode(',', array_fill(0, count($ownedIds), '?'));
        $db->query(
            "UPDATE responses SET status = ? WHERE id IN ({$ownedPlaceholders})",
            array_merge([$responseStatus], $ownedIds)
        );

        Session::setFlash('success', count($responseIds) . ' responses ' . $verdict);
        Response::redirect("/quality/{$surveyId}");
    }
}
