<?php

namespace Controllers;

use Core\Auth;
use Core\Response;
use Core\Session;
use Core\Database;

class AdminController
{
    public function dashboard(): void
    {
        Auth::requireAdmin();

        $db = Database::getInstance();
        $stats = [
            'total_users'     => $db->fetchOne("SELECT COUNT(*) as c FROM users")['c'],
            'researchers'     => $db->fetchOne("SELECT COUNT(*) as c FROM users WHERE role = 'researcher'")['c'],
            'respondents'     => $db->fetchOne("SELECT COUNT(*) as c FROM users WHERE role = 'respondent'")['c'],
            'total_surveys'   => $db->fetchOne("SELECT COUNT(*) as c FROM surveys")['c'],
            'active_surveys'  => $db->fetchOne("SELECT COUNT(*) as c FROM surveys WHERE status = 'active'")['c'],
            'total_responses' => $db->fetchOne("SELECT COUNT(*) as c FROM responses")['c'],
        ];

        $recentUsers = $db->fetchAll("SELECT * FROM users ORDER BY created_at DESC LIMIT 10");
        $recentSurveys = $db->fetchAll(
            "SELECT s.*, u.full_name as researcher_name
             FROM surveys s JOIN users u ON s.researcher_id = u.id
             ORDER BY s.created_at DESC LIMIT 10"
        );

        Response::layout('main', 'admin/dashboard', [
            'pageTitle'    => 'Admin Dashboard',
            'stats'        => $stats,
            'recentUsers'  => $recentUsers,
            'recentSurveys' => $recentSurveys,
        ]);
    }

    public function users(): void
    {
        Auth::requireAdmin();

        $db = Database::getInstance();
        $page = max(1, (int)($_GET['page'] ?? 1));
        $perPage = 30;
        $offset = ($page - 1) * $perPage;
        $roleFilter = $_GET['role'] ?? '';
        $approvalFilter = $_GET['approval'] ?? '';

        $where = '1=1';
        $params = [];
        if (!empty($roleFilter) && in_array($roleFilter, ['admin', 'researcher', 'respondent'])) {
            $where .= ' AND u.role = ?';
            $params[] = $roleFilter;
        }
        if (!empty($approvalFilter) && in_array($approvalFilter, ['pending', 'approved', 'rejected'])) {
            $where .= ' AND u.approval_status = ?';
            $params[] = $approvalFilter;
        }

        $total = $db->fetchOne("SELECT COUNT(*) as c FROM users u WHERE {$where}", $params)['c'];

        $users = $db->fetchAll(
            "SELECT u.*,
             (SELECT COUNT(*) FROM surveys s WHERE s.researcher_id = u.id) as survey_count,
             (SELECT COUNT(*) FROM responses r WHERE r.respondent_id = u.id) as response_count
             FROM users u WHERE {$where} ORDER BY u.created_at DESC LIMIT ? OFFSET ?",
            array_merge($params, [$perPage, $offset])
        );

        $stats = [
            'total'       => $db->fetchOne("SELECT COUNT(*) as c FROM users")['c'],
            'researchers' => $db->fetchOne("SELECT COUNT(*) as c FROM users WHERE role = 'researcher'")['c'],
            'respondents' => $db->fetchOne("SELECT COUNT(*) as c FROM users WHERE role = 'respondent'")['c'],
            'admins'      => $db->fetchOne("SELECT COUNT(*) as c FROM users WHERE role = 'admin'")['c'],
            'pending'     => $db->fetchOne("SELECT COUNT(*) as c FROM users WHERE approval_status = 'pending'")['c'],
        ];

        $totalPages = ceil($total / $perPage);

        Response::layout('main', 'admin/users', [
            'pageTitle'      => 'Manage Users',
            'users'          => $users,
            'stats'          => $stats,
            'page'           => $page,
            'totalPages'     => $totalPages,
            'total'          => $total,
            'roleFilter'     => $roleFilter,
            'approvalFilter' => $approvalFilter,
        ]);
    }

    public function toggleUser(string $id): void
    {
        Auth::requireAdmin();

        $db = Database::getInstance();
        $user = $db->fetchOne("SELECT * FROM users WHERE id = ?", [$id]);

        if ($user && $user['role'] !== 'admin') {
            $db->update('users', ['is_active' => $user['is_active'] ? 0 : 1], 'id = ?', [$id]);
            $db->insert('admin_logs', [
                'admin_id'     => Auth::id(),
                'action'       => ($user['is_active'] ? 'deactivated' : 'activated') . '_user',
                'details_json' => json_encode(['user_id' => (int)$id, 'email' => $user['email']]),
                'ip_address'   => $_SERVER['REMOTE_ADDR'] ?? null,
            ]);
            Session::setFlash('success', 'User status toggled');
        }

        Response::redirect('/admin/users');
    }

    public function approveUser(string $id): void
    {
        Auth::requireAdmin();

        $db = Database::getInstance();
        $user = $db->fetchOne("SELECT * FROM users WHERE id = ?", [$id]);

        if ($user && $user['role'] !== 'admin') {
            $db->update('users', ['approval_status' => 'approved', 'is_active' => 1], 'id = ?', [$id]);
            $db->insert('admin_logs', [
                'admin_id'     => Auth::id(),
                'action'       => 'approved_user',
                'details_json' => json_encode(['user_id' => (int)$id, 'email' => $user['email']]),
                'ip_address'   => $_SERVER['REMOTE_ADDR'] ?? null,
            ]);
            Session::setFlash('success', 'User approved');
        }

        Response::redirect('/admin/users');
    }

    public function rejectUser(string $id): void
    {
        Auth::requireAdmin();

        $db = Database::getInstance();
        $user = $db->fetchOne("SELECT * FROM users WHERE id = ?", [$id]);

        if ($user && $user['role'] !== 'admin') {
            $db->update('users', ['approval_status' => 'rejected', 'is_active' => 0], 'id = ?', [$id]);
            $db->insert('admin_logs', [
                'admin_id'     => Auth::id(),
                'action'       => 'rejected_user',
                'details_json' => json_encode(['user_id' => (int)$id, 'email' => $user['email']]),
                'ip_address'   => $_SERVER['REMOTE_ADDR'] ?? null,
            ]);
            Session::setFlash('success', 'User rejected');
        }

        Response::redirect('/admin/users');
    }

    public function deleteUser(string $id): void
    {
        Auth::requireAdmin();

        $db = Database::getInstance();
        $user = $db->fetchOne("SELECT * FROM users WHERE id = ?", [$id]);

        if ($user && $user['role'] !== 'admin') {
            $email = $user['email'];
            $db->delete('users', 'id = ?', [$id]);
            $db->insert('admin_logs', [
                'admin_id'     => Auth::id(),
                'action'       => 'deleted_user',
                'details_json' => json_encode(['user_id' => (int)$id, 'email' => $email]),
                'ip_address'   => $_SERVER['REMOTE_ADDR'] ?? null,
            ]);
            Session::setFlash('success', 'User deleted permanently');
        }

        Response::redirect('/admin/users');
    }

    public function createUserForm(): void
    {
        Auth::requireAdmin();

        Response::layout('main', 'admin/create-user', [
            'pageTitle' => 'Create User Account',
        ]);
    }

    public function createUser(): void
    {
        Auth::requireAdmin();

        $name = trim($_POST['full_name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $role = $_POST['role'] ?? 'respondent';
        $approvalStatus = $_POST['approval_status'] ?? 'approved';

        if (empty($name) || empty($email) || empty($password)) {
            Session::setFlash('danger', 'All fields are required');
            Response::redirect('/admin/users/create');
        }

        if (strlen($password) < 6) {
            Session::setFlash('danger', 'Password must be at least 6 characters');
            Response::redirect('/admin/users/create');
        }

        if (!in_array($role, ['researcher', 'respondent'])) {
            $role = 'respondent';
        }
        if (!in_array($approvalStatus, ['pending', 'approved', 'rejected'])) {
            $approvalStatus = 'approved';
        }

        $db = Database::getInstance();
        if ($db->exists('users', 'email = ?', [$email])) {
            Session::setFlash('danger', 'Email already registered');
            Response::redirect('/admin/users/create');
        }

        $config = require __DIR__ . '/../../config/app.php';
        $initialRep = $config['reputation']['initial'] ?? 50;

        $db->insert('users', [
            'email'             => $email,
            'password_hash'     => password_hash($password, PASSWORD_BCRYPT),
            'full_name'         => $name,
            'role'              => $role,
            'reputation_score'  => $role === 'researcher' ? 0 : $initialRep,
            'is_active'         => $approvalStatus === 'approved' ? 1 : 0,
            'approval_status'   => $approvalStatus,
        ]);

        $db->insert('admin_logs', [
            'admin_id'     => Auth::id(),
            'action'       => 'created_user',
            'details_json' => json_encode(['email' => $email, 'role' => $role]),
            'ip_address'   => $_SERVER['REMOTE_ADDR'] ?? null,
        ]);

        Session::setFlash('success', "User {$email} created as {$role}");
        Response::redirect('/admin/users');
    }

    public function surveys(): void
    {
        Auth::requireAdmin();

        $db = Database::getInstance();
        $surveys = $db->fetchAll(
            "SELECT s.*, u.full_name as researcher_name,
             (SELECT COUNT(*) FROM responses r WHERE r.survey_id = s.id) as response_count
             FROM surveys s JOIN users u ON s.researcher_id = u.id
             ORDER BY s.created_at DESC"
        );

        Response::layout('main', 'admin/surveys', [
            'pageTitle' => 'All Surveys',
            'surveys'   => $surveys,
        ]);
    }

    public function templates(): void
    {
        Auth::requireAdmin();

        $templates = \Helpers\SurveyTemplates::all();

        Response::layout('main', 'admin/templates', [
            'pageTitle' => 'Survey Templates',
            'templates' => $templates,
        ]);
    }

    public function settings(): void
    {
        Auth::requireAdmin();

        Response::layout('main', 'admin/settings', [
            'pageTitle' => 'System Settings',
        ]);
    }

    public function logs(): void
    {
        Auth::requireAdmin();

        $db = Database::getInstance();
        $page = max(1, (int)($_GET['page'] ?? 1));
        $perPage = 50;
        $offset = ($page - 1) * $perPage;

        $total = $db->fetchOne("SELECT COUNT(*) as c FROM admin_logs")['c'];
        $logs = $db->fetchAll(
            "SELECT al.*, u.full_name as admin_name, u.email as admin_email
             FROM admin_logs al
             LEFT JOIN users u ON al.admin_id = u.id
             ORDER BY al.created_at DESC LIMIT ? OFFSET ?",
            [$perPage, $offset]
        );

        $totalPages = ceil($total / $perPage);

        Response::layout('main', 'admin/logs', [
            'pageTitle'  => 'Admin Logs',
            'logs'       => $logs,
            'page'       => $page,
            'totalPages' => $totalPages,
            'total'      => $total,
        ]);
    }

    public function debugPasswords(): void
    {
        Auth::requireAdmin();

        $db = Database::getInstance();
        $users = $db->fetchAll("SELECT id, email, full_name, role, is_active FROM users ORDER BY email");

        $resetResult = Session::get('_password_reset_result');
        Session::remove('_password_reset_result');

        Response::layout('main', 'admin/debug-passwords', [
            'pageTitle'   => 'Debug: Passwords',
            'users'       => $users,
            'resetResult' => $resetResult,
        ]);
    }

    public function debugPasswordReset(): void
    {
        Auth::requireAdmin();

        $userId = (int)($_POST['user_id'] ?? 0);
        $password = $_POST['password'] ?? '';
        $confirm = $_POST['password_confirm'] ?? '';

        if (!$userId || strlen($password) < 6) {
            Session::setFlash('danger', 'Password must be at least 6 characters');
            Response::redirect('/admin/debug/passwords');
        }

        if ($password !== $confirm) {
            Session::setFlash('danger', 'Passwords do not match');
            Response::redirect('/admin/debug/passwords');
        }

        $db = Database::getInstance();
        $user = $db->fetchOne("SELECT id, email, full_name, role FROM users WHERE id = ?", [$userId]);

        if (!$user) {
            Session::setFlash('danger', 'User not found');
            Response::redirect('/admin/debug/passwords');
        }

        $db->update('users', ['password_hash' => password_hash($password, PASSWORD_BCRYPT)], 'id = ?', [$userId]);

        $db->insert('admin_logs', [
            'admin_id'     => Auth::id(),
            'action'       => 'debug_password_reset',
            'details_json' => json_encode(['target_user_id' => $userId, 'target_email' => $user['email']]),
            'ip_address'   => $_SERVER['REMOTE_ADDR'] ?? null,
        ]);

        Session::setFlash('success', "Password reset for {$user['full_name']} ({$user['email']})");
        Response::redirect('/admin/debug/passwords');
    }

    public function saveSettings(): void
    {
        Auth::requireAdmin();

        $appName = trim($_POST['app_name'] ?? '');
        if (empty($appName)) {
            Session::setFlash('danger', 'App name is required');
            Response::redirect('/admin/settings');
        }

        $configPath = __DIR__ . '/../../config/app.php';
        $config = require $configPath;
        $config['app_name'] = $appName;

        $written = file_put_contents(
            $configPath,
            '<?php return ' . var_export($config, true) . ';' . PHP_EOL,
            LOCK_EX
        );

        if ($written === false) {
            Session::setFlash('danger', 'Failed to write config file. Check file permissions.');
        } else {
            $db = Database::getInstance();
            $db->insert('admin_logs', [
                'admin_id'     => Auth::id(),
                'action'       => 'updated_settings',
                'details_json' => json_encode(['app_name' => $appName]),
                'ip_address'   => $_SERVER['REMOTE_ADDR'] ?? null,
            ]);
            Session::setFlash('success', 'Settings saved');
        }

        Response::redirect('/admin/settings');
    }
}
