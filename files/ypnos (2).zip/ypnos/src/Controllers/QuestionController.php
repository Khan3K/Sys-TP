<?php

namespace Controllers;

use Core\Auth;
use Core\Response;
use Core\Session;
use Core\Database;

class QuestionController
{
    public function addForm(string $id): void
    {
        Auth::requireRole('researcher');

        $db = Database::getInstance();
        $survey = $db->fetchOne("SELECT * FROM surveys WHERE id = ? AND researcher_id = ?", [$id, Auth::id()]);

        if (!$survey) {
            Response::notFound();
        }

        Response::layout('main', 'researcher/survey/question-add', [
            'pageTitle' => 'Add Question',
            'surveyId'  => $id,
        ]);
    }

    public function add(string $id): void
    {
        Auth::requireRole('researcher');

        $db = Database::getInstance();
        $survey = $db->fetchOne("SELECT * FROM surveys WHERE id = ? AND researcher_id = ?", [$id, Auth::id()]);

        if (!$survey) {
            Response::notFound();
        }

        $type = $_POST['type'] ?? 'text';
        $questionText = trim($_POST['question_text'] ?? '');
        $isRequired = isset($_POST['is_required']) ? 1 : 0;
        $isAttention = isset($_POST['is_attention_check']) ? 1 : 0;
        $expectedAnswer = trim($_POST['expected_answer'] ?? '');
        $isTrap = isset($_POST['is_trap']) ? 1 : 0;
        $isTimed = isset($_POST['is_timed']) ? 1 : 0;
        $timeLimit = $isTimed ? max(1, (int)($_POST['time_limit_seconds'] ?? 30)) : null;
        $minValue = $_POST['min_value'] !== '' ? (float)$_POST['min_value'] : null;
        $maxValue = $_POST['max_value'] !== '' ? (float)$_POST['max_value'] : null;
        $charLimit = $_POST['char_limit'] !== '' ? (int)$_POST['char_limit'] : null;
        $minLength = $_POST['min_length'] !== '' ? (int)$_POST['min_length'] : null;
        $maxLength = $_POST['max_length'] !== '' ? (int)$_POST['max_length'] : null;
        $allowPaste = isset($_POST['allow_paste']) ? 1 : 0;
        $isSpeedBump = isset($_POST['is_speed_bump']) ? 1 : 0;

        if (empty($questionText)) {
            Session::setFlash('danger', 'Question text is required');
            Response::redirect("/survey/{$id}/questions/add");
        }

        $validTypes = ['text','number','email','phone','date','likert5','likert7','mcq_single','mcq_multiple','dropdown','rating','slider','yes_no','matrix','file_upload'];
        if (!in_array($type, $validTypes)) {
            $type = 'text';
        }

        $options = [];
        $rows = [];
        if (in_array($type, ['likert5', 'likert7', 'mcq_single', 'mcq_multiple', 'dropdown', 'rating'])) {
            $raw = $_POST['options'] ?? '';
            $options = array_values(array_filter(explode("\n", str_replace("\r", "", $raw)), fn($o) => trim($o) !== ''));
        }

        if ($type === 'matrix') {
            $rawRows = $_POST['rows'] ?? '';
            $rows = array_values(array_filter(explode("\n", str_replace("\r", "", $rawRows)), fn($r) => trim($r) !== ''));
            $rawCols = $_POST['options'] ?? '';
            $options = array_values(array_filter(explode("\n", str_replace("\r", "", $rawCols)), fn($c) => trim($c) !== ''));
        }

        $maxOrder = $db->fetchOne(
            "SELECT MAX(order_index) as max_order FROM questions WHERE survey_id = ?",
            [$id]
        );
        $nextOrder = ($maxOrder['max_order'] ?? 0) + 1;

        $db->insert('questions', [
            'survey_id'          => $id,
            'type'               => $type,
            'question_text'      => $questionText,
            'options_json'       => !empty($options) ? json_encode($options) : null,
            'order_index'        => $nextOrder,
            'is_required'        => $isRequired,
            'is_attention_check' => $isAttention,
            'expected_answer'    => $expectedAnswer ?: null,
            'is_trap'            => $isTrap,
            'is_speed_bump'      => $isSpeedBump,
            'is_timed'           => $isTimed,
            'time_limit_seconds' => $timeLimit,
            'min_value'          => $minValue,
            'max_value'          => $maxValue,
            'char_limit'         => $charLimit,
            'min_length'         => $minLength,
            'max_length'         => $maxLength,
            'allow_paste'        => $allowPaste,
            'rows_json'          => !empty($rows) ? json_encode($rows) : null,
        ]);

        Session::setFlash('success', 'Question added');
        Response::redirect("/survey/edit/{$id}");
    }

    public function delete(string $id): void
    {
        Auth::requireRole('researcher');

        $db = Database::getInstance();
        $question = $db->fetchOne(
            "SELECT q.* FROM questions q
             JOIN surveys s ON q.survey_id = s.id
             WHERE q.id = ? AND s.researcher_id = ?",
            [$id, Auth::id()]
        );

        if ($question) {
            $surveyId = $question['survey_id'];
            $db->delete('questions', 'id = ?', [$id]);
            Session::setFlash('success', 'Question deleted');
            Response::redirect("/survey/edit/{$surveyId}");
        }

        Response::notFound();
    }

    public function reorder(): void
    {
        Auth::requireRole('researcher');

        $order = $_POST['order'] ?? [];
        if (empty($order)) {
            Response::json(['success' => true]);
            return;
        }

        $db = Database::getInstance();
        $userId = Auth::id();

        $placeholders = implode(',', array_fill(0, count($order), '?'));
        $questionIds = array_map('intval', $order);

        $rows = $db->fetchAll(
            "SELECT q.id FROM questions q
             JOIN surveys s ON q.survey_id = s.id
             WHERE q.id IN ($placeholders) AND s.researcher_id = ?",
            array_merge($questionIds, [$userId])
        );

        $ownedIds = array_column($rows, 'id');

        foreach ($order as $index => $questionId) {
            $qid = (int)$questionId;
            if (!in_array($qid, $ownedIds)) {
                Response::json(['success' => false, 'error' => 'Unauthorized'], 403);
                return;
            }
            $db->update('questions', ['order_index' => $index + 1], 'id = ?', [$qid]);
        }

        Response::json(['success' => true]);
    }
}
