<?php

namespace Controllers;

use Core\Auth;
use Core\Response;
use Core\Session;
use Core\Database;
use Core\Validator;

class AuthController
{
    public function index(): void
    {
        if (Auth::check()) {
            Response::redirect('/dashboard');
        }
        Response::redirect('/login');
    }

    public function loginForm(): void
    {
        if (Auth::check()) {
            Response::redirect('/dashboard');
        }
        Response::layout('main', 'auth/login');
    }

    public function login(): void
    {
        if (!Auth::checkRateLimit()) {
            Response::redirect('/login');
        }
        $email = $_POST['email'] ?? '';
        $password = $_POST['password'] ?? '';

        $v = new Validator($_POST);
        if (!$v->required('email')->email('email')->required('password', 'Password')->passes()) {
            Session::setFlash('danger', $v->firstError());
            Response::redirect('/login');
        }

        $result = Auth::attempt($email, $password);
        if ($result === true) {
            Session::setFlash('success', 'Welcome back!');
            Response::redirect('/dashboard');
        }

        $messages = [
            'no_account'     => 'No account found with this email address.',
            'inactive'       => 'This account has been deactivated. Contact support.',
            'pending'        => 'Your account is pending approval. An admin will review your registration shortly.',
            'rejected'       => 'Your account was not approved. Contact support for assistance.',
            'wrong_password' => 'Incorrect password. Please try again.',
        ];
        Session::setFlash('danger', $messages[$result] ?? 'Invalid email or password');
        Response::redirect('/login');
    }

    public function registerForm(): void
    {
        if (Auth::check()) {
            Response::redirect('/dashboard');
        }
        Response::layout('main', 'auth/register');
    }

    public function register(): void
    {
        if (!Auth::checkRateLimit()) {
            Response::redirect('/register');
        }
        $name = trim($_POST['full_name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $role = $_POST['role'] ?? 'respondent';

        $v = new Validator($_POST);
        if (!$v->required('full_name', 'Name')->required('email')->email('email')->required('password', 'Password')->min('password', 6)->passes()) {
            Session::setFlash('danger', $v->firstError());
            Response::redirect('/register');
        }

        if (!in_array($role, ['researcher', 'respondent'])) {
            $role = 'respondent';
        }

        $db = Database::getInstance();
        if ($db->exists('users', 'email = ?', [$email])) {
            Session::setFlash('danger', 'Email already registered');
            Response::redirect('/register');
        }

        Auth::register([
            'full_name' => $name,
            'email'     => $email,
            'password'  => $password,
            'role'      => $role,
        ]);

        Session::setFlash('success', 'Account created! Please login.');
        Response::redirect('/login');
    }

    public function googleRedirect(): void
    {
        $config = require __DIR__ . '/../../config/app.php';
        $clientId = $config['google_oauth']['client_id'] ?? '';

        if (empty($clientId)) {
            Session::setFlash('danger', 'Google OAuth is not configured. Please set GOOGLE_CLIENT_ID in .env');
            Response::redirect('/login');
            return;
        }

        $base = $config['base_url'] ?? '';
        $redirectUri = $base . '/auth/google/callback';

        $state = bin2hex(random_bytes(16));
        $params = http_build_query([
            'client_id'     => $clientId,
            'redirect_uri'  => $redirectUri,
            'response_type' => 'code',
            'scope'         => 'email profile',
            'state'         => $state,
        ]);

        Session::set('google_oauth_state', $state);
        Response::redirect('https://accounts.google.com/o/oauth2/v2/auth?' . $params);
    }

    public function googleCallback(): void
    {
        $config = require __DIR__ . '/../../config/app.php';
        $clientId = $config['google_oauth']['client_id'] ?? '';
        $clientSecret = $config['google_oauth']['client_secret'] ?? '';

        if (empty($clientId) || empty($clientSecret)) {
            Session::setFlash('danger', 'Google OAuth is not configured');
            Response::redirect('/login');
            return;
        }

        $code = $_GET['code'] ?? '';
        $state = $_GET['state'] ?? '';

        if (empty($code) || empty($state)) {
            Session::setFlash('danger', 'Invalid OAuth response');
            Response::redirect('/login');
            return;
        }

        $expectedState = Session::get('google_oauth_state');
        Session::remove('google_oauth_state');
        if (empty($expectedState) || !hash_equals($expectedState, $state)) {
            Session::setFlash('danger', 'Invalid OAuth state. Please try again.');
            Response::redirect('/login');
            return;
        }

        $base = $config['base_url'] ?? '';
        $redirectUri = $base . '/auth/google/callback';

        $ch = curl_init('https://oauth2.googleapis.com/token');
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => http_build_query([
                'code'          => $code,
                'client_id'     => $clientId,
                'client_secret' => $clientSecret,
                'redirect_uri'  => $redirectUri,
                'grant_type'    => 'authorization_code',
            ]),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 10,
        ]);
        $tokenResponse = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode !== 200) {
            Session::setFlash('danger', 'Failed to authenticate with Google');
            Response::redirect('/login');
            return;
        }

        $tokenData = json_decode($tokenResponse, true);
        $accessToken = $tokenData['access_token'] ?? '';

        if (empty($accessToken)) {
            Session::setFlash('danger', 'No access token received');
            Response::redirect('/login');
            return;
        }

        $ch = curl_init('https://www.googleapis.com/oauth2/v2/userinfo');
        curl_setopt_array($ch, [
            CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $accessToken],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 10,
        ]);
        $userResponse = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode !== 200) {
            Session::setFlash('danger', 'Failed to get user info from Google');
            Response::redirect('/login');
            return;
        }

        $googleUser = json_decode($userResponse, true);

        if (empty($googleUser['email'])) {
            Session::setFlash('danger', 'No email returned from Google');
            Response::redirect('/login');
            return;
        }

        Auth::loginWithGoogle($googleUser);

        $surveyId = Session::get('google_survey_redirect');
        Session::remove('google_survey_redirect');
        if ($surveyId) {
            Session::setFlash('success', 'Signed in with Google! You can now take the survey.');
            Response::redirect("/survey/take/{$surveyId}");
            return;
        }

        Session::setFlash('success', 'Signed in with Google! Welcome.');
        Response::redirect('/dashboard');
    }

    public function logout(): void
    {
        Auth::logout();
        Session::setFlash('info', 'You have been logged out');
        Response::redirect('/login');
    }

    public function forgotForm(): void
    {
        if (Auth::check()) {
            Response::redirect('/dashboard');
        }
        Response::layout('main', 'auth/forgot-password');
    }

    public function forgot(): void
    {
        if (!Auth::checkRateLimit()) {
            Response::redirect('/login');
        }
        $email = trim($_POST['email'] ?? '');

        $db = Database::getInstance();
        $user = $db->fetchOne("SELECT id FROM users WHERE email = ?", [$email]);

        if ($user) {
            $token = bin2hex(random_bytes(32));
            $expires = date('Y-m-d H:i:s', time() + 3600);
            $db->insert('password_resets', [
                'user_id'    => $user['id'],
                'token'      => $token,
                'expires_at' => $expires,
            ]);

            $resetUrl = url('/reset-password/' . $token);
            error_log("Password reset link for {$email}: {$resetUrl}");

            $appConfig = require __DIR__ . '/../../config/app.php';
            if (!empty($appConfig['debug'])) {
                Session::setFlash('info', "Dev mode — reset link: {$resetUrl}");
                Response::redirect('/login');
                return;
            }
        }

        Session::setFlash('info', 'If the email exists, a reset link has been sent.');
        Response::redirect('/login');
    }

    public function resetForm(string $token): void
    {
        if (Auth::check()) {
            Response::redirect('/dashboard');
        }

        $db = Database::getInstance();
        $reset = $db->fetchOne(
            "SELECT * FROM password_resets WHERE token = ? AND expires_at > NOW() AND used_at IS NULL",
            [$token]
        );

        if (!$reset) {
            Session::setFlash('danger', 'Invalid or expired reset link');
            Response::redirect('/login');
        }

        Response::layout('main', 'auth/reset-password', ['token' => $token]);
    }

    public function reset(string $token): void
    {
        $db = Database::getInstance();
        $reset = $db->fetchOne(
            "SELECT * FROM password_resets WHERE token = ? AND expires_at > NOW() AND used_at IS NULL",
            [$token]
        );

        if (!$reset) {
            Session::setFlash('danger', 'Invalid or expired reset link');
            Response::redirect('/login');
        }

        $password = $_POST['password'] ?? '';
        if (strlen($password) < 6) {
            Session::setFlash('danger', 'Password must be at least 6 characters');
            Response::redirect('/reset-password/' . $token);
        }

        $db->update('users', ['password_hash' => password_hash($password, PASSWORD_BCRYPT)], 'id = ?', [$reset['user_id']]);
        $db->update('password_resets', ['used_at' => date('Y-m-d H:i:s')], 'id = ?', [$reset['id']]);

        Session::setFlash('success', 'Password reset successfully. Please login.');
        Response::redirect('/login');
    }
}
