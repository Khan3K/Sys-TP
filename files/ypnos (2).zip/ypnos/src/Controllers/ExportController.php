<?php

namespace Controllers;

use Core\Auth;
use Core\Response;
use Core\Session;
use Core\Database;

class ExportController
{
    public function form(string $surveyId): void
    {
        Auth::requireRole('researcher');

        $db = Database::getInstance();
        $survey = $db->fetchOne("SELECT * FROM surveys WHERE id = ? AND researcher_id = ?", [$surveyId, Auth::id()]);

        if (!$survey) {
            Response::notFound();
        }

        $totalResponses = $db->fetchOne(
            "SELECT COUNT(*) as count FROM responses WHERE survey_id = ?",
            [$surveyId]
        )['count'];

        $qualityResponses = $db->fetchOne(
            "SELECT COUNT(*) as count FROM responses r
             LEFT JOIN quality_scores qs ON qs.response_id = r.id
             WHERE r.survey_id = ? AND (qs.overall_score >= ? OR qs.overall_score IS NULL)",
            [$surveyId, $survey['quality_threshold']]
        )['count'];

        Response::layout('main', 'researcher/export', [
            'pageTitle'        => "Export: {$survey['title']}",
            'survey'           => $survey,
            'totalResponses'   => $totalResponses,
            'qualityResponses' => $qualityResponses,
        ]);
    }

    public function export(string $surveyId): void
    {
        Auth::requireRole('researcher');

        $db = Database::getInstance();
        $survey = $db->fetchOne("SELECT * FROM surveys WHERE id = ? AND researcher_id = ?", [$surveyId, Auth::id()]);

        if (!$survey) {
            Response::notFound();
        }

        $format = $_POST['format'] ?? 'csv';
        if (!in_array($format, ['csv', 'json'], true)) {
            $format = 'csv';
        }
        $qualityFilter = $_POST['quality_filter'] ?? 'all';
        $includeHeaders = !empty($_POST['include_headers']);
        $includeTimestamps = !empty($_POST['include_timestamps']);

        $where = 'r.survey_id = ?';
        $params = [$surveyId];

        if ($qualityFilter === 'quality_only') {
            $where .= ' AND (qs.overall_score >= ? OR qs.overall_score IS NULL)';
            $params[] = $survey['quality_threshold'];
        } elseif ($qualityFilter === 'flagged') {
            $where .= ' AND qs.overall_score < ?';
            $params[] = $survey['quality_threshold'];
        } elseif ($qualityFilter === 'accepted') {
            $where .= " AND (qs.researcher_verdict = 'accepted' OR (qs.researcher_verdict IS NULL AND r.status = 'accepted'))";
        } elseif ($qualityFilter === 'rejected') {
            $where .= " AND (qs.researcher_verdict = 'rejected' OR r.status = 'rejected')";
        }

        $questions = $db->fetchAll(
            "SELECT * FROM questions WHERE survey_id = ? ORDER BY order_index ASC",
            [$surveyId]
        );

        $responses = $db->fetchAll(
            "SELECT r.*, qs.overall_score, qs.researcher_verdict
             FROM responses r
             LEFT JOIN quality_scores qs ON qs.response_id = r.id
             WHERE {$where}
             ORDER BY r.created_at DESC",
            $params
        );

        $exportDir = __DIR__ . '/../../storage/exports';
        if (!is_dir($exportDir)) {
            mkdir($exportDir, 0755, true);
        }

        $filename = 'survey_' . $surveyId . '_' . date('Ymd_His') . '.' . $format;
        $filePath = $exportDir . '/' . $filename;

        // Bulk-fetch all answers to avoid N+1
        $responseIds = array_column($responses, 'id');
        $answersByResponse = [];
        if (!empty($responseIds)) {
            $placeholders = implode(',', array_fill(0, count($responseIds), '?'));
            $answerRows = $db->fetchAll(
                "SELECT response_id, question_id, answer_value FROM answers WHERE response_id IN ({$placeholders})",
                $responseIds
            );
            foreach ($answerRows as $a) {
                $answersByResponse[$a['response_id']][$a['question_id']] = $a['answer_value'];
            }
        }

        $exportData = [];
        foreach ($responses as $response) {
            $row = [];
            if ($includeHeaders) {
                $row['Response ID'] = $response['id'];
            }
            if ($includeTimestamps) {
                $row['Completed At'] = $response['completed_at'];
                $row['Time (seconds)'] = $response['time_spent_seconds'];
            }
            $row['Quality Score'] = $response['overall_score'] ?? 'N/A';
            $row['Verdict'] = $response['researcher_verdict'] ?? 'pending';
            $row['Status'] = $response['status'];

            foreach ($questions as $q) {
                $val = $answersByResponse[$response['id']][$q['id']] ?? '';
                if ($q['type'] === 'mcq_multiple') {
                    $decoded = json_decode($val, true);
                    $row[$q['question_text']] = is_array($decoded) ? implode('; ', $decoded) : $val;
                } else {
                    $row[$q['question_text']] = $val;
                }
            }

            $exportData[] = $row;
        }

        switch ($format) {
            case 'json':
                file_put_contents($filePath, json_encode($exportData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                break;
            case 'csv':
            default:
                $handle = fopen($filePath, 'w');
                if (!empty($exportData)) {
                    fwrite($handle, "\xEF\xBB\xBF");
                    fputcsv($handle, array_keys($exportData[0]));
                    foreach ($exportData as $row) {
                        fputcsv($handle, $row);
                    }
                }
                fclose($handle);
                break;
        }

        $db->insert('export_history', [
            'user_id'         => Auth::id(),
            'survey_id'       => $surveyId,
            'format'          => $format,
            'filter_criteria' => json_encode(['quality_filter' => $qualityFilter]),
            'file_path'       => $filePath,
            'row_count'       => count($exportData),
        ]);

        Session::setFlash('success', 'Export ready for download');
        Response::redirect('/export/' . $surveyId);
    }

    public function download(string $id): void
    {
        Auth::requireAuth();

        $db = Database::getInstance();
        $export = $db->fetchOne(
            "SELECT e.* FROM export_history e WHERE e.id = ? AND e.user_id = ?",
            [$id, Auth::id()]
        );

        if (!$export || !file_exists($export['file_path'])) {
            Response::notFound();
        }

        $filename = 'resrch_export_' . $export['survey_id'] . '.' . $export['format'];
        Response::download($export['file_path'], $filename);
    }
}
