<?php

namespace Controllers;

use Core\Auth;
use Core\Response;
use Core\Database;
use Helpers\QuestionGenerator;
use Services\FreeAI;
use Services\QuestionNLP;

class ApiController
{
    public function surveys(): void
    {
        $token = $this->authenticateToken();
        if (!$token) {
            Response::json(["error" => "Unauthorized"], 401);
        }

        $db = Database::getInstance();
        $surveys = $db->fetchAll(
            "SELECT id, title, description, status, quality_threshold,
             current_responses, max_responses, created_at
             FROM surveys WHERE researcher_id = ?",
            [$token["user_id"]],
        );

        Response::json(["data" => $surveys]);
    }

    public function surveyResults(string $id): void
    {
        $token = $this->authenticateToken();
        if (!$token) {
            Response::json(["error" => "Unauthorized"], 401);
        }

        $db = Database::getInstance();
        $survey = $db->fetchOne(
            "SELECT * FROM surveys WHERE id = ? AND researcher_id = ?",
            [$id, $token["user_id"]],
        );

        if (!$survey) {
            Response::json(["error" => "Not found"], 404);
        }

        $questions = $db->fetchAll(
            "SELECT id, type, question_text, options_json, order_index FROM questions WHERE survey_id = ? ORDER BY order_index",
            [$id],
        );

        $responses = $db->fetchAll(
            "SELECT r.id as response_id, r.completed_at, r.time_spent_seconds, r.status, qs.overall_score
             FROM responses r
             LEFT JOIN quality_scores qs ON qs.response_id = r.id
             WHERE r.survey_id = ? AND r.status IN ('completed','accepted')
             ORDER BY r.created_at DESC",
            [$id],
        );

        // Bulk-fetch all answers to avoid N+1
        $responseIds = array_column($responses, "response_id");
        $answersByResponse = [];
        if (!empty($responseIds)) {
            $placeholders = implode(
                ",",
                array_fill(0, count($responseIds), "?"),
            );
            $answerRows = $db->fetchAll(
                "SELECT a.response_id, a.question_id, a.answer_value FROM answers a WHERE a.response_id IN ({$placeholders})",
                $responseIds,
            );
            foreach ($answerRows as $a) {
                $answersByResponse[$a["response_id"]][] = [
                    "question_id" => $a["question_id"],
                    "answer_value" => $a["answer_value"],
                ];
            }
        }

        foreach ($responses as &$resp) {
            $resp["answers"] = $answersByResponse[$resp["response_id"]] ?? [];
        }

        Response::json([
            "survey" => $survey,
            "questions" => $questions,
            "responses" => $responses,
        ]);
    }

    public function suggestQuestion(): void
    {
        if (!Auth::check() || !Auth::isResearcher()) {
            Response::json(
                ["success" => false, "error" => "Unauthorized"],
                401,
            );
            return;
        }
        if (!Auth::checkRateLimit()) {
            Response::json(
                [
                    "success" => false,
                    "error" => "Too many requests. Please slow down.",
                ],
                429,
            );
            return;
        }

        $input = json_decode(file_get_contents("php://input"), true);
        $prompt = trim($input["prompt"] ?? "");
        $history = $input["history"] ?? [];

        if (empty($prompt)) {
            Response::json(
                ["success" => false, "error" => "Prompt is required."],
                400,
            );
        }

        $result = \Services\FreeAI::suggestQuestion($prompt);
        Response::json($result);
    }

    public function generateQuestions(): void
    {
        if (!Auth::check() || !Auth::isResearcher()) {
            Response::json(
                ["success" => false, "error" => "Unauthorized"],
                401,
            );
            return;
        }
        if (!Auth::checkRateLimit()) {
            Response::json(
                [
                    "success" => false,
                    "error" => "Too many requests. Please slow down.",
                ],
                429,
            );
            return;
        }

        $input = json_decode(file_get_contents("php://input"), true);
        $text = trim((string) ($input["text"] ?? ""));
        $count = min(20, max(1, (int) ($input["count"] ?? 5)));
        $mode = ($input["mode"] ?? "form") === "chat" ? "chat" : "form";

        if (mb_strlen($text) < 10) {
            Response::json(
                [
                    "success" => false,
                    "error" =>
                        "Text is too short. Please provide at least 10 characters.",
                ],
                400,
            );
            return;
        }

        $result = FreeAI::generateQuestions($text, $count, $mode);
        $questions = $result["questions"] ?? [];

        if (count($questions) < $count) {
            $fallback = QuestionGenerator::fromText(
                $text,
                $count - count($questions),
            );
            foreach ($fallback as $q) {
                $questions[] = [
                    "type" => $q["type"] ?? "text",
                    "question_text" => trim(
                        (string) ($q["question_text"] ?? ""),
                    ),
                    "options" =>
                        isset($q["options"]) && is_array($q["options"])
                            ? array_values(
                                array_filter(
                                    array_map("strval", $q["options"]),
                                    fn($v) => trim($v) !== "",
                                ),
                            )
                            : null,
                    "explanation" => trim((string) ($q["explanation"] ?? "")),
                ];
                if (count($questions) >= $count) {
                    break;
                }
            }
        }

        if (count($questions) < $count) {
            $nlp = QuestionNLP::analyze($text);
            foreach ($nlp["suggestions"] ?? [] as $s) {
                $questions[] = [
                    "type" => $s["type"] ?? "text",
                    "question_text" => trim(
                        (string) ($s["question_text"] ?? ""),
                    ),
                    "options" =>
                        isset($s["options"]) && is_array($s["options"])
                            ? array_values(
                                array_filter(
                                    array_map("strval", $s["options"]),
                                    fn($v) => trim($v) !== "",
                                ),
                            )
                            : null,
                    "explanation" => trim((string) ($s["explanation"] ?? "")),
                ];
                if (count($questions) >= $count) {
                    break;
                }
            }
        }

        $normalized = [];
        foreach ($questions as $q) {
            $qt = trim((string) ($q["question_text"] ?? ""));
            if ($qt === "") {
                continue;
            }
            $normalized[] = [
                "type" => (string) ($q["type"] ?? "text"),
                "question_text" => $qt,
                "options" =>
                    isset($q["options"]) && is_array($q["options"])
                        ? array_values(
                            array_filter(
                                array_map("strval", $q["options"]),
                                fn($v) => trim($v) !== "",
                            ),
                        )
                        : null,
                "explanation" => trim((string) ($q["explanation"] ?? "")),
            ];
            if (count($normalized) >= $count) {
                break;
            }
        }

        if (empty($normalized)) {
            Response::json(
                [
                    "success" => false,
                    "error" =>
                        "Could not generate questions from the provided text.",
                ],
                422,
            );
            return;
        }

        Response::json([
            "success" => true,
            "source" => $result["source"] ?? "hybrid",
            "questions" => $normalized,
            "count" => count($normalized),
        ]);
    }

    public function chat(): void
    {
        $input = json_decode(file_get_contents("php://input"), true);
        $provider = trim($input["provider"] ?? "");
        $model = trim($input["model"] ?? "");
        $messages = $input["messages"] ?? [];
        $systemPrompt = trim(
            $input["system_prompt"] ?? "You are a helpful survey assistant.",
        );
        $temperature = min(2, max(0, (float) ($input["temperature"] ?? 0.7)));
        $maxTokens = min(4096, max(1, (int) ($input["max_tokens"] ?? 500)));

        $freeProviders = ["pollinations", "puter", "browser", "none"];
        if (in_array($provider, $freeProviders, true)) {
            Response::json(
                [
                    "error" =>
                        'Free provider "' .
                        $provider .
                        '" must be called client-side, not via server proxy',
                ],
                400,
            );
            return;
        }

        if (empty($messages)) {
            Response::json(["error" => "Messages are required"], 400);
            return;
        }

        $db = Database::getInstance();
        $responseId = (int) ($input["response_id"] ?? 0);
        $apiKey = trim((string) ($input["api_key"] ?? ""));

        if ($responseId > 0) {
            // Survey-run mode: use survey-configured provider/key via response_id
            $response = $db->fetchOne(
                "SELECT survey_id FROM responses WHERE id = ?",
                [$responseId],
            );
            if (!$response) {
                Response::json(["error" => "Invalid response_id"], 400);
                return;
            }

            $survey = $db->fetchOne(
                "SELECT ai_config FROM surveys WHERE id = ?",
                [$response["survey_id"]],
            );
            if (!$survey) {
                Response::json(["error" => "Survey not found"], 404);
                return;
            }

            $aiConfig = json_decode($survey["ai_config"] ?? "null", true) ?? [];
            $configProvider = trim($aiConfig["provider"] ?? "");
            $configModel = trim($aiConfig["model"] ?? "");
            $apiKey = trim($aiConfig["api_key"] ?? "");

            if ($provider !== $configProvider && !empty($configProvider)) {
                Response::json(
                    [
                        "error" => "Provider mismatch: survey is configured for '{$configProvider}'",
                    ],
                    400,
                );
                return;
            }

            if (empty($model)) {
                $model = $configModel;
            }

            // Rate limiting: max 15 calls per response per 60s
            $windowStart = date("Y-m-d H:i:s", time() - 60);
            $callCount = $db->fetchOne(
                "SELECT COUNT(*) as cnt FROM behavioral_logs WHERE response_id = ? AND event_type = 'ai_chat' AND created_at >= ?",
                [$responseId, $windowStart],
            );
            if ($callCount && (int) $callCount["cnt"] >= 15) {
                Response::json(
                    ["error" => "Rate limit exceeded. Try again later."],
                    429,
                );
                return;
            }

            $db->insert("behavioral_logs", [
                "response_id" => $responseId,
                "event_type" => "ai_chat",
                "event_data" => json_encode([
                    "provider" => $provider,
                    "model" => $model,
                ]),
            ]);
        } else {
            // Design-assistant mode: allow authenticated researchers to call AI without response_id
            if (!Auth::check() || !Auth::isResearcher()) {
                Response::json(
                    ["error" => "Authentication required for AI assistant"],
                    401,
                );
                return;
            }
            if (!Auth::checkRateLimit()) {
                Response::json(
                    ["error" => "Too many requests. Please slow down."],
                    429,
                );
                return;
            }
            if ($apiKey === "") {
                Response::json(
                    [
                        "error" =>
                            "API key is required for server-side provider calls in assistant mode",
                    ],
                    400,
                );
                return;
            }
        }

        switch ($provider) {
            case "openai":
                self::proxyOpenAI(
                    $apiKey,
                    $model,
                    $messages,
                    $systemPrompt,
                    $temperature,
                    $maxTokens,
                );
                return;
            case "claude":
                self::proxyClaude(
                    $apiKey,
                    $model,
                    $messages,
                    $systemPrompt,
                    $temperature,
                    $maxTokens,
                );
                return;
            case "gemini":
                if (empty($apiKey)) {
                    Response::json(
                        [
                            "error" =>
                                "Gemini API key is not configured for this survey",
                        ],
                        400,
                    );
                    return;
                }
                self::proxyGemini(
                    $apiKey,
                    $model,
                    $messages,
                    $systemPrompt,
                    $temperature,
                    $maxTokens,
                );
                return;
            case "deepseek":
                self::proxyDeepSeek(
                    $apiKey,
                    $model,
                    $messages,
                    $systemPrompt,
                    $temperature,
                    $maxTokens,
                );
                return;
            default:
                Response::json(["error" => "Unsupported provider"], 400);
        }
    }

    public function aiModels(): void
    {
        $input = json_decode(file_get_contents("php://input"), true);
        $provider = trim($input["provider"] ?? "");
        switch ($provider) {
            case "openai":
                Response::json([
                    "models" => [
                        "gpt-4o",
                        "gpt-4o-mini",
                        "gpt-4-turbo",
                        "gpt-3.5-turbo",
                    ],
                ]);
                return;
            case "claude":
                Response::json([
                    "models" => [
                        "claude-sonnet-4-20250514",
                        "claude-3.5-sonnet-20241022",
                        "claude-3.5-haiku-20241022",
                    ],
                ]);
                return;
            case "gemini":
                Response::json([
                    "models" => [
                        "gemini-2.0-flash",
                        "gemini-1.5-pro",
                        "gemini-1.5-flash",
                    ],
                ]);
                return;
            case "deepseek":
                Response::json([
                    "models" => ["deepseek-chat", "deepseek-reasoner"],
                ]);
                return;
            case "pollinations":
                Response::json(["models" => ["openai", "llama", "deepseek"]]);
                return;
            case "puter":
                Response::json([
                    "models" => [
                        "gemini-3.5-flash",
                        "gemini-3.1-pro-preview",
                        "gpt-4o",
                        "claude-sonnet-4-20250514",
                        "claude-3.5-haiku-20241022",
                    ],
                ]);
                return;
            default:
                Response::json(["models" => []]);
        }
    }

    private static function proxyOpenAI(
        string $apiKey,
        string $model,
        array $messages,
        string $systemPrompt,
        float $temperature,
        int $maxTokens,
    ): void {
        if (empty($apiKey)) {
            Response::json(["error" => "OpenAI API key is required"], 400);
            return;
        }
        $payload = json_encode([
            "model" => $model ?: "gpt-4o-mini",
            "messages" => array_merge(
                [["role" => "system", "content" => $systemPrompt]],
                $messages,
            ),
            "temperature" => $temperature,
            "max_tokens" => $maxTokens,
        ]);

        $maxRetries = 3;
        $baseDelay = 1000000; // 1 second in microseconds

        for ($attempt = 0; $attempt <= $maxRetries; $attempt++) {
            $result = @file_get_contents(
                "https://api.openai.com/v1/chat/completions",
                false,
                stream_context_create([
                    "http" => [
                        "method" => "POST",
                        "header" => "Content-Type: application/json\r\nAuthorization: Bearer {$apiKey}\r\n",
                        "content" => $payload,
                        "timeout" => 30,
                        "ignore_errors" => true,
                    ],
                ]),
            );

            if ($result !== false) {
                $data = json_decode($result, true);
                $text = $data["choices"][0]["message"]["content"] ?? null;
                if ($text !== null) {
                    Response::json(["success" => true, "text" => trim($text)]);
                    return;
                }
                // Check if it's a rate limit error - retry with backoff
                $errorMsg = $data["error"]["message"] ?? "";
                if (
                    $attempt < $maxRetries &&
                    (strpos($errorMsg, "rate limit") !== false ||
                        strpos($errorMsg, "quota") !== false)
                ) {
                    usleep($baseDelay * pow(2, $attempt));
                    continue;
                }
                Response::json(
                    [
                        "error" =>
                            "OpenAI API error: " . ($errorMsg ?: "unknown"),
                    ],
                    502,
                );
                return;
            }

            if ($attempt < $maxRetries) {
                usleep($baseDelay * pow(2, $attempt));
            }
        }

        Response::json(
            ["error" => "OpenAI API request failed after retries"],
            502,
        );
    }

    private static function proxyClaude(
        string $apiKey,
        string $model,
        array $messages,
        string $systemPrompt,
        float $temperature,
        int $maxTokens,
    ): void {
        if (empty($apiKey)) {
            Response::json(["error" => "Anthropic API key is required"], 400);
            return;
        }
        $claudeMessages = [];
        foreach ($messages as $m) {
            $role = $m["role"] === "assistant" ? "assistant" : "user";
            $claudeMessages[] = ["role" => $role, "content" => $m["content"]];
        }
        $payload = json_encode([
            "model" => $model ?: "claude-3.5-haiku-20241022",
            "system" => $systemPrompt,
            "messages" => $claudeMessages,
            "temperature" => $temperature,
            "max_tokens" => $maxTokens,
        ]);

        $maxRetries = 3;
        $baseDelay = 1000000;

        for ($attempt = 0; $attempt <= $maxRetries; $attempt++) {
            $result = @file_get_contents(
                "https://api.anthropic.com/v1/messages",
                false,
                stream_context_create([
                    "http" => [
                        "method" => "POST",
                        "header" => "Content-Type: application/json\r\nx-api-key: {$apiKey}\r\nanthropic-version: 2023-06-01\r\n",
                        "content" => $payload,
                        "timeout" => 30,
                        "ignore_errors" => true,
                    ],
                ]),
            );

            if ($result !== false) {
                $data = json_decode($result, true);
                $text = $data["content"][0]["text"] ?? null;
                if ($text !== null) {
                    Response::json(["success" => true, "text" => trim($text)]);
                    return;
                }
                $errorMsg = $data["error"]["message"] ?? "";
                if (
                    $attempt < $maxRetries &&
                    (strpos($errorMsg, "rate limit") !== false ||
                        strpos($errorMsg, "overloaded") !== false)
                ) {
                    usleep($baseDelay * pow(2, $attempt));
                    continue;
                }
                Response::json(
                    [
                        "error" =>
                            "Anthropic API error: " . ($errorMsg ?: "unknown"),
                    ],
                    502,
                );
                return;
            }

            if ($attempt < $maxRetries) {
                usleep($baseDelay * pow(2, $attempt));
            }
        }

        Response::json(
            ["error" => "Anthropic API request failed after retries"],
            502,
        );
    }

    private static function proxyGemini(
        string $apiKey,
        string $model,
        array $messages,
        string $systemPrompt,
        float $temperature,
        int $maxTokens,
    ): void {
        if (empty($apiKey)) {
            Response::json(["error" => "Gemini API key is required"], 400);
            return;
        }
        $geminiContents = [];
        foreach ($messages as $m) {
            $geminiContents[] = [
                "role" => $m["role"] === "assistant" ? "model" : "user",
                "parts" => [["text" => $m["content"]]],
            ];
        }
        $payload = json_encode([
            "contents" => $geminiContents,
            "systemInstruction" => ["parts" => [["text" => $systemPrompt]]],
            "generationConfig" => [
                "temperature" => $temperature,
                "maxOutputTokens" => $maxTokens,
            ],
        ]);
        $modelName = $model ?: "gemini-2.0-flash";

        $maxRetries = 3;
        $baseDelay = 1000000;

        for ($attempt = 0; $attempt <= $maxRetries; $attempt++) {
            $result = @file_get_contents(
                "https://generativelanguage.googleapis.com/v1beta/models/{$modelName}:generateContent?key={$apiKey}",
                false,
                stream_context_create([
                    "http" => [
                        "method" => "POST",
                        "header" => "Content-Type: application/json\r\n",
                        "content" => $payload,
                        "timeout" => 30,
                        "ignore_errors" => true,
                    ],
                ]),
            );

            if ($result !== false) {
                $data = json_decode($result, true);
                $text =
                    $data["candidates"][0]["content"]["parts"][0]["text"] ??
                    null;
                if ($text !== null) {
                    Response::json(["success" => true, "text" => trim($text)]);
                    return;
                }
                $errorMsg = $data["error"]["message"] ?? "";
                if (
                    $attempt < $maxRetries &&
                    (strpos($errorMsg, "rate limit") !== false ||
                        strpos($errorMsg, "quota") !== false)
                ) {
                    usleep($baseDelay * pow(2, $attempt));
                    continue;
                }
                Response::json(
                    ["error" => "Gemini API error: {$errorMsg}"],
                    502,
                );
                return;
            }

            if ($attempt < $maxRetries) {
                usleep($baseDelay * pow(2, $attempt));
            }
        }

        Response::json(
            ["error" => "Gemini API request failed after retries"],
            502,
        );
    }

    private static function proxyDeepSeek(
        string $apiKey,
        string $model,
        array $messages,
        string $systemPrompt,
        float $temperature,
        int $maxTokens,
    ): void {
        if (empty($apiKey)) {
            Response::json(["error" => "DeepSeek API key is required"], 400);
            return;
        }
        $payload = json_encode([
            "model" => $model ?: "deepseek-chat",
            "messages" => array_merge(
                [["role" => "system", "content" => $systemPrompt]],
                $messages,
            ),
            "temperature" => $temperature,
            "max_tokens" => $maxTokens,
        ]);

        $maxRetries = 3;
        $baseDelay = 1000000;

        for ($attempt = 0; $attempt <= $maxRetries; $attempt++) {
            $result = @file_get_contents(
                "https://api.deepseek.com/chat/completions",
                false,
                stream_context_create([
                    "http" => [
                        "method" => "POST",
                        "header" => "Content-Type: application/json\r\nAuthorization: Bearer {$apiKey}\r\n",
                        "content" => $payload,
                        "timeout" => 30,
                        "ignore_errors" => true,
                    ],
                ]),
            );

            if ($result !== false) {
                $data = json_decode($result, true);
                $text = $data["choices"][0]["message"]["content"] ?? null;
                if ($text !== null) {
                    Response::json(["success" => true, "text" => trim($text)]);
                    return;
                }
                $errorMsg = $data["error"]["message"] ?? "";
                if (
                    $attempt < $maxRetries &&
                    (strpos($errorMsg, "rate limit") !== false ||
                        strpos($errorMsg, "quota") !== false)
                ) {
                    usleep($baseDelay * pow(2, $attempt));
                    continue;
                }
                Response::json(
                    [
                        "error" =>
                            "DeepSeek API error: " . ($errorMsg ?: "unknown"),
                    ],
                    502,
                );
                return;
            }

            if ($attempt < $maxRetries) {
                usleep($baseDelay * pow(2, $attempt));
            }
        }

        Response::json(
            ["error" => "DeepSeek API request failed after retries"],
            502,
        );
    }

    public function logBehavior(): void
    {
        $input = json_decode(file_get_contents("php://input"), true);
        if (empty($input["response_id"]) || empty($input["event_type"])) {
            Response::json(
                ["error" => "response_id and event_type required"],
                400,
            );
            return;
        }
        $allowed = [
            "focus_loss",
            "tab_switch",
            "copy",
            "paste",
            "right_click",
            "devtools_open",
            "resize",
            "scroll",
            "idle",
            "keypress",
            "mouse_move",
            "orientation_change",
        ];
        if (!in_array($input["event_type"], $allowed)) {
            Response::json(["error" => "Invalid event_type"], 400);
            return;
        }
        $db = Database::getInstance();
        $responseId = (int) $input["response_id"];
        $response = $db->fetchOne("SELECT id FROM responses WHERE id = ?", [
            $responseId,
        ]);
        if (!$response) {
            Response::json(["error" => "Invalid response_id"], 400);
            return;
        }
        if (!Auth::checkRateLimit()) {
            Response::json(["error" => "Too many requests"], 429);
            return;
        }
        $db->insert("behavioral_logs", [
            "response_id" => (int) $input["response_id"],
            "event_type" => $input["event_type"],
            "event_data" => !empty($input["event_data"])
                ? json_encode($input["event_data"])
                : null,
            "timestamp_ms" =>
                (int) ($input["timestamp_ms"] ?? round(microtime(true) * 1000)),
            "question_index" => isset($input["question_index"])
                ? (int) $input["question_index"]
                : null,
        ]);
        Response::json(["success" => true]);
    }

    private function authenticateToken(): ?array
    {
        $header = $_SERVER["HTTP_AUTHORIZATION"] ?? "";
        if (preg_match("/Bearer\s+(.+)/", $header, $matches)) {
            $token = $matches[1];
            $db = Database::getInstance();
            $record = $db->fetchOne(
                "SELECT * FROM api_tokens WHERE token = ? AND is_active = 1 AND (expires_at IS NULL OR expires_at > NOW())",
                [$token],
            );
            return $record ?: null;
        }
        return null;
    }
}
