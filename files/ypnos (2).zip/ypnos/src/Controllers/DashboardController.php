<?php

namespace Controllers;

use Core\Auth;
use Core\Response;
use Core\Database;

class DashboardController
{
    public function index(): void
    {
        Auth::requireAuth();

        $role = Auth::role();
        if ($role === 'researcher') {
            $this->researcher();
        } elseif ($role === 'admin') {
            $this->admin();
        } else {
            $this->respondent();
        }
    }

    public function researcher(): void
    {
        Auth::requireRole('researcher');

        $db = Database::getInstance();
        $userId = Auth::id();

        $surveys = $db->fetchAll(
            "SELECT s.*,
             (SELECT COUNT(*) FROM responses r WHERE r.survey_id = s.id) as total_responses,
             (SELECT COUNT(*) FROM responses r WHERE r.survey_id = s.id AND r.quality_score >= s.quality_threshold) as quality_responses,
             (SELECT ROUND(AVG(r.quality_score), 1) FROM responses r WHERE r.survey_id = s.id AND r.quality_score IS NOT NULL) as avg_quality
             FROM surveys s WHERE s.researcher_id = ? ORDER BY s.created_at DESC",
            [$userId]
        );

        $totalResp = array_sum(array_column($surveys, 'total_responses'));
        $qualityResp = array_sum(array_column($surveys, 'quality_responses'));

        $stats = [
            'total_surveys'   => count($surveys),
            'active_surveys'  => count(array_filter($surveys, fn($s) => $s['status'] === 'active')),
            'draft_surveys'   => count(array_filter($surveys, fn($s) => $s['status'] === 'draft')),
            'total_responses' => $totalResp,
            'quality_rate'    => $totalResp > 0 ? round(($qualityResp / $totalResp) * 100, 1) : 100,
            'recent_responses' => $db->fetchAll(
                "SELECT r.*, s.title as survey_title FROM responses r
                 JOIN surveys s ON r.survey_id = s.id
                 WHERE s.researcher_id = ? ORDER BY r.created_at DESC LIMIT 5",
                [$userId]
            ),
        ];

        Response::layout('main', 'researcher/dashboard', [
            'pageTitle' => 'Researcher Dashboard',
            'surveys'   => $surveys,
            'stats'     => $stats,
        ]);
    }

    public function respondent(): void
    {
        Auth::requireRole('respondent');

        $db = Database::getInstance();
        $userId = Auth::id();
        $user = Auth::user();
        $reputation = (float)($user['reputation_score'] ?? 50);

        $availableSurveys = $db->fetchAll(
            "SELECT s.*,
             (SELECT COUNT(*) FROM responses r WHERE r.survey_id = s.id AND r.respondent_id = ?) as my_responses
             FROM surveys s
             WHERE s.status = 'active'
             AND s.min_reputation <= ?
             AND (s.max_responses IS NULL OR s.current_responses < s.max_responses)
             ORDER BY s.min_reputation ASC, s.created_at DESC",
            [$userId, $reputation]
        );

        $myResponses = $db->fetchAll(
            "SELECT r.*, s.title as survey_title, qs.overall_score, qs.researcher_verdict
             FROM responses r
             JOIN surveys s ON r.survey_id = s.id
             LEFT JOIN quality_scores qs ON qs.response_id = r.id
             WHERE r.respondent_id = ?
             ORDER BY r.created_at DESC LIMIT 20",
            [$userId]
        );

        $avgQ = $db->fetchOne(
            "SELECT ROUND(AVG(qs.overall_score), 1) as avg_q FROM quality_scores qs
             JOIN responses r ON r.id = qs.response_id WHERE r.respondent_id = ?",
            [$userId]
        );

        $reputationHistory = $db->fetchAll(
            "SELECT * FROM reputation_history WHERE user_id = ? ORDER BY created_at DESC LIMIT 10",
            [$userId]
        );

        $totalCount = count($myResponses);
        $qualityCount = 0;
        foreach ($myResponses as $r) {
            if ($r['overall_score'] !== null && (float)$r['overall_score'] >= 70) $qualityCount++;
        }

        $stats = [
            'completed'    => count(array_filter($myResponses, fn($r) => in_array($r['status'], ['completed', 'accepted']))),
            'quality_rate' => $totalCount > 0 ? round(($qualityCount / $totalCount) * 100, 1) : 100,
            'avg_quality'  => $avgQ['avg_q'] ?? '—',
        ];

        $reputationLevel = 'bronze';
        if ($reputation >= 80) $reputationLevel = 'platinum';
        elseif ($reputation >= 60) $reputationLevel = 'gold';
        elseif ($reputation >= 40) $reputationLevel = 'silver';

        Response::layout('main', 'respondent/dashboard', [
            'pageTitle'         => 'My Dashboard',
            'reputation'        => $reputation,
            'reputationLevel'   => $reputationLevel,
            'availableSurveys'  => $availableSurveys,
            'myResponses'       => $myResponses,
            'reputationHistory' => $reputationHistory,
            'stats'             => $stats,
        ]);
    }

    public function admin(): void
    {
        Auth::requireAdmin();

        $db = Database::getInstance();

        $stats = [
            'total_users'       => $db->fetchOne("SELECT COUNT(*) as c FROM users")['c'],
            'total_surveys'     => $db->fetchOne("SELECT COUNT(*) as c FROM surveys")['c'],
            'total_responses'   => $db->fetchOne("SELECT COUNT(*) as c FROM responses")['c'],
            'active_surveys'    => $db->fetchOne("SELECT COUNT(*) as c FROM surveys WHERE status = 'active'")['c'],
            'researchers'       => $db->fetchOne("SELECT COUNT(*) as c FROM users WHERE role = 'researcher'")['c'],
            'respondents'       => $db->fetchOne("SELECT COUNT(*) as c FROM users WHERE role = 'respondent'")['c'],
        ];

        $recentUsers = $db->fetchAll("SELECT * FROM users ORDER BY created_at DESC LIMIT 5");
        $recentSurveys = $db->fetchAll(
            "SELECT s.*, u.full_name as researcher_name FROM surveys s
             JOIN users u ON s.researcher_id = u.id ORDER BY s.created_at DESC LIMIT 5"
        );

        Response::layout('main', 'admin/dashboard', [
            'pageTitle'    => 'Admin Dashboard',
            'stats'        => $stats,
            'recentUsers'  => $recentUsers,
            'recentSurveys' => $recentSurveys,
        ]);
    }
}
