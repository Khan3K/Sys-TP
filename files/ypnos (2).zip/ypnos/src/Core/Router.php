<?php

namespace Core;

class Router
{
    private array $routes = [];

    public function get(string $path, string $handler): void
    {
        $this->routes['GET'][] = ['path' => $path, 'handler' => $handler];
    }

    public function post(string $path, string $handler): void
    {
        $this->routes['POST'][] = ['path' => $path, 'handler' => $handler];
    }

    public function load(): void
    {
        $this->registerRoutes();
        $this->dispatch();
    }

    private function registerRoutes(): void
    {
        $this->get('/', 'AuthController@index');

        // Auth
        $this->get('/login', 'AuthController@loginForm');
        $this->post('/login', 'AuthController@login');
        $this->get('/register', 'AuthController@registerForm');
        $this->post('/register', 'AuthController@register');
        $this->get('/logout', 'AuthController@logout');
        $this->get('/forgot-password', 'AuthController@forgotForm');
        $this->post('/forgot-password', 'AuthController@forgot');
        $this->get('/reset-password/{token}', 'AuthController@resetForm');
        $this->post('/reset-password/{token}', 'AuthController@reset');
        $this->get('/auth/google', 'AuthController@googleRedirect');
        $this->get('/auth/google/callback', 'AuthController@googleCallback');

        // Dashboard
        $this->get('/dashboard', 'DashboardController@index');

        // Survey
        $this->get('/survey/create', 'SurveyController@createType');
        $this->get('/survey/create/form', 'SurveyController@createForm');
        $this->get('/survey/create/chat', 'SurveyController@createChat');
        $this->post('/survey/create', 'SurveyController@create');
        $this->get('/survey/edit/{id}', 'SurveyController@editForm');
        $this->post('/survey/edit/{id}', 'SurveyController@update');
        $this->get('/survey/view/{id}', 'SurveyController@view');
        $this->post('/survey/delete/{id}', 'SurveyController@delete');
        $this->get('/survey/take/{id}', 'SurveyController@takeForm');
        $this->post('/survey/take/{id}', 'SurveyController@submit');
        $this->post('/survey/take/{id}/auth', 'SurveyController@takeAuth');
        $this->get('/survey/results/{id}', 'SurveyController@results');
        $this->get('/templates', 'SurveyController@templates');

        // Questions
        $this->get('/survey/{id}/questions/add', 'QuestionController@addForm');
        $this->post('/survey/{id}/questions/add', 'QuestionController@add');
        $this->post('/survey/questions/delete/{id}', 'QuestionController@delete');
        $this->post('/survey/questions/reorder', 'QuestionController@reorder');

        // Quality
        $this->get('/quality/{surveyId}', 'QualityController@dashboard');
        $this->get('/quality/{surveyId}/responses/{responseId}', 'QualityController@viewResponse');
        $this->post('/quality/{surveyId}/verdict/{responseId}', 'QualityController@verdict');
        $this->post('/quality/bulk-verdict/{surveyId}', 'QualityController@bulkVerdict');

        // Export
        $this->get('/export/{surveyId}', 'ExportController@form');
        $this->post('/export/{surveyId}', 'ExportController@export');
        $this->get('/export/download/{id}', 'ExportController@download');

        // Profile
        $this->get('/profile', 'ProfileController@index');
        $this->post('/profile', 'ProfileController@update');

        // Admin
        $this->get('/admin', 'AdminController@dashboard');
        $this->get('/admin/dashboard', 'AdminController@dashboard');
        $this->get('/admin/users', 'AdminController@users');
        $this->post('/admin/users/toggle/{id}', 'AdminController@toggleUser');
        $this->post('/admin/users/approve/{id}', 'AdminController@approveUser');
        $this->post('/admin/users/reject/{id}', 'AdminController@rejectUser');
        $this->post('/admin/users/delete/{id}', 'AdminController@deleteUser');
        $this->get('/admin/users/create', 'AdminController@createUserForm');
        $this->post('/admin/users/create', 'AdminController@createUser');
        $this->get('/admin/surveys', 'AdminController@surveys');
        $this->get('/admin/templates', 'AdminController@templates');
        $this->get('/admin/settings', 'AdminController@settings');
        $this->post('/admin/settings', 'AdminController@saveSettings');
        $this->get('/admin/logs', 'AdminController@logs');
        $this->get('/admin/debug/passwords', 'AdminController@debugPasswords');
        $this->post('/admin/debug/passwords', 'AdminController@debugPasswordReset');

        // Research Ground
        $this->get('/research', 'ResearchController@dashboard');
        $this->post('/research/create', 'ResearchController@create');
        $this->get('/research/{id}', 'ResearchController@view');
        $this->post('/research/delete/{id}', 'ResearchController@delete');
        $this->post('/research/{id}/import', 'ResearchController@importSurvey');
        $this->post('/research/{projectId}/source/{sourceId}/remove', 'ResearchController@removeSource');
        $this->get('/research/{id}/api/responses', 'ResearchController@apiResponses');
        $this->get('/research/{id}/api/answers', 'ResearchController@apiAnswers');
        $this->post('/research/{id}/viz/save', 'ResearchController@saveViz');
        $this->post('/research/{projectId}/viz/{vizId}/delete', 'ResearchController@deleteViz');

        // Bookmarklet
        $this->get('/bookmarklet-popup', 'BookmarkletController@popup');
        $this->post('/bookmarklet/fill', 'BookmarkletController@fill');
        $this->get('/bookmarklet/setup', 'BookmarkletController@setup');

        // Survey URL shortener
        $this->post('/survey/{id}/urls/create', 'SurveyController@createUrl');
        $this->get('/survey/{id}/urls', 'SurveyController@listUrls');
        $this->post('/survey/url/toggle/{urlId}', 'SurveyController@toggleUrl');
        $this->post('/survey/url/delete/{urlId}', 'SurveyController@deleteUrl');
        $this->get('/s/{code}', 'SurveyController@redirectByShortCode');
        $this->post('/s/{code}', 'SurveyController@redirectByShortCode');

        // API
        $this->get('/api/surveys', 'ApiController@surveys');
        $this->get('/api/surveys/{id}', 'ApiController@surveyResults');
        $this->post('/api/ai/suggest', 'ApiController@suggestQuestion');
        $this->post('/api/questions/generate', 'ApiController@generateQuestions');
        $this->post('/api/behavior/log', 'ApiController@logBehavior');
        $this->post('/api/ai/chat', 'ApiController@chat');
        $this->post('/api/ai/models', 'ApiController@aiModels');
    }

    private function dispatch(): void
    {
        $method = $_SERVER['REQUEST_METHOD'];
        $uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

        $base = dirname($_SERVER['SCRIPT_NAME']);
        if ($base !== '/' && strpos($uri, $base) === 0) {
            $uri = substr($uri, strlen($base));
        }
        $uri = '/' . trim($uri, '/');

        $routes = $this->routes[$method] ?? [];

        foreach ($routes as $route) {
            $pattern = preg_replace('/\{(\w+)\}/', '(?P<$1>[^/]+)', $route['path']);
            $pattern = '#^' . $pattern . '$#';

            if (preg_match($pattern, $uri, $matches)) {
                $parts = explode('@', $route['handler']);
                $controllerName = 'Controllers\\' . $parts[0];
                $action = $parts[1];

                $params = array_filter($matches, 'is_string', ARRAY_FILTER_USE_KEY);

                if (class_exists($controllerName)) {
                    $controller = new $controllerName();

                    // Global CSRF protection for state-changing POST requests.
                    // API endpoints and the cross-site bookmarklet fill have their own controls.
                    if ($method === 'POST') {
                        $exempt = strpos($uri, '/api/') === 0 || $uri === '/bookmarklet/fill';
                        if (!$exempt) {
                            $accept = $_SERVER['HTTP_ACCEPT'] ?? '';
                            $isAjax = (strtolower($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'xmlhttprequest')
                                || strpos($accept, 'application/json') === 0;
                            if ($isAjax) {
                                if (!\Core\Csrf::valid()) {
                                    http_response_code(403);
                                    header('Content-Type: application/json');
                                    echo json_encode(['error' => 'Security token mismatch']);
                                    exit;
                                }
                            } else {
                                \Core\Csrf::check();
                            }
                        }
                    }

                    $controller->$action(...$params);
                } else {
                    throw new \RuntimeException("Controller not found: {$controllerName}");
                }
                return;
            }
        }

        Response::notFound();
    }
}
