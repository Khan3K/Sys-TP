<?php

namespace Core;

class Response
{
    public static function json(mixed $data, int $status = 200): void
    {
        http_response_code($status);
        header("Content-Type: application/json; charset=utf-8");
        header("X-Content-Type-Options: nosniff");
        echo json_encode($data);
        exit();
    }

    private static function baseUrl(): string
    {
        static $base = null;
        if ($base === null) {
            $config = require __DIR__ . "/../../config/app.php";
            $base = $config["base_url"] ?? "";
        }
        return $base;
    }

    public static function redirect(string $url): void
    {
        $base = self::baseUrl();

        // Guard against protocol-relative redirects (e.g. //evil.com)
        if (str_starts_with($url, "//")) {
            $url = ($base ?: "") . "/dashboard";
            header("Location: {$url}");
            exit();
        }

        $isAbsolute = strpos($url, "://") !== false;

        // Prefix app base for relative paths
        if (!$isAbsolute && $base && strpos($url, $base) !== 0) {
            $url = $base . "/" . ltrim($url, "/");
        }

        // Allow absolute redirects only to known local host(s)
        if ($isAbsolute) {
            $targetHost = parse_url($url, PHP_URL_HOST);

            $config = require __DIR__ . "/../../config/app.php";
            $appHost = parse_url((string) ($config["url"] ?? ""), PHP_URL_HOST);
            $requestHost = $_SERVER["HTTP_HOST"] ?? null;
            if ($requestHost !== null) {
                $requestHost = explode(":", $requestHost, 2)[0];
            }

            $allowedHosts = array_filter(
                [$appHost, $requestHost],
                fn($h) => is_string($h) && $h !== "",
            );
            if ($targetHost && !in_array($targetHost, $allowedHosts, true)) {
                $url = ($base ?: "") . "/dashboard";
            }
        }

        header("Location: {$url}");
        exit();
    }

    public static function view(string $view, array $data = []): void
    {
        $viewPath = __DIR__ . "/../../views/" . $view . ".php";
        if (!file_exists($viewPath)) {
            throw new \RuntimeException("View not found: {$view}");
        }
        extract($data);
        require $viewPath;
    }

    public static function layout(
        string $layout,
        string $view,
        array $data = [],
    ): void {
        // CSP header for production hardening
        $csp =
            "default-src 'self'; " .
            "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://cdn.tailwindcss.com https://cdnjs.cloudflare.com https://cdn.jsdelivr.net; " .
            "style-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com https://fonts.googleapis.com; " .
            "font-src 'self' https://cdnjs.cloudflare.com https://fonts.gstatic.com data:; " .
            "img-src 'self' https: data: blob:; " .
            "connect-src 'self' https://api.openai.com https://api.anthropic.com https://generativelanguage.googleapis.com https://api.deepseek.com https://text.pollinations.ai; " .
            "frame-src 'self'; " .
            "object-src 'none'; " .
            "base-uri 'self'; " .
            "form-action 'self'";
        header("Content-Security-Policy: {$csp}");

        $data["_base_url"] = self::baseUrl();
        $data["_content"] = function () use ($view, $data) {
            extract($data);
            $viewPath = __DIR__ . "/../../views/" . $view . ".php";
            if (file_exists($viewPath)) {
                require $viewPath;
            }
        };
        $layoutPath = __DIR__ . "/../../views/layouts/" . $layout . ".php";
        if (!file_exists($layoutPath)) {
            throw new \RuntimeException("Layout not found: {$layout}");
        }
        extract($data);
        require $layoutPath;
    }

    public static function notFound(): void
    {
        http_response_code(404);
        self::layout("main", "errors/404", ["pageTitle" => "Not Found"]);
        exit();
    }

    public static function forbidden(): void
    {
        http_response_code(403);
        $base = htmlspecialchars(self::baseUrl(), ENT_QUOTES);
        echo '<div class="min-h-screen flex items-center justify-center"><div class="text-center"><h1 class="text-6xl font-bold text-gray-300">403</h1><p class="text-gray-500 mt-2">Forbidden</p><a href="' .
            $base .
            '/dashboard" class="mt-4 inline-block text-indigo-600 hover:underline">Back to Dashboard</a></div></div>';
        exit();
    }

    public static function download(string $filePath, string $filename): void
    {
        $realPath = realpath($filePath);
        $allowedDir =
            realpath(__DIR__ . "/../../storage/exports") ?:
            realpath(__DIR__ . "/../../storage");
        if (
            !$realPath ||
            !$allowedDir ||
            strpos($realPath, $allowedDir) !== 0
        ) {
            self::notFound();
        }
        $safeName = str_replace(['"', "\r", "\n"], "", $filename);
        header("Content-Type: application/octet-stream");
        header('Content-Disposition: attachment; filename="' . $safeName . '"');
        header("Content-Length: " . filesize($realPath));
        header("X-Content-Type-Options: nosniff");
        readfile($realPath);
        exit();
    }
}
