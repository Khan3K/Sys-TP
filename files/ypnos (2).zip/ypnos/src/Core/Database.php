<?php

namespace Core;

use PDO;

class Database
{
    private static ?Database $instance = null;
    private PDO $pdo;
    private array $cache = [];
    private array $cacheTTL = [];

    private static array $allowedTables = [
        "users",
        "sessions",
        "password_resets",
        "rate_limits",
        "admin_logs",
        "surveys",
        "questions",
        "question_rules",
        "responses",
        "answers",
        "quality_logs",
        "quality_scores",
        "api_tokens",
        "export_history",
        "behavioral_logs",
        "reputation_history",
        "research_projects",
        "research_project_surveys",
        "research_visualizations",
        "survey_urls",
        "animation_presets",
    ];

    private function __construct(array $config)
    {
        $dsn = sprintf(
            "mysql:host=%s;port=%d;dbname=%s;charset=%s",
            $config["host"] ?? "localhost",
            $config["port"] ?? 3306,
            $config["dbname"] ?? "resrch",
            $config["charset"] ?? "utf8mb4",
        );
        $this->pdo = new PDO(
            $dsn,
            $config["username"] ?? "root",
            $config["password"] ?? "",
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ],
        );
    }

    private static array $allowedColumns = [
        "id",
        "email",
        "password_hash",
        "full_name",
        "avatar_url",
        "role",
        "reputation_score",
        "is_active",
        "approval_status",
        "last_login_at",
        "last_activity_at",
        "created_at",
        "updated_at",

        "user_id",
        "token",
        "expires_at",
        "used_at",

        "ip_address",
        "endpoint",

        "admin_id",
        "action",
        "details_json",

        "researcher_id",
        "title",
        "description",
        "status",
        "quality_threshold",
        "min_reputation",
        "max_responses",
        "current_responses",
        "allow_anonymous",
        "require_quality_check",
        "quality_config",
        "type",
        "chat_config",
        "ai_config",
        "theme_config",
        "access_password",
        "starts_at",
        "ends_at",
        "shuffle_questions",
        "shuffle_options",
        "fullscreen_mode",
        "inactivity_timeout",
        "allow_resume",

        "question_id",
        "question_text",
        "options_json",
        "order_index",
        "is_required",
        "is_attention_check",
        "expected_answer",
        "is_trap",
        "is_timed",
        "time_limit_seconds",
        "min_value",
        "max_value",
        "char_limit",
        "min_length",
        "max_length",
        "allow_paste",
        "is_speed_bump",
        "rows_json",
        "placeholder",
        "hint",
        "image_url",
        "include_other",
        "animation",
        "accent_color",
        "explanation",
        "font_family",
        "font_size",
        "border_radius",
        "shadow_style",
        "bg_type",
        "bg_value",
        "frozen_animation",
        "interaction_animation",
        "validation_rules",
        "scoring_weight",

        "rule_type",
        "rule_value",

        "respondent_id",
        "response_id",
        "session_id",
        "device_fingerprint",
        "question_random_seed",
        "resume_code",
        "tab_switch_count",
        "user_agent",
        "started_at",
        "completed_at",
        "time_spent_seconds",
        "chat_data",
        "quality_score",

        "answer_value",
        "is_flagged",

        "check_type",
        "passed",
        "score",

        "overall_score",
        "attention_score",
        "time_score",
        "pattern_score",
        "consistency_score",
        "trap_score",
        "bot_score",
        "gibberish_score",
        "longstring_score",
        "outlier_score",
        "emoji_score",
        "profanity_score",
        "speed_bump_score",
        "is_auto_rejected",
        "researcher_verdict",
        "notes",

        "permissions",

        "format",
        "filter_criteria",
        "file_path",
        "row_count",

        "event_type",
        "event_data",
        "timestamp_ms",
        "question_index",

        "survey_id",
        "old_score",
        "new_score",
        "change_reason",

        "name",
        "project_id",
        "import_config",
        "imported_at",

        "chart_type",
        "chart_config",

        "short_code",
        "custom_slug",
        "slug",
        "full_url",
        "qr_code_path",
        "use_count",
        "click_count",
        "utm_source",
        "utm_medium",
        "utm_campaign",
        "utm_content",
        "utm_term",
        "password",
        "max_uses",

        "key_name",
        "label",
        "category",
        "css_class",
        "duration_ms",
        "is_premium",
        "sort_order",

        "disable_rightclick",
        "inactivity_warn_before",
        "vpn_detection",
        "ai_detection",
        "email_domain_verify",
        "geo_timezone_check",
        "language_consistency",
    ];

    private static function validateIdentifier(string $identifier): string
    {
        if (!preg_match('/^[a-zA-Z_][a-zA-Z0-9_]*$/', $identifier)) {
            throw new \InvalidArgumentException(
                "Invalid identifier: {$identifier}",
            );
        }
        return $identifier;
    }

    private static function validateTable(string $table): string
    {
        $table = self::validateIdentifier($table);
        if (!in_array($table, self::$allowedTables, true)) {
            throw new \InvalidArgumentException("Table not allowed: {$table}");
        }
        return $table;
    }

    private static function validateColumns(array $columns): array
    {
        foreach ($columns as $col) {
            if (!in_array($col, self::$allowedColumns, true)) {
                throw new \InvalidArgumentException(
                    "Column not allowed: {$col}",
                );
            }
        }
        return $columns;
    }

    public function getPdo(): PDO
    {
        return $this->pdo;
    }

    public static function init(array $config): void
    {
        self::$instance = new self($config);
    }

    public static function getInstance(): self
    {
        if (!self::$instance) {
            throw new \RuntimeException("Database not initialized");
        }
        return self::$instance;
    }

    public function query(string $sql, array $params = []): \PDOStatement
    {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    public function beginTransaction(): void
    {
        $this->pdo->beginTransaction();
    }

    public function commit(): void
    {
        $this->pdo->commit();
    }

    public function rollback(): void
    {
        $this->pdo->rollBack();
    }

    public function transaction(callable $callback): mixed
    {
        $this->beginTransaction();
        try {
            $result = $callback($this);
            $this->commit();
            return $result;
        } catch (\Throwable $e) {
            $this->rollback();
            throw $e;
        }
    }

    public function fetchAll(string $sql, array $params = []): array
    {
        return $this->query($sql, $params)->fetchAll();
    }

    public function fetchOne(string $sql, array $params = []): ?array
    {
        $row = $this->query($sql, $params)->fetch();
        return $row ?: null;
    }

    public function insert(string $table, array $data): int
    {
        self::validateTable($table);
        self::validateColumns(array_keys($data));
        $cols = array_keys($data);
        $quoted = array_map(fn($c) => "`{$c}`", $cols);
        $columns = implode(", ", $quoted);
        $placeholders = implode(", ", array_fill(0, count($data), "?"));
        $sql = "INSERT INTO `{$table}` ({$columns}) VALUES ({$placeholders})";
        $this->query($sql, array_values($data));
        return (int) $this->pdo->lastInsertId();
    }

    public function update(
        string $table,
        array $data,
        string $where,
        array $whereParams = [],
    ): int {
        self::validateTable($table);
        self::validateColumns(array_keys($data));
        $cols = array_keys($data);
        $sets = implode(", ", array_map(fn($col) => "`{$col}` = ?", $cols));
        $sql = "UPDATE `{$table}` SET {$sets} WHERE {$where}";
        $stmt = $this->query(
            $sql,
            array_merge(array_values($data), $whereParams),
        );
        return $stmt->rowCount();
    }

    public function delete(
        string $table,
        string $where,
        array $params = [],
    ): int {
        self::validateTable($table);
        $sql = "DELETE FROM `{$table}` WHERE {$where}";
        $stmt = $this->query($sql, $params);
        return $stmt->rowCount();
    }

    public function exists(
        string $table,
        string $where,
        array $params = [],
    ): bool {
        self::validateTable($table);
        $sql = "SELECT 1 FROM `{$table}` WHERE {$where} LIMIT 1";
        return (bool) $this->fetchOne($sql, $params);
    }

    public function cacheFetchOne(
        string $key,
        string $sql,
        array $params = [],
        int $ttl = 60,
    ): ?array {
        if (
            isset($this->cache[$key]) &&
            time() - $this->cacheTTL[$key] < $ttl
        ) {
            return $this->cache[$key];
        }
        $result = $this->fetchOne($sql, $params);
        $this->cache[$key] = $result;
        $this->cacheTTL[$key] = time();
        return $result;
    }

    public function cacheFetchAll(
        string $key,
        string $sql,
        array $params = [],
        int $ttl = 60,
    ): array {
        if (
            isset($this->cache[$key]) &&
            time() - $this->cacheTTL[$key] < $ttl
        ) {
            return $this->cache[$key];
        }
        $result = $this->fetchAll($sql, $params);
        $this->cache[$key] = $result;
        $this->cacheTTL[$key] = time();
        return $result;
    }

    public function clearCache(string $key = null): void
    {
        if ($key) {
            unset($this->cache[$key], $this->cacheTTL[$key]);
        } else {
            $this->cache = [];
            $this->cacheTTL = [];
        }
    }

    public function clearTableCache(string $table): void
    {
        foreach (array_keys($this->cache) as $key) {
            if (str_starts_with($key, $table . ".")) {
                unset($this->cache[$key], $this->cacheTTL[$key]);
            }
        }
    }
}
