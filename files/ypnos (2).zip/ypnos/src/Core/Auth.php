<?php

namespace Core;

class Auth
{
    private static ?array $user = null;

    public static function attempt(string $email, string $password): string|true
    {
        $db = Database::getInstance();
        $user = $db->fetchOne("SELECT * FROM users WHERE email = ?", [$email]);

        if (!$user) {
            return 'no_account';
        }
        if (!$user['is_active']) {
            return 'inactive';
        }
        if ($user['approval_status'] === 'pending') {
            return 'pending';
        }
        if ($user['approval_status'] === 'rejected') {
            return 'rejected';
        }
        if (!password_verify($password, $user['password_hash'])) {
            return 'wrong_password';
        }

        $token = bin2hex(random_bytes(32));
        $expires = date('Y-m-d H:i:s', time() + 86400);

        $db->insert('sessions', [
            'user_id'    => $user['id'],
            'token'      => $token,
            'expires_at' => $expires,
        ]);

        $db->update('users', ['last_login_at' => date('Y-m-d H:i:s')], 'id = ?', [$user['id']]);

        session_regenerate_id(true);
        $_SESSION['_created'] = time();

        Session::set('user_id', $user['id']);
        Session::set('user_role', $user['role']);
        Session::set('user_name', $user['full_name']);
        Session::set('auth_token', $token);

        self::$user = $user;
        return true;
    }

    public static function user(): ?array
    {
        if (self::$user) {
            return self::$user;
        }
        $userId = Session::get('user_id');
        if (!$userId) {
            return null;
        }
        $db = Database::getInstance();
        self::$user = $db->fetchOne("SELECT * FROM users WHERE id = ? AND is_active = 1", [$userId]);
        return self::$user;
    }

    public static function id(): ?int
    {
        $id = Session::get('user_id');
        return $id ? (int)$id : null;
    }

    public static function role(): ?string
    {
        return Session::get('user_role');
    }

    public static function check(): bool
    {
        if (!Session::has('user_id')) {
            return false;
        }
        $token = Session::get('auth_token');
        if (!$token) {
            return false;
        }
        $db = Database::getInstance();
        $row = $db->fetchOne("SELECT id FROM sessions WHERE token = ? AND expires_at > NOW() AND user_id = ?", [$token, Session::get('user_id')]);
        return $row !== null;
    }

    public static function isAdmin(): bool
    {
        return Session::get('user_role') === 'admin';
    }

    public static function isResearcher(): bool
    {
        return Session::get('user_role') === 'researcher';
    }

    public static function isRespondent(): bool
    {
        return Session::get('user_role') === 'respondent';
    }

    public static function requireAuth(): void
    {
        if (!self::check()) {
            Session::setFlash('warning', 'Please login to continue');
            Response::redirect('/login');
        }
        if (!self::user()) {
            self::logout();
            Session::setFlash('danger', 'Your account no longer exists. Please login again.');
            Response::redirect('/login');
        }
    }

    public static function requireRole(string $role): void
    {
        self::requireAuth();
        if (self::role() !== $role) {
            Response::forbidden();
        }
    }

    public static function requireAdmin(): void
    {
        self::requireAuth();
        if (!self::isAdmin()) {
            Response::forbidden();
        }
    }

    public static function loginWithGoogle(array $googleUser): int
    {
        $db = Database::getInstance();
        $existing = $db->fetchOne("SELECT * FROM users WHERE email = ?", [$googleUser['email']]);

        if ($existing) {
            $token = bin2hex(random_bytes(32));
            $expires = date('Y-m-d H:i:s', time() + 86400);
            $db->insert('sessions', [
                'user_id'    => $existing['id'],
                'token'      => $token,
                'expires_at' => $expires,
            ]);
            $db->update('users', [
                'last_login_at' => date('Y-m-d H:i:s'),
                'avatar_url'    => strip_tags($googleUser['picture'] ?? $existing['avatar_url']),
            ], 'id = ?', [$existing['id']]);

            session_regenerate_id(true);
            $_SESSION['_created'] = time();

            Session::set('user_id', $existing['id']);
            Session::set('user_role', $existing['role']);
            Session::set('user_name', $existing['full_name']);
            Session::set('auth_token', $token);
            self::$user = $existing;
            return (int)$existing['id'];
        }

        $config = require __DIR__ . '/../../config/app.php';
        $initialRep = $config['reputation']['initial'] ?? 50;
        $newId = $db->insert('users', [
            'email'             => $googleUser['email'],
            'password_hash'     => '',
            'full_name'         => strip_tags($googleUser['name'] ?? $googleUser['email']),
            'avatar_url'        => strip_tags($googleUser['picture'] ?? ''),
            'role'              => 'respondent',
            'reputation_score'  => $initialRep,
            'is_active'         => 1,
            'approval_status'   => 'approved',
            'last_login_at'     => date('Y-m-d H:i:s'),
        ]);

        $token = bin2hex(random_bytes(32));
        $expires = date('Y-m-d H:i:s', time() + 86400);
        $db->insert('sessions', [
            'user_id'    => $newId,
            'token'      => $token,
            'expires_at' => $expires,
        ]);

        $user = $db->fetchOne("SELECT * FROM users WHERE id = ?", [$newId]);

        session_regenerate_id(true);
        $_SESSION['_created'] = time();

        Session::set('user_id', $newId);
        Session::set('user_role', $user['role']);
        Session::set('user_name', $user['full_name']);
        Session::set('auth_token', $token);
        self::$user = $user;
        return $newId;
    }

    public static function logout(): void
    {
        $token = Session::get('auth_token');
        if ($token) {
            $db = Database::getInstance();
            $db->delete('sessions', 'token = ?', [$token]);
        }
        Session::destroy();
    }

    public static function register(array $data): int
    {
        $db = Database::getInstance();
        $config = require __DIR__ . '/../../config/app.php';
        $initialRep = $config['reputation']['initial'] ?? 50;
        $allowedRoles = ['respondent', 'researcher'];
        $role = in_array($data['role'] ?? '', $allowedRoles) ? $data['role'] : 'respondent';
        $isResearcher = ($role === 'researcher');
        return $db->insert('users', [
            'email'             => $data['email'],
            'password_hash'     => password_hash($data['password'], PASSWORD_BCRYPT),
            'full_name'         => $data['full_name'],
            'role'              => $role,
            'reputation_score'  => $isResearcher ? 0 : $initialRep,
            'is_active'         => 1,
            'approval_status'   => $isResearcher ? 'pending' : 'approved',
        ]);
    }

    public static function checkRateLimit(): bool
    {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        $db = Database::getInstance();
        $config = require __DIR__ . '/../../config/app.php';
        $maxReqs = $config['rate_limit']['max_requests'] ?? 100;
        $window = $config['rate_limit']['window_minutes'] ?? 60;

        $row = $db->fetchOne(
            "SELECT COUNT(*) as cnt FROM rate_limits WHERE ip_address = ? AND created_at > DATE_SUB(NOW(), INTERVAL ? MINUTE)",
            [$ip, $window]
        );
        $count = ($row['cnt'] ?? 0) ?: 0;

        if ($count >= $maxReqs) {
            Session::setFlash('danger', 'Too many requests. Please slow down.');
            return false;
        }

        $db->insert('rate_limits', [
            'ip_address' => $ip,
            'endpoint'   => $_SERVER['REQUEST_URI'] ?? '',
        ]);
        return true;
    }
}
