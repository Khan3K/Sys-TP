<?php

namespace Core;

class Validator
{
    private array $errors = [];
    private array $data;

    public function __construct(array $data)
    {
        $this->data = $data;
    }

    public function required(string $field, string $label = ''): self
    {
        $label = $label ?: ucfirst(str_replace('_', ' ', $field));
        if (empty(trim($this->data[$field] ?? ''))) {
            $this->errors[$field] = "{$label} is required";
        }
        return $this;
    }

    public function email(string $field, string $label = ''): self
    {
        $label = $label ?: ucfirst(str_replace('_', ' ', $field));
        if (!empty($this->data[$field] ?? '') && !filter_var($this->data[$field], FILTER_VALIDATE_EMAIL)) {
            $this->errors[$field] = "{$label} must be a valid email";
        }
        return $this;
    }

    public function min(string $field, int $length, string $label = ''): self
    {
        $label = $label ?: ucfirst(str_replace('_', ' ', $field));
        if (strlen(trim($this->data[$field] ?? '')) < $length) {
            $this->errors[$field] = "{$label} must be at least {$length} characters";
        }
        return $this;
    }

    public function numeric(string $field, string $label = ''): self
    {
        $label = $label ?: ucfirst(str_replace('_', ' ', $field));
        if (!empty($this->data[$field] ?? '') && !is_numeric($this->data[$field])) {
            $this->errors[$field] = "{$label} must be a number";
        }
        return $this;
    }

    public function inList(string $field, array $list, string $label = ''): self
    {
        $label = $label ?: ucfirst(str_replace('_', ' ', $field));
        if (!empty($this->data[$field] ?? '') && !in_array($this->data[$field], $list)) {
            $this->errors[$field] = "{$label} is invalid";
        }
        return $this;
    }

    public function range(string $field, float $min, float $max, string $label = ''): self
    {
        $label = $label ?: ucfirst(str_replace('_', ' ', $field));
        $val = (float)($this->data[$field] ?? $min - 1);
        if ($val < $min || $val > $max) {
            $this->errors[$field] = "{$label} must be between {$min} and {$max}";
        }
        return $this;
    }

    public function passes(): bool
    {
        return empty($this->errors);
    }

    public function errors(): array
    {
        return $this->errors;
    }

    public function firstError(): string
    {
        return !empty($this->errors) ? reset($this->errors) : '';
    }
}
