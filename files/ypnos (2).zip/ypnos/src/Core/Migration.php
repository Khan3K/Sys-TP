<?php

namespace Core;

class Migration
{
    private Database $db;
    private string $migrationsDir;

    private const TABLE = 'migrations';

    public function __construct(Database $db, ?string $migrationsDir = null)
    {
        $this->db = $db;
        $this->migrationsDir = $migrationsDir ?? __DIR__ . '/../../database/migrations';
    }

    public function ensureTable(): void
    {
        $this->db->query("
            CREATE TABLE IF NOT EXISTS `migrations` (
                id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                migration VARCHAR(255) NOT NULL UNIQUE,
                batch INT UNSIGNED NOT NULL,
                executed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB
        ");
    }

    public function pending(): array
    {
        $this->ensureTable();
        $applied = $this->db->fetchAll("SELECT migration FROM migrations");
        $applied = array_column($applied, 'migration');

        $files = glob($this->migrationsDir . '/*.sql');
        sort($files);

        $pending = [];
        foreach ($files as $f) {
            $name = basename($f);
            if (!in_array($name, $applied, true)) {
                $pending[] = $name;
            }
        }
        return $pending;
    }

    public function migrate(): array
    {
        $pending = $this->pending();
        if (empty($pending)) {
            return ['status' => 'idle', 'message' => 'Nothing to migrate'];
        }

        $batch = $this->nextBatch();
        $executed = [];

        foreach ($pending as $file) {
            $sql = file_get_contents($this->migrationsDir . '/' . $file);
            if (empty(trim($sql))) {
                continue;
            }

            try {
                $this->db->beginTransaction();
                $statements = $this->splitStatements($sql);
                foreach ($statements as $stmt) {
                    if (!empty(trim($stmt))) {
                        $this->db->query($stmt);
                    }
                }
                $this->db->insert('migrations', [
                    'migration' => $file,
                    'batch'     => $batch,
                ]);
                $this->db->commit();
                $executed[] = $file;
            } catch (\Throwable $e) {
                $this->db->rollback();
                return [
                    'status'  => 'error',
                    'file'    => $file,
                    'message' => $e->getMessage(),
                ];
            }
        }

        return ['status' => 'ok', 'executed' => $executed, 'batch' => $batch];
    }

    public function rollback(int $steps = 1): array
    {
        $this->ensureTable();
        $lastBatch = $this->db->fetchOne("SELECT MAX(batch) as b FROM migrations")['b'] ?? 0;
        if ($lastBatch === 0) {
            return ['status' => 'idle', 'message' => 'Nothing to roll back'];
        }

        $target = max(0, $lastBatch - $steps + 1);
        $rolled = [];

        for ($batch = $lastBatch; $batch >= $target; $batch--) {
            $migs = $this->db->fetchAll("SELECT migration FROM migrations WHERE batch = ? ORDER BY migration DESC", [$batch]);
            foreach ($migs as $m) {
                $downFile = $this->migrationsDir . '/' . pathinfo($m['migration'], PATHINFO_FILENAME) . '.down.sql';
                if (!file_exists($downFile)) {
                    continue;
                }
                $sql = file_get_contents($downFile);
                if (!empty(trim($sql))) {
                    try {
                        $this->db->beginTransaction();
                        $statements = $this->splitStatements($sql);
                        foreach ($statements as $stmt) {
                            if (!empty(trim($stmt))) {
                                $this->db->query($stmt);
                            }
                        }
                        $this->db->delete('migrations', 'migration = ?', [$m['migration']]);
                        $this->db->commit();
                        $rolled[] = $m['migration'];
                    } catch (\Throwable $e) {
                        $this->db->rollback();
                        return ['status' => 'error', 'file' => $m['migration'], 'message' => $e->getMessage()];
                    }
                } else {
                    $this->db->delete('migrations', 'migration = ?', [$m['migration']]);
                    $rolled[] = $m['migration'];
                }
            }
        }

        return ['status' => 'ok', 'rolled_back' => $rolled];
    }

    private function nextBatch(): int
    {
        $row = $this->db->fetchOne("SELECT COALESCE(MAX(batch), 0) + 1 as next FROM migrations");
        return (int)($row['next'] ?? 1);
    }

    private function splitStatements(string $sql): array
    {
        $sql = preg_replace('/^-- .*$/m', '', $sql);
        $statements = preg_split('/;\s*$/m', $sql);
        return array_map('trim', $statements);
    }
}
