<?php

namespace Core;

class Csrf
{
    public static function token(): string
    {
        if (empty($_SESSION['_csrf_token'])) {
            $_SESSION['_csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['_csrf_token'];
    }

    public static function validate(string $token): bool
    {
        if (empty($_SESSION['_csrf_token']) || empty($token)) {
            return false;
        }
        return hash_equals($_SESSION['_csrf_token'], $token);
    }

    public static function valid(): bool
    {
        return self::validate($_POST['_csrf_token'] ?? '');
    }

    public static function check(): void
    {
        if (!self::valid()) {
            Session::setFlash('danger', 'Security token expired. Please try again.');
            $referer = $_SERVER['HTTP_REFERER'] ?? '/dashboard';
            Response::redirect($referer);
        }
    }

    public static function field(): string
    {
        return '<input type="hidden" name="_csrf_token" value="' . self::token() . '">';
    }
}
