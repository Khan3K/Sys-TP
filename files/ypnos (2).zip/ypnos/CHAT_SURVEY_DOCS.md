# Ypnos Chat Survey System — Complete Documentation

## Table of Contents

1. [System Overview](#1-system-overview)
2. [Architecture & Files](#2-architecture--files)
3. [Data Model](#3-data-model)
4. [Chat Builder — Create Mode](#4-chat-builder--create-mode)
5. [Chat Builder — Edit Mode](#5-chat-builder--edit-mode)
6. [Answer Scope System (3 Types)](#6-answer-scope-system-3-types)
7. [Respondent Chat Engine](#7-respondent-chat-engine)
8. [Validation Pipeline](#8-validation-pipeline)
9. [AI Engine Configuration](#9-ai-engine-configuration)
10. [AI Response Parsing](#10-ai-response-parsing)
11. [Navigation & Skip Logic](#11-navigation--skip-logic)
12. [Theming & Branding](#12-theming--branding)
13. [Quality Controls](#13-quality-controls)
14. [Template System](#14-template-system)
15. [Sharing & Distribution](#15-sharing--distribution)
16. [Behavioral Tracking & Anti-Cheating](#16-behavioral-tracking--anti-cheating)
17. [Submission Flow](#17-submission-flow)
18. [Keyboard Shortcuts](#18-keyboard-shortcuts)
19. [CSS Animations](#19-css-animations)
20. [API Endpoints](#20-api-endpoints)

---

## 1. System Overview

Ypnos is an AI-powered survey platform with two survey modes:
- **Form Mode**: Traditional question-by-question form surveys
- **Chat Mode**: AI-mediated conversational surveys (the focus of this document)

The chat mode creates a WhatsApp/iMessage-like experience where an AI bot asks questions one at a time, validates answers in real-time, provides follow-ups, and adapts to respondent answers. The system has three layers:

1. **Builder** — Researchers design chat flows, configure AI behavior, and set validation rules
2. **Engine** — The respondent-side JavaScript engine renders the conversation and validates answers
3. **AI Pipeline** — Multi-provider fallback system that validates answer quality in real-time

---

## 2. Architecture & Files

| File | Role | Lines |
|------|------|-------|
| `views/researcher/survey/create-chat.php` | Chat survey builder (create new) | ~1,852 |
| `views/researcher/survey/edit.php` | Survey editor (edit existing, dual-mode form+chat) | ~4,382 |
| `views/respondent/chat_survey.php` | Respondent-facing chat UI + validation engine | ~1,063 |

**Data flow:**
```
Builder (create/edit) → JSON config (hidden inputs) → PHP POST → Database
Database → PHP render → chat_survey.php → JavaScript engine → Respondent
```

---

## 3. Data Model

### 3.1 Chat Config Object (top-level)

Stored in the `chat_config` hidden input as JSON.

```json
{
  "nodes": [ /* array of ChatNode objects */ ],
  "intro_message": "Hello! Welcome to our survey...",
  "tone": "neutral"
}
```

| Field | Type | Values | Description |
|-------|------|--------|-------------|
| `nodes` | `ChatNode[]` | — | Array of question nodes in conversation order |
| `intro_message` | `string` | Free text | Welcome message shown before first question |
| `tone` | `string` | `neutral`, `friendly`, `formal`, `empathetic` | AI conversation tone |

### 3.2 ChatNode Object

Each node represents one question in the conversation.

```json
{
  "id": 42,
  "key": "q_1",
  "question": "How would you rate your experience?",
  "type": "rating",
  "options": ["1", "2", "3", "4", "5"],
  "required": true,
  "sentiment": true,
  "followup": true,
  "depth": 2,
  "followupTemplate": "Can you tell me more about that?",
  "animation": "slide-up",
  "scope_type": "absolute",
  "scope_label": "",
  "answer_scope": ["Excellent", "Good", "Average", "Poor"],
  "min_value": null,
  "max_value": null,
  "min_length": null,
  "max_length": null,
  "placeholder": ""
}
```

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `id` | `number` | auto | Unique node identifier |
| `key` | `string` | `"q_N"` | Response key used in results JSON |
| `question` | `string` | `""` | Question text displayed as bot message |
| `type` | `string` | `"text"` | Input type (see Section 3.3) |
| `options` | `string[]` | `[]` | Choice/rating options |
| `required` | `boolean` | `false` | Whether answer is mandatory |
| `sentiment` | `boolean` | `false` | Enable sentiment analysis for this node |
| `followup` | `boolean` | `false` | Enable AI adaptive follow-ups |
| `depth` | `number` | `1` | Max follow-up chain depth (1-5) |
| `followupTemplate` | `string` | `""` | Custom follow-up question template |
| `animation` | `string` | `"slide-up"` | Message entrance animation |
| `scope_type` | `string` | `"none"` | Answer scope mode: `none`, `absolute`, `set`, `near` |
| `scope_label` | `string` | `""` | Category name (used by `set` scope type) |
| `answer_scope` | `string[]` | `[]` | Accepted answer values |
| `min_value` | `number\|null` | `null` | Minimum value (number type only) |
| `max_value` | `number\|null` | `null` | Maximum value (number type only) |
| `min_length` | `number\|null` | `null` | Minimum character length (text types) |
| `max_length` | `number\|null` | `null` | Maximum character length (text types) |
| `placeholder` | `string` | `""` | Custom input placeholder text |
| `condition` | `object\|null` | `null` | Skip logic condition (see Section 11) |

### 3.3 Question Types

| Type | Value | Input Method | Options Source |
|------|-------|-------------|----------------|
| Text | `text` | Text input | — |
| Number | `number` | Number input | — |
| Rating | `rating` | Rating buttons (1-5) | Default: 1-5 or custom |
| Yes/No | `yes_no` | Choice chips | Fixed: Yes, No |
| MCQ Single | `mcq_single` | Choice chips | Custom options |
| MCQ Multiple | `mcq_multiple` | Choice chips | Custom options |
| NPS | `nps` | Rating buttons (0-10) | Fixed: 0-10 |
| Likert 5 | `likert5` | Rating buttons | Fixed: Strongly Disagree → Strongly Agree |

### 3.4 AI Config Object

Stored in the `ai_config` hidden input as JSON.

```json
{
  "provider": "pollinations",
  "model": "gpt-4o-mini",
  "api_key": "",
  "capabilities": {
    "sentiment": true,
    "followup": true,
    "summarize": true,
    "context_awareness": true
  },
  "system_prompt": "You are a helpful survey assistant...",
  "temperature": 0.7,
  "max_tokens": 200
}
```

| Field | Type | Description |
|-------|------|-------------|
| `provider` | `string` | AI provider selection |
| `model` | `string` | Model identifier |
| `api_key` | `string` | API key (stripped before client-side rendering) |
| `capabilities` | `object` | Feature flags for AI behavior |
| `system_prompt` | `string` | Custom system prompt override |
| `temperature` | `number` | 0.0-2.0, controls response creativity |
| `max_tokens` | `number` | Max response length |

---

## 4. Chat Builder — Create Mode

**File:** `views/researcher/survey/create-chat.php`

### 4.1 Page Sections

| Section | ID | Purpose | Collapsible |
|---------|-----|---------|-------------|
| Survey Identity | `ci-identity` | Title and description | Yes |
| Templates | `ci-templates` | Browse and apply templates | Yes |
| Chat Builder | `ci-chat-builder` | Intro message, tone, node list | Yes |
| AI Engine Config | `ci-ai-config` | Provider, model, capabilities | Yes |
| Branding | `ci-branding` | Theme, background, card style, fonts | Yes |
| Who Can Respond | `ci-access` | Auth type, password, max responses | Yes |
| Status & Visibility | `ci-vis-body` | Draft/Active/Closed, date range | Yes |
| Quality Controls | `ci-qc` | Anti-bot, response quality, focus, gamification | Yes |

### 4.2 Node List

- Displays all chat nodes as cards with type badges
- Each card shows: question text, type label, feature badges (Sentiment, Follow-up, Required, Scope)
- Drag-and-drop reordering via grip handle
- Action buttons: Edit, Duplicate, Delete
- Empty state with "Add Question" CTA

### 4.3 Node Editor Modal

The modal contains these field groups:

1. **Question Text** — textarea for the question
2. **Response Type** — dropdown (text, rating, yes_no, mcq_single, mcq_multiple, number, nps, likert5)
3. **Options** — dynamic input list (shown for MCQ/rating types)
4. **Validation** — min/max value (number type)
5. **Text Length Limits** — min/max character length (text types)
6. **Answer Scope** — type picker + items (see Section 6)
7. **AI Behavior** — sentiment toggle, follow-up toggle, depth, template
8. **Message Animation** — dropdown (slide-up, fade-in, scale-in, none)
9. **Required** — toggle switch

### 4.4 Chat Config Serialization

`updateChatConfig()` serializes to two hidden inputs:
- `chat-config-input`: Full config `{nodes, intro_message, tone}` for PHP backend
- `questions-json`: Just the nodes array for the main form

### 4.5 Chat Preview

Right sidebar shows a phone-shaped live preview:
- Renders bot/user message bubbles
- Shows typing indicator
- Updates in real-time as nodes are added/edited
- Reflects theme colors, card styles, and fonts

---

## 5. Chat Builder — Edit Mode

**File:** `views/researcher/survey/edit.php`

### 5.1 Dual-Mode Editor

The edit page supports both Form and Chat modes:
- Toggle buttons switch between editing zones
- Data converts between modes via `convertSurveyModeData()`
- Chat config stored in `eb-chat-config-input` hidden field

### 5.2 Chat Node Modal (Edit)

Same fields as Create mode but with additional:
- **Skip Logic** — conditional field/operator/value inputs for branching
- **Follow-up** — dropdown (No follow-up, Light probe, Deep dive)

### 5.3 Quick-Add

`quickAddChat(type)` adds pre-configured nodes:
- Text, Number, MCQ, Rating, Yes/No with sensible defaults

### 5.4 AI Assistant Panel

Slide-out panel with two tabs:
- **Generate** — AI generates entire surveys from a topic description
- **Chat** — Interactive AI chat for question refinement and suggestions

---

## 6. Answer Scope System (3 Types)

The answer scope system controls how strictly the engine validates respondent answers against a predefined list of acceptable values. It operates at two levels: **local validation** (client-side JavaScript) and **AI validation** (server-side AI prompt).

### 6.1 Scope Types Overview

| Type | Icon | Local Validation | AI Prompt | Use Case |
|------|------|-----------------|-----------|----------|
| **None** | `fa-times` | No validation | No scope rules | Free-text questions |
| **Absolute** | `fa-lock` | Strict edit-distance | "Reject anything not in this exact list" | Exact values: Yes/No, countries, specific items |
| **Set** | `fa-layer-group` | Strict edit-distance | "These are [category]. Accept only valid members" | Categorized items: car brands, emotions, tools |
| **Near** | `fa-wave-square` | Skipped (defers to AI) | "Accept semantically related/adjacent answers" | Concepts, qualitative data, related ideas |

### 6.2 Data Model Extension

```js
node.scope_type = "none" | "absolute" | "set" | "near"
node.scope_label = ""  // Category name (only used by "set" type)
node.answer_scope = ["item1", "item2", ...]  // Accepted values (all types)
```

Backward compatibility: nodes without `scope_type` default to `"absolute"`.

### 6.3 Builder UI

Both create and edit builders show the same scope editor inside the node modal:

```
+----------------------------------------------+
| Answer Scope (optional)                      |
|                                              |
| [None] [Absolute] [Set] [Near]               |
|  ^^^^  pill button picker                    |
|                                              |
| (shown when type = "set"):                   |
| Category Name: [Car Brands_____]             |
|                                              |
| (shown when type != "none"):                 |
| Accepted Values (one per line):              |
| +------------------------------------------+ |
| | Honda                                    | |
| | BMW                                      | |
| | Toyota                                   | |
| +------------------------------------------+ |
|                                              |
| Hint text changes per type:                  |
|  - Absolute: "Only exact answers accepted"   |
|  - Set: "AI checks category membership"      |
|  - Near: "Lenient semantic matching"         |
+----------------------------------------------+
```

### 6.4 Local Validation Logic (`validateAnswerScope`)

Located in `chat_survey.php` line 528.

```
function validateAnswerScope(node, answer):
  1. If scope is empty -> return null (no validation)
  2. If scope_type is "near" -> return null (skip local, defer to AI)
  3. Normalize answer: lowercase, strip accents, remove non-alphanumeric
  4. For each scope item:
     a. If normalized answer === normalized item -> ACCEPT (exact match)
     b. Calculate Levenshtein edit distance
     c. Track closest item
  5. Check if answer is close enough for CONFIRM:
     - Answer >= 3 chars AND item >= 3 chars
     - First character matches
     - Edit distance <= 25% of item length
     -> Return CONFIRM with canonical spelling
  6. If scope_type is "set" and has scope_label:
     -> "Please answer with a valid [label] (e.g. [first 3 items])"
  7. Otherwise:
     -> "Please answer with one of: [all items]"
```

**Normalization** (`normalizeScopeAnswer`):
```
"  Honda!  " -> "honda"
"I think BMW" -> "bmw"
"Nono" -> "nono"
```

**Edit Distance Example:**
```
Answer: "Hond"   Item: "Honda" -> distance: 1, threshold: 1 -> CONFIRM
Answer: "Toyta"  Item: "Toyota" -> distance: 1, threshold: 1 -> CONFIRM
Answer: "Hondaa" Item: "Honda" -> distance: 1, threshold: 1 -> CONFIRM
Answer: "Tesla"  Item: "Honda" -> distance: 5, threshold: 1 -> RETRY
```

### 6.5 AI Prompt Per Scope Type

**Absolute scope:**
```
Accepted answer scope (strict): ["Honda", "BMW", "Toyota"].
Reject answers outside this scope. If the answer is clearly a
misspelling of one item, use CONFIRM with only the corrected item.
```

**Set scope (with category label):**
```
Accepted answer scope (category: Car Brands): ["Honda", "BMW", "Toyota"].
The answer must be a valid member of this category. If the answer is
clearly a misspelling of one item, use CONFIRM with only the corrected
item. Reject items that do not belong to this category.
```

**Near scope:**
```
Answer anchors (lenient): ["transportation", "vehicles", "mobility"].
These are examples of acceptable answers. Accept any answer that is
SEMANTICALLY RELATED or NEARBY in meaning to these anchors. Broader,
narrower, or synonymous concepts are all fine.
```

### 6.6 Node Card Badges

Scope is displayed in the node list as a colored badge:

| Scope Type | Badge Example | Badge Color |
|------------|---------------|-------------|
| Absolute (3 items) | `lock 3 absolute` | Cyan |
| Set (5 items) | `layers 5 set` | Cyan |
| Near (4 items) | `waves 4 near` | Cyan |

---

## 7. Respondent Chat Engine

**File:** `views/respondent/chat_survey.php`

### 7.1 Initialization

1. PHP renders theme config, chat config, AI config as JSON
2. JavaScript IIFE captures all config as constants
3. DOM references cached at startup
4. Event listeners attached (send button, Enter key, skip button, restart, finish)
5. `startSurvey()` called immediately

### 7.2 Survey Start Flow

```
startSurvey()
  -> Show typing indicator (1 second delay)
  -> getNextNodeIndex() -- finds first node without unmet conditions
  -> renderNode(nodes[index])
    -> addBotMessage(question text)
    -> renderNodeInput(node) -- shows appropriate input method
```

### 7.3 Message Rendering

**Bot messages** (`addBotMessage`):
- Robot avatar with gradient background
- White/light bubble with shadow
- Timestamp (HH:MM format)
- Merges with previous bot messages (hides avatar, adjusts spacing)

**User messages** (`addUserMessage`):
- Gradient bubble matching theme color
- White text
- Timestamp
- Merges with previous user messages

**Message merge logic:**
- Uses `data-merge="true"` attribute on consecutive same-role messages
- Merged messages: avatar hidden, timestamp hidden, reduced spacing
- Border radius adjusted (top corners become rounded)

### 7.4 Input Methods

| Node Type | Input Rendered | Container |
|-----------|---------------|-----------|
| `text`, `number`, `file_upload` | Textarea with auto-resize | `#chat-input-area` |
| `choice`, `yes_no`, `mcq_single`, `mcq_multiple` | Choice chips (clickable pills) | `#chat-choices-container` (appended to messages) |
| `rating`, `likert5`, `nps` | Numbered rating buttons | `#chat-choices-container` (appended to messages) |
| `file_upload`, `file`, `image` | Text input with URL/description hint | `#chat-input-area` |

### 7.5 Auto-Resize Textarea

- Input grows with content up to `max-height: 128px`
- Character counter shows remaining characters
- Warning at <200 chars remaining (amber color)
- Critical warning at <50 chars (theme color)
- Send button disabled when empty or processing

### 7.6 Progress Tracking

- Progress bar in header: `answered / total` percentage
- Current question counter
- Updates after each answer

---

## 8. Validation Pipeline

Every answer goes through a multi-stage validation pipeline:

```
User types answer
       |
  processAnswer(answer)
       |
  +-- Pending correction? -> Handle yes/no confirmation
  |
  +-- Empty? -> "Please type something"
  |
  +-- validateAnswerScope(node, answer)
  |   +-- near -> null (skip)
  |   +-- exact match -> ACCEPT immediately
  |   +-- close match -> CONFIRM (ask yes/no)
  |   +-- no match -> RETRY with error
  |
  +-- Type-specific shortcuts:
  |   +-- file/image types -> proceed immediately
  |   +-- choice/rating types -> proceed immediately
  |   +-- number type (valid format) -> proceed immediately
  |
  +-- localValidate(node, answer)
  |   +-- Single char / repeated chars -> RETRY
  |   +-- Repeating the question -> EXPLAIN
  |   +-- "where" question with irrelevant answer -> EXPLAIN
  |   +-- "who" question with irrelevant answer -> EXPLAIN
  |   +-- Confusion phrases ("i don't know") -> EXPLAIN
  |
  +-- validateWithAI(answer)
      +-- Build prompt with scope rules + context
      +-- Try provider chain (fallback on error)
      +-- Handle AI response:
          +-- ACCEPT -> save answer, advance
          +-- RETRY -> increment try count, maybe show skip
          +-- CONFIRM -> ask yes/no for correction
          +-- EXPLAIN -> show clarification message
          +-- CLARIFY -> show AI's clarification
          +-- OFFER_SKIP -> show skip button
```

### 8.1 Local Validation Rules (`localValidate`)

| Rule | Condition | Response |
|------|-----------|----------|
| Too short | `answer.length <= 1` | RETRY: "Please provide a more complete answer" |
| Repeated chars | `/(.)\1{2,}/.test(answer)` | RETRY: "Please type a real answer" |
| Repeating question | Answer contains question core word | EXPLAIN: "Please answer in your own words" |
| Where + irrelevant | Question has "where" + generic answer | EXPLAIN: "I asked about your location..." |
| Who + irrelevant | Question has "who" + generic answer | EXPLAIN: "I asked who someone is..." |
| Confusion detected | Any confusion phrase found | EXPLAIN: "No problem! Take your time..." |

**Confusion phrases detected:**
```
"i dont know", "i don't know", "i dunno", "not sure",
"i don't understand", "i dont understand", "i don't get",
"i dont get", "i'm confused", "im confused", "i am confused",
"i dont know what", "i don't know what", "i dont", "i don't"
```

**Irrelevant answers for where/who questions:**
```
"good", "bad", "ok", "okay", "fine", "yes", "no", "maybe",
"idk", "dunno", "sure", "nice", "cool", "great", "awesome",
"wow", "lol", "lmao", "xd", "hmm", "meh", "whatever",
"nothing", "nope", "yeah", "nah", "yep", "perhaps"
```

### 8.2 Try Count & Skip

- `currentTryCount` tracks failed attempts per question
- `MAX_RETRIES = 5` -- after 5 failed attempts, skip button is offered
- Skip records `[SKIPPED]` as the answer and advances

---

## 9. AI Engine Configuration

### 9.1 Provider Chain

The system cascades through multiple AI providers as fallback:

| Priority | Provider | Auth | Cost | Notes |
|----------|----------|------|------|-------|
| 1 | Pollinations (Free API) | None | Free | `text.pollinations.ai` endpoint |
| 2 | Puter (Browser AI) | None | Free | Client-side via `puter.ai.chat()` |
| 3 | OpenAI | API Key | Paid | User-configured |
| 4 | Claude | API Key | Paid | User-configured |
| 5 | Gemini | API Key | Paid | User-configured |
| 6 | DeepSeek | API Key | Paid | User-configured |

### 9.2 Provider Selection (Builder)

```javascript
// Available providers in builder
const providers = ['none', 'browser', 'pollinations', 'openai', 'claude', 'gemini', 'deepseek', 'puter'];

// Model options per provider
const aiModelOptions = {
  browser: ['Xenova/all-MiniLM-L6-v2'],
  pollinations: ['pollinations/ai'],
  openai: ['gpt-4o-mini', 'gpt-4o'],
  claude: ['claude-3-haiku', 'claude-3-sonnet'],
  gemini: ['gemini-2.0-flash'],
  deepseek: ['deepseek-chat', 'deepseek-reasoner'],
  puter: ['gemini-3.1-pro-preview', 'gpt-4o', 'claude-sonnet-4-20250514', 'claude-3.5-haiku-20241022']
};
```

### 9.3 AI Capabilities (Feature Flags)

| Capability | Config Key | Effect |
|------------|------------|--------|
| Sentiment Analysis | `sentiment` | Includes sentiment detection in prompt |
| Adaptive Follow-ups | `followup` | Allows AI to ask follow-up questions |
| Summarize | `summarize` | Enables response summarization |
| Context Aware | `context_awareness` | Includes full conversation history in prompt |

When `context_awareness` is enabled, the AI prompt includes the full conversation:
```
Full conversation history (previous questions and answers for context):
Assistant: How are you feeling today?
Respondent: Pretty good actually
Assistant: That's great to hear! What made today good?
```

### 9.4 AI Error Detection (`isAIError`)

The system detects AI errors through multiple methods:

1. **Length heuristic**: Messages >300 chars with 3+ tech keywords
2. **Keyword matching**: 30+ error-related keywords
3. **Regex patterns**: Stack traces, API errors, provider failures

**Detected keywords:**
```
"cannot read", "does not support", "error:", "api error",
"i can't", "i am unable", "not able to", "sorry, but i",
"failed to", "rate limit", "quota exceeded", "bad request",
"internal server", "service unavailable", "gateway timeout", ...
```

When an error is detected, the AI response is treated as ACCEPT to prevent blocking the survey.

---

## 10. AI Response Parsing

### 10.1 Prefix-Based Protocol

AI responses use a prefix protocol:

| Prefix | Action | Meaning |
|--------|--------|---------|
| `ACCEPT:` | Accept answer | Answer is good, save and advance |
| `CONFIRM:` | Confirm correction | Propose corrected spelling, ask yes/no |
| `RETRY:` | Reject answer | Answer is bad, ask again |
| `EXPLAIN:` | Clarify question | Respondent misunderstood, rephrase |
| `CLARIFY:` | Provide clarification | Answer the respondent's question about the question |
| `OFFER_SKIP:` | Offer skip | Let respondent skip this question |

**Example AI responses:**
```
ACCEPT: Great, thanks for sharing that! Let's move on.
CONFIRM: Did you mean "Honda"?
RETRY: I didn't quite catch that. Could you please type a real answer?
EXPLAIN: I asked about your location - could you tell me where you are right now? Like "at home" or "in New York"?
```

### 10.2 CONFIRM Flow

When AI returns CONFIRM:
1. `pendingCorrection` is set to the corrected value
2. Bot asks: `Did you mean "[correction]"? Please answer Yes or No.`
3. User responds with yes/no variant
4. If yes -> corrected answer saved, advance
5. If no -> clear correction, ask to re-type
6. If other -> re-prompt yes/no

---

## 11. Navigation & Skip Logic

### 11.1 Node Navigation

`getNextNodeIndex()` advances through nodes sequentially, skipping any with unmet conditions:

```javascript
function getNextNodeIndex() {
  nextIdx = currentNodeIndex + 1;
  while (nextIdx < nodes.length) {
    if (node.condition) {
      prevAnswer = responses[node.condition.field] || '';
      if (condition not met) { nextIdx++; continue; }
    }
    return nextIdx;
  }
  return nodes.length;  // No more nodes
}
```

### 11.2 Skip Logic (Conditional Branching)

Each node can have a condition that determines if it should be shown:

```json
{
  "condition": {
    "field": "q_1",
    "operator": "contains",
    "value": "yes"
  }
}
```

**Operators:**
| Operator | Logic |
|----------|-------|
| `equals` | Previous answer exactly matches value (case-insensitive) |
| `contains` | Previous answer contains value substring |
| `not_contains` | Previous answer does NOT contain value substring |

**Example:**
- Node 1: "Do you own a car?" -> answer: "Yes"
- Node 2: condition `{field: "q_1", operator: "equals", value: "yes"}` -> SHOWN
- Node 3: condition `{field: "q_1", operator: "equals", value: "no"}` -> SKIPPED

### 11.3 Skip Button

- Appears after `MAX_RETRIES` (5) failed attempts
- Records `[SKIPPED]` as the answer
- Proceeds to next node

---

## 12. Theming & Branding

### 12.1 Theme Colors (12 options)

| Key | Color | Gradient |
|-----|-------|----------|
| `emerald` | Green | `from-emerald-500 to-emerald-600` |
| `indigo` | Purple | `from-indigo-500 to-indigo-600` |
| `amber` | Orange | `from-amber-500 to-amber-600` |
| `rose` | Pink | `from-rose-500 to-rose-600` |
| `cyan` | Light blue | `from-cyan-500 to-cyan-600` |
| `violet` | Violet | `from-violet-500 to-violet-600` |
| `teal` | Teal | `from-teal-500 to-teal-600` |
| `red` | Red | `from-red-500 to-red-600` |
| `orange` | Orange | `from-orange-500 to-orange-600` |
| `pink` | Pink | `from-pink-500 to-pink-600` |
| `blue` | Blue | `from-blue-500 to-blue-600` |
| `slate` | Gray | `from-slate-500 to-slate-600` |

### 12.2 Background Presets (12 options)

| Key | Style | Dark Mode |
|-----|-------|-----------|
| `glass` | Frosted glass gradient | No |
| `warm` | Amber/orange gradient | No |
| `cool` | Sky/blue gradient | No |
| `dark` | Near-black gradient | Yes |
| `mountain` | Indigo/purple dark | Yes |
| `sunset` | Orange/rose/purple dark | Yes |
| `ocean` | Cyan/blue/indigo dark | Yes |
| `forest` | Green/teal dark | Yes |
| `midnight` | Slate/zinc dark | Yes |
| `lavender` | Violet/fuchsia light | No |
| `peach` | Amber/orange light | No |
| `particles` | Gray/indigo dark | Yes |

### 12.3 Card Styles (7 options)

| Key | Description |
|-----|-------------|
| `glass` | Transparent glass with blur |
| `solid` | Solid white with subtle shadow |
| `bordered` | White with colored border |
| `ghost` | Transparent with thin border |
| `dark-glass` | Dark glass with blur |
| `neumorphic` | Soft shadows (light/dark) |
| `gradient` | Gradient background |

### 12.4 Border Radius (8 options)

`none`, `sm`, `md`, `lg`, `xl`, `2xl`, `3xl`, `full`

### 12.5 Shadow Levels (8 options)

`none`, `sm`, `md`, `lg`, `xl`, `2xl`, `inner`

### 12.6 Font Families (8 options)

`System Default`, `Inter`, `DM Sans`, `Plus Jakarta Sans`, `Georgia (Serif)`, `Courier New (Mono)`, `Nunito`, `Poppins`

### 12.7 Background Types

| Type | Fields |
|------|--------|
| `gradient` | CSS gradient value |
| `solid` | Single hex color |
| `image` | Image URL |
| `video` | Video URL |

### 12.8 Theme Config Serialization

All theme options are serialized to `theme-config-input` as JSON:
```json
{
  "theme": "emerald",
  "bg": "glass",
  "card": "glass",
  "radius": "xl",
  "shadow": "lg",
  "font": "inherit",
  "animation": "slide-up",
  "custom_css": "",
  "bg_type": "gradient",
  "bg_value": "",
  "bg_image": "",
  "bg_video": "",
  "logo_url": ""
}
```

---

## 13. Quality Controls

### 13.1 Anti-Bot & Security

| Check | Key | Description |
|-------|-----|-------------|
| Honeypot | `honeypot` | Hidden form field that catches bots |
| Math CAPTCHA | `captcha` | Simple math puzzle |
| IP Rate Limit | `ip_rate_limit` | Block repeat IPs |
| Browser Fingerprint | `browser_fingerprint` | Unique browser ID |
| VPN Detection | `vpn_detection` | Flag proxy users |

### 13.2 Response Quality

| Check | Key | Description |
|-------|-----|-------------|
| Block Duplicates | `prevent_duplicates` | One response per user |
| Straight-Line Detection | `detect_straightline` | Same answer pattern |
| Input Validation | `validate_input` | Email/phone format |
| AI Detection | `ai_detection` | Flag GPT-generated answers |
| Language Check | `language_consistency` | Consistent language |

### 13.3 Focus & Integrity

| Check | Key | Description |
|-------|-----|-------------|
| Prevent Back | `prevent_back_nav` | Disable back button |
| No Copy-Paste | `prevent_copy_paste` | Disable paste |
| Track Tabs | `track_tab_switches` | Detect tab switches |
| Attention Check | `require_attention` | Mandatory focus test |
| Fullscreen | `fullscreen_mode` | Force fullscreen |
| No Right-Click | `disable_rightclick` | Disable context menu |
| Confirm Answers | `confirm_answers` | Review before submit |

### 13.4 Progression & Gamification

| Check | Key | Description |
|-------|-----|-------------|
| Sequential Unlock | `sequential_unlock` | One question at a time |
| Quiz Mode | `quiz_mode` | Scoring + lives system |
| Shuffle Questions | `shuffle_questions` | Random order |
| Shuffle Options | `shuffle_options` | Random choice order |
| Allow Resume | `allow_resume` | Save & continue later |
| Time Per Question | `time_per_question` | Per-question timer |

### 13.5 Quiz Mode Settings

When quiz mode is enabled:

| Setting | Default | Description |
|---------|---------|-------------|
| `quiz_pass_score` | 70 | Minimum % to pass |
| `quiz_lives` | 3 | Number of attempts |
| `quiz_timer_per_q` | 30 | Seconds per question |
| `quiz_show_answers` | false | Reveal correct answers |

**Scoring:** Correct = +1, Wrong = lose life, 3+ correct = streak bonus

### 13.6 Advanced Verification

| Check | Key | Description |
|-------|-----|-------------|
| Email Domain | `email_domain_verify` | Verify email domain |
| Timezone Check | `geo_timezone_check` | Match IP timezone |

### 13.7 Numeric Thresholds

| Setting | Default | Description |
|---------|---------|-------------|
| `min_time_seconds` | 30 | Minimum survey completion time |
| `min_text_length` | 10 | Minimum characters per text answer |
| `inactivity_timeout` | 300 | Auto-submit after inactivity |
| `inactivity_warn_before` | 30 | Warn before timeout |
| `max_idle_seconds` | 300 | Max idle time |

---

## 14. Template System

### 14.1 Built-in Templates (6 templates)

| Key | Name | Description | Nodes |
|-----|------|-------------|-------|
| `csat` | CSAT Survey | Customer satisfaction | 4 nodes |
| `nps` | NPS Survey | Net Promoter Score | 3 nodes |
| `feedback` | Feedback | General feedback | 3 nodes |
| `quiz` | Quiz | Knowledge check | 4 nodes |
| `onboarding` | Onboarding | New user onboarding | 3 nodes |
| `research` | Research | Academic research | 3 nodes |

### 14.2 Template Node Structure

Each template node includes:
```json
{
  "question": "How would you rate your overall experience?",
  "type": "rating",
  "options": [],
  "required": true,
  "sentiment": true,
  "followup": true,
  "depth": 2,
  "scope_type": "none",
  "scope_label": "",
  "answer_scope": []
}
```

### 14.3 Template Application

When a template is selected:
1. All existing nodes are cleared
2. Template nodes are cloned and assigned new IDs
3. Node counter is reset
4. Template key is saved to hidden input
5. Chat preview and node list update

---

## 15. Sharing & Distribution

### 15.1 Share URL

Base format: `{baseUrl}/survey/take/{surveyId}`

### 15.2 Short URLs

Custom short URLs with options:
- **Slug** -- Custom path segment
- **Password** -- Access protection
- **Expiry** -- Automatic deactivation date
- **Max Uses** -- Usage limit

### 15.3 QR Code

Generated from the share URL for easy mobile access.

### 15.4 Auth Options

| Type | Description |
|------|-------------|
| `anyone` | No login needed (anonymous) |
| `password` | Shared password required |
| `email` | Email verification required |
| `google` | Google OAuth login only |
| `any_account` | Any registered user |

---

## 16. Behavioral Tracking & Anti-Cheating

### 16.1 Events Tracked

```javascript
behaviorLog.push({
  event_type: "tab_switch" | "focus_loss" | ...,
  event_data: { action: "switched_away" | "returned" | ... },
  timestamp_ms: Date.now(),
  question_index: currentQuestionIndex
});
```

### 16.2 Tracked Behaviors

| Event | Trigger | Data |
|-------|---------|------|
| `tab_switch` | `visibilitychange` | `switched_away` / `returned` |
| `focus_loss` | `window blur/focus` | `blur` / `focus` |

### 16.3 Activity Monitoring

- `lastActivityMs` updated on: click, keydown, mousemove, focus return
- Inactive seconds calculated at submission: `(Date.now() - lastActivityMs) / 1000`
- Tab switch count tracked in `tabSwitches` variable

### 16.4 Device Fingerprint

Lightweight fingerprint assembled at submission:
```
userAgent | language | platform | screenWidth | screenHeight
```
Truncated to 250 characters.

---

## 17. Submission Flow

### 17.1 Finish Button

When respondent completes all questions:
1. Input area hides, done area shows
2. Final count displayed
3. "Finish & Submit" button appears with pulse animation
4. "Start over" option available

### 17.2 Submission Payload

```javascript
// JSON payload
{
  responses: { "q_1": "answer1", "q_2": "answer2", ... },
  conversation: [{ role: "bot", message: "..." }, ...],
  config: { survey_id: "...", response_id: "..." }
}

// FormData fields
{
  _csrf_token: "...",
  survey_id: "...",
  response_id: "...",
  chat_responses: "{JSON payload}",
  survey_type: "chat",
  tab_switches: "3",
  _inactive_seconds: "45",
  _behavior_log: "[{event...}]",
  device_fingerprint: "Mozilla/5.0|en-US|..."
}
```

### 17.3 Submission Handler

1. Button shows spinner, disabled
2. `fetch()` POST to form action URL
3. On redirect -> follow redirect
4. On success -> navigate to dashboard
5. On error -> re-enable button, show error message

---

## 18. Keyboard Shortcuts

### 18.1 Chat Builder Shortcuts

| Key | Action |
|-----|--------|
| `Q` | Quick-add Text question |
| `Shift+Q` | Open Custom question modal |
| `Ctrl+Z` | Undo last action |
| `Ctrl+Shift+Z` | Redo |
| `E` | Edit selected question |
| `D` | Duplicate selected |
| `Delete` | Remove selected |
| `/` | Focus question search |
| `Ctrl+S` | Save survey |

### 18.2 Respondent Chat

| Key | Action |
|-----|--------|
| `Enter` | Send message |
| `Shift+Enter` | New line in textarea |

---

## 19. CSS Animations

### 19.1 Message Animations

| Animation | Keyframe | Effect |
|-----------|----------|--------|
| `msgIn` | opacity 0->1, translateY 16px->0, scale 0.97->1 | Message entrance |
| `bubblePop` | opacity 0->1, scale 0.85->1, translateX -8px->0 | Bot bubble pop |
| `bubbleSlide` | opacity 0->1, scale 0.85->1, translateX 8px->0 | User bubble slide |

### 19.2 UI Animations

| Animation | Effect |
|-----------|--------|
| `animate-scale-in` | Scale 0.95->1 with fade |
| `slideUp` | Translate Y 8px->0 with fade |
| `onlinePulse` | Pulsing green glow ring |
| `brainGlow` | Border color pulse for AI messages |
| `thinkingBounce` | 3-dot typing indicator bounce |
| `dotBounce` | Staggered dot animation |
| `donePop` | Celebration animation on completion |
| `finishPulse` | Pulsing shadow on finish button |

### 19.3 Message Merge CSS

```css
.chat-msg[data-merge="true"] .msg-avatar { visibility: hidden; }
.chat-msg[data-merge="true"] .msg-time { display: none; }
.chat-msg[data-merge="true"] { margin-top: -6px; }
.chat-msg.bot[data-merge="true"] .bot-bubble { border-top-left-radius: 12px; }
.chat-msg.user-msg[data-merge="true"] { margin-top: -4px; }
.chat-msg.user-msg[data-merge="true"] .user-bubble { border-top-right-radius: 12px; }
```

### 19.4 Scrollbar Customization

```css
#chat-messages::-webkit-scrollbar { width: 4px; }
#chat-messages::-webkit-scrollbar-thumb { background: themeColor + 30; border-radius: 2px; }
#chat-messages::-webkit-scrollbar-track { background: transparent; }
```

---

## 20. API Endpoints

### 20.1 AI Chat Endpoint

```
POST /api/ai/chat
Content-Type: application/json

{
  "provider": "openai",
  "response_id": "...",
  "model": "gpt-4o-mini",
  "messages": [{ "role": "user", "content": "..." }],
  "system_prompt": "You are a smart survey response validator...",
  "temperature": 0.3,
  "max_tokens": 200
}

Response:
{ "success": true, "text": "ACCEPT: Great answer!" }
```

### 20.2 AI Models Endpoint

```
GET /api/ai/models?provider=openai

Response:
{ "models": ["gpt-4o-mini", "gpt-4o"] }
```

### 20.3 Question Generation Endpoint

```
POST /api/questions/generate

{
  "topic": "Customer satisfaction",
  "count": 10,
  "mode": "form"
}

Response:
{ "questions": [...] }
```

### 20.4 Survey Submission

```
POST /survey/take/{surveyId}
Content-Type: multipart/form-data

Fields:
  _csrf_token, survey_id, response_id, chat_responses,
  survey_type, tab_switches, _inactive_seconds,
  _behavior_log, device_fingerprint
```

---

## Appendix A: Complete Validation Prompt Template

```
You are a strict but helpful survey assistant. Your job is to validate
answers and guide the respondent.

Current question: "{question}" (type: {type})
{scope_rule}
{context}

New answer from respondent: "{answer}"

IMPORTANT -- Decide what to do. Respond with EXACTLY one prefix line
followed by your message:

ACCEPT: Use ONLY when the answer genuinely and meaningfully addresses
the question. The answer must be RELEVANT to what was asked. Follow
with a brief warm acknowledgment (max 1 sentence) that restates key
information from the answer and transitions to next topic.

RETRY: Use when the answer is gibberish, meaningless, outside the
accepted answer scope, just a single random character/letter, keyboard
smash (like "asdf", "qqq", "jjjj"), or completely non-responsive.
Follow with a gentle prompt asking for a real answer (max 1 sentence).

CONFIRM: Use when the answer is relevant but contains a clear likely
spelling mistake. After the prefix output ONLY the corrected answer,
not a sentence. Never correct names, opinions, or uncertain wording.

EXPLAIN: Use when the answer is OFF-TOPIC or shows the respondent
clearly misunderstood what was being asked. Follow with a clarifying
rephrasing of the question and an example of what kind of answer is
expected (1-2 sentences). Help them narrow down.

Rules:
- The answer MUST be RELEVANT to the specific question asked.
- Single characters, random letters, or gibberish are ALWAYS rejected.
- Off-topic answers that show misunderstanding get EXPLAIN.
- Never ACCEPT a likely misspelling when a clear correction exists.
- Be warm and helpful, but firm about answer quality.
```

## Appendix B: Configuration Defaults

| Config | Default Value |
|--------|---------------|
| `intro_message` | "Hello! I'll be asking you some questions today..." |
| `tone` | `"neutral"` |
| `ai_provider` | `"pollinations"` |
| `ai_temperature` | `0.7` |
| `ai_max_tokens` | `200` |
| `quality_threshold` | `70` |
| `auth_type` | `"anyone"` |
| `status` | `"draft"` |
| `animation` | `"slide-up"` |
| `scope_type` | `"none"` |
| `MAX_RETRIES` | `5` |
| `MAX_LOG_ENTRIES` | `200` |
