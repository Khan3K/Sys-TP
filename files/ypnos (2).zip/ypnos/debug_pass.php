<?php
/**
 * debug_pass.php — Standalone user management toolbox.
 * Access: http://localhost/dashboard/ypnos/debug_pass.php
 * NO AUTH, NO TOKEN, NO RESTRICTIONS.  Use at your own risk.
 */

// ---- Bootstrap -----------------------------------------------------------
spl_autoload_register(function ($class) {
    $map = [
        'Core\\' => 'src/Core/',
        'Controllers\\' => 'src/Controllers/',
        'Quality\\' => 'src/Quality/',
        'Quality\\Checks\\' => 'src/Quality/Checks/',
        'Helpers\\' => 'src/Helpers/',
        'Services\\' => 'src/Services/',
    ];
    foreach ($map as $prefix => $dir) {
        if (strncmp($class, $prefix, strlen($prefix)) === 0) {
            $file = __DIR__ . '/' . $dir . substr($class, strlen($prefix)) . '.php';
            if (file_exists($file)) { require $file; return; }
        }
    }
});

$config   = require __DIR__ . '/config/app.php';
$dbConfig = require __DIR__ . '/config/database.php';

\Core\Database::init($dbConfig);
$db = \Core\Database::getInstance();

$baseUrl = $config['base_url'] ?? '';

// ---- Get a valid admin_id for logging ------------------------------------
$adminUser = $db->fetchOne("SELECT id FROM users WHERE role = 'admin' ORDER BY id LIMIT 1");
$logAdminId = $adminUser ? (int)$adminUser['id'] : 0;

// ---- Handle POST actions -------------------------------------------------
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    try {
        if ($action === 'reset_password') {
            $userId   = (int)($_POST['user_id'] ?? 0);
            $password = $_POST['password'] ?? '';

            if (!$userId || strlen($password) < 6) {
                $message = '<div class="msg error">Password must be at least 6 characters.</div>';
            } else {
                $user = $db->fetchOne("SELECT id, email, full_name FROM users WHERE id = ?", [$userId]);
                if (!$user) {
                    $message = '<div class="msg error">User not found.</div>';
                } else {
                    $db->update('users', ['password_hash' => password_hash($password, PASSWORD_BCRYPT)], 'id = ?', [$userId]);
                    $db->insert('admin_logs', [
                        'admin_id'     => $logAdminId,
                        'action'       => 'debug_password_reset',
                        'details_json' => json_encode(['target_user_id' => $userId, 'target_email' => $user['email']]),
                        'ip_address'   => $_SERVER['REMOTE_ADDR'] ?? '',
                    ]);
                    $message = '<div class="msg ok">Password reset for <b>' . htmlspecialchars($user['full_name'] ?: $user['email']) . '</b></div>';
                }
            }
        }

        if ($action === 'edit_user') {
            $userId = (int)($_POST['user_id'] ?? 0);
            if (!$userId) {
                $message = '<div class="msg error">Invalid user.</div>';
            } else {
                $data = [];
                if (!empty($_POST['full_name']))  $data['full_name'] = $_POST['full_name'];
                if (!empty($_POST['email']))      $data['email'] = $_POST['email'];
                if (!empty($_POST['role']))        $data['role'] = $_POST['role'];
                if (isset($_POST['is_active']))    $data['is_active'] = (int)$_POST['is_active'];
                if (isset($_POST['approval_status'])) $data['approval_status'] = $_POST['approval_status'];

                if (empty($data)) {
                    $message = '<div class="msg error">No fields to update.</div>';
                } else {
                    $db->update('users', $data, 'id = ?', [$userId]);
                    $db->insert('admin_logs', [
                        'admin_id'     => $logAdminId,
                        'action'       => 'debug_edit_user',
                        'details_json' => json_encode(array_merge(['target_user_id' => $userId], $data)),
                        'ip_address'   => $_SERVER['REMOTE_ADDR'] ?? '',
                    ]);
                    $message = '<div class="msg ok">User #' . $userId . ' updated.</div>';
                }
            }
        }

        if ($action === 'create_user') {
            $name   = trim($_POST['full_name'] ?? '');
            $email  = trim($_POST['email'] ?? '');
            $pass   = $_POST['password'] ?? '';
            $role   = $_POST['role'] ?? 'respondent';

            if (!$name || !$email || strlen($pass) < 6) {
                $message = '<div class="msg error">Name, valid email, and password (min 6 chars) required.</div>';
            } elseif (!in_array($role, ['admin', 'researcher', 'respondent'], true)) {
                $message = '<div class="msg error">Invalid role.</div>';
            } elseif ($db->exists('users', 'email = ?', [$email])) {
                $message = '<div class="msg error">Email already registered.</div>';
            } else {
                $db->insert('users', [
                    'full_name'       => $name,
                    'email'           => $email,
                    'password_hash'   => password_hash($pass, PASSWORD_BCRYPT),
                    'role'            => $role,
                    'is_active'       => 1,
                    'approval_status' => 'approved',
                    'reputation_score' => 50,
                ]);
                $db->insert('admin_logs', [
                    'admin_id'     => $logAdminId,
                    'action'       => 'debug_create_user',
                    'details_json' => json_encode(['email' => $email, 'role' => $role]),
                    'ip_address'   => $_SERVER['REMOTE_ADDR'] ?? '',
                ]);
                $message = '<div class="msg ok">User <b>' . htmlspecialchars($email) . '</b> created as <b>' . $role . '</b>.</div>';
            }
        }

        if ($action === 'delete_user') {
            $userId = (int)($_POST['user_id'] ?? 0);
            if (!$userId) {
                $message = '<div class="msg error">Invalid user.</div>';
            } else {
                $user = $db->fetchOne("SELECT id, email, full_name FROM users WHERE id = ?", [$userId]);
                if (!$user) {
                    $message = '<div class="msg error">User not found.</div>';
                } else {
                    $db->delete('users', 'id = ?', [$userId]);
                    $db->insert('admin_logs', [
                        'admin_id'     => $logAdminId,
                        'action'       => 'debug_delete_user',
                        'details_json' => json_encode(['target_user_id' => $userId, 'target_email' => $user['email']]),
                        'ip_address'   => $_SERVER['REMOTE_ADDR'] ?? '',
                    ]);
                    $message = '<div class="msg ok">User <b>' . htmlspecialchars($user['full_name'] ?: $user['email']) . '</b> deleted (cascade).</div>';
                }
            }
        }
    } catch (\Throwable $e) {
        $message = '<div class="msg error">Error: ' . htmlspecialchars($e->getMessage()) . '</div>';
    }
}

// ---- Fetch users ---------------------------------------------------------
$users = $db->fetchAll("SELECT * FROM users ORDER BY created_at DESC");
$roles = ['admin', 'researcher', 'respondent'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Debug: User Management</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body { background: #f1f5f9; font-family: system-ui, sans-serif; }
.msg { padding: 12px 16px; border-radius: 10px; margin-bottom: 16px; font-size: 14px; }
.msg.ok { background: #dcfce7; color: #166534; border: 1px solid #bbf7d0; }
.msg.error { background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; }
table { width: 100%; border-collapse: collapse; font-size: 13px; }
th { text-align: left; padding: 10px 12px; background: #f8fafc; color: #475569; font-weight: 600; border-bottom: 2px solid #e2e8f0; }
td { padding: 10px 12px; border-bottom: 1px solid #f1f5f9; vertical-align: middle; }
tr:hover td { background: #f8fafc; }
.badge { display: inline-block; padding: 2px 8px; border-radius: 999px; font-size: 11px; font-weight: 600; }
.badge-admin { background: #eef2ff; color: #4338ca; }
.badge-researcher { background: #faf5ff; color: #7e22ce; }
.badge-respondent { background: #f0fdf4; color: #166534; }
.inline-form { display: none; margin-top: 8px; }
.inline-form.open { display: block; }
.inline-form input, .inline-form select { padding: 6px 10px; border: 1px solid #d1d5db; border-radius: 8px; font-size: 12px; width: 100%; box-sizing: border-box; }
.inline-form label { font-size: 11px; font-weight: 600; color: #374151; display: block; margin-bottom: 2px; }
.inline-form .field { margin-bottom: 6px; }
.btn-xs { padding: 4px 10px; border-radius: 6px; font-size: 11px; font-weight: 600; border: none; cursor: pointer; }
.btn-danger { background: #fee2e2; color: #991b1b; }
.btn-danger:hover { background: #fecaca; }
.btn-edit { background: #dbeafe; color: #1e40af; }
.btn-edit:hover { background: #bfdbfe; }
.btn-key { background: #fef3c7; color: #92400e; }
.btn-key:hover { background: #fde68a; }
</style>
</head>
<body>

<div class="max-w-7xl mx-auto px-4 py-6">

    <div class="flex items-center justify-between mb-6">
        <div>
            <h1 class="text-2xl font-bold text-gray-900"><i class="fas fa-tools text-red-500 mr-2"></i>Debug: User Management</h1>
            <p class="text-sm text-gray-500 mt-1">Password reset · Edit · Delete — no restrictions</p>
        </div>
        <span class="text-xs text-gray-400 bg-white px-3 py-1.5 rounded-full shadow-sm">
            <?= count($users) ?> user<?= count($users) !== 1 ? 's' : '' ?>
        </span>
    </div>

    <?= $message ?>

    <!-- Add User -->
    <div class="bg-white rounded-2xl shadow-sm border border-gray-200 p-5 mb-6">
        <div class="flex items-center justify-between mb-3">
            <h2 class="text-base font-bold text-gray-900"><i class="fas fa-user-plus text-green-600 mr-2"></i>Add User</h2>
        </div>
        <form method="POST" class="grid grid-cols-12 gap-3 items-end">
            <input type="hidden" name="action" value="create_user">
            <div class="col-span-3">
                <label class="text-xs font-semibold text-gray-600 block mb-1">Full Name</label>
                <input type="text" name="full_name" required
                    class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-green-500 focus:border-green-500">
            </div>
            <div class="col-span-3">
                <label class="text-xs font-semibold text-gray-600 block mb-1">Email</label>
                <input type="email" name="email" required
                    class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-green-500 focus:border-green-500">
            </div>
            <div class="col-span-2">
                <label class="text-xs font-semibold text-gray-600 block mb-1">Password</label>
                <input type="text" name="password" required minlength="6" value="test123"
                    class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-green-500 focus:border-green-500">
            </div>
            <div class="col-span-2">
                <label class="text-xs font-semibold text-gray-600 block mb-1">Role</label>
                <select name="role"
                    class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-green-500 focus:border-green-500">
                    <option value="admin">Admin</option>
                    <option value="researcher">Researcher</option>
                    <option value="respondent" selected>Respondent</option>
                </select>
            </div>
            <div class="col-span-2">
                <button type="submit"
                    class="w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 transition-all text-sm font-semibold shadow-sm">
                    <i class="fas fa-plus mr-1"></i>Add
                </button>
            </div>
        </form>
    </div>

    <!-- Users table -->
    <div class="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
        <div class="flex items-center justify-between px-5 pt-4 pb-2">
            <span class="text-sm font-semibold text-gray-700">All Users</span>
            <div class="flex items-center gap-2">
                <label class="text-xs text-gray-500">Filter:</label>
                <select id="roleFilter" onchange="filterTable()"
                    class="text-xs px-3 py-1.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500">
                    <option value="">All roles</option>
                    <option value="admin">Admin</option>
                    <option value="researcher">Researcher</option>
                    <option value="respondent">Respondent</option>
                </select>
            </div>
        </div>
        <div class="overflow-x-auto">
            <table>
                <thead>
                    <tr>
                        <th style="width:44px">ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Approval</th>
                        <th>Rep</th>
                        <th>Created</th>
                        <th style="width:220px">Actions</th>
                    </tr>
                </thead>
                <tbody id="userTableBody">
                    <?php foreach ($users as $u): ?>
                    <tr id="user-<?= $u['id'] ?>" data-role="<?= $u['role'] ?>">
                        <td class="text-gray-400 font-mono text-xs"><?= $u['id'] ?></td>
                        <td class="font-medium text-gray-900"><?= htmlspecialchars($u['full_name'] ?: '-') ?></td>
                        <td class="text-gray-600"><?= htmlspecialchars($u['email']) ?></td>
                        <td>
                            <span class="badge badge-<?= $u['role'] ?>"><?= $u['role'] ?></span>
                        </td>
                        <td><?= $u['is_active'] ? '<span class="text-green-600 text-xs font-medium">Active</span>' : '<span class="text-red-500 text-xs font-medium">Inactive</span>' ?></td>
                        <td class="text-xs text-gray-500"><?= $u['approval_status'] ?? '-' ?></td>
                        <td class="text-xs text-gray-500"><?= $u['reputation_score'] ?? '-' ?></td>
                        <td class="text-xs text-gray-400 whitespace-nowrap"><?= date('M j, Y', strtotime($u['created_at'])) ?></td>
                        <td>
                            <div class="flex flex-wrap gap-1.5">
                                <!-- Reset Password -->
                                <button onclick="toggleForm('pw-<?= $u['id'] ?>')" class="btn-xs btn-key"><i class="fas fa-key mr-1"></i>PW</button>
                                <!-- Edit -->
                                <button onclick="toggleForm('edit-<?= $u['id'] ?>')" class="btn-xs btn-edit"><i class="fas fa-pen mr-1"></i>Edit</button>
                                <!-- Delete -->
                                <form method="POST" onsubmit="return confirm('Delete <?= htmlspecialchars(addslashes($u['full_name'] ?: $u['email'])) ?>?\n\nSurveys, responses, quality data will all be removed.')" style="display:inline">
                                    <input type="hidden" name="action" value="delete_user">
                                    <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                                    <button type="submit" class="btn-xs btn-danger"><i class="fas fa-trash mr-1"></i>Del</button>
                                </form>
                            </div>

                            <!-- Inline: Reset Password -->
                            <div id="pw-<?= $u['id'] ?>" class="inline-form">
                                <form method="POST" class="flex items-end gap-2">
                                    <input type="hidden" name="action" value="reset_password">
                                    <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                                    <div class="flex-1">
                                        <label>New password</label>
                                        <input type="password" name="password" required minlength="6" placeholder="min 6 chars">
                                    </div>
                                    <div class="flex-1">
                                        <label>Confirm</label>
                                        <input type="password" name="password_confirm" required minlength="6" placeholder="repeat"
                                            oninput="this.setCustomValidity(this.value!==this.form.password.value?'Mismatch':'')">
                                    </div>
                                    <button type="submit" class="btn-xs btn-key" style="margin-bottom:0;padding:7px 14px"><i class="fas fa-check mr-1"></i>Set</button>
                                </form>
                            </div>

                            <!-- Inline: Edit User -->
                            <div id="edit-<?= $u['id'] ?>" class="inline-form">
                                <form method="POST" class="grid grid-cols-6 gap-2">
                                    <input type="hidden" name="action" value="edit_user">
                                    <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                                    <div class="col-span-2">
                                        <label>Name</label>
                                        <input type="text" name="full_name" value="<?= htmlspecialchars($u['full_name']) ?>">
                                    </div>
                                    <div class="col-span-2">
                                        <label>Email</label>
                                        <input type="email" name="email" value="<?= htmlspecialchars($u['email']) ?>">
                                    </div>
                                    <div>
                                        <label>Role</label>
                                        <select name="role">
                                            <?php foreach ($roles as $r): ?>
                                                <option value="<?= $r ?>" <?= $u['role'] === $r ? 'selected' : '' ?>><?= $r ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div>
                                        <label>Active</label>
                                        <select name="is_active">
                                            <option value="1" <?= $u['is_active'] ? 'selected' : '' ?>>Yes</option>
                                            <option value="0" <?= !$u['is_active'] ? 'selected' : '' ?>>No</option>
                                        </select>
                                    </div>
                                    <div class="col-span-6 flex gap-2">
                                        <div class="flex-1">
                                            <label>Approval</label>
                                            <select name="approval_status">
                                                <option value="approved" <?= ($u['approval_status'] ?? '') === 'approved' ? 'selected' : '' ?>>Approved</option>
                                                <option value="pending" <?= ($u['approval_status'] ?? '') === 'pending' ? 'selected' : '' ?>>Pending</option>
                                                <option value="rejected" <?= ($u['approval_status'] ?? '') === 'rejected' ? 'selected' : '' ?>>Rejected</option>
                                            </select>
                                        </div>
                                        <div class="flex items-end">
                                            <button type="submit" class="btn-xs btn-edit" style="padding:7px 14px"><i class="fas fa-save mr-1"></i>Save</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($users)): ?>
                    <tr><td colspan="9" class="text-center text-gray-400 py-8">No users found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <p class="text-xs text-red-500 mt-4 flex items-center gap-1">
        <i class="fas fa-exclamation-triangle"></i>
        This page has zero access control. Anyone who finds this URL can change any password, edit, or delete any user.
    </p>
</div>

<script>
function toggleForm(id) {
    var el = document.getElementById(id);
    if (!el) return;
    var open = el.classList.contains('open');
    document.querySelectorAll('.inline-form.open').forEach(function(f) { f.classList.remove('open'); });
    if (!open) el.classList.add('open');
}
function filterTable() {
    var val = document.getElementById('roleFilter').value;
    document.querySelectorAll('#userTableBody tr').forEach(function(tr) {
        tr.style.display = !val || tr.dataset.role === val ? '' : 'none';
    });
}
</script>

</body>
</html>
